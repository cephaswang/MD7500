package com.agopengps.drive

import android.app.AlertDialog
import android.content.Context
import android.content.res.Resources
import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.agopengps.classes.*
import com.example.agopengps.CSim
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.*
import java.util.*
import kotlin.math.*

class FormGPS : AppCompatActivity(), OnMapReadyCallback {
    companion object {
        const val MAXSECTIONS = 64
        const val MAXBOUNDARIES = 6
        const val MAXHEADS = 6
    }

    // Class properties
    private val buttonOrder = mutableListOf<Int>()
    private var btnCounter = 0
    private lateinit var flpRight: ViewGroup
    lateinit var autoSteerButton: Button
    private lateinit var btnAutoSteer: Button

    // Position and movement related properties
    var makeUTurnCounter: Int = 0
    var guidanceLineDistanceOff: Short = 0
    var guidanceLineSteerAngle: Short = 0
    var avGuidanceSteerAngle = 0.0
    var errorAngVel: Short = 0
    var setAngVel = 0.0
    var actAngVel = 0.0
    var isConstantContourOn = false
    var guidanceLookAheadTime = 2.0
    var guidanceLookPos = vec2(0.0, 0.0)
    var dualReverseDetectionDistance = 0.0

    var fixHeading = 0.0
    var camHeading = 0.0
    var smoothCamHeading = 0.0
    var gpsHeading = 10.0
    var prevGPSHeading = 0.0
    var isReverse = false
    var isSteerInReverse = true
    var isSuperSlow = false
    var startGPSHeading = 0.0
    var avgSpeed: Double = 0.0
    var previousSpeed = 0.0
    var crossTrackError = 0

    var headingFromSource = ""
    var headingFromSourceBak = ""

    var cosSectionHeading = 1.0
    var sinSectionHeading = 0.0

    var sectionTriggerDistance = 0.0
    var contourTriggerDistance = 0.0
    var sectionTriggerStepDistance = 0.0
    var gridTriggerDistance = 0.0

    var pivotAxlePos: vec3 = vec3(0.0, 0.0, 0.0)
    var steerAxlePos: vec3 = vec3(0.0, 0.0, 0.0)
    var toolPivotPos: vec3 = vec3(0.0, 0.0, 0.0)
    var toolPos: vec3 = vec3(0.0, 0.0, 0.0)
    var tankPos: vec3 = vec3(0.0, 0.0, 0.0)
    var hitchPos: vec2 = vec2(0.0, 0.0)

    var prevFix = vec2(0.0, 0.0)
    var prevJumpFix = vec2(0.0, 0.0)
    var prevDistFix = vecFix2Fix(0.0, 0.0, 0.0, 1)
    var lastReverseFix = vec2(0.0, 0.0)

    var prevSectionPos = vec2(0.0, 0.0)
    var prevContourPos = vec2(0.0, 0.0)
    var prevGridPos = vec2(0.0, 0.0)
    var patchCounter = 0
    var prevBoundaryPos = vec2(0.0, 0.0)
    var startCounter = 0

    var distancePivotToTurnLine = -2222.0
    var distanceToolToTurnLine = -2222.0
    var youTurnProgressBar = 0

    var rollCorrectionDistance = 0.0
    var imuGPS_Offset = 0.0
    var imuCorrected = 0.0

    private var currentStepFix = 0
    private val totalFixSteps = 10
    var stepFixPts = Array(totalFixSteps) { vecFix2Fix(0.0, 0.0, 0.0, 0) }
    var distanceCurrentStepFix = 0.0
    var distanceCurrentStepFixDisplay = 0.0
    var minHeadingStepDist = 1.0
    var startSpeed = 0.5
    var fixToFixHeadingDistance = 0.0
    var gpsMinimumStepDistance = 0.05

    var isChangingDirection = false
    var isReverseWithIMU = false

    private var nowHz = 0.0
    private var filteredDelta = 0.0
    private var delta = 0.0

    var isRTK_AlarmOn = false
    var isRTK_KillAutosteer = false

    var headlandDistanceDelta = 0.0
    var boundaryDistanceDelta = 0.0

    var lastGPS = vec2(0.0, 0.0)

    var uncorrectedEastingGraph = 0.0
    var correctionDistanceGraph = 0.0

    var frameTimeRough = 3.0
    var timeSliceOfLastFix = 0.0

    var isMaxAngularVelocity = false
    var minSteerSpeedTimer = 0

    private var lastLocation: Location? = null

    // State flags
    var isFirstFixPositionSet = false
    var isGPSPositionInitialized = false
    var isFirstHeadingSet = false
    var leftMouseDownOnOpenGL = false
    var flagNumberPicked = 0
    var isJobStarted = false
    var isBtnAutoSteerOn = false
    var isLidarBtnOn = true
    var isSavingFile = false
    var isSideGuideLines = false
    var isInAutoDrive = true
    var isGPSSentencesOn = false
    var isKeepOffsetsOn = false

    val secondsSinceStart: Double
        get() = SystemClock.elapsedRealtime() / 1000.0
    var gridToolSpacing = 0.0

    var frameTime = 0.0
    var gpsHz = 10.0
    var isStanleyUsed = true

    var pbarSteer = 0
    var pbarMachine = 0
    var pbarUDP = 0
    var nudNumber = 0.0

    var m2InchOrCm = 0.0
    var inchOrCm2m = 0.0
    var m2FtOrM = 0.0
    var ftOrMtoM = 0.0
    var cm2CmOrIn = 0.0
    var inOrCm2Cm = 0.0
    var unitsFtM: String? = null
    var unitsInCm: String? = null
    var unitsInCmNS: String? = null

    var hotkeys: CharArray? = null
    var filePickerFileAndDirectory: String? = null

    var GPSDataWindowLeft = 80
    var GPSDataWindowTopOffset = 220

    var fixLat: Double = 0.0 // 修正後的緯度
    var fixLon: Double = 0.0 // 修正後的經度

    // Class instances
    lateinit var camera: CCamera
    lateinit var worldGrid: CWorldGrid
    lateinit var pn: CNMEA
    lateinit var section: Array<CSection>
    val triStrip = mutableListOf<CPatches>()
    lateinit var ABLine: CABLine
    lateinit var tram: CTram
    lateinit var ct: CContour
    lateinit var trk: CTrack
    lateinit var curve: CABCurve
    lateinit var yt: CYouTurn
    lateinit var vehicle: CVehicle
    lateinit var tool: CTool
    lateinit var mc: CModuleComm
    lateinit var bnd: CBoundary
    lateinit var hdl: CHeadLine
    lateinit var sim: CSim
    lateinit var _rm: Resources
    lateinit var ahrs: CAHRS
    lateinit var recPath: CRecordedPath
    lateinit var fd: CFieldData
    lateinit var sounds: CSound
    lateinit var font: CFont
    lateinit var gyd: CGuidance
  //  lateinit var displayBrightness: CWindowsSettingsBrightnessController

    var sentenceCounter: Short = 0

    val p_239: CPGN_EF = CPGN_EF()

    // Settings and display
    lateinit var settings: SettingsData
    var currentFieldDirectory: String? = null
    var displayFieldName: String? = null

    // Colors
    var frameDayColor: Color? = null
    var frameNightColor: Color? = null
    var sectionColorDay: Color? = null
    var fieldColorDay: Color? = null
    var fieldColorNight: Color? = null
    var textColorDay: Color? = null
    var textColorNight: Color? = null

    // Vehicle appearance
    var vehicleOpacityByte: Int = 255
    var vehicleColor: Int = Color.rgb(237, 37, 39)
    var vehicleOpacity: Double = 1.0
    var isVehicleImage: Boolean = true

    // Google Maps
    lateinit var mMap: GoogleMap
    private lateinit var mapFragment: SupportMapFragment
    private var googleMap: GoogleMap? = null

    private var fileSaveCounter = 0
    val flagPts = mutableListOf<Any>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form_gps)

        initializeComponents()
        settings = SettingsData()

        // Setup Google Maps
        mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        setupPowerModeListener()

        // Initialize buttons
        btnAutoSteer = findViewById(R.id.btnAutoSteer)
        btnAutoSteer.setOnClickListener {
            println("AutoSteer button clicked")
        }

        autoSteerButton = findViewById(R.id.autoSteerButton)
        flpRight = findViewById(R.id.flpRight)

        setupAutoSteerButtonListener()
    }

    private fun setupAutoSteerButtonListener() {
        autoSteerButton.setOnClickListener {
            flpRight.addView(createAutoSteerView())
            autoSteerButton.isEnabled = false
            buttonOrder.add(0)
            btnCounter++
        }
    }

    private fun createAutoSteerView(): View {
        val autoSteerView = Button(this).apply {
            text = "Auto Steer"
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        return autoSteerView
    }

    private fun initializeComponents() {
        camera = CCamera(this)
        //worldGrid = CWorldGrid(this)
        vehicle = CVehicle(this)
      //  tool = CTool(this)

        section = Array(MAXSECTIONS) { CSection() }
        triStrip.add(CPatches(this))

        pn = CNMEA(this)
        ABLine = CABLine(this)
        ct = CContour(this)
        curve = CABCurve(this)
        trk = CTrack(this)
        hdl = CHeadLine(this)
        yt = CYouTurn(this)
        mc = CModuleComm(this)
        bnd = CBoundary(this)
        sim = CSim(this)
        ahrs = CAHRS(this)
        recPath = CRecordedPath(this)
        fd = CFieldData(this)
        tram = CTram(this)
        _rm = resources
        font = CFont(this)
        gyd = CGuidance(this)
        sounds = CSound(this)
       // displayBrightness = CWindowsSettingsBrightnessController(false)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        this.googleMap = googleMap
        setupMap()
        loadMapData()
    }

    private fun setupMap() {
        mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isCompassEnabled = true
    }

    private fun loadMapData() {
        val vehiclePosition = LatLng(pn.latitude, pn.longitude)
        mMap.addMarker(
            MarkerOptions()
                .position(vehiclePosition)
                .title("Vehicle")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.tractor_icon))
        )

        if (bnd.bndList.isNotEmpty()) {
            val polygonOptions = PolygonOptions()
            bnd.bndList.forEach { boundary ->
                boundary.points.forEach { point ->
                    polygonOptions.add(LatLng(point.latitude, point.longitude))
                }
            }
            mMap.addPolygon(polygonOptions.strokeColor(android.graphics.Color.RED))
        }

        setZoom()
    }

    private fun setupPowerModeListener() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
    }

    fun jobNew() {
        isJobStarted = true
        findViewById<View>(R.id.btnSectionMasterManual)?.isEnabled = true
        findViewById<View>(R.id.btnSectionMasterAuto)?.isEnabled = true
        findViewById<View>(R.id.btnContour)?.isEnabled = true
        findViewById<View>(R.id.btnTrack)?.isEnabled = true
        findViewById<View>(R.id.btnABDraw)?.isEnabled = true
        findViewById<View>(R.id.btnAutoSteer)?.isEnabled = true
        findViewById<View>(R.id.btnFlag)?.isEnabled = true

        ABLine.abHeading = 0.00
        fileSaveCounter = 25

        updateMapDisplay()
    }

    fun jobClose() {
        recPath.resumeState = 0
        bnd.isHeadlandOn = false

        mMap.clear()

        isJobStarted = false
        triStrip.clear()
        triStrip.add(CPatches(this))
        flagPts.clear()
        tram.tramList?.clear()
        curve.ResetCurveLine()
        trk.gArr?.clear()
        trk.idx = -1

        updateMapDisplay()
    }

    private fun updateMapDisplay() {
        mMap.clear()

        val vehiclePosition = LatLng(pn.latitude, pn.longitude)
        val heading = if (pn.headingTrueDual != 0.0) {
            pn.headingTrueDual // 優先使用雙天線朝向
        } else {
            pn.headingTrue // 否則使用單天線朝向
        }
        mMap.addMarker(
            MarkerOptions()
                .position(vehiclePosition)
                .title("Vehicle")
                .rotation(heading.toFloat()) // 使用 pn 的 heading
        )

        section.forEach { sec ->
            if (sec.isSectionOn) {
                val polygon = PolygonOptions()
                sec.points.forEach { point ->
                    polygon.add(LatLng(point.latitude, point.longitude))
                }
                mMap.addPolygon(polygon.fillColor(android.graphics.Color.argb(100, 0, 255, 0)))
            }
        }
    }

    fun setZoom() {
        val zoomLevel = when {
            camera.camSetDistance < 100 -> 18f
            camera.camSetDistance < 500 -> 15f
            camera.camSetDistance < 2000 -> 12f
            else -> 10f
        }

        gridToolSpacing = (camera.gridZoom / tool.width + 0.5).roundToInt().toDouble()
        if (gridToolSpacing < 1) gridToolSpacing = 1.0
        camera.gridZoom = gridToolSpacing * tool.width

        mMap.animateCamera(CameraUpdateFactory.zoomTo(zoomLevel))
    }

    fun updateFixPosition(location: Location) {
        val currentFix = vec2(location.longitude, location.latitude)

        val currentTime = System.currentTimeMillis()

        // 更新 fixLat 和 fixLon（這裡簡化處理，實際應根據邏輯計算）
        fixLat = location.latitude
        fixLon = location.longitude

        if (lastLocation != null) {
            timeSliceOfLastFix = (currentTime - lastLocation!!.time) / 1000.0
            nowHz = 1 / timeSliceOfLastFix
            nowHz = nowHz.coerceIn(3.0, 70.0)
        }
        lastLocation = location

        startCounter++

        if (!isGPSPositionInitialized) {
            initializeFirstFewGPSPositions(currentFix)
            return
        }

        avgSpeed = (previousSpeed * 0.9) + (location.speed * 0.1)
        previousSpeed = avgSpeed

        when (headingFromSource) {
            "Fix" -> {
                distanceCurrentStepFixDisplay = distanceBetween(prevDistFix, currentFix) * 100
                prevDistFix = vecFix2Fix(currentFix.easting, currentFix.northing, 0.0, 1)

                if (abs(avgSpeed) < 1.5 && !isFirstHeadingSet) {
                    theRest(currentFix)
                    return
                }

                if (!isFirstHeadingSet) {
                    isFirstHeadingSet = true
                    lastGPS = currentFix
                    return
                }

                if (vehicle.antennaOffset != 0.0) {
                    val corrected = correctForAntennaOffset(currentFix, fixHeading, vehicle.antennaOffset)
                    currentFix.easting = corrected.easting
                    currentFix.northing = corrected.northing
                }

                uncorrectedEastingGraph = currentFix.easting

                if (ahrs.imuRoll != 88888.0 && vehicle.antennaHeight != 0.0) {
                    rollCorrectionDistance = sin(Math.toRadians(ahrs.imuRoll)) * -vehicle.antennaHeight
                    correctionDistanceGraph = rollCorrectionDistance

                    val rollCorrected = correctForRoll(currentFix, fixHeading, rollCorrectionDistance)
                    currentFix.easting = rollCorrected.easting
                    currentFix.northing = rollCorrected.northing
                }

                distanceCurrentStepFix = distanceBetween(stepFixPts[0], currentFix)

                if (distanceCurrentStepFix < gpsMinimumStepDistance) {
                    theRest(currentFix)
                    return
                }

                val newGPSHeading = calculateHeading(stepFixPts[currentStepFix], currentFix)

                if (ahrs.imuHeading != 99999.0) {
                    // IMU heading fusion implementation...
                }

                for (i in totalFixSteps - 1 downTo 1) {
                    stepFixPts[i] = stepFixPts[i - 1]
                }
                stepFixPts[0] = vecFix2Fix(currentFix.easting, currentFix.northing, 0.0, 1)

                smoothCameraHeading(fixHeading)

                theRest(currentFix)
            }
            "VTG" -> theRest(currentFix)
            "Dual" -> theRest(currentFix)
        }

        updateAutoSteer(currentFix)
        updateYouTurn(currentFix)
        updateMapDisplay(currentFix)
    }

    private fun initializeFirstFewGPSPositions(currentFix: vec2) {
        isGPSPositionInitialized = true
    }

    private fun theRest(currentFix: vec2) {
        // Implementation...
    }

    private fun updateAutoSteer(currentFix: vec2) {
        // Implementation...
    }

    private fun updateYouTurn(currentFix: vec2) {
        // Implementation...
    }

    private fun updateMapDisplay(currentFix: vec2) {
        googleMap?.let { map ->
            val latLng = LatLng(currentFix.northing, currentFix.easting)
            // Update camera position, markers, etc.
        }
    }

    private fun distanceBetween(a: vecFix2Fix, b: vec2): Double {
        return sqrt((a.easting - b.easting).pow(2) + (a.northing - b.northing).pow(2))
    }

    private fun calculateHeading(from: vecFix2Fix, to: vec2): Double {
        return atan2(to.easting - from.easting, to.northing - from.northing).let {
            if (it < 0) it + 2 * PI else it
        }
    }

    private fun correctForAntennaOffset(position: vec2, heading: Double, offset: Double): vec2 {
        return vec2(
            cos(-heading) * offset + position.easting,
            sin(-heading) * offset + position.northing
        )
    }

    private fun correctForRoll(position: vec2, heading: Double, rollCorrection: Double): vec2 {
        return vec2(
            cos(-heading) * rollCorrection + position.easting,
            sin(-heading) * rollCorrection + position.northing
        )
    }

    private fun smoothCameraHeading(newHeading: Double) {
        var camDelta = newHeading - smoothCamHeading
        camDelta = when {
            camDelta < 0 -> camDelta + 2 * PI
            camDelta > 2 * PI -> camDelta - 2 * PI
            else -> camDelta
        }
        camDelta = when {
            camDelta >= -PI / 2 && camDelta <= PI / 2 -> camDelta * -1.0
            camDelta > PI / 2 -> 2 * PI - camDelta
            else -> (2 * PI + camDelta) * -1.0
        }
        smoothCamHeading -= camDelta * camera.camSmoothFactor
        smoothCamHeading = when {
            smoothCamHeading > 2 * PI -> smoothCamHeading - 2 * PI
            smoothCamHeading < -2 * PI -> smoothCamHeading + 2 * PI
            else -> smoothCamHeading
        }
        camHeading = Math.toDegrees(smoothCamHeading)
    }

    fun timedMessageBox(context: Context, timeout: Int, s1: String, s2: String) {
        AlertDialog.Builder(context)
            .setTitle(s1)
            .setMessage(s2)
            .setCancelable(true)
            .create()
            .apply {
                show()
                Handler(Looper.getMainLooper()).postDelayed({
                    dismiss()
                }, timeout.toLong())
            }
    }

    fun yesMessageBox(s1: String) {
        android.app.AlertDialog.Builder(this)
            .setMessage(s1)
            .setPositiveButton("OK") { _, _ -> }
            .show()
    }

    fun randomNumber(min: Double, max: Double): Double {
        return min + Random().nextDouble() * (max - min)
    }
}