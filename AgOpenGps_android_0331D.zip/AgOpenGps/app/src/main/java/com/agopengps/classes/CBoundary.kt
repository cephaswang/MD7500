package com.agopengps.classes

import android.opengl.GLES20
import com.agopengps.drive.FormGPS
import java.util.*
import kotlin.math.*
import com.agopengps.classes.*
import java.nio.FloatBuffer

class CBoundary(private val mf: FormGPS) {
    // Lists
    val bndList = mutableListOf<CBoundaryList>()
    private val bndBeingMadePts = mutableListOf<vec3>()

    // Add these OpenGL-related properties
    private val vbo = IntArray(1) // Vertex Buffer Object
    private var colorHandle = -1   // Shader color uniform location
    private var positionHandle = -1 // Shader position attribute location

    // Properties
    var createBndOffset: Double = 0.0
    var isBndBeingMade: Boolean = false
    var isDrawRightSide: Boolean = true
    var isDrawAtPivot: Boolean = true
    var isOkToAddPoints: Boolean = false
    var isRecBoundaryWhenSectionOn: Boolean = false
    var closestFenceNum: Int = 0
    var closestFencePt = vec3(-10000.0, -10000.0, 9.0)
    var isHeadlandOn: Boolean = false
    private var isToolInHeadland: Boolean = false
    private var isToolOuterPointsInHeadland: Boolean = false
    var isSectionControlledByHeadland: Boolean =
        Properties.Settings.Default.setHeadland_isSectionControlled
    private var turnSelected: Int = 0
    var closestTurnNum: Int = 0
    var iE: Double = 0.0
    var iN: Double = 0.0

    init {
        turnSelected = 0
        isHeadlandOn = false
    }

    fun isPointInsideFenceArea(testPoint: vec3): Boolean {
        if (bndList[0].fenceLineEar.isPointInPolygon(testPoint)) {
            for (i in 1 until bndList.size) {
                if (bndList[i].fenceLineEar.isPointInPolygon(testPoint)) {
                    return false
                }
            }
            return true
        }
        return false
    }

    fun isPointInsideFenceArea(testPoint: vec2): Boolean {
        if (bndList[0].fenceLineEar.isPointInPolygon(testPoint)) {
            for (i in 1 until bndList.size) {
                if (bndList[i].fenceLineEar.isPointInPolygon(testPoint)) {
                    return false
                }
            }
            return true
        }
        return false
    }


    fun drawFenceLines() {
        if (bndBeingMadePts.isEmpty()) return

        // Convert points to float array
        val vertices = FloatArray(bndBeingMadePts.size * 3)
        for (i in bndBeingMadePts.indices) {
            vertices[i * 3] = bndBeingMadePts[i].easting.toFloat()
            vertices[i * 3 + 1] = bndBeingMadePts[i].northing.toFloat()
            vertices[i * 3 + 2] = 0f
        }

        // Bind VBO and upload data
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo[0])
        GLES20.glBufferData(
            GLES20.GL_ARRAY_BUFFER, vertices.size * 4,
            FloatBuffer.wrap(vertices), GLES20.GL_STATIC_DRAW
        )

        // Draw lines
        GLES20.glUseProgram(mf.glProgram)
        GLES20.glLineWidth(mf.abLine.lineWidth.toFloat())
        GLES20.glUniform4f(colorHandle, 0.825f, 0.22f, 0.90f, 1.0f)

        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(
            positionHandle, 3, GLES20.GL_FLOAT,
            false, 0, 0
        )
        GLES20.glDrawArrays(GLES20.GL_LINE_STRIP, 0, bndBeingMadePts.size)
        GLES20.glDisableVertexAttribArray(positionHandle)
    }


    fun setHydPosition() {
        if (mf.vehicle.isHydLiftOn || mf.avgSpeed > 0.2 ||
            mf.autoBtnState == BtnStates.AUTO || !mf.isReverse
        ) {
            if (isToolInHeadland) {
                mf.p_239.pgn[mf.p_239.hydLift] = 2
                if (mf.sounds.isHydLiftChange != isToolInHeadland) {
                    if (mf.sounds.isHydLiftSoundOn) mf.sounds.playHydLiftUp()
                    mf.sounds.isHydLiftChange = isToolInHeadland
                    isToolInHeadland
                }
            } else {
                mf.p_239.pgn[mf.p_239.hydLift] = 1
                if (mf.sounds.isHydLiftChange != isToolInHeadland) {
                    if (mf.sounds.isHydLiftSoundOn) mf.sounds.playHydLiftDown()
                    mf.sounds.isHydLiftChange = isToolInHeadland
                }
            }
        }
    }

    fun whereAreToolCorners() {
        if (bndList.isNotEmpty() && bndList[0].hdLine.isNotEmpty()) {
            var isLeftInWk: Boolean
            var isRightInWk = true

            for (j in 0 until mf.tool.numOfSections) {
                isLeftInWk =
                    if (j == 0) isPointInsideHeadArea(mf.section[j].leftPoint) else isRightInWk
                isRightInWk = isPointInsideHeadArea(mf.section[j].rightPoint)

                if (j == 0) mf.tool.isLeftSideInHeadland = !isLeftInWk
                mf.section[j].isInHeadlandArea = !isLeftInWk && !isRightInWk
            }

            mf.tool.isRightSideInHeadland = !isRightInWk
            isToolOuterPointsInHeadland =
                mf.tool.isLeftSideInHeadland && mf.tool.isRightSideInHeadland
        }
    }

    fun whereAreToolLookOnPoints() {
        if (bndList.isNotEmpty() && bndList[0].hdLine.isNotEmpty()) {
            var isLookRightIn = false
            val toolFix = mf.toolPivotPos
            val sinAB = sin(toolFix.heading)
            val cosAB = cos(toolFix.heading)
            var pos = 0.0
            val mOn = (mf.tool.lookAheadDistanceOnPixelsRight -
                    mf.tool.lookAheadDistanceOnPixelsLeft) / mf.tool.rpWidth

            for (j in 0 until mf.tool.numOfSections) {
                val isLookLeftIn = if (j == 0) isPointInsideHeadArea(
                    vec2(
                        mf.section[j].leftPoint.easting + (sinAB * mf.tool.lookAheadDistanceOnPixelsLeft * 0.1),
                        mf.section[j].leftPoint.northing + (cosAB * mf.tool.lookAheadDistanceOnPixelsLeft * 0.1)
                    )
                ) else isLookRightIn

                pos += mf.section[j].rpSectionWidth
                val endHeight = (mf.tool.lookAheadDistanceOnPixelsLeft + (mOn * pos)) * 0.1

                isLookRightIn = isPointInsideHeadArea(
                    vec2(
                        mf.section[j].rightPoint.easting + (sinAB * endHeight),
                        mf.section[j].rightPoint.northing + (cosAB * endHeight)
                    )
                )

                mf.section[j].isLookOnInHeadland = !isLookLeftIn && !isLookRightIn
            }
        }
    }

    private fun isPointInsideHeadArea(pt: vec2): Boolean {
        if (bndList[0].hdLine.isPointInPolygon(pt)) {
            for (i in 1 until bndList.size) {
                if (bndList[i].hdLine.isPointInPolygon(pt)) {
                    return false
                }
            }
            return true
        }
        return false
    }

    fun isPointInsideTurnArea(pt: vec3): Int {
        if (bndList.isNotEmpty() && bndList[0].turnLine.isPointInPolygon(pt)) {
            for (i in 1 until bndList.size) {
                if (bndList[i].isDriveThru) continue
                if (bndList[i].turnLine.isPointInPolygon(pt)) {
                    return i
                }
            }
            return 0
        }
        return -1
    }

    fun buildTurnLines() {
        if (bndList.isEmpty()) {
            return
        }

        mf.fd.updateFieldBoundaryGUIAreas()
        val totalHeadWidth = mf.yt.uturnDistanceFromBoundary

        for (j in bndList.indices) {
            bndList[j].turnLine.clear()
            if (bndList[j].isDriveThru) continue

            val ptCount = bndList[j].fenceLine.size
            for (i in ptCount - 1 downTo 0) {
                val point = vec3(
                    easting = bndList[j].fenceLine[i].easting + (-sin(PI / 2 + bndList[j].fenceLine[i].heading) * totalHeadWidth),
                    northing = bndList[j].fenceLine[i].northing + (-cos(PI / 2 + bndList[j].fenceLine[i].heading) * totalHeadWidth),
                    heading = bndList[j].fenceLine[i].heading
                ).apply {
                    if (heading < -2 * PI) heading += 2 * PI
                }

                if (j == 0 == bndList[j].fenceLineEar.isPointInPolygon(point)) {
                    bndList[j].turnLine.add(vec3(point.easting, point.northing, point.heading))
                }
            }
            bndList[j].fixTurnLine(totalHeadWidth, 2)

            val cnt = bndList[j].turnLine.size
            val arr = Array(cnt) { bndList[j].turnLine[it] }
            var delta = 0.0
            bndList[j].turnLine.clear()

            for (i in arr.indices) {
                if (i == 0) {
                    bndList[j].turnLine.add(arr[i])
                    continue
                }
                delta += (arr[i - 1].heading - arr[i].heading)
                if (abs(delta) > 0.005) {
                    bndList[j].turnLine.add(arr[i])
                    delta = 0.0
                }
            }

            if (bndList[j].turnLine.isNotEmpty()) {
                bndList[j].turnLine.add(
                    vec3(
                        bndList[j].turnLine[0].easting,
                        bndList[j].turnLine[0].northing,
                        bndList[j].turnLine[0].heading
                    )
                )
            }
        }
    }
}


class Polygon {
    fun isPointInPolygon(point: vec3): Boolean = false // Placeholder
    fun isPointInPolygon(point: vec2): Boolean = false // Placeholder
    fun drawPolygon() {} // Placeholder
    fun clear() {} // Placeholder
    val size: Int get() = 0 // Placeholder
}

object Properties {
    object Settings {
        object Default {
            val setHeadland_isSectionControlled: Boolean = false
        }
    }
}

