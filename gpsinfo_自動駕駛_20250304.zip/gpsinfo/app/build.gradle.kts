plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)

}

android {
    namespace = "tw.ibiz.gpsinfo"
    compileSdk = 35

    defaultConfig {
        applicationId = "tw.ibiz.gpsinfo"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    implementation("androidx.activity:activity-compose:1.10.1")  // 或更高版本
    implementation("androidx.compose.ui:ui:1.7.8")              // 或相應版本的 Compose
    implementation("androidx.compose.material3:material3:1.3.1") // 如果需要 Material3
    implementation("androidx.compose.ui:ui-tooling:1.7.8")  // 或者使用相應的版本

   // implementation ("androidx.compose.ui:ui:1.4.0")
   // implementation ("androidx.compose.material3:material3:1.0.0")
    implementation ("androidx.compose.ui:ui-tooling-preview:1.7.8")
    //implementation ("androidx.activity:activity-compose:1.10.1")
    implementation ("androidx.core:core-ktx:1.10.0")
    implementation ("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation ("androidx.compose.foundation:foundation:1.7.8")

    implementation ("com.google.android.gms:play-services-maps:19.1.0")
    implementation ("com.google.maps.android:android-maps-utils:2.4.0")

    // Google Maps
    implementation ("com.google.android.gms:play-services-maps:19.1.0")
    implementation ("com.google.android.gms:play-services-location:21.3.0")

    // Testing
    testImplementation ("junit:junit:4.13.2")
    androidTestImplementation ("androidx.test.ext:junit:1.1.5")
    androidTestImplementation ("androidx.test.espresso:espresso-core:3.5.1")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    implementation("com.google.code.gson:gson:2.10.1")

    implementation ("com.google.maps.android:android-maps-utils:3.4.0")

   // implementation ('androidx.compose.ui:ui-tooling:1.4.0')

}