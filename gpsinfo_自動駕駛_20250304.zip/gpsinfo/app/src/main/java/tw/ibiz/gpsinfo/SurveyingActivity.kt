package tw.ibiz.gpsinfo

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.Polygon
import com.google.android.gms.maps.model.PolygonOptions
import com.google.gson.Gson
import com.google.maps.android.SphericalUtil

class SurveyingActivity : AppCompatActivity(), OnMapReadyCallback, GoogleMap.OnCameraMoveListener,
    GoogleMap.OnMarkerClickListener {

    private lateinit var map: GoogleMap
    private lateinit var dbHelper: SurveyingDBHelper
    private val points = mutableListOf<LatLng>()
    private val markers = mutableListOf<Marker>() // 用於保存地圖上的標示點
    private lateinit var tvBearing: TextView
    private lateinit var tvCenter: TextView
    private lateinit var tvZoom: TextView
    private lateinit var etDescription: EditText

    // 下方視圖相關
    private lateinit var bottomView: LinearLayout
    private lateinit var tvLatitude: TextView
    private lateinit var tvLongitude: TextView
    private lateinit var btnIncrease: Button
    private lateinit var btnDecrease: Button
    private lateinit var btnSavePoint: Button

    // 當前編輯的點
    private var currentEditingMarker: Marker? = null
    private var selectedTextView: TextView? = null // 當前選取的文字（經度或緯度）

    // 定位相關
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val LOCATION_PERMISSION_REQUEST_CODE = 1001

    // 地圖模式狀態
    private var isSatelliteMode = false

    // 宣告 Polygon 變數
    private var polygon: Polygon? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_surveying)

        dbHelper = SurveyingDBHelper(this)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        tvBearing = findViewById(R.id.tvBearing)
        tvCenter = findViewById(R.id.tvCenter)
        tvZoom = findViewById(R.id.tvZoom)
        etDescription = findViewById(R.id.etDescription)

        // 初始化下方視圖
        bottomView = findViewById(R.id.bottomView)
        tvLatitude = findViewById(R.id.tvLatitude)
        tvLongitude = findViewById(R.id.tvLongitude)
        btnIncrease = findViewById(R.id.btnIncrease)
        btnDecrease = findViewById(R.id.btnDecrease)
        btnSavePoint = findViewById(R.id.btnSavePoint)

        // 初始化 FusedLocationProviderClient
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // 繪圖按鍵
        findViewById<Button>(R.id.btnDraw).setOnClickListener {
            // 啟用地圖點擊事件
            map.setOnMapClickListener { latLng ->
                addPoint(latLng)
            }
            Log.d("DrawMode", "繪圖模式已啟用")
        }

        // 保存按鍵
        findViewById<Button>(R.id.btnSave).setOnClickListener {
            if (points.size >= 3) {
                // 清除原有連線
                //   map.clear()
                //  markers.forEach { it.remove() }
                //  markers.clear()

                // 清除舊的 Polygon
                polygon?.remove()

                // 連線所有點形成一個封閉區域
                val polygonOptions = PolygonOptions().addAll(points)
                polygon = map.addPolygon(polygonOptions)

                // 計算封閉區域面積（平方公尺）
                val areaSqm = SphericalUtil.computeArea(points)
                // 換算為坪
                val areaPing = areaSqm * 0.3025
                // 換算為分地
                val areaFen = areaPing / 293.4

                // 保存到資料庫
                val description = etDescription.text.toString()
                val zoom = map.cameraPosition.zoom
                val center = map.cameraPosition.target
                val bearing = map.cameraPosition.bearing

                val id = dbHelper.insertSurveyingData(
                    points,
                    description,
                    zoom,
                    center,
                    bearing,
                    areaSqm,
                    areaPing,
                    areaFen
                )
                if (id != -1L) {
                    Toast.makeText(this, "資料保存成功", Toast.LENGTH_SHORT).show()
                    Log.d(
                        "SaveData", """
                        SQL 指令：
                        INSERT INTO Surveying (coordinates, description, created_at, zoom, center, bearing, area_sqm, area_ping, area_fen)
                        VALUES (
                            '${Gson().toJson(points)}',
                            '$description',
                            '${System.currentTimeMillis()}',
                            $zoom,
                            '${Gson().toJson(center)}',
                            $bearing,
                            $areaSqm,
                            $areaPing,
                            $areaFen
                        )
                    """.trimIndent()
                    )
                } else {
                    Toast.makeText(this, "資料保存失敗", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "至少需要 3 個點才能形成封閉區域", Toast.LENGTH_SHORT).show()
            }
        }

        // 清除按鍵
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            points.clear()
            markers.forEach { it.remove() } // 清除所有標示點
            markers.clear()
            map.clear()
            etDescription.text.clear()
            Log.d("Clear", "清除所有點、線和輸入框內容")
        }

        // 刪除按鍵
        findViewById<Button>(R.id.btnDelete).setOnClickListener {
            if (points.isNotEmpty()) {
                // 移除最後一個點
                points.removeAt(points.size - 1)
                // 移除最後一個標示點
                markers.lastOrNull()?.remove()
                markers.removeLastOrNull()
                Log.d("Delete", "刪除上一個點")
            } else {
                Toast.makeText(this, "沒有點可以刪除", Toast.LENGTH_SHORT).show()
            }
        }

        // 模式按鍵
        findViewById<Button>(R.id.btnMode).setOnClickListener {
            toggleMapMode()
        }

        // 增加按鍵
        btnIncrease.setOnClickListener {
            adjustPoint(0.0000002) // 增加 0.5 公分（約 0.000005 度）
        }

        // 減少按鍵
        btnDecrease.setOnClickListener {
            adjustPoint(-0.0000002) // 減少 0.5 公分（約 -0.000005 度）
        }

        // 保存按鍵
        btnSavePoint.setOnClickListener {
            savePoint()
        }

        // 緯度文字點擊事件
        tvLatitude.setOnClickListener {
            selectTextView(tvLatitude)
        }

        // 經度文字點擊事件
        tvLongitude.setOnClickListener {
            selectTextView(tvLongitude)
        }
    }

    @SuppressLint("PotentialBehaviorOverride")
    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.setOnCameraMoveListener(this)
        map.uiSettings.isZoomControlsEnabled = true
        map.uiSettings.isRotateGesturesEnabled = true
        map.setOnMarkerClickListener(this) // 設置標示點點擊事件

        // 檢查定位權限
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            enableMyLocation()
        } else {
            // 請求定位權限
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        }
    }

    @SuppressLint("SetTextI18n")
    override fun onCameraMove() {
        tvBearing.text = "地圖傾角: ${map.cameraPosition.bearing}"
        tvCenter.text = "地圖中心點: ${map.cameraPosition.target}"
        tvZoom.text = "地圖縮放比: ${map.cameraPosition.zoom}"
    }

    // 標示點點擊事件
    @SuppressLint("SetTextI18n")
    override fun onMarkerClick(marker: Marker): Boolean {
        // 顯示下方視圖
        bottomView.visibility = View.VISIBLE
        // 設置當前編輯的標示點
        currentEditingMarker = marker
        // 更新文字的值
        tvLatitude.text = "緯度: ${marker.position.latitude}"
        tvLongitude.text = "經度: ${marker.position.longitude}"
        // 預設選取經度文字
        selectTextView(tvLongitude)
        return true // 返回 true 表示事件已處理
    }

    // 新增點
    private fun addPoint(latLng: LatLng) {
        // 在地圖上放置標示圖
        val marker = map.addMarker(MarkerOptions().position(latLng).title("N${points.size + 1}"))
        marker?.let {
            points.add(latLng)
            markers.add(it)
        }
    }

    // 調整點的座標
    @SuppressLint("SetTextI18n")
    private fun adjustPoint(delta: Double) {
        currentEditingMarker?.let { marker ->
            val latLng = marker.position
            val newLatLng = when (selectedTextView) {
                tvLatitude -> LatLng(latLng.latitude + delta, latLng.longitude)
                tvLongitude -> LatLng(latLng.latitude, latLng.longitude + delta)
                else -> return
            }
            marker.position = newLatLng
            // 更新文字的值
            tvLatitude.text = "緯度: ${newLatLng.latitude}"
            tvLongitude.text = "經度: ${newLatLng.longitude}"
        }
    }

    // 保存點的座標
    private fun savePoint() {
        currentEditingMarker?.let { marker ->
            // 更新點的座標
            val index = markers.indexOf(marker)
            if (index != -1) {
                points[index] = marker.position
            }
            // 關閉下方視圖
            bottomView.visibility = View.GONE
            // 清除當前編輯的標示點
            currentEditingMarker = null
            Log.d(
                "SavePoint",
                "更新點座標：(${marker.position.latitude}, ${marker.position.longitude})"
            )
        }
    }

    // 選取文字
    private fun selectTextView(textView: TextView) {
        // 清除之前選取的文字底色
        selectedTextView?.setBackgroundColor(Color.TRANSPARENT)
        // 設置當前選取的文字
        selectedTextView = textView
        // 設置選取文字的底色
        textView.setBackgroundColor(Color.GREEN)
    }

    // 啟用定位功能
    private fun enableMyLocation() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            map.isMyLocationEnabled = true
            // 獲取當前位置
            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                location?.let {
                    val currentLatLng = LatLng(it.latitude, it.longitude)
                    map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15f))
                }
            }
        }
    }

    // 處理權限請求結果
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableMyLocation()
            } else {
                Toast.makeText(this, "需要定位權限以顯示當前位置", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // 切換地圖模式
    private fun toggleMapMode() {
        if (isSatelliteMode) {
            // 切換到普通模式
            map.mapType = GoogleMap.MAP_TYPE_NORMAL
            isSatelliteMode = false
            Log.d("MapMode", "當前模式：普通模式")
        } else {
            // 切換到衛星模式
            map.mapType = GoogleMap.MAP_TYPE_SATELLITE
            isSatelliteMode = true
            Log.d("MapMode", "當前模式：衛星模式")
        }
    }
}