﻿using System;
using System.Windows.Forms;
using System.Globalization;
using System.Drawing;
/* 
 * 
 * 
 * Special thanks to Ray Bear for pounding out the original program
 * for keys.
 * 
 */
namespace Keypad
{
    public partial class Keyboard : GenericKeypad
    {
        private string currentLanguage = "en"; // Default to English
        public Keyboard()
        {
            InitializeComponent();
        }
        private void Keyboard_Load(object sender, EventArgs e)
        {
            currentLanguage = "en-US"; // Set default language to English
            CultureInfo.CurrentCulture = new CultureInfo("en-US");
            btn_lang.Text = "EN";
            chk_shift.Checked = false;
            //  Console.WriteLine("Keyboard_Load started");
            // UpdateButtonVisibility(currentLanguage);
            /// Console.WriteLine("UpdateButtonVisibility completed");
            changeCase();
            //  Console.WriteLine("changeCase completed");
            tableLayoutPanel.Invalidate(); // 強制重繪佈局
            this.Invalidate(); // 強制重繪表單
            this.Refresh();
        }



        private void UpdateLanguageMenuCheckState()
        {
            englishMenuItem.Checked = currentLanguage == "en-US";
            germanMenuItem.Checked = currentLanguage == "de";
            frenchMenuItem.Checked = currentLanguage == "fr";
            japaneseMenuItem.Checked = currentLanguage == "ja";
            koreanMenuItem.Checked = currentLanguage == "ko";
        //    vietnameseMenuItem.Checked = currentLanguage == "vi";  // 新增
            thaiMenuItem.Checked = currentLanguage == "th";        // 新增
            indonesianMenuItem.Checked = currentLanguage == "id";  // 新增
            ukrainianMenuItem.Checked = currentLanguage == "uk";   // 新增
            russianMenuItem.Checked = currentLanguage == "ru";     // 新增
            spanishMenuItem.Checked = currentLanguage == "es";     // 新增
            portugueseMenuItem.Checked = currentLanguage == "pt";  // 新增
        }




        private void EnglishMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "en-US";
            btn_lang.Text = "EN";
            CultureInfo.CurrentCulture = new CultureInfo("en-US"); // 使用 "en-US" 確保文化設置有效
            changeCase();
            UpdateLanguageMenuCheckState();
        }
        private void Chk_shift_CheckedChanged(object sender, EventArgs e)
        {
            changeCase();
        }



        private void Btn_lang_Click(object sender, EventArgs e)
        {
            langMenuStrip.Show(btn_lang, new System.Drawing.Point(0, btn_lang.Height));

            englishMenuItem.Click -= EnglishMenuItem_Click;
            englishMenuItem.Click += EnglishMenuItem_Click;
            germanMenuItem.Click -= GermanMenuItem_Click;
            germanMenuItem.Click += GermanMenuItem_Click;
            frenchMenuItem.Click -= FrenchMenuItem_Click;
            frenchMenuItem.Click += FrenchMenuItem_Click;
            japaneseMenuItem.Click -= JapaneseMenuItem_Click;
            japaneseMenuItem.Click += JapaneseMenuItem_Click;
            koreanMenuItem.Click -= KoreanMenuItem_Click;
            koreanMenuItem.Click += KoreanMenuItem_Click;
            vietnameseMenuItem.Click -= VietnameseMenuItem_Click;  // 新增
            vietnameseMenuItem.Click += VietnameseMenuItem_Click;
            thaiMenuItem.Click -= ThaiMenuItem_Click;              // 新增
            thaiMenuItem.Click += ThaiMenuItem_Click;
            indonesianMenuItem.Click -= IndonesianMenuItem_Click;  // 新增
            indonesianMenuItem.Click += IndonesianMenuItem_Click;
            ukrainianMenuItem.Click -= UkrainianMenuItem_Click;    // 新增
            ukrainianMenuItem.Click += UkrainianMenuItem_Click;
            russianMenuItem.Click -= RussianMenuItem_Click;        // 新增
            russianMenuItem.Click += RussianMenuItem_Click;
            spanishMenuItem.Click -= SpanishMenuItem_Click;        // 新增
            spanishMenuItem.Click += SpanishMenuItem_Click;
            portugueseMenuItem.Click -= PortugueseMenuItem_Click;  // 新增
            portugueseMenuItem.Click += PortugueseMenuItem_Click;

            UpdateLanguageMenuCheckState();
        }



        private void VietnameseMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "vi";
            btn_lang.Text = "VI";
            CultureInfo.CurrentCulture = new CultureInfo("vi");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void ThaiMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "th";
            btn_lang.Text = "TH";
            CultureInfo.CurrentCulture = new CultureInfo("th");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void IndonesianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "id";
            btn_lang.Text = "ID";
            CultureInfo.CurrentCulture = new CultureInfo("id");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void UkrainianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "uk";
            btn_lang.Text = "UK";
            CultureInfo.CurrentCulture = new CultureInfo("uk");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void RussianMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ru";
            btn_lang.Text = "RU";
            CultureInfo.CurrentCulture = new CultureInfo("ru");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void SpanishMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "es";
            btn_lang.Text = "ES";
            CultureInfo.CurrentCulture = new CultureInfo("es");
            changeCase();
            UpdateLanguageMenuCheckState();
        }

        private void PortugueseMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "pt";
            btn_lang.Text = "PT";
            CultureInfo.CurrentCulture = new CultureInfo("pt");
            changeCase();
            UpdateLanguageMenuCheckState();
        }


        private void UpdateButtonFont(string language)
        {
            Font newFont;
            try
            {
                switch (language)
                {
                    case "ja":
                        newFont = new Font("MS Gothic", 24F, FontStyle.Bold);
                        break;
                    case "ko":
                        newFont = new Font("Malgun Gothic", 24F, FontStyle.Bold);
                        break;
                    case "vi":  // 越南語
                        newFont = new Font("Arial", 24F, FontStyle.Bold);  // 越南語使用拉丁字母
                        break;
                    case "th":  // 泰語
                        newFont = new Font("Tahoma", 24F, FontStyle.Bold);  // Windows 上 Tahoma 支持泰文
                        break;
                    case "id":  // 印尼語
                        newFont = new Font("Arial", 24F, FontStyle.Bold);  // 印尼語使用拉丁字母
                        break;
                    case "uk":  // 烏克蘭語
                        newFont = new Font("Arial", 24F, FontStyle.Bold);  // 支援西里爾字母
                        break;
                    case "ru":  // 俄語
                        newFont = new Font("Arial", 24F, FontStyle.Bold);  // 支援西里爾字母
                        break;
                    case "es":  // 西班牙語
                        newFont = new Font("Arial", 24F, FontStyle.Bold);  // 拉丁字母
                        break;
                    case "pt":  // 葡萄牙語
                        newFont = new Font("Arial", 24F, FontStyle.Bold);  // 拉丁字母
                        break;
                    default:
                        newFont = new Font("Tahoma", 24F, FontStyle.Bold);
                        break;
                }
            }
            catch
            {
                newFont = new Font("Arial", 24F, FontStyle.Bold); // 後備字型
            }

            foreach (Control control in tableLayoutPanel.Controls)
            {
                if (control is Button btn)
                {
                    btn.Font = newFont;
                }
            }
        }




        private void JapaneseMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ja";
            btn_lang.Text = "JA";
            CultureInfo.CurrentCulture = new CultureInfo("ja");
            changeCase();
        }
        private void KoreanMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "ko";
            btn_lang.Text = "KO";
            CultureInfo.CurrentCulture = new CultureInfo("ko");
            changeCase();
        }
        private void GermanMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "de";
            btn_lang.Text = "DE";
            CultureInfo.CurrentCulture = new CultureInfo("de");
            changeCase();
        }
        private void FrenchMenuItem_Click(object sender, EventArgs e)
        {
            currentLanguage = "fr";
            btn_lang.Text = "FR";
            CultureInfo.CurrentCulture = new CultureInfo("fr");
            changeCase();
        }
        private void SendChar(Button senderb)
        {
            Button btn = (Button)senderb;
            RaiseButtonPressed(btn.Text[0]);
            //if (chk_shift.Checked) chk_shift.Checked = false;
        }
        private void BtnClick(object sender, EventArgs e)
        {
            SendChar((Button)sender);
        }



        private void changeCase()
        {
            // 先更新字型
            UpdateButtonFont(CultureInfo.CurrentCulture.Name);


            // 更新按鍵可見性
            UpdateButtonVisibility(CultureInfo.CurrentCulture.Name);

            switch (CultureInfo.CurrentCulture.Name)
            {



                case "fr":



                case "de": // -------------------------------------------Deutsch
                    if (chk_shift.Checked == true)
                    {
                        a1.Text = "!";
                        a2.Text = "@";
                        a3.Text = "#";
                        a4.Text = "$";
                        a5.Text = "%";
                        a6.Text = "^";
                        a7.Text = "&&";
                        a8.Text = "*";
                        a9.Text = "(";
                        a10.Text = ")";
                        a11.Text = "\u00DF";
                        c1.Text = "?";
                        c2.Text = "Q";
                        c3.Text = "W";
                        c4.Text = "E";
                        c5.Text = "R";
                        c6.Text = "T";
                        c7.Text = "Z";
                        c8.Text = "U";
                        c9.Text = "I";
                        c10.Text = "O";
                        c11.Text = "P";
                        c12.Text = "\u00DC";

                        d1.Text = "-";
                        d2.Text = "A";
                        d3.Text = "S";
                        d4.Text = "D";
                        d5.Text = "F";
                        d6.Text = "G";
                        d7.Text = "H";
                        d8.Text = "J";
                        d9.Text = "K";
                        d10.Text = "L";
                        d11.Text = "\u00D6";
                        d12.Text = "\u00C4";
                        e1.Text = "~";
                        e2.Text = "+";
                        e3.Text = "Y";
                        e4.Text = "X";
                        e5.Text = "C";
                        e6.Text = "V";
                        e7.Text = "B";
                        e8.Text = "N";
                        e9.Text = "M";
                        e10.Text = "<";
                        e11.Text = ">";
                        e12.Text = ":";
                        btnApos.Text = "\u0060";
                    }
                    else
                    {
                        c1.Text = "/";
                        c2.Text = "q";
                        c3.Text = "w";
                        c4.Text = "e";
                        c5.Text = "r";
                        c6.Text = "t";
                        c7.Text = "z";
                        c8.Text = "u";
                        c9.Text = "i";
                        c10.Text = "o";
                        c11.Text = "p";
                        c12.Text = "\u00FC";
                        d1.Text = "_";
                        d2.Text = "a";
                        d3.Text = "s";
                        d4.Text = "d";
                        d5.Text = "f";
                        d6.Text = "g";
                        d7.Text = "h";
                        d8.Text = "j";
                        d9.Text = "k";
                        d10.Text = "l";
                        d11.Text = "\u00F6";
                        d12.Text = "\u00E4";
                        e1.Text = "|";
                        e2.Text = "=";
                        e3.Text = "y";
                        e4.Text = "x";
                        e5.Text = "c";
                        e6.Text = "v";
                        e7.Text = "b";
                        e8.Text = "n";
                        e9.Text = "m";
                        e10.Text = ",";
                        e11.Text = ".";
                        e12.Text = ";";
                        a1.Text = "1";
                        a2.Text = "2";
                        a3.Text = "3";
                        a4.Text = "4";
                        a5.Text = "5";
                        a6.Text = "6";
                        a7.Text = "7";
                        a8.Text = "8";
                        a9.Text = "9";
                        a10.Text = "0";
                        a11.Text = "\u00DF";
                        btnApos.Text = "\u00B4";
                    }
                    break;



                // Add Japanese and Korean cases to the changeCase() method
                case "ja": // Japanese
                    if (chk_shift.Checked == true)
                    {
                        a1.Text = "！";
                        a2.Text = "＠";
                        a3.Text = "＃";
                        a4.Text = "＄";
                        a5.Text = "％";
                        a6.Text = "＾";
                        a7.Text = "＆";
                        a8.Text = "＊";
                        a9.Text = "（";
                        a10.Text = "）";
                        a11.Text = "＋";
                        c1.Text = "？";
                        c2.Text = "Q";
                        c3.Text = "W";
                        c4.Text = "E";
                        c5.Text = "R";
                        c6.Text = "T";
                        c7.Text = "Y";
                        c8.Text = "U";
                        c9.Text = "I";
                        c10.Text = "O";
                        c11.Text = "P";
                        d1.Text = "｜";
                        d2.Text = "A";
                        d3.Text = "S";
                        d4.Text = "D";
                        d5.Text = "F";
                        d6.Text = "G";
                        d7.Text = "H";
                        d8.Text = "J";
                        d9.Text = "K";
                        d10.Text = "L";
                        e1.Text = "「";
                        e2.Text = "」";
                        e3.Text = "Z";
                        e4.Text = "X";
                        e5.Text = "C";
                        e6.Text = "V";
                        e7.Text = "B";
                        e8.Text = "N";
                        e9.Text = "M";
                        e10.Text = "＜";
                        e11.Text = "＞";
                        e12.Text = "：";
                        btnApos.Text = "＠";
                    }
                    else
                    {
                        a1.Text = "1";
                        a2.Text = "2";
                        a3.Text = "3";
                        a4.Text = "4";
                        a5.Text = "5";
                        a6.Text = "6";
                        a7.Text = "7";
                        a8.Text = "8";
                        a9.Text = "9";
                        a10.Text = "0";
                        a11.Text = "＝";
                        c1.Text = "／";
                        c2.Text = "q";
                        c3.Text = "w";
                        c4.Text = "e";
                        c5.Text = "r";
                        c6.Text = "t";
                        c7.Text = "y";
                        c8.Text = "u";
                        c9.Text = "i";
                        c10.Text = "o";
                        c11.Text = "p";
                        d1.Text = "～";
                        d2.Text = "a";
                        d3.Text = "s";
                        d4.Text = "d";
                        d5.Text = "f";
                        d6.Text = "g";
                        d7.Text = "h";
                        d8.Text = "j";
                        d9.Text = "k";
                        d10.Text = "l";
                        e1.Text = "『";
                        e2.Text = "』";
                        e3.Text = "z";
                        e4.Text = "x";
                        e5.Text = "c";
                        e6.Text = "v";
                        e7.Text = "b";
                        e8.Text = "n";
                        e9.Text = "m";
                        e10.Text = "、";
                        e11.Text = "。";
                        e12.Text = "；";
                        btnApos.Text = "・";
                    }
                    break;



                case "ko": // Korean
                    if (chk_shift.Checked == true)
                    {
                        a1.Text = "!";
                        a2.Text = "@";
                        a3.Text = "#";
                        a4.Text = "$";
                        a5.Text = "%";
                        a6.Text = "^";
                        a7.Text = "&";
                        a8.Text = "*";
                        a9.Text = "(";
                        a10.Text = ")";
                        a11.Text = "+";
                        c1.Text = "?";
                        c2.Text = "ㅃ"; // Double consonants or shifted characters
                        c3.Text = "ㅉ";
                        c4.Text = "ㄸ";
                        c5.Text = "ㄲ";
                        c6.Text = "ㅆ";
                        c7.Text = "ㅒ";
                        c8.Text = "ㅖ";
                        c9.Text = "ㅋ";
                        c10.Text = "ㅌ";
                        c11.Text = "ㅍ";
                        d1.Text = "|";
                        d2.Text = "ㅁ";
                        d3.Text = "ㄴ";
                        d4.Text = "ㅇ";
                        d5.Text = "ㄹ";
                        d6.Text = "ㅎ";
                        d7.Text = "ㅗ";
                        d8.Text = "ㅓ";
                        d9.Text = "ㅏ";
                        d10.Text = "ㅣ";
                        e1.Text = "「";
                        e2.Text = "」";
                        e3.Text = "ㅋ";
                        e4.Text = "ㅌ";
                        e5.Text = "ㅊ";
                        e6.Text = "ㅍ";
                        e7.Text = "ㅠ";
                        e8.Text = "ㅜ";
                        e9.Text = "ㅡ";
                        e10.Text = "<";
                        e11.Text = ">";
                        e12.Text = ":";
                        btnApos.Text = "＠";
                    }
                    else
                    {
                        a1.Text = "1";
                        a2.Text = "2";
                        a3.Text = "3";
                        a4.Text = "4";
                        a5.Text = "5";
                        a6.Text = "6";
                        a7.Text = "7";
                        a8.Text = "8";
                        a9.Text = "9";
                        a10.Text = "0";
                        a11.Text = "=";
                        c1.Text = "/";
                        c2.Text = "ㅂ";
                        c3.Text = "ㅈ";
                        c4.Text = "ㄷ";
                        c5.Text = "ㄱ";
                        c6.Text = "ㅅ";
                        c7.Text = "ㅛ";
                        c8.Text = "ㅕ";
                        c9.Text = "ㅑ";
                        c10.Text = "ㅐ";
                        c11.Text = "ㅔ";
                        d1.Text = "~";
                        d2.Text = "ㅁ";
                        d3.Text = "ㄴ";
                        d4.Text = "ㅇ";
                        d5.Text = "ㄹ";
                        d6.Text = "ㅎ";
                        d7.Text = "ㅗ";
                        d8.Text = "ㅓ";
                        d9.Text = "ㅏ";
                        d10.Text = "ㅣ";
                        e1.Text = "『";
                        e2.Text = "』";
                        e3.Text = "ㅋ";
                        e4.Text = "ㅌ";
                        e5.Text = "ㅊ";
                        e6.Text = "ㅍ";
                        e7.Text = "ㅠ";
                        e8.Text = "ㅜ";
                        e9.Text = "ㅡ";
                        e10.Text = "、";
                        e11.Text = "。";
                        e12.Text = "；";
                        btnApos.Text = "·";
                    }
                    break;



                // 現有語言的 case 保持不變，這裡僅添加新語言
                case "vi": // 越南語 (使用拉丁字母，含變音符號)
                    if (chk_shift.Checked == true)
                    {
                        a1.Text = "!"; a2.Text = "@"; a3.Text = "#"; a4.Text = "$"; a5.Text = "%";
                        a6.Text = "^"; a7.Text = "&"; a8.Text = "*"; a9.Text = "("; a10.Text = ")";
                        a11.Text = "+"; c1.Text = "?"; c2.Text = "Q"; c3.Text = "W"; c4.Text = "E";
                        c5.Text = "R"; c6.Text = "T"; c7.Text = "Y"; c8.Text = "U"; c9.Text = "I";
                        c10.Text = "O"; c11.Text = "P"; d1.Text = "Ă"; d2.Text = "A"; d3.Text = "S";
                        d4.Text = "D"; d5.Text = "F"; d6.Text = "G"; d7.Text = "H"; d8.Text = "J";
                        d9.Text = "K"; d10.Text = "L"; e1.Text = "{"; e2.Text = "}"; e3.Text = "Z";
                        e4.Text = "X"; e5.Text = "C"; e6.Text = "V"; e7.Text = "B"; e8.Text = "N";
                        e9.Text = "M"; e10.Text = "<"; e11.Text = ">"; e12.Text = ":"; btnApos.Text = "Đ";
                    }
                    else
                    {
                        a1.Text = "1"; a2.Text = "2"; a3.Text = "3"; a4.Text = "4"; a5.Text = "5";
                        a6.Text = "6"; a7.Text = "7"; a8.Text = "8"; a9.Text = "9"; a10.Text = "0";
                        a11.Text = "="; c1.Text = "/"; c2.Text = "q"; c3.Text = "w"; c4.Text = "e";
                        c5.Text = "r"; c6.Text = "t"; c7.Text = "y"; c8.Text = "u"; c9.Text = "i";
                        c10.Text = "o"; c11.Text = "p"; d1.Text = "ă"; d2.Text = "a"; d3.Text = "s";
                        d4.Text = "d"; d5.Text = "f"; d6.Text = "g"; d7.Text = "h"; d8.Text = "j";
                        d9.Text = "k"; d10.Text = "l"; e1.Text = "["; e2.Text = "]"; e3.Text = "z";
                        e4.Text = "x"; e5.Text = "c"; e6.Text = "v"; e7.Text = "b"; e8.Text = "n";
                        e9.Text = "m"; e10.Text = ","; e11.Text = "."; e12.Text = ";"; btnApos.Text = "đ";
                    }
                    break;



                case "th": // 泰語 (簡單映射，實際需更多按鍵支援泰文字母)
                    if (chk_shift.Checked == true)
                    {
                        a1.Text = "!"; a2.Text = "@"; a3.Text = "#"; a4.Text = "$"; a5.Text = "%";
                        a6.Text = "^"; a7.Text = "&"; a8.Text = "*"; a9.Text = "("; a10.Text = ")";
                        a11.Text = "+"; c1.Text = "?"; c2.Text = "ภ"; c3.Text = "ถ"; c4.Text = "ุ";
                        c5.Text = "ึ"; c6.Text = "ค"; c7.Text = "ต"; c8.Text = "จ"; c9.Text = "ข";
                        c10.Text = "ช"; c11.Text = " "; d1.Text = "ๆ"; d2.Text = "ไ"; d3.Text = "ำ";
                        d4.Text = "พ"; d5.Text = "ะ"; d6.Text = "ั"; d7.Text = "ี"; d8.Text = "ร";
                        d9.Text = "น"; d10.Text = "ย"; e1.Text = "{"; e2.Text = "}"; e3.Text = "บ";
                        e4.Text = "ล"; e5.Text = "ฟ"; e6.Text = "ห"; e7.Text = "ก"; e8.Text = "ด";
                        e9.Text = "เ"; e10.Text = "<"; e11.Text = ">"; e12.Text = ":"; btnApos.Text = "฿";
                    }
                    else
                    {
                        a1.Text = "1"; a2.Text = "2"; a3.Text = "3"; a4.Text = "4"; a5.Text = "5";
                        a6.Text = "6"; a7.Text = "7"; a8.Text = "8"; a9.Text = "9"; a10.Text = "0";
                        a11.Text = "="; c1.Text = "/"; c2.Text = "ผ"; c3.Text = "ป"; c4.Text = "แ";
                        c5.Text = "อ"; c6.Text = "ิ"; c7.Text = "ื"; c8.Text = "ท"; c9.Text = "ม";
                        c10.Text = "ใ"; c11.Text = "ฝ"; d1.Text = "ฃ"; d2.Text = "บ"; d3.Text = "ต";
                        d4.Text = "ถ"; d5.Text = "ุ"; d6.Text = "ึ"; d7.Text = "ค"; d8.Text = "ฏ";
                        d9.Text = "ช"; d10.Text = "ซ"; e1.Text = "["; e2.Text = "]"; e3.Text = "ง";
                        e4.Text = "จ"; e5.Text = "ฉ"; e6.Text = "ฮ"; e7.Text = "ฎ"; e8.Text = "ฑ";
                        e9.Text = "ธ"; e10.Text = ","; e11.Text = "."; e12.Text = ";"; btnApos.Text = "฿";
                    }
                    break;



                case "id": // 印尼語 (使用拉丁字母，與英文相似)
                    if (chk_shift.Checked == true)
                    {
                        a1.Text = "!"; a2.Text = "@"; a3.Text = "#"; a4.Text = "$"; a5.Text = "%";
                        a6.Text = "^"; a7.Text = "&"; a8.Text = "*"; a9.Text = "("; a10.Text = ")";
                        a11.Text = "+"; c1.Text = "?"; c2.Text = "Q"; c3.Text = "W"; c4.Text = "E";
                        c5.Text = "R"; c6.Text = "T"; c7.Text = "Y"; c8.Text = "U"; c9.Text = "I";
                        c10.Text = "O"; c11.Text = "P"; d1.Text = "|"; d2.Text = "A"; d3.Text = "S";
                        d4.Text = "D"; d5.Text = "F"; d6.Text = "G"; d7.Text = "H"; d8.Text = "J";
                        d9.Text = "K"; d10.Text = "L"; e1.Text = "{"; e2.Text = "}"; e3.Text = "Z";
                        e4.Text = "X"; e5.Text = "C"; e6.Text = "V"; e7.Text = "B"; e8.Text = "N";
                        e9.Text = "M"; e10.Text = "<"; e11.Text = ">"; e12.Text = ":"; btnApos.Text = "'";
                    }
                    else
                    {
                        a1.Text = "1"; a2.Text = "2"; a3.Text = "3"; a4.Text = "4"; a5.Text = "5";
                        a6.Text = "6"; a7.Text = "7"; a8.Text = "8"; a9.Text = "9"; a10.Text = "0";
                        a11.Text = "="; c1.Text = "/"; c2.Text = "q"; c3.Text = "w"; c4.Text = "e";
                        c5.Text = "r"; c6.Text = "t"; c7.Text = "y"; c8.Text = "u"; c9.Text = "i";
                        c10.Text = "o"; c11.Text = "p"; d1.Text = "~"; d2.Text = "a"; d3.Text = "s";
                        d4.Text = "d"; d5.Text = "f"; d6.Text = "g"; d7.Text = "h"; d8.Text = "j";
                        d9.Text = "k"; d10.Text = "l"; e1.Text = "["; e2.Text = "]"; e3.Text = "z";
                        e4.Text = "x"; e5.Text = "c"; e6.Text = "v"; e7.Text = "b"; e8.Text = "n";
                        e9.Text = "m"; e10.Text = ","; e11.Text = "."; e12.Text = ";"; btnApos.Text = "'";
                    }
                    break;



                case "uk": // 烏克蘭語 (使用西里爾字母)
                    if (chk_shift.Checked == true)
                    {
                        a1.Text = "!"; a2.Text = "@"; a3.Text = "#"; a4.Text = "$"; a5.Text = "%";
                        a6.Text = "^"; a7.Text = "&"; a8.Text = "*"; a9.Text = "("; a10.Text = ")";
                        a11.Text = "+"; c1.Text = "?"; c2.Text = "Й"; c3.Text = "Ц"; c4.Text = "У";
                        c5.Text = "К"; c6.Text = "Е"; c7.Text = "Н"; c8.Text = "Г"; c9.Text = "Ш";
                        c10.Text = "Щ"; c11.Text = "З"; d1.Text = "|"; d2.Text = "Ф"; d3.Text = "И";
                        d4.Text = "В"; d5.Text = "А"; d6.Text = "П"; d7.Text = "Р"; d8.Text = "О";
                        d9.Text = "Л"; d10.Text = "Д"; e1.Text = "{"; e2.Text = "}"; e3.Text = "Я";
                        e4.Text = "Ч"; e5.Text = "С"; e6.Text = "М"; e7.Text = "И"; e8.Text = "Т";
                        e9.Text = "Ь"; e10.Text = "<"; e11.Text = ">"; e12.Text = ":"; btnApos.Text = "Ґ";
                    }
                    else
                    {
                        a1.Text = "1"; a2.Text = "2"; a3.Text = "3"; a4.Text = "4"; a5.Text = "5";
                        a6.Text = "6"; a7.Text = "7"; a8.Text = "8"; a9.Text = "9"; a10.Text = "0";
                        a11.Text = "="; c1.Text = "/"; c2.Text = "й"; c3.Text = "ц"; c4.Text = "у";
                        c5.Text = "к"; c6.Text = "е"; c7.Text = "н"; c8.Text = "г"; c9.Text = "ш";
                        c10.Text = "щ"; c11.Text = "з"; d1.Text = "~"; d2.Text = "ф"; d3.Text = "и";
                        d4.Text = "в"; d5.Text = "а"; d6.Text = "п"; d7.Text = "р"; d8.Text = "о";
                        d9.Text = "л"; d10.Text = "д"; e1.Text = "["; e2.Text = "]"; e3.Text = "я";
                        e4.Text = "ч"; e5.Text = "с"; e6.Text = "м"; e7.Text = "и"; e8.Text = "т";
                        e9.Text = "ь"; e10.Text = ","; e11.Text = "."; e12.Text = ";"; btnApos.Text = "ґ";
                    }
                    break;



                case "ru": // 俄語 (使用西里爾字母)
                    if (chk_shift.Checked == true)
                    {
                        a1.Text = "!"; a2.Text = "@"; a3.Text = "#"; a4.Text = "$"; a5.Text = "%";
                        a6.Text = "^"; a7.Text = "&"; a8.Text = "*"; a9.Text = "("; a10.Text = ")";
                        a11.Text = "+"; c1.Text = "?"; c2.Text = "Й"; c3.Text = "Ц"; c4.Text = "У";
                        c5.Text = "К"; c6.Text = "Е"; c7.Text = "Н"; c8.Text = "Г"; c9.Text = "Ш";
                        c10.Text = "Щ"; c11.Text = "З"; d1.Text = "|"; d2.Text = "Ф"; d3.Text = "Ы";
                        d4.Text = "В"; d5.Text = "А"; d6.Text = "П"; d7.Text = "Р"; d8.Text = "О";
                        d9.Text = "Л"; d10.Text = "Д"; e1.Text = "{"; e2.Text = "}"; e3.Text = "Я";
                        e4.Text = "Ч"; e5.Text = "С"; e6.Text = "М"; e7.Text = "И"; e8.Text = "Т";
                        e9.Text = "Ь"; e10.Text = "<"; e11.Text = ">"; e12.Text = ":"; btnApos.Text = "Ъ";
                    }
                    else
                    {
                        a1.Text = "1"; a2.Text = "2"; a3.Text = "3"; a4.Text = "4"; a5.Text = "5";
                        a6.Text = "6"; a7.Text = "7"; a8.Text = "8"; a9.Text = "9"; a10.Text = "0";
                        a11.Text = "="; c1.Text = "/"; c2.Text = "й"; c3.Text = "ц"; c4.Text = "у";
                        c5.Text = "к"; c6.Text = "е"; c7.Text = "н"; c8.Text = "г"; c9.Text = "ш";
                        c10.Text = "щ"; c11.Text = "з"; d1.Text = "~"; d2.Text = "ф"; d3.Text = "ы";
                        d4.Text = "в"; d5.Text = "а"; d6.Text = "п"; d7.Text = "р"; d8.Text = "о";
                        d9.Text = "л"; d10.Text = "д"; e1.Text = "["; e2.Text = "]"; e3.Text = "я";
                        e4.Text = "ч"; e5.Text = "с"; e6.Text = "м"; e7.Text = "и"; e8.Text = "т";
                        e9.Text = "ь"; e10.Text = ","; e11.Text = "."; e12.Text = ";"; btnApos.Text = "ъ";
                    }
                    break;



                case "es": // 西班牙語 (使用拉丁字母，含特殊字符)
                    if (chk_shift.Checked == true)
                    {
                        a1.Text = "!"; a2.Text = "@"; a3.Text = "#"; a4.Text = "$"; a5.Text = "%";
                        a6.Text = "^"; a7.Text = "&"; a8.Text = "*"; a9.Text = "("; a10.Text = ")";
                        a11.Text = "+"; c1.Text = "?"; c2.Text = "Q"; c3.Text = "W"; c4.Text = "E";
                        c5.Text = "R"; c6.Text = "T"; c7.Text = "Y"; c8.Text = "U"; c9.Text = "I";
                        c10.Text = "O"; c11.Text = "P"; d1.Text = "Ñ"; d2.Text = "A"; d3.Text = "S";
                        d4.Text = "D"; d5.Text = "F"; d6.Text = "G"; d7.Text = "H"; d8.Text = "J";
                        d9.Text = "K"; d10.Text = "L"; e1.Text = "{"; e2.Text = "}"; e3.Text = "Z";
                        e4.Text = "X"; e5.Text = "C"; e6.Text = "V"; e7.Text = "B"; e8.Text = "N";
                        e9.Text = "M"; e10.Text = "<"; e11.Text = ">"; e12.Text = ":"; btnApos.Text = "¿";
                    }
                    else
                    {
                        a1.Text = "1"; a2.Text = "2"; a3.Text = "3"; a4.Text = "4"; a5.Text = "5";
                        a6.Text = "6"; a7.Text = "7"; a8.Text = "8"; a9.Text = "9"; a10.Text = "0";
                        a11.Text = "="; c1.Text = "/"; c2.Text = "q"; c3.Text = "w"; c4.Text = "e";
                        c5.Text = "r"; c6.Text = "t"; c7.Text = "y"; c8.Text = "u"; c9.Text = "i";
                        c10.Text = "o"; c11.Text = "p"; d1.Text = "ñ"; d2.Text = "a"; d3.Text = "s";
                        d4.Text = "d"; d5.Text = "f"; d6.Text = "g"; d7.Text = "h"; d8.Text = "j";
                        d9.Text = "k"; d10.Text = "l"; e1.Text = "["; e2.Text = "]"; e3.Text = "z";
                        e4.Text = "x"; e5.Text = "c"; e6.Text = "v"; e7.Text = "b"; e8.Text = "n";
                        e9.Text = "m"; e10.Text = ","; e11.Text = "."; e12.Text = ";"; btnApos.Text = "¡";
                    }
                    break;



                case "pt": // 葡萄牙語 (使用拉丁字母，含特殊字符)
                    if (chk_shift.Checked == true)
                    {
                        a1.Text = "!"; a2.Text = "@"; a3.Text = "#"; a4.Text = "$"; a5.Text = "%";
                        a6.Text = "^"; a7.Text = "&"; a8.Text = "*"; a9.Text = "("; a10.Text = ")";
                        a11.Text = "+"; c1.Text = "?"; c2.Text = "Q"; c3.Text = "W"; c4.Text = "E";
                        c5.Text = "R"; c6.Text = "T"; c7.Text = "Y"; c8.Text = "U"; c9.Text = "I";
                        c10.Text = "O"; c11.Text = "P"; d1.Text = "Ç"; d2.Text = "A"; d3.Text = "S";
                        d4.Text = "D"; d5.Text = "F"; d6.Text = "G"; d7.Text = "H"; d8.Text = "J";
                        d9.Text = "K"; d10.Text = "L"; e1.Text = "{"; e2.Text = "}"; e3.Text = "Z";
                        e4.Text = "X"; e5.Text = "C"; e6.Text = "V"; e7.Text = "B"; e8.Text = "N";
                        e9.Text = "M"; e10.Text = "<"; e11.Text = ">"; e12.Text = ":"; btnApos.Text = "'";
                    }
                    else
                    {
                        a1.Text = "1"; a2.Text = "2"; a3.Text = "3"; a4.Text = "4"; a5.Text = "5";
                        a6.Text = "6"; a7.Text = "7"; a8.Text = "8"; a9.Text = "9"; a10.Text = "0";
                        a11.Text = "="; c1.Text = "/"; c2.Text = "q"; c3.Text = "w"; c4.Text = "e";
                        c5.Text = "r"; c6.Text = "t"; c7.Text = "y"; c8.Text = "u"; c9.Text = "i";
                        c10.Text = "o"; c11.Text = "p"; d1.Text = "ç"; d2.Text = "a"; d3.Text = "s";
                        d4.Text = "d"; d5.Text = "f"; d6.Text = "g"; d7.Text = "h"; d8.Text = "j";
                        d9.Text = "k"; d10.Text = "l"; e1.Text = "["; e2.Text = "]"; e3.Text = "z";
                        e4.Text = "x"; e5.Text = "c"; e6.Text = "v"; e7.Text = "b"; e8.Text = "n";
                        e9.Text = "m"; e10.Text = ","; e11.Text = "."; e12.Text = ";"; btnApos.Text = "'";
                    }
                    break;





               default:
                    if (chk_shift.Checked == true)
                    {
                        a1.Text = "!";
                        a2.Text = "@";
                        a3.Text = "#";
                        a4.Text = "$";
                        a5.Text = "%";
                        a6.Text = "^";
                        a7.Text = "&&";
                        a8.Text = "*";
                        a9.Text = "(";
                        a10.Text = ")";
                        a11.Text = "+";
                        c1.Text = "?";
                        c2.Text = "Q";
                        c3.Text = "W";
                        c4.Text = "E";
                        c5.Text = "R";
                        c6.Text = "T";
                        c7.Text = "Y";
                        c8.Text = "U";
                        c9.Text = "I";
                        c10.Text = "O";
                        c11.Text = "P";
                        c12.Text = ".";

                        d1.Text = "|";
                        d2.Text = "A";
                        d3.Text = "S";
                        d4.Text = "D";
                        d5.Text = "F";
                        d6.Text = "G";
                        d7.Text = "H";
                        d8.Text = "J";
                        d9.Text = "K";
                        d10.Text = "L";
                        d11.Text = "-";
                        e1.Text = "{";
                        e2.Text = "}";
                        e3.Text = "Z";
                        e4.Text = "X";
                        e5.Text = "C";
                        e6.Text = "V";
                        e7.Text = "B";
                        e8.Text = "N";
                        e9.Text = "M";
                        e10.Text = "<";
                        e11.Text = ">";
                        e12.Text = ":";
                        btnApos.Text = "\u0060";
                    }
                    else
                    {
                        a1.Text = "1";
                        a2.Text = "2";
                        a3.Text = "3";
                        a4.Text = "4";
                        a5.Text = "5";
                        a6.Text = "6";
                        a7.Text = "7";
                        a8.Text = "8";
                        a9.Text = "9";
                        a10.Text = "0";
                        a11.Text = "=";
                        c1.Text = "/";
                        c2.Text = "q";
                        c3.Text = "w";
                        c4.Text = "e";
                        c5.Text = "r";
                        c6.Text = "t";
                        c7.Text = "y";
                        c8.Text = "u";
                        c9.Text = "i";
                        c10.Text = "o";
                        c11.Text = "p";

                        d1.Text = "~";
                        d2.Text = "a";
                        d3.Text = "s";
                        d4.Text = "d";
                        d5.Text = "f";
                        d6.Text = "g";
                        d7.Text = "h";
                        d8.Text = "j";
                        d9.Text = "k";
                        d10.Text = "l";
                        d11.Text = "_";
                        e1.Text = "[";
                        e2.Text = "]";
                        e3.Text = "z";
                        e4.Text = "x";
                        e5.Text = "c";
                        e6.Text = "v";
                        e7.Text = "b";
                        e8.Text = "n";
                        e9.Text = "m";
                        e10.Text = ",";
                        e11.Text = ".";
                        e12.Text = ";";
                        btnApos.Text = "\u00B4";
                    }
                    break;




            }
            // 強制刷新 UI
            this.Refresh();
        }




        private void UpdateButtonVisibility(string language)
        {
            // 預設所有按鍵隱藏，然後根據語言顯示需要的按鍵
            foreach (Control control in tableLayoutPanel.Controls)
            {
                if (control is Button btn && btn != btn_space && btn != btn_clear && btn != btn_cancel &&
                    btn != btn_OK && btn != btn_backspace && btn != btn_lang && btn != btnApos)
                {
                    btn.Visible = false;
                }
            }
            // MessageBox.Show(language);
            switch (language)
            {


                case "vi":  // 越南語
                case "th":  // 泰語
                case "id":  // 印尼語
                case "uk":  // 烏克蘭語
                case "ru":  // 俄語
                case "es":  // 西班牙語

                case "pt":  // 葡萄牙語
                            // 這些語言使用相同的按鍵佈局
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; c1.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true;
                    c5.Visible = true; c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true;
                    c10.Visible = true; c11.Visible = true; d1.Visible = true; d2.Visible = true; d3.Visible = true;
                    d4.Visible = true; d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true;
                    d9.Visible = true; d10.Visible = true; e1.Visible = true; e2.Visible = true; e3.Visible = true;
                    e4.Visible = true; e5.Visible = true; e6.Visible = true; e7.Visible = true; e8.Visible = true;
                    e9.Visible = true; e10.Visible = true; e11.Visible = true; e12.Visible = true;

                        c12.Visible = true;
                        d11.Visible = true;
                        d12.Visible = true;
                    break;

                case "en-US":
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; c1.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true;
                    c5.Visible = true; c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true;
                    c10.Visible = true; d1.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true;
                    d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true;
                    d10.Visible = true; e1.Visible = true; e2.Visible = true; e3.Visible = true; e4.Visible = true;
                    e5.Visible = true; e6.Visible = true; e7.Visible = true; e8.Visible = true; e9.Visible = true;
                    e10.Visible = true; e11.Visible = true; e12.Visible = true;
                    break;



                case "de":
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; c1.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true;
                    c5.Visible = true; c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true;
                    c10.Visible = true; c12.Visible = true; d1.Visible = true; d2.Visible = true; d3.Visible = true;
                    d4.Visible = true; d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true;
                    d9.Visible = true; d10.Visible = true; d11.Visible = true; d12.Visible = true; e1.Visible = true;
                    e2.Visible = true; e3.Visible = true; e4.Visible = true; e5.Visible = true; e6.Visible = true;
                    e7.Visible = true; e8.Visible = true; e9.Visible = true; e10.Visible = true; e11.Visible = true;
                    e12.Visible = true;
                    break;



                case "fr":
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; b1.Visible = true; b2.Visible = true; b3.Visible = true; b4.Visible = true;
                    b5.Visible = true; b6.Visible = true; b7.Visible = true; b8.Visible = true; b9.Visible = true;
                    b10.Visible = true; b11.Visible = true; b12.Visible = true; c1.Visible = true; c2.Visible = true;
                    c3.Visible = true; c4.Visible = true; c5.Visible = true; c6.Visible = true; c7.Visible = true;
                    c8.Visible = true; c9.Visible = true; c10.Visible = true; c11.Visible = true; c12.Visible = true;
                    d1.Visible = true; d2.Visible = true; d3.Visible = true; d4.Visible = true; d5.Visible = true;
                    d6.Visible = true; d7.Visible = true; d8.Visible = true; d9.Visible = true; d10.Visible = true;
                    d11.Visible = true; d12.Visible = true; e1.Visible = true; e2.Visible = true; e3.Visible = true;
                    e4.Visible = true; e5.Visible = true; e6.Visible = true; e7.Visible = true; e8.Visible = true;
                    e9.Visible = true; e10.Visible = true; e11.Visible = true; e12.Visible = true;
                    break;



                case "ja":
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; c1.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true;
                    c5.Visible = true; c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true;
                    c10.Visible = true; c11.Visible = true; d1.Visible = true; d2.Visible = true; d3.Visible = true;
                    d4.Visible = true; d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true;
                    d9.Visible = true; d10.Visible = true; e1.Visible = true; e2.Visible = true; e3.Visible = true;
                    e4.Visible = true; e5.Visible = true; e6.Visible = true; e7.Visible = true; e8.Visible = true;
                    e9.Visible = true; e10.Visible = true; e11.Visible = true; e12.Visible = true;
                    break;


                case "ko":
                    a1.Visible = true; a2.Visible = true; a3.Visible = true; a4.Visible = true; a5.Visible = true;
                    a6.Visible = true; a7.Visible = true; a8.Visible = true; a9.Visible = true; a10.Visible = true;
                    a11.Visible = true; c1.Visible = true; c2.Visible = true; c3.Visible = true; c4.Visible = true;
                    c5.Visible = true; c6.Visible = true; c7.Visible = true; c8.Visible = true; c9.Visible = true;
                    c10.Visible = true; c11.Visible = true; d1.Visible = true; d2.Visible = true; d3.Visible = true;
                    d4.Visible = true; d5.Visible = true; d6.Visible = true; d7.Visible = true; d8.Visible = true;
                    d9.Visible = true; d10.Visible = true; e1.Visible = true; e2.Visible = true; e3.Visible = true;
                    e4.Visible = true; e5.Visible = true; e6.Visible = true; e7.Visible = true; e8.Visible = true;
                    e9.Visible = true; e10.Visible = true; e11.Visible = true; e12.Visible = true;
                    break;


            }
        }
        private void Btn_space_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed(' ');
        }
        private void Btn_backspace_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('\u0008');
        }
        private void Btn_clear_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('\u0005');
        }
        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('\u0027');
        }
        private void Btn_OK_Click(object sender, EventArgs e)
        {
            RaiseButtonPressed('\u0004');
        }
        private void button7_Click(object sender, EventArgs e)
        {
        }
    }
}