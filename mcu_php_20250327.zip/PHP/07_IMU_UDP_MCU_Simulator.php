<?php
// IMU_UDP_MCU_Simulator.php
// 模擬 IMU UDP 設備的 PHP 腳本

// 錯誤報告設定
error_reporting(E_ALL);
ini_set('display_errors', 1);

// 配置參數
$config = [
    'listen_port' => 8888,
    'target_port' => 9999,
    'network_address' => ['192', '168', '5'],
    'device_ip' => '192.168.5.121',
    'gateway_ip' => '192.168.5.1',
    'broadcast_ip' => '192.168.5.255',
    'loop_time' => 100000, // 100ms 微秒
    'simulate_heading' => true, // 模擬航向變化
    'heading' => 0, // 初始航向
    'roll' => 0,    // 初始滾轉
];

// 創建UDP套接字
$socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
if ($socket === false) {
    die("無法創建套接字: " . socket_strerror(socket_last_error()));
}

// 綁定到本地端口
if (!socket_bind($socket, '0.0.0.0', $config['listen_port'])) {
    die("無法綁定套接字: " . socket_strerror(socket_last_error()));
}

// 設置非阻塞模式
socket_set_nonblock($socket);

echo "IMU MCU 模擬器已啟動，監聽端口: {$config['listen_port']}\n";
echo "目標端口: {$config['target_port']}\n";
echo "按 Ctrl+C 停止\n";

// 主循環
$last_time = microtime(true) * 1000; // 毫秒
while (true) {
    $current_time = microtime(true) * 1000;
    
    // 模擬IMU數據 - 每100ms發送一次
    if ($current_time - $last_time >= $config['loop_time']) {
        $last_time = $current_time;
        
        // 更新模擬數據
        if ($config['simulate_heading']) {
            $config['heading'] = ($config['heading'] + 1) % 360;
            $config['roll'] = sin($current_time / 1000) * 10; // -10到10度之間波動
        }
        
        // 構建數據包 (PGN 211 - 0xD3)
        $data = [
            128, 129, 121, 211, 8, // 頭部
            ($config['heading'] * 10) & 0xFF, ($config['heading'] * 10) >> 8, // 航向 *10
            ($config['roll'] * 10) & 0xFF, ($config['roll'] * 10) >> 8,      // 滾轉 *10
            0, 0, 0, 0, // 保留
            15 // 校驗和 (簡化)
        ];
        
        // 轉換為二進制
        $binary_data = '';
        foreach ($data as $byte) {
            $binary_data .= chr($byte);
        }
        
        // 發送到目標
        $target = $config['broadcast_ip'];
        socket_sendto($socket, $binary_data, strlen($binary_data), 0, $target, $config['target_port']);
        
        echo "發送 IMU 數據: 航向=".$config['heading']."°, 滾轉=".$config['roll']."°\n";
    }
    
    // 接收處理UDP消息
    $buf = '';
    $from = '';
    $port = 0;
    $bytes_received = socket_recvfrom($socket, $buf, 2048, 0, $from, $port);
    
    if ($bytes_received > 0) {
        echo "收到來自 {$from}:{$port} 的數據 (".$bytes_received." bytes)\n";
        
        // 解析數據
        $bytes = [];
        for ($i = 0; $i < $bytes_received; $i++) {
            $bytes[] = ord($buf[$i]);
        }
        
        // 打印十六進制
        echo "數據內容: ";
        foreach ($bytes as $b) {
            printf("%02X ", $b);
        }
        echo "\n";
        
        // 處理消息
        if ($bytes[0] == 0x80 && $bytes[1] == 0x81 && $bytes[2] == 0x7F) {
            // 來自AgIO的消息
            switch ($bytes[3]) {
                case 200: // Hello from AgIO
                    echo "處理: AgIO Hello 消息\n";
                    $hello = [128, 129, 121, 121, 5, 0, 0, 0, 0, 0, 71];
                    $hello_bin = '';
                    foreach ($hello as $byte) {
                        $hello_bin .= chr($byte);
                    }
                    socket_sendto($socket, $hello_bin, strlen($hello_bin), 0, $from, $port);
                    break;
                    
                case 202: // 掃描請求
                    echo "處理: 掃描請求\n";
                    if ($bytes[4] == 3 && $bytes[5] == 202 && $bytes[6] == 202) {
                        $scan_reply = [
                            128, 129, 121, 203, 4,
                            $config['network_address'][0], $config['network_address'][1], $config['network_address'][2], 121,
                            explode('.', $from)[0], explode('.', $from)[1], explode('.', $from)[2], 23
                        ];
                        // 計算校驗和
                        $ck_a = 0;
                        for ($i = 2; $i < count($scan_reply) - 1; $i++) {
                            $ck_a += $scan_reply[$i];
                        }
                        $scan_reply[count($scan_reply) - 1] = $ck_a;
                        
                        $scan_bin = '';
                        foreach ($scan_reply as $byte) {
                            $scan_bin .= chr($byte);
                        }
                        socket_sendto($socket, $scan_bin, strlen($scan_bin), 0, '255.255.255.255', $config['target_port']);
                    }
                    break;
                    
                case 201: // IP配置更新
                    echo "處理: IP配置更新\n";
                    if ($bytes[4] == 5 && $bytes[5] == 201 && $bytes[6] == 201) {
                        $config['network_address'] = [$bytes[7], $bytes[8], $bytes[9]];
                        echo "更新網路配置: ".implode('.', $config['network_address']).".121\n";
                        // 這裡模擬EEPROM保存
                    }
                    break;
            }
        }
    }
    
    // 減輕CPU負載
    usleep(10000); // 10ms
}

// 關閉套接字 (理論上不會執行到這裡)
socket_close($socket);
?>