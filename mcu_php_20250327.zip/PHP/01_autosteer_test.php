<?php
// Autosteer Test Shell for AgOpenGPS UDP Communication
// Simulates the communication with the autosteer module

// 錯誤報告設置 - 顯示所有錯誤但不顯示警告
error_reporting(E_ALL & ~E_WARNING);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Configuration
$local_ip = '192.168.5.126';  // Default module IP
$local_port = 8888;
$remote_ip = '192.168.5.255';  // Broadcast address
$remote_port = 9999;

// Create UDP socket
$socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
socket_set_option($socket, SOL_SOCKET, SO_BROADCAST, 1);
socket_bind($socket, $local_ip, $local_port);

// Simulated autosteer parameters
$steerSettings = [
    'Kp' => 120,
    'lowPWM' => 30,
    'highPWM' => 160,
    'minPWM' => 25,
    'steerSensorCounts' => 30,
    'wasOffset' => 0,
    'AckermanFix' => 1.0
];

$steerConfig = [
    'InvertWAS' => 0,
    'IsRelayActiveHigh' => 0,
    'MotorDriveDirection' => 0,
    'SingleInputWAS' => 1,
    'CytronDriver' => 1,
    'SteerSwitch' => 0,
    'SteerButton' => 0,
    'ShaftEncoder' => 0,
    'PressureSensor' => 0,
    'CurrentSensor' => 0,
    'PulseCountMax' => 5,
    'IsDanfoss' => 0,
    'IsUseX_Axis' => 0
];

// Simulation variables
$steerAngleActual = 0.0;
$steerAngleSetPoint = 0.0;
$guidanceStatus = 0;
$watchdogTimer = 0;
$pwmDrive = 0;
$sensorReading = 0;
$helloSteerPosition = 0;
$switchByte = 0;
$correctionCount = 0;
$simulatedHeading = 180.0;  // Initial heading (degrees)
$simulatedRoll = 0.0;       // Initial roll (degrees)

echo "Autosteer Test Shell\n";
echo "Listening on $local_ip:$local_port\n";
echo "Sending to $remote_ip:$remote_port\n\n";

// Main loop
while (true) {
    // Check for incoming data
    $from = '';
    $port = 0;
    $data = '';
    if (@socket_recvfrom($socket, $data, 2048, 0, $from, $port) !== false) {
        // Process received packet
        if (strlen($data) > 0) {
            $bytes = unpack('C*', $data);
            processPacket($bytes, $from, $port);
        }
    }
    
    // Simulate periodic updates (every 100ms)
    usleep(100000);
    
    // Simulate sensor drift and corrections
    simulateSteering();
}

// Close socket (unreachable in this loop)
socket_close($socket);

function processPacket($bytes, $from, $port) {
    global $steerSettings, $steerConfig, $steerAngleActual, $steerAngleSetPoint;
    global $guidanceStatus, $watchdogTimer, $pwmDrive, $sensorReading;
    global $helloSteerPosition, $switchByte, $remote_ip, $remote_port;
    global $simulatedHeading, $simulatedRoll, $socket;
    
    // 檢查封包頭 (80 81 7F)
    if (count($bytes) >= 4 && $bytes[1] == 128 && $bytes[2] == 129 && $bytes[3] == 127) {
        $pgn = $bytes[4];
        
        switch ($pgn) {
		    case 100: // 处理 PGN 100 - 转向控制命令
				if (count($bytes) >= 8) {
					$steerAngleSetPoint = (($bytes[6] << 8) | $bytes[5]) * 0.01; // 读取转向设定点
					$guidanceStatus = $bytes[7];
					
					/*
					echo "Received PGN 100 - Steer Control: ";
					echo "SetPoint: " . round($steerAngleSetPoint, 2) . "°, ";
					echo "Status: $guidanceStatus\n";
					*/
					
					// 重置修正计数器
					$correctionCount = 0;
				}
				break;

            case 254: // 轉向資料
                // 檢查是否有足夠的位元組來解析資料
                if (count($bytes) >= 13) {
                    // 解析轉向資料
                    $gpsSpeed = (($bytes[6] << 8) | $bytes[5]) * 0.1;
                    $guidanceStatus = $bytes[7];
                    $steerAngleSetPoint = (($bytes[9] << 8) | $bytes[8]) * 0.01;
                    $xte = $bytes[10];
                    $relay = $bytes[11];
                    $relayHi = $bytes[12];
                    /*
                    echo "Received Steer Data: ";
                    echo "Speed: " . round($gpsSpeed, 1) . " kph, ";
                    echo "SetPoint: " . round($steerAngleSetPoint, 2) . "°, "; // 修正顯示格式
                    echo "Status: $guidanceStatus\n";
                    */
                    // 重置看門狗計時器
                    $watchdogTimer = 0;
                    
                    // 發送回應 (PGN 253)
                    $heading10x = (int)($simulatedHeading * 10);
                    $roll10x = (int)($simulatedRoll * 10);
                    
                    $steerAngle100 = (int)($steerAngleActual * 100);
                    $pgn253 = pack('C*', 
                        128, 129, 126, 253, 8, 
                        $steerAngle100 & 0xFF, ($steerAngle100 >> 8) & 0xFF,
                        $heading10x & 0xFF, ($heading10x >> 8) & 0xFF,
                        $roll10x & 0xFF, ($roll10x >> 8) & 0xFF,
                        $switchByte, $pwmDrive
                    );
                    
                    // 添加校驗和
                    $checksum = 0;
                    for ($i = 2; $i < 13; $i++) {
                        $checksum += ord($pgn253[$i]);
                    }
                    $pgn253 .= chr($checksum & 0xFF);
                    
                    socket_sendto($socket, $pgn253, strlen($pgn253), 0, $remote_ip, $remote_port);
                    
                    // 偶爾發送感測器資料 (PGN 250)
                    if (rand(0, 2) == 0) {
                        $pgn250 = pack('C*', 128, 129, 126, 250, 8, $sensorReading, 0, 0, 0, 0, 0, 0);
                        
                        // 添加校驗和
                        $checksum = 0;
                        for ($i = 2; $i < 13; $i++) {
                            $checksum += ord($pgn250[$i]);
                        }
                        $pgn250 .= chr($checksum & 0xFF);
                        
                        socket_sendto($socket, $pgn250, strlen($pgn250), 0, $remote_ip, $remote_port);
                    }
                } else {
                    echo "警告：接收到的轉向資料封包長度不足（需要至少13個位元組，實際收到 " . count($bytes) . " 個位元組）\n";
                }
                break;
                
            // 其他 case 保持不變...
            case 200: // Hello from AgIO
                echo "Received Hello from AgIO\n";
                
                // Send hello response
                $steerAngle100 = (int)($steerAngleActual * 100);
                $hello = pack('C*', 
                    128, 129, 126, 126, 5,
                    $steerAngle100 & 0xFF, ($steerAngle100 >> 8) & 0xFF,
                    $helloSteerPosition & 0xFF, ($helloSteerPosition >> 8) & 0xFF,
                    $switchByte, 71
                );
                
                socket_sendto($socket, $hello, strlen($hello), 0, $remote_ip, $remote_port);
                break;
                
            case 252: // PID settings
                $steerSettings['Kp'] = $bytes[5];
                $steerSettings['highPWM'] = $bytes[6];
                $steerSettings['lowPWM'] = $bytes[7];
                $steerSettings['minPWM'] = $bytes[8];
                $steerSettings['steerSensorCounts'] = $bytes[9];
                $steerSettings['wasOffset'] = ($bytes[11] << 8) | $bytes[10];
                $steerSettings['AckermanFix'] = $bytes[12] * 0.01;
                
                echo "Updated PID Settings:\n";
                print_r($steerSettings);
                break;
                
            case 251: // Configuration
                $sett = $bytes[5];
                $steerConfig['InvertWAS'] = ($sett & 0x01) ? 1 : 0;
                $steerConfig['IsRelayActiveHigh'] = ($sett & 0x02) ? 1 : 0;
                $steerConfig['MotorDriveDirection'] = ($sett & 0x04) ? 1 : 0;
                $steerConfig['SingleInputWAS'] = ($sett & 0x08) ? 1 : 0;
                $steerConfig['CytronDriver'] = ($sett & 0x10) ? 1 : 0;
                $steerConfig['SteerSwitch'] = ($sett & 0x20) ? 1 : 0;
                $steerConfig['SteerButton'] = ($sett & 0x40) ? 1 : 0;
                $steerConfig['ShaftEncoder'] = ($sett & 0x80) ? 1 : 0;
                
                $steerConfig['PulseCountMax'] = $bytes[6];
                
                $sett = $bytes[8];
                $steerConfig['IsDanfoss'] = ($sett & 0x01) ? 1 : 0;
                $steerConfig['PressureSensor'] = ($sett & 0x02) ? 1 : 0;
                $steerConfig['CurrentSensor'] = ($sett & 0x04) ? 1 : 0;
                $steerConfig['IsUseX_Axis'] = ($sett & 0x08) ? 1 : 0;
                
                echo "Updated Configuration:\n";
                print_r($steerConfig);
                break;
                
            case 201: // Subnet change
                if ($bytes[5] == 5 && $bytes[6] == 201 && $bytes[7] == 201) {
                    $ipOne = $bytes[8];
                    $ipTwo = $bytes[9];
                    $ipThree = $bytes[10];
                    
                    echo "Subnet changed to: $ipOne.$ipTwo.$ipThree\n";
                }
                break;
                
            case 202: // Scan request
                if ($bytes[5] == 3 && $bytes[6] == 202 && $bytes[7] == 202) {
                    echo "Received scan request from $from:$port\n";
                    
                    // Send scan reply
                    $fromParts = explode('.', $from);
                    $scanReply = pack('C*', 
                        128, 129, 126, 203, 7,
                        192, 168, 5, 126,
                        $fromParts[0], $fromParts[1], $fromParts[2], 23
                    );
                    
                    // Add checksum
                    $checksum = 0;
                    for ($i = 2; $i < 13; $i++) {
                        $checksum += ord($scanReply[$i]);
                    }
                    $scanReply .= chr($checksum & 0xFF);
                    
                    socket_sendto($socket, $scanReply, strlen($scanReply), 0, '255.255.255.255', $remote_port);
                }
                break;
			default:
				echo "\r\n".$pgn."==========================\r\n";
				break;
        }
    }
}

function simulateSteering() {
    global $steerSettings, $steerConfig, $steerAngleActual, $steerAngleSetPoint;
    global $guidanceStatus, $pwmDrive, $correctionCount, $simulatedHeading;
    global $simulatedRoll, $helloSteerPosition, $sensorReading, $switchByte;
    
    // Only simulate when guidance is active
    if ($guidanceStatus == 1) {
        // Simulate error and correction
        $error = $steerAngleSetPoint - $steerAngleActual;
        $absError = abs($error);
        
        // Calculate PID (simplified)
        $pValue = $steerSettings['Kp'] * $error;
        
        // Simulate PWM drive
        if ($absError < 3.0) {
            $newMax = ($absError * (($steerSettings['highPWM'] - $steerSettings['lowPWM']) / 3.0)) + $steerSettings['lowPWM'];
        } else {
            $newMax = $steerSettings['highPWM'];
        }
        
        // Add min PWM
        if ($pValue < 0) $pValue -= $steerSettings['minPWM'];
        else if ($pValue > 0) $pValue += $steerSettings['minPWM'];
        
        // Limit PWM
        $pwmDrive = max(min($pValue, $newMax), -$newMax);
        
        // Apply motor direction
        if ($steerConfig['MotorDriveDirection']) {
            $pwmDrive *= -1;
        }
        
        // Simulate Danfoss valve if configured
        if ($steerConfig['IsDanfoss']) {
            $pwmDrive = max(min($pwmDrive, 250), -250);
            $pwmDrive = ($pwmDrive / 4) + 128;
        }
        
        // Simulate steering movement
        $movement = $pwmDrive * 0.01;  // Scale factor for simulation
        $steerAngleActual += $movement;
        
        // Simulate overshoot and correction
        if ($correctionCount < 5) {
            // First 5 corrections - simulate overshoot
            $steerAngleActual += ($error * 0.2 * (5 - $correctionCount) / 5);
            $correctionCount++;
        } else {
            // After 5 corrections - stabilize
            $steerAngleActual = $steerAngleSetPoint + (rand(-10, 10) / 100.0); // Small random variation
        }
        
        // Simulate heading drift (slowly changes over time)
        $simulatedHeading += (rand(-5, 5) / 10.0);
        if ($simulatedHeading < 0) $simulatedHeading += 360;
        if ($simulatedHeading >= 360) $simulatedHeading -= 360;
        
        // Simulate roll (small variations)
        $simulatedRoll = max(min($simulatedRoll + (rand(-3, 3) / 10.0), 15), -15); // Fixed syntax here
        
        // Update other simulated values
        $helloSteerPosition = (int)($steerAngleActual * 100);
        $sensorReading = rand(0, 100);
        $switchByte = rand(0, 7);
        
        echo "Correction: $correctionCount, Actual: " . round($steerAngleActual, 2) . 
             "°, SetPoint: " . round($steerAngleSetPoint, 2) . 
             "°, PWM: $pwmDrive, Heading: " . round($simulatedHeading, 1) . "°\n";
    } else {
        // Not in guidance mode - reset correction count
        $correctionCount = 0;
        $pwmDrive = 0;
    }
}
?>