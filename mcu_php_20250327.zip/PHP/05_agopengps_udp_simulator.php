<?php
/**
 * AgOpenGPS UDP ��ĳ������ (�D NMEA ����)
 * �\��G�����{ PGN 254/252/251/239/238 ����ĳ���ѪR�P�T��
 * �ϥΡGphp agopengps_udp_simulator.php [--ip=192.168.5.255]
 */

// �p�����M (�P�� C# �޿�@�P)
function calculateChecksum($data) {
    $checksum = 0;
    for ($i = 2; $i < strlen($data) - 1; $i++) {
        $checksum += ord($data[$i]);
    }
    return chr($checksum & 0xFF);
}

// �Ѽưt�m
$options = getopt('', ['ip::']);
$broadcastIP = $options['ip'] ?? '192.168.5.255';
$localPort = 8888;
$remotePort = 9999;

// ��l�� UDP Socket
$socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
socket_set_option($socket, SOL_SOCKET, SO_REUSEADDR, 1);
socket_set_option($socket, SOL_SOCKET, SO_BROADCAST, 1);
socket_bind($socket, '0.0.0.0', $localPort);

// ���������A�ܼ� (�P�� C# �N�X�O���@�P)
$steerAngleActual = 0.0;
$guidanceStatus = 0;
$relayState = 0;
$workSwitch = 1;
$steerSwitch = 1;
$imuYaw = 0.0; // ��l�� IMU ���訤

$pgnCache = [
    253 => "\x80\x81\x7F\xFD\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00", // �w�] PGN 253 �ҪO
    126 => "\x80\x81\x7E\x7E\x05\x00\x00\x00\x00\x00\x47",             // AutoSteer �߸�
    123 => "\x80\x81\x7B\x7B\x05\x00\x00\x00\x00\x00\x47",             // Machine �߸�
    121 => "\x80\x81\x7F\x79\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00"  // IMU �߸��ҪO
];

echo "UDP Simulator started. Listening on port $localPort...\n";

while (true) {
    // �����ƾ�
    $data = '';
    socket_recvfrom($socket, $data, 1024, 0, $clientIP, $clientPort);
    
    if (strlen($data) < 5) continue; // �L�o�L�ļƾ�

    // �ѪR PGN (�q��4�r�`���)
    $pgn = ord($data[3]);
    $response = null;

    switch ($pgn) {
        case 200: // �߸��˴�
            // ��s IMU �ƾ� (�����ʺA�ܤ�)
            $imuRoll = rand(-200, 200) / 10.0;  // -20�X ~ +20�X
            $imuPitch = rand(-100, 100) / 10.0; // -10�X ~ +10�X
            $imuYaw = fmod($imuYaw + rand(-5, 5), 360.0);
            
            // �c�� IMU �M�Τ߸��] (PGN 121)
            $pgn121 = $pgnCache[121];
            $yawValue = (int)($imuYaw * 10);
            $pgn121[5] = chr($yawValue & 0xFF);
            $pgn121[6] = chr(($yawValue >> 8) & 0xFF);
            $pgn121[13] = calculateChecksum($pgn121); // ��s����M
            
            // �T���Ҧ��߸��]
            $response = [
                $pgnCache[126],  // AutoSteer
                $pgnCache[123],  // Machine
                $pgn121          // IMU
            ];
            break;

        case 240: // IMU �M�μƾڽШD (�۩w�q PGN)
            $pgn241 = "\x80\x81\x7F\xF1\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00";
            $rollInt = (int)($imuRoll * 10);
            $pitchInt = (int)($imuPitch * 10);
            $pgn241[5] = chr($rollInt & 0xFF);
            $pgn241[6] = chr(($rollInt >> 8) & 0xFF);
            $pgn241[7] = chr($pitchInt & 0xFF);
            $pgn241[8] = chr(($pitchInt >> 8) & 0xFF);
            $pgn241[13] = calculateChecksum($pgn241);
            $response = $pgn241;
            break;

        case 254: // �ɯ豱����O
            if (strlen($data) >= 13) {
                $guidanceStatus = ord($data[7]);
                $steerAngleSetPoint = unpack('s', $data[5] . $data[6])[1] * 0.01;
                $relayState = ord($data[11]);
                
                // ��s�����V�� (���� PID ����ĪG)
                $steerAngleActual = $steerAngleSetPoint * 0.8 + rand(-5, 5) * 0.01;
                
                // �c�� PGN 253 �T��
                $pgn253 = $pgnCache[253];
                $angle = (int)($steerAngleActual * 100);
                $pgn253[5] = chr($angle & 0xFF);
                $pgn253[6] = chr(($angle >> 8) & 0xFF);
                $pgn253[11] = chr(($workSwitch & 0x01) | (($steerSwitch & 0x01) << 1));
                $pgn253[12] = chr(50); // ���� PWM ��
                
                // ��s����M
                $pgn253[13] = calculateChecksum($pgn253);
                $response = $pgn253;
            }
            break;

        case 252: // PID �ѼƳ]�m
            if (strlen($data) >= 14) {
                $kp = ord($data[5]);
                $highPWM = ord($data[6]);
                $lowPWM = ord($data[7]);
                $minPWM = ord($data[8]);
                $wasOffset = unpack('s', $data[9] . $data[10])[1];
                $ackermann = ord($data[12]) * 0.01;
                
                echo "[PID Updated] Kp=$kp HiPWM=$highPWM LoPWM=$lowPWM WAS_Offset=$wasOffset\n";
            }
            break;

        case 251: // �w��t�m
            if (strlen($data) >= 14) {
                $configByte = ord($data[5]);
                $invertWAS = ($configByte & 0x01) ? 1 : 0;
                $isRelayActiveHigh = ($configByte & 0x02) ? 1 : 0;
                $motorDirection = ($configByte & 0x04) ? 1 : 0;
                
                echo "[Config Updated] InvertWAS=$invertWAS RelayActiveHigh=$isRelayActiveHigh\n";
            }
            break;

        case 202: // ���y�ШD
            $pgn203 = "\x80\x81\x7F\xCB\x07\xC0\xA8\x05\x7E\xC0\xA8\x05\x17\x00";
            $pgn203[13] = calculateChecksum($pgn203);
            $response = $pgn203;
            break;
    }

    // �o�e�T��
    if ($response) {
        if (is_array($response)) {
            foreach ($response as $packet) {
                socket_sendto($socket, $packet, strlen($packet), 0, $broadcastIP, $remotePort);
            }
        } else {
            socket_sendto($socket, $response, strlen($response), 0, $broadcastIP, $remotePort);
        }
    }
}