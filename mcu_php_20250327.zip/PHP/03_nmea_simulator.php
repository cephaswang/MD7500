<?php
/**
 * NMEA Simulator in PHP
 * 完整模擬 ModSim 的 GPS 數據生成與 UDP 發送功能
 * 使用方法: php nmea_simulator.php [--lat 初始緯度] [--lon 初始經度] [--speed 初始速度]
 */

// 參數設定
$options = getopt('', ['lat:', 'lon:', 'speed:']);
$latitude = $options['lat'] ?? 40.7128;  // 預設紐約緯度
$longitude = $options['lon'] ?? -74.0060; // 預設紐約經度
$initialSpeed = $options['speed'] ?? 0.5;

// UDP 設定
$udpPort = 9999;
$broadcastIP = '255.255.255.255';
$socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
socket_set_option($socket, SOL_SOCKET, SO_BROADCAST, 1);

// 模擬狀態變數
$headingTrue = 0;      // 弧度制
$steerAngle = 0;       // 度
$roll = 0;             // 度
$stepDistance = $initialSpeed * 0.1;
$fixQuality = 8;
$sats = 12;
$HDOP = 0.9;
$altitude = 300;

// 主循環
while (true) {
    // 1. 計算新位置 (移植自 CalculateNewPostionFromBearingDistance)
    $newPosition = calculatePosition($latitude, $longitude, $headingTrue, $stepDistance / 1000.0);
    $latitude = $newPosition['lat'];
    $longitude = $newPosition['lon'];
    
    // 2. 生成所有 NMEA 句子
    $timeNow = gmdate('His.v');
    $sentences = [
        buildGGA($timeNow, $latitude, $longitude),
        buildVTG($timeNow, $headingTrue, $stepDistance),
        buildHDT($headingTrue),
        buildAVR($timeNow, $headingTrue, $roll),
        buildRMC($timeNow, $latitude, $longitude, $stepDistance, $headingTrue)
    ];

    // 3. 發送 UDP
    foreach ($sentences as $sentence) {
        socket_sendto($socket, $sentence, strlen($sentence), 0, $broadcastIP, $udpPort);
    }

    // 4. 控制台輸出
    echo "[".date('Y-m-d H:i:s')."] Sent: ".implode(" ", array_map('trim', $sentences))."\n";
    
    // 5. 更新下一次計算參數
    $steerAngle = rand(-30, 30); // 模擬隨機轉向
    $headingTrue += ($stepDistance * tan(deg2rad($steerAngle * 0.02)) / 2.5);
    $headingTrue = normalizeAngle($headingTrue);
    $roll = rand(-10, 10); // 模擬隨機滾轉
    
    usleep(100000); // 100ms 間隔
}

// 關閉 socket (實際上不會執行到這裡)
socket_close($socket);

// ================== 核心算法函數 ================== //

/**
 * 計算新位置 (移植自 CalculateNewPostionFromBearingDistance)
 */
function calculatePosition($lat, $lon, $bearing, $distance) {
    $R = $distance / 6371.0;
    $latRad = deg2rad($lat);
    $lonRad = deg2rad($lon);
    
    $newLat = asin(sin($latRad) * cos($R) + cos($latRad) * sin($R) * cos($bearing));
    $newLon = $lonRad + atan2(sin($bearing) * sin($R) * cos($latRad), cos($R) - sin($latRad) * sin($newLat));
    
    return [
        'lat' => rad2deg($newLat),
        'lon' => rad2deg($newLon)
    ];
}

/**
 * 生成 GGA 句子
 */
function buildGGA($time, $lat, $lon) {
    global $fixQuality, $sats, $HDOP, $altitude;
    
    $ns = $lat >= 0 ? 'N' : 'S';
    $ew = $lon >= 0 ? 'E' : 'W';
    
    $latAbs = abs($lat);
    $latDeg = floor($latAbs);
    $latMin = ($latAbs - $latDeg) * 60;
    $latFormatted = sprintf("%02d%07.4f", $latDeg, $latMin);
    
    $lonAbs = abs($lon);
    $lonDeg = floor($lonAbs);
    $lonMin = ($lonAbs - $lonDeg) * 60;
    $lonFormatted = sprintf("%03d%07.4f", $lonDeg, $lonMin);
    
    $sentence = sprintf("GPGGA,%s,%s,%s,%s,%s,%d,%02d,%.1f,%.1f,M,,M,", 
        $time, $latFormatted, $ns, $lonFormatted, $ew, 
        $fixQuality, $sats, $HDOP, $altitude);
    
    return '$' . $sentence . '*' . calculateNmeaChecksum($sentence) . "\r\n";
}

/**
 * 生成 VTG 句子
 */
function buildVTG($time, $heading, $speed) {
    $speedKnots = $speed * 1.944; // m/s to knots
    $sentence = sprintf("GPVTG,%.2f,T,,M,%.2f,N,%.2f,K", 
        rad2deg($heading), $speedKnots, $speed * 3.6);
    return '$' . $sentence . '*' . calculateNmeaChecksum($sentence) . "\r\n";
}

/**
 * 生成 HDT 句子
 */
function buildHDT($heading) {
    $sentence = sprintf("GNHDT,%.2f,T", rad2deg($heading));
    return '$' . $sentence . '*' . calculateNmeaChecksum($sentence) . "\r\n";
}

/**
 * 生成 AVR 句子
 */
function buildAVR($time, $heading, $roll) {
    $sentence = sprintf("PTNL,AVR,%s,%.2f,Yaw,-2.1,Tilt,%.2f,Roll,444.232,3,1.2,17", 
        $time, rad2deg($heading), $roll);
    return '$' . $sentence . '*' . calculateNmeaChecksum($sentence) . "\r\n";
}

/**
 * 生成 RMC 句子
 */
function buildRMC($time, $lat, $lon, $speed, $heading) {
    $ns = $lat >= 0 ? 'N' : 'S';
    $ew = $lon >= 0 ? 'E' : 'W';
    
    $latAbs = abs($lat);
    $latDeg = floor($latAbs);
    $latMin = ($latAbs - $latDeg) * 60;
    $latFormatted = sprintf("%02d%07.4f", $latDeg, $latMin);
    
    $lonAbs = abs($lon);
    $lonDeg = floor($lonAbs);
    $lonMin = ($lonAbs - $lonDeg) * 60;
    $lonFormatted = sprintf("%03d%07.4f", $lonDeg, $lonMin);
    
    $sentence = sprintf("GPRMC,%s,A,%s,%s,%s,%s,%.2f,%.2f,%s,,",
        $time, $latFormatted, $ns, $lonFormatted, $ew,
        $speed * 1.944, rad2deg($heading), date('dmy'));
    
    return '$' . $sentence . '*' . calculateNmeaChecksum($sentence) . "\r\n";
}

/**
 * 計算 NMEA 校驗和
 */
function calculateNmeaChecksum($sentence) {
    $checksum = 0;
    for ($i = 0; $i < strlen($sentence); $i++) {
        $char = $sentence[$i];
        if ($char == '$') continue;
        if ($char == '*') break;
        $checksum ^= ord($char);
    }
    return strtoupper(dechex($checksum));
}

/**
 * 歸一化角度到 0-2π
 */
function normalizeAngle($angle) {
    $twoPi = 2 * M_PI;
    while ($angle < 0) $angle += $twoPi;
    while ($angle >= $twoPi) $angle -= $twoPi;
    return $angle;
}