<?php
// Arduino Nano ������ - �����W����R�O�æ^��
// ���� Autosteer.ino �M zEthernet.ino ���\��

// �t�m�Ѽ�
$localIP = "192.168.5.126";  // ���� Arduino Nano �� IP
$broadcastIP = "192.168.5.255"; // �s���a�}
$port = 8888;                // ��ť�M�o�e�ݤf
$serverPort = 9999;          // �W����ݤf

// �Ы� UDP socket
$socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
socket_bind($socket, $localIP, $port);
socket_set_option($socket, SOL_SOCKET, SO_BROADCAST, 1);
socket_set_option($socket, SOL_SOCKET, SO_RCVTIMEO, array("sec" => 1, "usec" => 0));

// ��l�Ƽ������A�ܼ�
$steerAngleActual = 0.0;     // �����V����
$steerAngleSetPoint = 0.0;   // �ؼ���V����
$gpsSpeed = 0.0;             // GPS �t�� (km/h)
$watchdogTimer = 0;          // �ݪ����p�ɾ�
$guidanceStatus = 0;         // �ɯ説�A
$workSwitch = 1;             // �u�@�}�����A
$steerSwitch = 1;            // ��V�}�����A
$relay = 0;                  // �~�q�����A
$pwmDrive = 0;               // PWM �X�ʭ�
$sensorReading = 0;          // �ǷP��Ū��

// PID �Ѽ�
$steerSettings = [
    'Kp' => 40,
    'lowPWM' => 10,
    'highPWM' => 60,
    'minPWM' => 9,
    'steerSensorCounts' => 30,
    'wasOffset' => 0,
    'AckermanFix' => 1.0
];

// �]�ưt�m
$steerConfig = [
    'InvertWAS' => 0,
    'IsRelayActiveHigh' => 0,
    'MotorDriveDirection' => 0,
    'SingleInputWAS' => 1,
    'CytronDriver' => 1,
    'SteerSwitch' => 0,
    'SteerButton' => 0,
    'ShaftEncoder' => 0,
    'PressureSensor' => 0,
    'CurrentSensor' => 0,
    'PulseCountMax' => 5,
    'IsDanfoss' => 0,
    'IsUseY_Axis' => 0
];

// �D�`��
echo "Arduino Nano Simulator started. Listening on $localIP:$port\n";

while (true) {
    // 1. �����W����ƾ�
    $received = @socket_recvfrom($socket, $buf, 1024, 0, $remoteIP, $remotePort);
    
    if ($received !== false) {
        // �ѪR���쪺�ƾڥ]
        if (strlen($buf) >= 5 && ord($buf[0]) == 0x80 && ord($buf[1]) == 0x81) {
            $source = ord($buf[2]);
            $command = ord($buf[3]);
            
            // �B�z���P�R�O
            switch ($command) {
				case 100: // 0x64 - Hello from AgIO (�S���B�z)
					handleHelloFromAgIO($remoteIP);
					break;

                case 0xFE: // 254 - �ɯ�ƾ�
                    handleNavigationData($buf);
                    break;
                    
                case 0xFC: // 252 - PID �ѼƳ]�m
                    handlePIDSettings($buf);
                    break;
                    
                case 0xFB: // 251 - �t�m�]�m
                    handleConfigSettings($buf);
                    break;
                    
                case 200: // Hello �ШD
                    sendHelloResponse($remoteIP);
                    break;
                    
                case 201: // IP �]�m
                    handleIPSettings($buf);
                    break;
                    
                case 202: // WhoAmI �ШD
                    sendWhoAmIResponse($remoteIP);
                    break;
                    
                default:
                    echo "Received unknown command: 0x" . dechex($command) . "\n";
            }
        } else {
            echo "Received invalid packet\n";
        }
    }
    
    // 2. �����ɯ豱���޿�
    if ($guidanceStatus == 1 && $watchdogTimer < 100) {
        // �p����V�~�t
        $steerAngleError = $steerAngleSetPoint - $steerAngleActual;
        
        // ���� PID ����
        $pValue = $steerSettings['Kp'] * $steerAngleError;
        $pwmDrive = (int)$pValue;
        
        // �K�[�̤p PWM
        if ($pwmDrive < 0) $pwmDrive -= $steerSettings['minPWM'];
        else if ($pwmDrive > 0) $pwmDrive += $steerSettings['minPWM'];
        
        // ���� PWM �d��
        $errorAbs = abs($steerAngleError);
        $newMax = ($errorAbs < 3.0) ? 
            ($errorAbs * (($steerSettings['highPWM'] - $steerSettings['lowPWM']) / 3.0) + $steerSettings['lowPWM']) : 
            $steerSettings['highPWM'];
        
        if ($pwmDrive > $newMax) $pwmDrive = $newMax;
        if ($pwmDrive < -$newMax) $pwmDrive = -$newMax;
        
        // ��V�ץ�
        if ($steerConfig['MotorDriveDirection']) $pwmDrive *= -1;
        
        // ���������V�����ܤ�
        $steerAngleActual += ($pwmDrive / 100.0) * (1.0 + (rand(-20, 20) / 100.0));
        
        // �H�������ǷP��Ū��
        $sensorReading = rand(0, 100);
    } else {
        // �ɯ襼�E���A���m PWM
        $pwmDrive = 0;
    }
    
    // 3. �w�ɵo�e���A�ƾ�
    static $lastSendTime = 0;
    $currentTime = time();
    
    if ($currentTime - $lastSendTime >= 0.1) { // 10Hz
        $lastSendTime = $currentTime;
        
        // �o�e�����V���� (253)
        sendSteerData();
        
        // �����o�e�ǷP���ƾ� (250)
        if (rand(0, 10) > 8) {
            sendSensorData();
        }
    }
    
    // 4. ��s�ݪ����p�ɾ�
    if ($watchdogTimer < 255) $watchdogTimer++;
    
    // �u�ȩ���
    usleep(10000); // 10ms
}

// ����socket (�z�פW���|�����o��)
socket_close($socket);

// �s�W���B�z���
function handleHelloFromAgIO($remoteIP) {
    global $socket, $localIP, $serverPort, $steerAngleActual, $steerSwitch, $workSwitch;
    
    echo "Received Hello from AgIO (0x64)\n";
    
    // �c�ئ^���ƾڥ]
    $response = pack('C*', 0x80, 0x81, 0x7E, 0x7E, 5);
    
    // �����V���� (2�r�`)
    $sa = (int)($steerAngleActual * 100);
    $response .= pack('v', $sa);
    
    // ��m�ƾ� (2�r�`)
    $response .= pack('v', 0);
    
    // �}�����A (1�r�`)
    $switchByte = ($workSwitch << 2) | ($steerSwitch << 1) | 1;
    $response .= pack('C', $switchByte);
    
    // �p�����M
    $checksum = 0;
    for ($i = 2; $i < strlen($response); $i++) {
        $checksum += ord($response[$i]);
    }
    $response .= pack('C', $checksum & 0xFF);
    
    // �o�e�^��
    socket_sendto($socket, $response, strlen($response), 0, $remoteIP, $serverPort);
    echo "Sent response to Hello from AgIO\n";
    
    // �p�G��IMU�ƾڡA�]�o�eIMU��Hello�]
    // �o��²�ƳB�z�A������ھڰt�m�M�w
    $imuHello = pack('C*', 0x80, 0x81, 0x79, 0x79, 5, 0, 0, 0, 0, 0, 71);
    socket_sendto($socket, $imuHello, strlen($imuHello), 0, $remoteIP, $serverPort);
    echo "Sent IMU Hello packet\n";
}

// �B�z�ɯ�ƾ� (0xFE)
function handleNavigationData($data) {
    global $gpsSpeed, $guidanceStatus, $steerAngleSetPoint, $watchdogTimer, $steerSwitch, $relay;
    
    if (strlen($data) >= 13) {
        $gpsSpeed = unpack('v', substr($data, 5, 2))[1] * 0.1;
        $newGuidanceStatus = ord($data[7]);
        
        // �˴��ɯ説�A�ܤ�
        if ($newGuidanceStatus != $guidanceStatus) {
            echo "Guidance status changed to: " . $newGuidanceStatus . "\n";
            $guidanceStatus = $newGuidanceStatus;
        }
        
        $steerAngleSetPoint = unpack('v', substr($data, 8, 2))[1] * 0.01;
        $relay = ord($data[11]);
        
        // ���m�ݪ���
        if (($guidanceStatus & 1) && $steerSwitch == 0) {
            $watchdogTimer = 0;
        } else {
            $watchdogTimer = 100; // �W�L�H��
        }
        
        echo "Received navigation data - Speed: " . $gpsSpeed . " km/h, Target: " . $steerAngleSetPoint . "�X, Relay: " . $relay . "\n";
    }
}

// �B�z PID �]�m (0xFC)
function handlePIDSettings($data) {
    global $steerSettings;
    
    if (strlen($data) >= 14) {
        $steerSettings['Kp'] = ord($data[5]);
        $steerSettings['highPWM'] = ord($data[6]);
        $steerSettings['lowPWM'] = ord($data[7]);
        $steerSettings['minPWM'] = ord($data[8]);
        $steerSettings['steerSensorCounts'] = ord($data[9]);
        $steerSettings['wasOffset'] = unpack('v', substr($data, 10, 2))[1];
        $steerSettings['AckermanFix'] = ord($data[12]) * 0.01;
        
        echo "Updated PID settings - Kp: " . $steerSettings['Kp'] . 
             ", highPWM: " . $steerSettings['highPWM'] . 
             ", lowPWM: " . $steerSettings['lowPWM'] . "\n";
    }
}

// �B�z�t�m�]�m (0xFB)
function handleConfigSettings($data) {
    global $steerConfig;
    
    if (strlen($data) >= 14) {
        $settings0 = ord($data[5]);
        
        $steerConfig['InvertWAS'] = ($settings0 & 0x01) ? 1 : 0;
        $steerConfig['IsRelayActiveHigh'] = ($settings0 & 0x02) ? 1 : 0;
        $steerConfig['MotorDriveDirection'] = ($settings0 & 0x04) ? 1 : 0;
        $steerConfig['SingleInputWAS'] = ($settings0 & 0x08) ? 1 : 0;
        $steerConfig['CytronDriver'] = ($settings0 & 0x10) ? 1 : 0;
        $steerConfig['SteerSwitch'] = ($settings0 & 0x20) ? 1 : 0;
        $steerConfig['SteerButton'] = ($settings0 & 0x40) ? 1 : 0;
        $steerConfig['ShaftEncoder'] = ($settings0 & 0x80) ? 1 : 0;
        
        $steerConfig['PulseCountMax'] = ord($data[6]);
        
        $settings1 = ord($data[8]);
        $steerConfig['IsDanfoss'] = ($settings1 & 0x01) ? 1 : 0;
        $steerConfig['PressureSensor'] = ($settings1 & 0x02) ? 1 : 0;
        $steerConfig['CurrentSensor'] = ($settings1 & 0x04) ? 1 : 0;
        $steerConfig['IsUseY_Axis'] = ($settings1 & 0x08) ? 1 : 0;
        
        echo "Updated config settings - InvertWAS: " . $steerConfig['InvertWAS'] . 
             ", CytronDriver: " . $steerConfig['CytronDriver'] . 
             ", PulseCountMax: " . $steerConfig['PulseCountMax'] . "\n";
    }
}

// �B�z IP �]�m (201)
function handleIPSettings($data) {
    if (strlen($data) >= 10 && ord($data[4]) == 5 && ord($data[5]) == 201 && ord($data[6]) == 201) {
        $ip1 = ord($data[7]);
        $ip2 = ord($data[8]);
        $ip3 = ord($data[9]);
        
        echo "Received IP settings: " . $ip1 . "." . $ip2 . "." . $ip3 . ".X\n";
        // �b��ڳ]�Ƥ��|�O�s�� EEPROM �í���
    }
}

// �o�e Hello �^��
function sendHelloResponse($remoteIP) {
    global $socket, $localIP, $serverPort, $steerAngleActual, $steerSwitch, $workSwitch;
    
    $sa = (int)($steerAngleActual * 100);
    $response = pack('C*', 0x80, 0x81, 0x7E, 0x7E, 5);
    $response .= pack('v', $sa);
    $response .= pack('v', 0); // ��m
    $response .= pack('C', ($workSwitch << 2) | ($steerSwitch << 1) | 1);
    $response .= pack('C', 0); // ����M����
    
    // �p�����M
    $checksum = 0;
    for ($i = 2; $i < strlen($response) - 1; $i++) {
        $checksum += ord($response[$i]);
    }
    $response[strlen($response) - 1] = chr($checksum & 0xFF);
    
    socket_sendto($socket, $response, strlen($response), 0, $remoteIP, $serverPort);
    echo "Sent Hello response\n";
}

// �o�e WhoAmI �^��
function sendWhoAmIResponse($remoteIP) {
    global $socket, $localIP;
    
    $response = pack('C*', 0x80, 0x81, $localIP[3], 203, 7);
    $response .= pack('C*', $localIP[0], $localIP[1], $localIP[2], $localIP[3]);
    $response .= pack('C*', explode('.', $remoteIP)[0], explode('.', $remoteIP)[1], explode('.', $remoteIP)[2]);
    $response .= pack('C', 23); // �ݤf
    $response .= pack('C', 0); // ����M����
    
    // �p�����M
    $checksum = 0;
    for ($i = 2; $i < strlen($response) - 1; $i++) {
        $checksum += ord($response[$i]);
    }
    $response[strlen($response) - 1] = chr($checksum & 0xFF);
    
    socket_sendto($socket, $response, strlen($response), 0, $broadcastIP, 9999);
    echo "Sent WhoAmI response\n";
}

// �o�e��V�ƾ� (253)
function sendSteerData() {
    global $socket, $broadcastIP, $serverPort, $steerAngleActual, $steerSwitch, $workSwitch, $pwmDrive, $watchdogTimer;
    
    $sa = (int)($steerAngleActual * 100);
    $response = pack('C*', 0x80, 0x81, 0x7E, 0xFD, 8);
    $response .= pack('v', $sa); // �����V����
    $response .= pack('v', 9999); // ��V
    $response .= pack('v', 8888); // �u��
    $response .= pack('C', ($workSwitch << 2) | ($steerSwitch << 1) | 1); // �}�����A
    $response .= pack('C', abs($pwmDrive)); // PWM ���
    $response .= pack('C', 0); // ����M����
    
    // �p�����M
    $checksum = 0;
    for ($i = 2; $i < strlen($response) - 1; $i++) {
        $checksum += ord($response[$i]);
    }
    $response[strlen($response) - 1] = chr($checksum & 0xFF);
    
    socket_sendto($socket, $response, strlen($response), 0, $broadcastIP, $serverPort);
    echo "Sent steer data - Angle: " . $steerAngleActual . "�X, PWM: " . $pwmDrive . 
         ", Watchdog: " . $watchdogTimer . "\n";
}

// �o�e�ǷP���ƾ� (250)
function sendSensorData() {
    global $socket, $broadcastIP, $serverPort, $sensorReading;
    
    $response = pack('C*', 0x80, 0x81, 0x7E, 0xFA, 8);
    $response .= pack('C', $sensorReading); // �ǷP��Ū��
    $response .= pack('C*', 0, 0, 0, 0, 0, 0); // ��R
    $response .= pack('C', 0); // ����M����
    
    // �p�����M
    $checksum = 0;
    for ($i = 2; $i < strlen($response) - 1; $i++) {
        $checksum += ord($response[$i]);
    }
    $response[strlen($response) - 1] = chr($checksum & 0xFF);
    
    socket_sendto($socket, $response, strlen($response), 0, $broadcastIP, $serverPort);
    echo "Sent sensor data: " . $sensorReading . "\n";
}
?>