<?php
/**
 * AgOpenGPS UDP Autosteer Simulator
 * Combines complete Autosteer functionality with full PGN protocol support
 * Usage: php agopengps_autosteer_simulator.php [--ip=192.168.5.255]
 */

// Error reporting setup
error_reporting(E_ALL & ~E_WARNING);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

// Calculate checksum (consistent with original C# logic)
function calculateChecksum($data) {
    $checksum = 0;
    for ($i = 2; $i < strlen($data) - 1; $i++) {
        $checksum += ord($data[$i]);
    }
    return chr($checksum & 0xFF);
}

// Configuration and parameters
$options = getopt('', ['ip::']);
$local_ip = '0.0.0.0';
$local_port = 8888;
$remote_ip = $options['ip'] ?? '192.168.5.255';
$remote_port = 9999;

// Create and configure UDP socket
$socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
socket_set_option($socket, SOL_SOCKET, SO_REUSEADDR, 1);
socket_set_option($socket, SOL_SOCKET, SO_BROADCAST, 1);
socket_bind($socket, $local_ip, $local_port);

// Autosteer parameters
$steerSettings = [
    'Kp' => 120,
    'lowPWM' => 30,
    'highPWM' => 160,
    'minPWM' => 25,
    'steerSensorCounts' => 30,
    'wasOffset' => 0,
    'AckermanFix' => 1.0
];

$steerConfig = [
    'InvertWAS' => 0,
    'IsRelayActiveHigh' => 0,
    'MotorDriveDirection' => 0,
    'SingleInputWAS' => 1,
    'CytronDriver' => 1,
    'SteerSwitch' => 0,
    'SteerButton' => 0,
    'ShaftEncoder' => 0,
    'PressureSensor' => 0,
    'CurrentSensor' => 0,
    'PulseCountMax' => 5,
    'IsDanfoss' => 0,
    'IsUseX_Axis' => 0
];

// Simulation variables
$steerAngleActual = 0.0;
$steerAngleSetPoint = 0.0;
$guidanceStatus = 0;
$watchdogTimer = 0;
$pwmDrive = 0;
$sensorReading = 0;
$helloSteerPosition = 0;
$switchByte = 0;
$correctionCount = 0;
$simulatedHeading = 180.0;
$simulatedRoll = 0.0;
$imuYaw = 0.0;
$imuRoll = 0.0;
$imuPitch = 0.0;
$workSwitch = 1;
$steerSwitch = 1;
$relayState = 0;

// PGN response templates
$pgnCache = [
    253 => "\x80\x81\x7E\xFD\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00",
    126 => "\x80\x81\x7E\x7E\x05\x00\x00\x00\x00\x00\x47",
    123 => "\x80\x81\x7B\x7B\x05\x00\x00\x00\x00\x00\x47",
    121 => "\x80\x81\x7F\x79\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00"
];

echo "Autosteer Simulator started\n";
echo "Listening on $local_ip:$local_port\n";
echo "Broadcasting to $remote_ip:$remote_port\n\n";

// Main loop
while (true) {
    // Receive data
    $from = '';
    $port = 0;
    $data = '';
    if (@socket_recvfrom($socket, $data, 2048, 0, $from, $port) !== false) {
        if (strlen($data) > 0) {
            $bytes = unpack('C*', $data);
            processPacket($bytes, $from, $port);
        }
    }

    // Simulate periodic updates
    usleep(100000); // 100ms
    simulateSteering();
}

function processPacket($bytes, $from, $port) {
    global $socket, $remote_ip, $remote_port, $steerSettings, $steerConfig;
    global $steerAngleActual, $steerAngleSetPoint, $guidanceStatus, $watchdogTimer;
    global $pwmDrive, $sensorReading, $helloSteerPosition, $switchByte;
    global $simulatedHeading, $simulatedRoll, $imuYaw, $imuRoll, $imuPitch;
    global $workSwitch, $steerSwitch, $relayState, $pgnCache;

    // Check packet header
    if (count($bytes) >= 4 && $bytes[1] == 128 && $bytes[2] == 129) {
        $pgn = $bytes[4];
        $response = null;

        switch ($pgn) {
            case 100: // Steering control command
                if (count($bytes) >= 8) {
                    $steerAngleSetPoint = (($bytes[6] << 8) | $bytes[5]) * 0.01;
                    $guidanceStatus = $bytes[7];
                }
                break;

            case 200: // Heartbeat
                // Update IMU simulation
                $imuRoll = rand(-200, 200) / 10.0;
                $imuPitch = rand(-100, 100) / 10.0;
                $imuYaw = fmod($imuYaw + rand(-5, 5) / 100.0, 360.0);

                // Build IMU heartbeat (PGN 121)
                $pgn121 = $pgnCache[121];
                $yawValue = (int)($imuYaw * 10);
                $pgn121[5] = chr($yawValue & 0xFF);
                $pgn121[6] = chr(($yawValue >> 8) & 0xFF);
                $pgn121[13] = calculateChecksum($pgn121);

                $response = [
                    $pgnCache[126],  // AutoSteer
                    $pgnCache[123],  // Machine
                    $pgn121         // IMU
                ];
                break;

            case 240: // IMU data request
                $pgn241 = "\x80\x81\x7F\xF1\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00";
                $rollInt = (int)($imuRoll * 10);
                $pitchInt = (int)($imuPitch * 10);
                $pgn241[5] = chr($rollInt & 0xFF);
                $pgn241[6] = chr(($rollInt >> 8) & 0xFF);
                $pgn241[7] = chr($pitchInt & 0xFF);
                $pgn241[8] = chr(($pitchInt >> 8) & 0xFF);
                $pgn241[13] = calculateChecksum($pgn241);
                $response = $pgn241;
                break;

            case 254: // Navigation control
                if (count($bytes) >= 13) {
                    $gpsSpeed = (($bytes[6] << 8) | $bytes[5]) * 0.1;
                    $guidanceStatus = $bytes[7];
                    $steerAngleSetPoint = (($bytes[9] << 8) | $bytes[8]) * 0.01;
                    $relayState = $bytes[11];

                    // Build PGN 253 response
                    $pgn253 = $pgnCache[253];
                    $angle = (int)($steerAngleActual * 100);
                    $heading10x = (int)($simulatedHeading * 10);
                    $roll10x = (int)($simulatedRoll * 10);
                    
                    $pgn253[5] = chr($angle & 0xFF);
                    $pgn253[6] = chr(($angle >> 8) & 0xFF);
                    $pgn253[7] = chr($heading10x & 0xFF);
                    $pgn253[8] = chr(($heading10x >> 8) & 0xFF);
                    $pgn253[9] = chr($roll10x & 0xFF);
                    $pgn253[10] = chr(($roll10x >> 8) & 0xFF);
                    $pgn253[11] = chr($switchByte);
                    $pgn253[12] = chr($pwmDrive);
                    $pgn253[13] = calculateChecksum($pgn253);
                    $response = $pgn253;

                    // Send sensor data occasionally (PGN 250)
                    if (rand(0, 2) == 0) {
                        $pgn250 = pack('C*', 128, 129, 126, 250, 8, $sensorReading, 0, 0, 0, 0, 0, 0);
                        $pgn250 .= calculateChecksum($pgn250);
                        socket_sendto($socket, $pgn250, strlen($pgn250), 0, $remote_ip, $remote_port);
                    }
                }
                break;

            case 252: // PID settings
                if (count($bytes) >= 14) {
                    $steerSettings['Kp'] = $bytes[5];
                    $steerSettings['highPWM'] = $bytes[6];
                    $steerSettings['lowPWM'] = $bytes[7];
                    $steerSettings['minPWM'] = $bytes[8];
                    $steerSettings['steerSensorCounts'] = $bytes[9];
                    $steerSettings['wasOffset'] = ($bytes[11] << 8) | $bytes[10];
                    $steerSettings['AckermanFix'] = $bytes[12] * 0.01;
                }
                break;

            case 251: // Configuration
                if (count($bytes) >= 14) {
                    $sett = $bytes[5];
                    $steerConfig['InvertWAS'] = ($sett & 0x01) ? 1 : 0;
                    $steerConfig['IsRelayActiveHigh'] = ($sett & 0x02) ? 1 : 0;
                    $steerConfig['MotorDriveDirection'] = ($sett & 0x04) ? 1 : 0;
                    $steerConfig['SingleInputWAS'] = ($sett & 0x08) ? 1 : 0;
                    $steerConfig['CytronDriver'] = ($sett & 0x10) ? 1 : 0;
                    $steerConfig['SteerSwitch'] = ($sett & 0x20) ? 1 : 0;
                    $steerConfig['SteerButton'] = ($sett & 0x40) ? 1 : 0;
                    $steerConfig['ShaftEncoder'] = ($sett & 0x80) ? 1 : 0;
                    $steerConfig['PulseCountMax'] = $bytes[6];
                    
                    $sett = $bytes[8];
                    $steerConfig['IsDanfoss'] = ($sett & 0x01) ? 1 : 0;
                    $steerConfig['PressureSensor'] = ($sett & 0x02) ? 1 : 0;
                    $steerConfig['CurrentSensor'] = ($sett & 0x04) ? 1 : 0;
                    $steerConfig['IsUseX_Axis'] = ($sett & 0x08) ? 1 : 0;
                }
                break;

            case 202: // Scan request
                if ($bytes[5] == 3 && $bytes[6] == 202 && $bytes[7] == 202) {
                    $fromParts = explode('.', $from);
                    $scanReply = pack('C*', 128, 129, 126, 203, 7, 192, 168, 5, 126,
                        $fromParts[0], $fromParts[1], $fromParts[2], 23);
                    $scanReply .= calculateChecksum($scanReply);
                    $response = $scanReply;
                }
                break;
        }

        // Send response
        if ($response) {
            if (is_array($response)) {
                foreach ($response as $packet) {
                    socket_sendto($socket, $packet, strlen($packet), 0, $remote_ip, $remote_port);
                }
            } else {
                socket_sendto($socket, $response, strlen($response), 0, $remote_ip, $remote_port);
            }
        }
    }
}

function simulateSteering() {
    global $steerSettings, $steerConfig, $steerAngleActual, $steerAngleSetPoint;
    global $guidanceStatus, $pwmDrive, $correctionCount, $simulatedHeading;
    global $simulatedRoll, $helloSteerPosition, $sensorReading, $switchByte;

    if ($guidanceStatus == 1) {
        $error = $steerAngleSetPoint - $steerAngleActual;
        $absError = abs($error);
        
        $pValue = $steerSettings['Kp'] * $error;
        
        if ($absError < 3.0) {
            $newMax = ($absError * (($steerSettings['highPWM'] - $steerSettings['lowPWM']) / 3.0)) + $steerSettings['lowPWM'];
        } else {
            $newMax = $steerSettings['highPWM'];
        }
        
        if ($pValue < 0) $pValue -= $steerSettings['minPWM'];
        else if ($pValue > 0) $pValue += $steerSettings['minPWM'];
        
        $pwmDrive = max(min($pValue, $newMax), -$newMax);
        
        if ($steerConfig['MotorDriveDirection']) {
            $pwmDrive *= -1;
        }
        
        if ($steerConfig['IsDanfoss']) {
            $pwmDrive = max(min($pwmDrive, 250), -250);
            $pwmDrive = ($pwmDrive / 4) + 128;
        }
        
        $movement = $pwmDrive * 0.01;
        $steerAngleActual += $movement;
        
        if ($correctionCount < 5) {
            $steerAngleActual += ($error * 0.2 * (5 - $correctionCount) / 5);
            $correctionCount++;
        } else {
            $steerAngleActual = $steerAngleSetPoint + (rand(-10, 10) / 100.0);
        }
        
        $simulatedHeading += (rand(-5, 5) / 10.0);
        if ($simulatedHeading < 0) $simulatedHeading += 360;
        if ($simulatedHeading >= 360) $simulatedHeading -= 360;
        
        $simulatedRoll = max(min($simulatedRoll + (rand(-3, 3) / 10.0), 15), -15);
        
        $helloSteerPosition = (int)($steerAngleActual * 100);
        $sensorReading = rand(0, 100);
        $switchByte = rand(0, 7);
        
        echo "Correction: $correctionCount, Actual: " . round($steerAngleActual, 2) . 
             "�X, SetPoint: " . round($steerAngleSetPoint, 2) . 
             "�X, PWM: $pwmDrive, Heading: " . round($simulatedHeading, 1) . "�X\n";
    } else {
        $correctionCount = 0;
        $pwmDrive = 0;
    }
}

// Close socket (unreachable in infinite loop)
socket_close($socket);
?>