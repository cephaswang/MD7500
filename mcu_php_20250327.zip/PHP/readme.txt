設備回應，autosteer_simulator.php 請附加上，需參考原有提供的三個源碼協議。Autosteer_UDP_v5.ino
AutosteerPID.ino
AutosteerRelays.ino


請依照附件三個檔案，生成相容的 php sheel 程式，供上位機測試。UDP ，設備問答，方向修正。參數調整。等相關全部對話。含生成誤差，經5次修正後完成，並持續運行，誤差與修正。


https://www.youtube.com/watch?v=Cpk947Xf-5I&list=PL1N2N2XFHWW1fIDhb7koOa7hxH0LGppYc&index=5



https://www.youtube.com/watch?v=kb54ZQuGYJE
UDP and Ethernet Setup In AgIO

https://www.youtube.com/watch?v=iaR2L3Cnu_A
UDP Network and AgOpenGPS

