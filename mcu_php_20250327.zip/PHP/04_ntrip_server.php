<?php
/**
 * 簡易 NTRIP Server 模擬器（Windows 兼容版本，支持 Source Table）
 * 使用方式: php ntrip_server.php
 */

class NtripServer {
    private $host = '0.0.0.0'; // 接受所有接口連接
    private $port = 2101;
    private $server;
    private $clients = [];
    
    private $auth = [
        'user1' => 'pass1',
        'user2' => 'pass2'
    ];
    private $mountpoints = [
        'RTCM32' => [
            'description' => '模擬的RTCM3.2數據流',
            'format' => 'RTCM 3.2',
            'carrier' => 'L1+L2',
            'position' => '23.12;120.34;100'
        ],
        'RTCM30' => [
            'description' => '模擬的RTCM3.0數據流',
            'format' => 'RTCM 3.0',
            'carrier' => 'L1',
            'position' => '23.12;120.34;100'
        ]
    ];
    
    public function __construct() {
        set_time_limit(0); // 移除腳本執行時間限制
        
        $this->server = @stream_socket_server("tcp://{$this->host}:{$this->port}", $errno, $errstr);
        
        if (!$this->server) {
            die("無法創建伺服器: $errstr ($errno)\n");
        }
        
        stream_set_blocking($this->server, false); // 非阻塞模式
        
        echo "NTRIP 伺服器已啟動在 {$this->host}:{$this->port}\n";
        echo "可用掛載點: " . implode(', ', array_keys($this->mountpoints)) . "\n";
    }
    
    public function run() {
        while (true) {
            $read = [$this->server];
            $write = null;
            $except = null;
            
            if (stream_select($read, $write, $except, 1) > 0) {
                $client = @stream_socket_accept($this->server, 0);
                if ($client) {
                    stream_set_blocking($client, true);
                    $clientId = (int)$client;
                    $this->clients[$clientId] = $client;
                    $this->handleClient($client);
                }
            }
            
            usleep(10000); // 防止 CPU 使用率過高
        }
    }
    
    private function handleClient($client) {
        $clientIp = stream_socket_get_name($client, true) ?: '未知IP';
        echo "新客戶端連接: {$clientIp}\n";
        
        $headers = [];
        $request = '';
        $timeout = time() + 10;
        
        while (time() < $timeout) {
            $line = @fgets($client);
            if ($line === false) break;
            if ($line == "\r\n") break;
            
            $request .= $line;
            if (preg_match('/^([^:]+):\s*(.*)$/', $line, $matches)) {
                $headers[strtolower($matches[1])] = trim($matches[2]);
            }
        }
        
        if (empty($request)) {
            $this->closeClient($client);
            return;
        }
        
        echo "請求內容:\n{$request}\n";
        
        if (preg_match('/^GET\s+\/\s+HTTP/i', $request)) {
            $this->sendSourceTable($client);
            $this->closeClient($client);
            return;
        }
        
        if (!isset($headers['authorization'])) {
            $this->sendResponse($client, "ICY 401 Unauthorized\r\n\r\n");
            $this->closeClient($client);
            return;
        }
        
        if (!preg_match('/^Basic\s+(.+)$/i', $headers['authorization'], $matches)) {
            $this->sendResponse($client, "ICY 401 Unauthorized\r\n\r\n");
            $this->closeClient($client);
            return;
        }
        
        $credentials = base64_decode($matches[1]);
        list($username, $password) = array_pad(explode(':', $credentials, 2), 2, '');
        
        if (!isset($this->auth[$username]) || $this->auth[$username] != $password) {
            $this->sendResponse($client, "ICY 401 Unauthorized\r\n\r\n");
            $this->closeClient($client);
            return;
        }
        
        echo "用戶 {$username} 認證成功\n";
        
        $mountpoint = '';
        if (preg_match('/^GET\s+\/(\w+)\s+/i', $request, $matches)) {
            $mountpoint = $matches[1];
        }
        
        if (!isset($this->mountpoints[$mountpoint])) {
            $this->sendResponse($client, "ICY 404 Not Found\r\n\r\n");
            $this->closeClient($client);
            return;
        }
        
        echo "客戶端請求掛載點: {$mountpoint}\n";
        $this->sendResponse($client, "ICY 200 OK\r\n\r\n");
        
        $counter = 0;
        while (is_resource($client) && !feof($client)) {
            $data = $this->mountpoints[$mountpoint]['description'] . " - " . date('Y-m-d H:i:s') . " - " . (++$counter) . "\n";
            if (@fwrite($client, $data) === false) {
                break;
            }
            fflush($client);
            sleep(1);
        }
        
        echo "客戶端斷開連接\n";
        $this->closeClient($client);
    }
    
    private function sendSourceTable($client) {
        $response = "SOURCETABLE 200 OK\r\n";
        $response .= "Server: NTRIP SimpleServer/1.0\r\n";
        $response .= "Content-Type: text/plain\r\n\r\n";
        
        foreach ($this->mountpoints as $mount => $info) {
            $response .= sprintf(
                "STR;%s;%s;%s;%s;0;NONE;0;0;%s\r\n",
                $mount,
                $mount,
                $info['format'],
                $info['carrier'],
                $info['position']
            );
        }
        
        $response .= "ENDSOURCETABLE\r\n";
        
        $this->sendResponse($client, $response);
    }
    
    private function sendResponse($client, $response) {
        if (is_resource($client)) {
            @fwrite($client, $response);
            echo "發送響應: {$response}";
        }
    }
    
    private function closeClient($client) {
        if (is_resource($client)) {
            $clientId = (int)$client;
            fclose($client);
            unset($this->clients[$clientId]);
        }
    }
    
    public function __destruct() {
        if (is_resource($this->server)) {
            fclose($this->server);
        }
        foreach ($this->clients as $client) {
            if (is_resource($client)) {
                fclose($client);
            }
        }
    }
}

try {
    $server = new NtripServer();
    $server->run(); // 這裡調用 run() 方法
} catch (Exception $e) {
    echo "錯誤: " . $e->getMessage() . "\n";
}
?>