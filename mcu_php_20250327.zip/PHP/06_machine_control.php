<?php
// Machine Control - PHP Simulation for Testing with AgOpenGPS
// Date: March 27, 2025

// ���� EEPROM �x�s�A�ϥ��ɮץN��
define('EEP_IDENT', 0x5425);
define('EEPROM_FILE', 'eeprom_sim.dat');

// �����t�m
class ConfigIP {
    public $ipOne = 192;
    public $ipTwo = 168;
    public $ipThree = 5;
}
$networkAddress = new ConfigIP();

// �H�Ӻ������Ѽ�
$myip = [0, 0, 0, 123];
$gwip = [0, 0, 0, 1];
$myDNS = [8, 8, 8, 8];
$mask = [255, 255, 255, 0];
$portMy = 5123;
$ipDestination = [0, 0, 0, 255];
$portDestination = 9999;
$mymac = [0x00, 0x00, 0x56, 0x00, 0x00, 0x7B];

// �t�m�Ѽ�
class Config {
    public $raiseTime = 2;
    public $lowerTime = 4;
    public $enableToolLift = 0;
    public $isRelayActiveHigh = 0;
    public $user1 = 0;
    public $user2 = 0;
    public $user3 = 0;
    public $user4 = 0;
}
$aogConfig = new Config();

// �����޸}�M�~�q�����A
$pin = array_fill(0, 24, 0); // 24 �Ӥ޸}��l�� 0
$relayState = array_fill(0, 24, 0);

// ���� AgIO �� Hello �T��
$helloFromMachine = [128, 129, 123, 123, 5, 0, 0, 0, 0, 0, 71];

// �ɶ�����
const LOOP_TIME = 200; // 200ms ���� 5Hz
$lastTime = 0;
$watchdogTimer = 20;
$serialResetTimer = 0;
$isRaise = false;
$isLower = false;

// �ܼ��x�s
$relayHi = 0;
$relayLo = 0;
$tramline = 0;
$uTurn = 0;
$hydLift = 0;
$geoStop = 0;
$gpsSpeed = 0.0;
$raiseTimer = 0;
$lowerTimer = 0;
$lastTrigger = 0;

// PGN_237 �Ω�o�e���A
$PGN_237 = [0x80, 0x81, 0x7f, 237, 8, 1, 2, 3, 4, 0, 0, 0, 0, 0xCC];
$PGN_237_Size = count($PGN_237) - 1;

// UDP �M���r��l��
$socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
socket_bind($socket, '0.0.0.0', 8888);

// ���� EEPROM Ū���P�g�J
function loadEEPROM() {
    global $aogConfig, $pin, $networkAddress;
    if (!file_exists(EEPROM_FILE)) {
        file_put_contents(EEPROM_FILE, pack('v', EEP_IDENT) . serialize([$aogConfig, $pin, $networkAddress]));
    } else {
        $data = file_get_contents(EEPROM_FILE);
        $eeRead = unpack('v', substr($data, 0, 2))[1];
        if ($eeRead !== EEP_IDENT) {
            file_put_contents(EEPROM_FILE, pack('v', EEP_IDENT) . serialize([$aogConfig, $pin, $networkAddress]));
        } else {
            [$aogConfig, $pin, $networkAddress] = unserialize(substr($data, 2));
        }
    }
}

function saveEEPROM($data) {
    file_put_contents(EEPROM_FILE, pack('v', EEP_IDENT) . serialize($data));
}

// �]�m����
function setup() {
    global $myip, $gwip, $ipDestination, $networkAddress, $socket;
    loadEEPROM();

    $myip[0] = $networkAddress->ipOne;
    $myip[1] = $networkAddress->ipTwo;
    $myip[2] = $networkAddress->ipThree;

    $gwip[0] = $networkAddress->ipOne;
    $gwip[1] = $networkAddress->ipTwo;
    $gwip[2] = $networkAddress->ipThree;

    $ipDestination[0] = $networkAddress->ipOne;
    $ipDestination[1] = $networkAddress->ipTwo;
    $ipDestination[2] = $networkAddress->ipThree;

    echo "Setup complete, waiting for AgOpenGPS\n";
    echo "IP: " . implode('.', $myip) . "\n";
    echo "Gateway: " . implode('.', $gwip) . "\n";
    echo "Destination: " . implode('.', $ipDestination) . "\n";
}

// �����~�q���]�m
function setRelays() {
    global $relayState, $relayLo, $relayHi, $tramline, $isLower, $isRaise, $geoStop, $gpsSpeed, $pin;

    $gpsSpeed *= 3.61111; // �����t�׭p��
    for ($i = 0; $i < 8; $i++) {
        $relayState[$i] = ($relayLo >> $i) & 1;
        $relayState[$i + 8] = ($relayHi >> $i) & 1;
    }

    $relayState[16] = $isLower ? 1 : 0;
    $relayState[17] = $isRaise ? 1 : 0;
    $relayState[18] = ($tramline >> 0) & 1; // right
    $relayState[19] = ($tramline >> 1) & 1; // left
    $relayState[20] = $geoStop ? 1 : 0;

    // �����޸}��X
    $output = "Relay State: " . implode(',', $relayState) . "\n";
    // file_put_contents('relay_log.txt', $output, FILE_APPEND);
    file_put_contents('relay_log.txt', $output);
}

// UDP �o�e����
function sendUdp($data, $ip, $port) {
    global $socket;
    $packet = implode(array_map('chr', $data));
    socket_sendto($socket, $packet, strlen($packet), 0, implode('.', $ip), $port);
}

// �D�`��
function loop() {
    global $lastTime, $watchdogTimer, $serialResetTimer, $hydLift, $lastTrigger, $raiseTimer, $lowerTimer, 
           $aogConfig, $isRaise, $isLower, $relayLo, $relayHi, $PGN_237, $PGN_237_Size, $ipDestination, 
           $portDestination, $socket;

    $currentTime = microtime(true) * 1000; // �@��
    if ($currentTime - $lastTime >= LOOP_TIME) {
        $lastTime = $currentTime;

        if (++$watchdogTimer > 250) $watchdogTimer = 20;
        if (++$serialResetTimer > 20) $serialResetTimer = 0;

        if ($watchdogTimer > 20) {
            $relayLo = $aogConfig->isRelayActiveHigh ? 255 : 0;
            $relayHi = $aogConfig->isRelayActiveHigh ? 255 : 0;
        }

        if ($hydLift != $lastTrigger && ($hydLift == 1 || $hydLift == 2)) {
            $lastTrigger = $hydLift;
            $lowerTimer = 0;
            $raiseTimer = 0;
            if ($hydLift == 1) $lowerTimer = $aogConfig->lowerTime * 5;
            if ($hydLift == 2) $raiseTimer = $aogConfig->raiseTime * 5;
        }

        if ($raiseTimer) $raiseTimer--;
        if ($lowerTimer) $lowerTimer--;

        if ($hydLift != 1 && $hydLift != 2 || $watchdogTimer > 10) {
            $lowerTimer = $raiseTimer = $lastTrigger = 0;
        }

        $isLower = $isRaise = $aogConfig->isRelayActiveHigh ? false : true;
        if ($lowerTimer) $isLower = !$aogConfig->isRelayActiveHigh;
        if ($raiseTimer) $isRaise = !$aogConfig->isRelayActiveHigh;

        setRelays();

        $CK_A = 0;
        for ($i = 2; $i < $PGN_237_Size; $i++) {
            $CK_A += $PGN_237[$i];
        }
        $PGN_237[$PGN_237_Size] = $CK_A & 0xFF;

        sendUdp($PGN_237, $ipDestination, $portDestination);
    }

    // ���� UDP ����
    socket_set_nonblock($socket);
    $from = '';
    $port = 0;
    if (@socket_recvfrom($socket, $buf, 200, 0, $from, $port) !== false) {
        $udpData = array_map('ord', str_split($buf));
        udpSteerRecv($udpData, count($udpData));
    }
}

// UDP �����B�z
function udpSteerRecv($udpData, $len) {
    global $uTurn, $gpsSpeed, $hydLift, $tramline, $relayLo, $relayHi, $watchdogTimer, $aogConfig, 
           $helloFromMachine, $ipDestination, $portDestination, $networkAddress, $pin;

    if ($udpData[0] == 0x80 && $udpData[1] == 0x81 && $udpData[2] == 0x7F) {
        if ($udpData[3] == 239) { // Machine data
            $uTurn = $udpData[5];
            $gpsSpeed = (float)$udpData[6];
            $hydLift = $udpData[7];
            $tramline = $udpData[8];
            $relayLo = $udpData[11];
            $relayHi = $udpData[12];

            if ($aogConfig->isRelayActiveHigh) {
                $tramline = 255 - $tramline;
                $relayLo = 255 - $relayLo;
                $relayHi = 255 - $relayHi;
            }
            $watchdogTimer = 0;
        } elseif ($udpData[3] == 200) { // Hello from AgIO
            if ($udpData[7] == 1) {
                $relayLo -= 255;
                $relayHi -= 255;
                $watchdogTimer = 0;
            }
            $helloFromMachine[5] = $relayLo;
            $helloFromMachine[6] = $relayHi;
            sendUdp($helloFromMachine, $ipDestination, $portDestination);
        } elseif ($udpData[3] == 238) { // Settings
            $aogConfig->raiseTime = $udpData[5];
            $aogConfig->lowerTime = $udpData[6];
            $aogConfig->enableToolLift = $udpData[7];
            $sett = $udpData[8];
            $aogConfig->isRelayActiveHigh = ($sett & 1) ? 1 : 0;
            $aogConfig->user1 = $udpData[9];
            $aogConfig->user2 = $udpData[10];
            $aogConfig->user3 = $udpData[11];
            $aogConfig->user4 = $udpData[12];
            saveEEPROM([$aogConfig, $pin, $networkAddress]);
        } elseif ($udpData[3] == 201) { // Subnet
            if ($udpData[4] == 5 && $udpData[5] == 201 && $udpData[6] == 201) {
                $networkAddress->ipOne = $udpData[7];
                $networkAddress->ipTwo = $udpData[8];
                $networkAddress->ipThree = $udpData[9];
                saveEEPROM([$aogConfig, $pin, $networkAddress]);
            }
        } elseif ($udpData[3] == 202) { // Scan Reply
            if ($udpData[4] == 3 && $udpData[5] == 202 && $udpData[6] == 202) {
                $scanReply = [128, 129, 123, 203, 7, 
                    $networkAddress->ipOne, $networkAddress->ipTwo, $networkAddress->ipThree, 123,
                    $udpData[0], $udpData[1], $udpData[2], 23];
                $CK_A = 0;
                for ($i = 2; $i < count($scanReply) - 1; $i++) {
                    $CK_A += $scanReply[$i];
                }
                $scanReply[count($scanReply) - 1] = $CK_A & 0xFF;
                sendUdp($scanReply, [255, 255, 255, 255], 9999);
            }
        } elseif ($udpData[3] == 236) { // Relay Pin Settings
            for ($i = 0; $i < 24; $i++) {
                $pin[$i] = $udpData[$i + 5];
            }
            saveEEPROM([$aogConfig, $pin, $networkAddress]);
        }
    }
}

// �������
setup();
while (true) {
    loop();
    usleep(1000); // ��������
}

socket_close($socket);
?>