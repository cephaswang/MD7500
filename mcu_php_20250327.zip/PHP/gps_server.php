<?php
// 创建UDP socket
$socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
if ($socket === false) {
    die("无法创建socket: " . socket_strerror(socket_last_error()));
}

// 绑定到2233端口
if (!socket_bind($socket, '0.0.0.0', 2233)) {
    die("无法绑定socket: " . socket_strerror(socket_last_error()));
}

echo "UDP GPS模拟服务器已启动，监听端口2233...\n";

// 模拟的GPS坐标 (可以修改为实际需要的数据)
$baseLat = 39.9042;  // 北京纬度
$baseLng = 116.4074; // 北京经度
$offset = 0.001;     // 偏移量，用于模拟移动

while (true) {
    // 接收客户端请求 (UDP是无连接的，所以这里只是接收数据)
    $from = '';
    $port = 0;
    socket_recvfrom($socket, $buf, 1024, 0, $from, $port);
    
    echo "收到来自 {$from}:{$port} 的请求\n";
    
    // 模拟GPS位置变化
    $currentLat = $baseLat + (rand(-100, 100) * $offset / 100);
    $currentLng = $baseLng + (rand(-100, 100) * $offset / 100);
    $speed = rand(0, 120); // 随机速度 0-120 km/h
    $timestamp = date('Y-m-d H:i:s');
    
    // 构建GPS数据格式 (这里使用简单的CSV格式，可以根据需要修改)
    $gpsData = sprintf(
        "%s,%.6f,%.6f,%.1f",
        $timestamp,
        $currentLat,
        $currentLng,
        $speed
    );
    
    // 发送模拟的GPS数据回客户端
    socket_sendto($socket, $gpsData, strlen($gpsData), 0, $from, $port);
    
    echo "已发送GPS数据: {$gpsData}\n";
}

// 关闭socket (实际上上面的循环是无限的，这里不会执行到)
socket_close($socket);
?>