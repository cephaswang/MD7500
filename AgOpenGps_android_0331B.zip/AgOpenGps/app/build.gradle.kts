plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.agopengps.drive"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.agopengps.drive"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    // 基础 Android 库
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)

    // OpenGL ES 2.0 核心支持
    implementation ("androidx.opengl:opengl:1.1.0-alpha05") // GLES20 接口
    implementation ("androidx.opengl:opengl-android:1.0.0") // GLSurfaceView 支持

    // Google Maps
    implementation ("com.google.android.gms:play-services-maps:19.1.0")
    implementation ("com.google.android.gms:play-services-location:21.3.0")

    // 生命周期管理
    implementation ("androidx.lifecycle:lifecycle-livedata-ktx:2.8.7")
    implementation ("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.1")

    // 工具库
    implementation ("com.jakewharton.timber:timber:5.0.1")
    implementation ("org.apache.commons:commons-math3:3.6.1")
    implementation(libs.androidx.runtime.saved.instance.state)
    implementation(libs.androidx.navigation.fragment.ktx)
    implementation(libs.androidx.navigation.ui.ktx)

    // 测试
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    // 可选：Multik（如果实际需要）
    implementation ("org.jetbrains.kotlinx:multik-core:0.2.0")
    implementation ("org.jetbrains.kotlinx:multik-default:0.2.0")

    implementation ("com.google.android.gms:play-services-maps:18.2.0")
    implementation ("com.google.maps.android:android-maps-utils:3.8.0")
}

