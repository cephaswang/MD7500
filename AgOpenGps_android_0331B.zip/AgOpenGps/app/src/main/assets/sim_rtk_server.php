<?php
// advanced_sim_rtk.php
header('Content-Type: text/plain');
header('Cache-Control: no-cache');

// 驗證
if (!isset($_SERVER['PHP_AUTH_USER']) || $_SERVER['PHP_AUTH_USER'] != 'fieldbee' ||
    $_SERVER['PHP_AUTH_PW'] != 'demo123') {
    header('WWW-Authenticate: Basic realm="FieldBee Advanced Simulator"');
    header('HTTP/1.0 401 Unauthorized');
    die('Authentication required');
}

// 預定義路徑 (矩形地塊)
$path = [
    ['lat' => 25.0330, 'lon' => 121.5654], // 起點
    ['lat' => 25.0335, 'lon' => 121.5654], // 北移
    ['lat' => 25.0335, 'lon' => 121.5660], // 東移
    ['lat' => 25.0330, 'lon' => 121.5660], // 南移
    ['lat' => 25.0330, 'lon' => 121.5654]  // 西移回到起點
];

$current_segment = 0;
$progress = 0; // 當前線段進度 (0-1)
$speed = 1.39; // 5 km/h in m/s
$interval = 1; // 更新間隔

echo "ICY 200 OK\r\n\r\n";

while(true) {
    // 計算當前位置
    $start = $path[$current_segment];
    $end = $path[($current_segment + 1) % count($path)];

    $distance = haversineDistance($start['lat'], $start['lon'], $end['lat'], $end['lon']);
    $step = ($speed * $interval) / $distance;

    $progress += $step;

    if ($progress >= 1) {
        $progress = 0;
        $current_segment = ($current_segment + 1) % (count($path) - 1);
    }

    $lat = $start['lat'] + ($end['lat'] - $start['lat']) * $progress;
    $lon = $start['lon'] + ($end['lon'] - $start['lon']) * $progress;

    // 生成RTCM數據
    echo generateEnhancedRTCM($lat, $lon, time(), 0.01); // 1cm精度

    ob_flush();
    flush();

    if (connection_aborted()) break;
    sleep($interval);
}

// 計算兩點間距離 (米)
function haversineDistance($lat1, $lon1, $lat2, $lon2) {
    $R = 6371000; // 地球半徑(米)
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $a = sin($dLat/2) * sin($dLat/2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLon/2) * sin($dLon/2);
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));
    return $R * $c;
}

// 生成更真實的RTCM數據
function generateEnhancedRTCM($lat, $lon, $timestamp, $accuracy) {
    // 這裡應該使用專業的RTCM生成庫
    // 以下是簡化版本
    $msg = sprintf(
        "SIM-RTCM,%.8f,%.8f,%.2f,%d,%.3f",
        $lat,
        $lon,
        100.0, // 高度
        $timestamp,
        $accuracy
    );

    return $msg . "\r\n";
}
?>