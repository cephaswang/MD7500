﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Drawing;
using System.Globalization;
using System.Diagnostics;
using System.Xml.Linq;
using AgOpenGPS.Culture;
using System.Text;
namespace AgOpenGPS
{
    public partial class FormGPS
    {
        // - App Sockets  -----------------------------------------------------
        private Socket loopBackSocket;
        //endpoints of modules
        private EndPoint epAgIO = new IPEndPoint(IPAddress.Parse("127.255.255.255"), 17777);
        private EndPoint endPointLoopBack = new IPEndPoint(IPAddress.Loopback, 0);
        // Data stream
        private byte[] loopBuffer = new byte[1024];
        // Status delegate
        public int missedSentenceCount = 0;
        public int udpWatchLimit = 70;
        private readonly Stopwatch udpWatch = new Stopwatch();
        private void ReceiveFromAgIO(byte[] data)
        {
            if (data.Length > 4 && data[0] == 0x80 && data[1] == 0x81)
            {
                int Length = Math.Max((data[4]) + 5, 5);
                if (data.Length > Length)
                {
                    byte CK_A = 0;
                    for (int j = 2; j < Length; j++)
                    {
                        CK_A += data[j];
                    }
                    if (data[Length] != (byte)CK_A)
                    {
                        return;
                    }
                }
                else
                {
                    return;
                }
                switch (data[3])
                {
                    case 0xD6:
                        {
                            if (udpWatch.ElapsedMilliseconds < udpWatchLimit)
                            {
                                missedSentenceCount++;
                                return;
                            }
                            udpWatch.Reset();
                            udpWatch.Start();
                            double Lon = BitConverter.ToDouble(data, 5);
                            double Lat = BitConverter.ToDouble(data, 13);
                            if (Lon != double.MaxValue && Lat != double.MaxValue)
                            {
                                if (timerSim.Enabled)
                                    DisableSim();
                                pn.longitude = Lon;
                                pn.latitude = Lat;
                                pn.ConvertWGS84ToLocal(Lat, Lon, out pn.fix.northing, out pn.fix.easting);
                                //From dual antenna heading sentences
                                float temp = BitConverter.ToSingle(data, 21);
                                if (temp != float.MaxValue)
                                {
                                    pn.headingTrueDual = temp + pn.headingTrueDualOffset;
                                    if (pn.headingTrueDual >= 360) pn.headingTrueDual -= 360;
                                    else if (pn.headingTrueDual < 0) pn.headingTrueDual += 360;
                                }
                                //from single antenna sentences (VTG,RMC)
                                pn.headingTrue = BitConverter.ToSingle(data, 25);
                                //always save the speed.
                                temp = BitConverter.ToSingle(data, 29);
                                if (temp != float.MaxValue)
                                {
                                    pn.vtgSpeed = temp;
                                }
                                //roll in degrees
                                temp = BitConverter.ToSingle(data, 33);
                                if (temp != float.MaxValue)
                                {
                                    if (ahrs.isRollInvert) temp *= -1;
                                    ahrs.imuRoll = temp - ahrs.rollZero;
                                }
                                if (temp == float.MinValue)
                                    ahrs.imuRoll = 0;
                                //altitude in meters
                                temp = BitConverter.ToSingle(data, 37);
                                if (temp != float.MaxValue)
                                    pn.altitude = temp;
                                ushort sats = BitConverter.ToUInt16(data, 41);
                                if (sats != ushort.MaxValue)
                                    pn.satellitesTracked = sats;
                                byte fix = data[43];
                                if (fix != byte.MaxValue)
                                    pn.fixQuality = fix;
                                ushort hdop = BitConverter.ToUInt16(data, 44);
                                if (hdop != ushort.MaxValue)
                                    pn.hdop = hdop * 0.01;
                                ushort age = BitConverter.ToUInt16(data, 46);
                                if (age != ushort.MaxValue)
                                    pn.age = age * 0.01;
                                ushort imuHead = BitConverter.ToUInt16(data, 48);
                                if (imuHead != ushort.MaxValue)
                                {
                                    ahrs.imuHeading = imuHead;
                                    ahrs.imuHeading *= 0.1;
                                }
                                short imuRol = BitConverter.ToInt16(data, 50);
                                if (imuRol != short.MaxValue)
                                {
                                    double rollK = imuRol;
                                    if (ahrs.isRollInvert) rollK *= -0.1;
                                    else rollK *= 0.1;
                                    rollK -= ahrs.rollZero;
                                    ahrs.imuRoll = ahrs.imuRoll * ahrs.rollFilter + rollK * (1 - ahrs.rollFilter);
                                }
                                short imuPich = BitConverter.ToInt16(data, 52);
                                if (imuPich != short.MaxValue)
                                {
                                    ahrs.imuPitch = imuPich;
                                }
                                short imuYaw = BitConverter.ToInt16(data, 54);
                                if (imuYaw != short.MaxValue)
                                {
                                    ahrs.imuYawRate = imuYaw;
                                }
                                sentenceCounter = 0;
                                UpdateFixPosition();
                            }
                        }
                        break;
                    case 0xD3: //external IMU
                        {
                            if (data.Length != 14)
                                break;
                            if (ahrs.imuRoll > 25 || ahrs.imuRoll < -25) ahrs.imuRoll = 0;
                            //Heading
                            ahrs.imuHeading = (Int16)((data[6] << 8) + data[5]);
                            ahrs.imuHeading *= 0.1;

                            //Roll
                            double rollK = (Int16)((data[8] << 8) + data[7]);
                            if (ahrs.isRollInvert) rollK *= -0.1;
                            else rollK *= 0.1;
                            rollK -= ahrs.rollZero;
                            ahrs.imuRoll = ahrs.imuRoll * ahrs.rollFilter + rollK * (1 - ahrs.rollFilter);
                            //Angular velocity
                            ahrs.angVel = (Int16)((data[10] << 8) + data[9]);
                            ahrs.angVel /= -2;
                            break;
                        }
                    case 0xD4: //imu disconnect pgn
                        {
                            if (data[5] == 1)
                            {
                                ahrs.imuHeading = 99999;
                                ahrs.imuRoll = 88888;
                                ahrs.angVel = 0;
                            }
                            break;
                        }
                    case 253: //return from autosteer module
                        {
                            //Steer angle actual
                            if (data.Length != 14)
                                break;
                            mc.actualSteerAngleChart = (Int16)((data[6] << 8) + data[5]);
                            mc.actualSteerAngleDegrees = (double)mc.actualSteerAngleChart * 0.01;
                            //Heading
                            double head253 = (Int16)((data[8] << 8) + data[7]);
                            if (head253 != 9999)
                            {
                                ahrs.imuHeading = head253 * 0.1;
                            }
                            //Roll
                            double rollK = (Int16)((data[10] << 8) + data[9]);
                            if (rollK != 8888)
                            {
                                if (ahrs.isRollInvert) rollK *= -0.1;
                                else rollK *= 0.1;
                                rollK -= ahrs.rollZero;
                                ahrs.imuRoll = ahrs.imuRoll * ahrs.rollFilter + rollK * (1 - ahrs.rollFilter);
                            }
                            //else ahrs.imuRoll = 88888;
                            //switch status
                            mc.workSwitchHigh = (data[11] & 1) == 1;
                            mc.steerSwitchHigh = (data[11] & 2) == 2;
                            //the pink steer dot reset
                            steerModuleConnectedCounter = 0;
                            //Actual PWM
                            mc.pwmDisplay = data[12];
                            break;
                        }
                    case 250:
                        {
                            if (data.Length != 14)
                                break;
                            mc.sensorData = data[5];
                            break;
                        }
                    case 221: // DD
                        {
                            //{ 0x80, 0x81, 0x7f, 221, number bytes, seconds to display, mystery byte, 98,99,100,101, CRC };
                            if (data.Length < 9) break;
                            if (isHardwareMessages)
                            {
                                lblHardwareMessage.Text = System.Text.Encoding.UTF8.GetString(data, 7, data[4] - 2);
                                lblHardwareMessage.Visible = true;
                                hardwareLineCounter = data[5] * 10;
                                Log.EventWriter(lblHardwareMessage.Text);
                                //color based on byte 6
                                if (data[6] == 0)
                                {
                                    lblHardwareMessage.BackColor = Color.Salmon;
                                    lblHardwareMessage.ForeColor = Color.Black;
                                }
                                else
                                {
                                    lblHardwareMessage.BackColor = Color.Bisque;
                                    lblHardwareMessage.ForeColor = Color.Black;
                                }
                            }
                            else
                            {
                                lblHardwareMessage.Visible = false;
                                hardwareLineCounter = 0;
                            }
                            break;
                        }
                    #region Remote Switches
                    case 234://MTZ8302 Feb 2020
                        {
                            //Steer angle actual
                            if (data.Length != 14)
                                break;
                            Buffer.BlockCopy(data, 5, mc.ss, 1, 8);
                            DoRemoteSwitches();
                            break;
                        }
                     #endregion
                }
            }
        }
        //start the UDP server
        public void StartLoopbackServer()
        {
            try
            {
                // Initialise the socket
                loopBackSocket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                loopBackSocket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, true);
                loopBackSocket.Bind(new IPEndPoint(IPAddress.Loopback, 15555));
                loopBackSocket.BeginReceiveFrom(loopBuffer, 0, loopBuffer.Length, SocketFlags.None,
                    ref endPointLoopBack, new AsyncCallback(ReceiveAppData), null);
                Log.EventWriter("UDP Loopback network started: " + IPAddress.Loopback.ToString() + ":" + "15555");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Load Error: " + ex.Message, "UDP Server", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Log.EventWriter("Catch -> Load UDP Loopback Error: " + ex.ToString());
            }
        }
        private void DisableSim()
        {
            isFirstFixPositionSet = false;
            isGPSPositionInitialized = false;
            isFirstHeadingSet = false;
            startCounter = 0;
            panelSim.Visible = false;
            timerSim.Enabled = false;
            simulatorOnToolStripMenuItem.Checked = false;
            Properties.Settings.Default.setMenu_isSimulatorOn = simulatorOnToolStripMenuItem.Checked;
            Properties.Settings.Default.Save();
            return;
        }
        private void ReceiveAppData(IAsyncResult asyncResult)
        {
            try
            {
                // Receive all data
                int msgLen = loopBackSocket.EndReceiveFrom(asyncResult, ref endPointLoopBack);
                byte[] localMsg = new byte[msgLen];
                Array.Copy(loopBuffer, localMsg, msgLen);
                // Listen for more connections again...
                loopBackSocket.BeginReceiveFrom(loopBuffer, 0, loopBuffer.Length, SocketFlags.None,
                    ref endPointLoopBack, new AsyncCallback(ReceiveAppData), null);
                BeginInvoke((MethodInvoker)(() => ReceiveFromAgIO(localMsg)));
            }
            catch (Exception)
            {
                // MessageBox.Show("ReceiveData Error: " + ex.Message, "UDP Server", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public void SendPgnToLoop(byte[] byteData)
        {
            if (loopBackSocket != null && byteData.Length > 2)
            {
                try
                {
                    int crc = 0;
                    for (int i = 2; i + 1 < byteData.Length; i++)
                    {
                        crc += byteData[i];
                    }
                    byteData[byteData.Length - 1] = (byte)crc;
                    loopBackSocket.BeginSendTo(byteData, 0, byteData.Length, SocketFlags.None,
                        epAgIO, new AsyncCallback(SendAsyncLoopData), null);
                }
                catch (Exception)
                {
                    //Log.EventWriter("Sending UDP Message" + e.ToString());
                    //MessageBox.Show("Send Error: " + e.Message, "UDP Client", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public void SendAsyncLoopData(IAsyncResult asyncResult)
        {
            try
            {
                loopBackSocket.EndSend(asyncResult);
            }
            catch (Exception)
            {
                //MessageBox.Show("SendData Error: " + ex.Message, "UDP Server", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //for moving and sizing borderless window
        protected override void WndProc(ref Message m)
        {
            const int RESIZE_HANDLE_SIZE = 7;
            switch (m.Msg)
            {
                case 0x0084/*NCHITTEST*/ :
                    base.WndProc(ref m);
                    if (!isKioskMode)
                    {
                        if ((int)m.Result == 0x01/*HTCLIENT*/)
                        {
                            Point screenPoint = new Point(m.LParam.ToInt32());
                            Point clientPoint = this.PointToClient(screenPoint);
                            if (clientPoint.Y <= RESIZE_HANDLE_SIZE)
                            {
                                if (clientPoint.X <= RESIZE_HANDLE_SIZE)
                                    m.Result = (IntPtr)13/*HTTOPLEFT*/ ;
                                else if (clientPoint.X < (Size.Width - RESIZE_HANDLE_SIZE))
                                    m.Result = (IntPtr)12/*HTTOP*/ ;
                                else
                                    m.Result = (IntPtr)14/*HTTOPRIGHT*/ ;
                            }
                            else if (clientPoint.Y <= (Size.Height - RESIZE_HANDLE_SIZE))
                            {
                                if (clientPoint.X <= RESIZE_HANDLE_SIZE)
                                    m.Result = (IntPtr)10/*HTLEFT*/ ;
                                else if (clientPoint.X < (Size.Width - RESIZE_HANDLE_SIZE))
                                    m.Result = (IntPtr)2/*HTCAPTION*/ ;
                                else
                                    m.Result = (IntPtr)11/*HTRIGHT*/ ;
                            }
                            else
                            {
                                if (clientPoint.X <= RESIZE_HANDLE_SIZE)
                                    m.Result = (IntPtr)16/*HTBOTTOMLEFT*/ ;
                                else if (clientPoint.X < (Size.Width - RESIZE_HANDLE_SIZE))
                                    m.Result = (IntPtr)15/*HTBOTTOM*/ ;
                                else
                                    m.Result = (IntPtr)17/*HTBOTTOMRIGHT*/ ;
                            }
                        }
                    }
                    return;
            }
            base.WndProc(ref m);
        }
        protected override CreateParams CreateParams
        {
            get
            {
                //drop shadow
                CreateParams cp = base.CreateParams;
                cp.Style |= 0x20000; // <--- use 0x20000
                return cp;
            }
        }
        #region keystrokes
        //keystrokes for easy and quick startup
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if ((char)keyData == hotkeys[0]) //autosteer button on off
            {
                btnAutoSteer.PerformClick();
                if (!isBtnAutoSteerOn) TimedMessageBox(2000, gStr.gsGuidanceStopped, "Hotkey Triggered");
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == hotkeys[1]) //open the steer chart
            {
                btnCycleLines.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == hotkeys[2])
            {
                FileSaveEverythingBeforeClosingField();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == hotkeys[3]) // Flag click
            {
                btnFlag.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == hotkeys[4]) //auto section on off
            {
                btnSectionMasterManual.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == hotkeys[5]) //auto section on off
            {
                btnSectionMasterAuto.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == hotkeys[6]) // Snap/Prioritu click
            {
                trk.SnapToPivot();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == hotkeys[7])
            {
                if (trk.idx > -1) //
                {
                    trk.NudgeTrack((double)Properties.Settings.Default.setAS_snapDistance * -0.01);
                }
                return true;
            }
            if ((char)keyData == hotkeys[8])
            {
                if (trk.idx > -1)
                {
                    trk.NudgeTrack((double)Properties.Settings.Default.setAS_snapDistance * 0.01);
                }
                return true;
            }
            if ((char)keyData == (hotkeys[9])) //open the vehicle Settings
            {
                toolStripConfig.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == (hotkeys[10])) // Wizard
            {
                Form fcs = Application.OpenForms["FormSteer"];
                if (fcs != null)
                {
                    fcs.Focus();
                    fcs.Close();
                }
                //check if window already exists
                Form fc = Application.OpenForms["FormSteerWiz"];
                if (fc != null)
                {
                    fc.Focus();
                    //fc.Close();
                    return true;
                }
                //
                Form form = new FormSteerWiz(this);
                form.Show(this);
            }
            if ((char)keyData == (hotkeys[11])) //section or zone button
            {
                if (tool.isSectionsNotZones) btnSection1Man.PerformClick();
                else btnZone1.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == (hotkeys[12])) //section or zone button
            {
                if (tool.isSectionsNotZones) btnSection2Man.PerformClick();
                else btnZone2.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == (hotkeys[13])) //section or zone button
            {
                if (tool.isSectionsNotZones) btnSection3Man.PerformClick();
                else btnZone3.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == (hotkeys[14])) //section or zone button
            {
                if (tool.isSectionsNotZones) btnSection4Man.PerformClick();
                else btnZone4.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == (hotkeys[15])) //section or zone button
            {
                if (tool.isSectionsNotZones) btnSection5Man.PerformClick();
                else btnZone5.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == (hotkeys[16])) //section or zone button
            {
                if (tool.isSectionsNotZones) btnSection6Man.PerformClick();
                else btnZone6.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == (hotkeys[17])) //section or zone button
            {
                if (tool.isSectionsNotZones) btnSection7Man.PerformClick();
                else btnZone7.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if ((char)keyData == (hotkeys[18])) //section or zone button
            {
                if (tool.isSectionsNotZones) btnSection8Man.PerformClick();
                else btnZone8.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            //////////////////////////////////////////////
            if (keyData == (Keys.NumPad1)) //auto section on off
            {
                btnSectionMasterAuto.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if (keyData == (Keys.NumPad0)) //auto section on off
            {
                btnSectionMasterManual.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            if (keyData == (Keys.F11)) // Full Screen click
            {
                btnMaximizeMainForm.PerformClick();
                return true;    // indicate that you handled this keystroke
            }
            //reset Sim
            if (keyData == Keys.R)
            {
                btnResetSim.PerformClick();
                return true;
            }
            //UTurn
            if (keyData == Keys.U)
            {
                sim.headingTrue += Math.PI;
                ABLine.isABValid = false;
                curve.isCurveValid = false;
                if (isBtnAutoSteerOn)
                {
                    btnAutoYouTurn.PerformClick();
                }
            }
            //speed up
            if (keyData == Keys.Up)
            {
                if (sim.stepDistance < 0.4 && sim.stepDistance > -0.36) sim.stepDistance += 0.01;
                else
                    sim.stepDistance += 0.04;
                if (sim.stepDistance > 4) sim.stepDistance = 4;
                return true;
            }
            //slow down
            if (keyData == Keys.Down)
            {
                if (sim.stepDistance < 0.2 && sim.stepDistance > -0.04) sim.stepDistance -= 0.01;
                else sim.stepDistance -= 0.04;
                if (sim.stepDistance < -0.35) sim.stepDistance = -0.35;
                return true;
            }
            //Stop
            if (keyData == Keys.OemPeriod)
            {
                sim.stepDistance = 0;
                return true;
            }
            //turn right
            if (keyData == Keys.Right)
            {
                sim.steerAngle += 1.0;
                if (sim.steerAngle > 40) sim.steerAngle = 40;
                if (sim.steerAngle < -40) sim.steerAngle = -40;
                sim.steerAngleScrollBar = sim.steerAngle;
                btnResetSteerAngle.Text = sim.steerAngle.ToString();
                hsbarSteerAngle.Value = (int)(10 * sim.steerAngle) + 400;
                return true;
            }
            //turn left
            if (keyData == Keys.Left)
            {
                sim.steerAngle -= 1.0;
                if (sim.steerAngle > 40) sim.steerAngle = 40;
                if (sim.steerAngle < -40) sim.steerAngle = -40;
                sim.steerAngleScrollBar = sim.steerAngle;
                btnResetSteerAngle.Text = sim.steerAngle.ToString();
                hsbarSteerAngle.Value = (int)(10 * sim.steerAngle) + 400;
                return true;
            }
            //zero steering
            if (keyData == Keys.OemQuestion)
            {
                sim.steerAngle = 0.0;
                sim.steerAngleScrollBar = sim.steerAngle;
                btnResetSteerAngle.Text = sim.steerAngle.ToString();
                hsbarSteerAngle.Value = (int)(10 * sim.steerAngle) + 400;
                return true;
            }
            if (keyData == Keys.OemOpenBrackets)
            {
                sim.stepDistance = 0;
                sim.isAccelBack = true;
            }
            if (keyData == Keys.OemCloseBrackets)
            {
                sim.stepDistance = 0;
                sim.isAccelForward = true;
            }
            if (keyData == Keys.OemQuotes)
            {
                sim.stepDistance = 0;
                return true;
            }
            if (keyData == (Keys.F6)) // Fast/Normal Sim
            {
                if (timerSim.Enabled)
                {
                    if (timerSim.Interval < 20) timerSim.Interval = 93;
                    else timerSim.Interval = 15;
                }
                return true;    // indicate that you handled this keystroke
            }
            // Call the base class
            return base.ProcessCmdKey(ref msg, keyData);
        }
        #endregion
        #region Gesture
        #endregion Gesture
    }
}
