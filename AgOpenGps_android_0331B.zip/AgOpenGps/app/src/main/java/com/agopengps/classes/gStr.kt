package com.agopengps.classes

import android.content.Context
import androidx.annotation.StringRes
import  com.agopengps.drive.R

object gStr {
    private lateinit var appContext: Context

    fun initialize(context: Context) {
        appContext = context.applicationContext
    }

    private fun getString(@StringRes resId: Int): String {
        return try {
            appContext.getString(resId)
        } catch (e: Exception) {
            ""
        }
    }

    // AB Line/Curve Related
    val gsABCurve: String get() = getString(R.string.gsABCurve)
    val gsABline: String get() = getString(R.string.gsABline)
    val gsEditABCurve: String get() = getString(R.string.gsEditABCurve)
    val gsEditABLine: String get() = getString(R.string.gsEditABLine)
    val gsTurnABCurveOn: String get() = getString(R.string.gsTurnABCurveOn)
    val gsSmoothABCurve: String get() = getString(R.string.gsSmoothABCurve)
    val gsNoABLineActive: String get() = getString(R.string.gsNoABLineActive)
    val gsPleaseEnterABLine: String get() = getString(R.string.gsPleaseEnterABLine)

    // Boundary Related
    val gsBoundary: String get() = getString(R.string.gsBoundary)
    val gsBoundaryMenu: String get() = getString(R.string.gsBoundaryMenu)
    val gsNoBoundary: String get() = getString(R.string.gsNoBoundary)
    val gsCreateABoundaryFirst: String get() = getString(R.string.gsCreateABoundaryFirst)
    val gsCompletelyDeleteBoundary: String get() = getString(R.string.gsCompletelyDeleteBoundary)
    val gsStartDeleteABoundary: String get() = getString(R.string.gsStartDeleteABoundary)
    val gsMakeBoundaryContours: String get() = getString(R.string.gsMakeBoundaryContours)

    // Field Related
    val gsField: String get() = getString(R.string.gsField)
    val gsFieldIsOpen: String get() = getString(R.string.gsFieldIsOpen)
    val gsFieldNotOpen: String get() = getString(R.string.gsFieldNotOpen)
    val gsCreateNewField: String get() = getString(R.string.gsCreateNewField)
    val gsStartNewField: String get() = getString(R.string.gsStartNewField)
    val gsEditFieldName: String get() = getString(R.string.gsEditFieldName)
    val gsEnterFieldName: String get() = getString(R.string.gsEnterFieldName)
    val gsBasedOnField: String get() = getString(R.string.gsBasedOnField)

    // Error Messages
    val gsError: String get() = getString(R.string.gsError)
    val gsFileError: String get() = getString(R.string.gsFileError)
    val gsAreYouSure: String get() = getString(R.string.gsAreYouSure)
    val gsActionHasBeenCancelled: String get() = getString(R.string.gsActionHasBeenCancelled)
    val gsProblemMakingPath: String get() = getString(R.string.gsProblemMakingPath)
    val gsCouldntGenerateValidPath: String get() = getString(R.string.gsCouldntGenerateValidPath)

    // Operations
    val gsManual: String get() = getString(R.string.gsManual)
    val gsRecord: String get() = getString(R.string.gsRecord)
    val gsPause: String get() = getString(R.string.gsPause)
    val gsResume: String get() = getString(R.string.gsResume)
    val gsSaveAndReturn: String get() = getString(R.string.gsSaveAndReturn)
    val gsSaveAs: String get() = getString(R.string.gsSaveAs)
    val gsClose: String get() = getString(R.string.gsClose)
    val gsOpen: String get() = getString(R.string.gsOpen)
    val gsNew: String get() = getString(R.string.gsNew)
    val gsUseSelected: String get() = getString(R.string.gsUseSelected)

    // Measurements
    val gsMeters: String get() = getString(R.string.gsMeters)
    val gsCentimeters: String get() = getString(R.string.gsCentimeters)
    val gsInches: String get() = getString(R.string.gsInches)
    val gsDistance: String get() = getString(R.string.gsDistance)
    val gsSpacing: String get() = getString(R.string.gsSpacing)
    val gsOffset: String get() = getString(R.string.gsOffset)
    val gsArea: String get() = getString(R.string.gsArea)

    // Directions
    val gsNorth: String get() = getString(R.string.gsNorth)
    val gsSouth: String get() = getString(R.string.gsSouth)
    val gsEast: String get() = getString(R.string.gsEast)
    val gsWest: String get() = getString(R.string.gsWest)
    val gsN_East: String get() = getString(R.string.gsN_East)
    val gsN_West: String get() = getString(R.string.gsN_West)
    val gsS_East: String get() = getString(R.string.gsS_East)
    val gsS_West: String get() = getString(R.string.gsS_West)

    // Videos
    val v_AboutIntro: String get() = getString(R.string.v_AboutIntro)
    val v_RecordedPathForm: String get() = getString(R.string.v_RecordedPathForm)
    val v_SteerSettingsForm: String get() = getString(R.string.v_SteerSettingsForm)

    // ... 其他所有屬性 (根據需要繼續添加)
}