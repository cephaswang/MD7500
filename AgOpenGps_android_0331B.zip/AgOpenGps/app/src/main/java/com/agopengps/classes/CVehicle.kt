package com.agopengps.classes

import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.PolygonOptions
import kotlin.math.*

class CVehicle(private val mf: FormGPS) {

    var isSteerAxleAhead: Boolean = mf.settings.setVehicle_isSteerAxleAhead
    var isPivotBehindAntenna: Boolean = mf.settings.setVehicle_isPivotBehindAntenna

    var antennaHeight: Double = mf.settings.setVehicle_antennaHeight
    var antennaPivot: Double = mf.settings.setVehicle_antennaPivot
    var wheelbase: Double = mf.settings.setVehicle_wheelbase
    var antennaOffset: Double = mf.settings.setVehicle_antennaOffset
    var deadZoneHeading: Int = mf.settings.setAS_deadZoneHeading
    var deadZoneDelay: Int = mf.settings.setAS_deadZoneDelay
    var vehicleType: Int = mf.settings.setVehicle_vehicleType
    var deadZoneDelayCounter: Int = 0
    var isInDeadZone: Boolean = false

    var slowSpeedCutoff: Double = mf.settings.setVehicle_slowSpeedCutoff

    var goalPointLookAheadHold: Double = mf.settings.setVehicle_goalPointLookAheadHold
    var goalPointLookAheadMult: Double = mf.settings.setVehicle_goalPointLookAheadMult
    var goalPointAcquireFactor: Double = mf.settings.setVehicle_goalPointAcquireFactor
    var uturnCompensation: Double = mf.settings.setAS_uTurnCompensation

    var stanleyDistanceErrorGain: Double = mf.settings.stanleyDistanceErrorGain
    var stanleyHeadingErrorGain: Double = mf.settings.stanleyHeadingErrorGain
    var minLookAheadDistance: Double = 2.0
    var maxSteerAngle: Double = mf.settings.setVehicle_maxSteerAngle
    var maxSteerSpeed: Double = mf.settings.setAS_maxSteerSpeed
    var minSteerSpeed: Double = mf.settings.setAS_minSteerSpeed
    var maxAngularVelocity: Double = mf.settings.setVehicle_maxAngularVelocity
    var hydLiftLookAheadTime: Double = mf.settings.setVehicle_hydraulicLiftLookAhead
    var trackWidth: Double = mf.settings.setVehicle_trackWidth

    var hydLiftLookAheadDistanceLeft: Double = 0.0
    var hydLiftLookAheadDistanceRight: Double = 0.0

    var isHydLiftOn: Boolean = false
    var stanleyIntegralDistanceAwayTriggerAB: Double = mf.settings.stanleyIntegralDistanceAwayTriggerAB
    var stanleyIntegralGainAB: Double = mf.settings.stanleyIntegralGainAB
    var purePursuitIntegralGain: Double = mf.settings.purePursuitIntegralGainAB

    var isInFreeDriveMode: Boolean = false
    var driveFreeSteerAngle: Double = 0.0

    var modeXTE: Double = 0.2
    var modeActualXTE: Double = 0.0
    var modeActualHeadingError: Double = 0.0
    var modeTime: Int = 1

    var functionSpeedLimit: Double = mf.settings.setAS_functionSpeedLimit

    var modeTimeCounter: Int = 0
    var goalDistance: Double = 0.0

    var vehicleOpacityByte: Int = mf.vehicleOpacityByte
    var vehicleColorR: Int = android.graphics.Color.red(mf.vehicleColor)
    var vehicleColorG: Int = android.graphics.Color.green(mf.vehicleColor)
    var vehicleColorB: Int = android.graphics.Color.blue(mf.vehicleColor)

    init {
        vehicleOpacityByte = vehicleOpacityByte.coerceIn(0, 255)
        vehicleColorR = vehicleColorR.coerceIn(0, 255)
        vehicleColorG = vehicleColorG.coerceIn(0, 255)
        vehicleColorB = vehicleColorB.coerceIn(0, 255)
    }

    fun UpdateGoalPointDistance(): Double {
        val xTE = abs(modeActualXTE)
        var goalPointDistance = mf.avgSpeed * 0.05 * goalPointLookAheadMult

        var LoekiAheadHold = goalPointLookAheadHold
        val LoekiAheadAcquire = goalPointLookAheadHold * goalPointAcquireFactor

        if (!mf.isBtnAutoSteerOn) {
            LoekiAheadHold = 5.0
        }

        when {
            xTE <= 0.1 -> {
                goalPointDistance *= LoekiAheadHold
                goalPointDistance += LoekiAheadHold
            }
            xTE in 0.1..0.4 -> {
                val adjustedXTE = xTE - 0.1
                LoekiAheadHold = (1 - (adjustedXTE / 0.3)) * (LoekiAheadHold - LoekiAheadAcquire) + LoekiAheadAcquire
                goalPointDistance *= LoekiAheadHold
                goalPointDistance += LoekiAheadHold
            }
            else -> {
                goalPointDistance *= LoekiAheadAcquire
                goalPointDistance += LoekiAheadAcquire
            }
        }

        if (goalPointDistance < 2) goalPointDistance = 2.0
        goalDistance = goalPointDistance

        return goalPointDistance
    }

    fun DrawVehicle(googleMap: GoogleMap) {
        // Assuming mf provides a current position (LatLng) and heading
        val currentPosition = LatLng(mf.fixLat, mf.fixLon)
        val heading = -mf.fixHeading

        // Rotate points around the current position based on heading
        fun rotatePoint(x: Double, y: Double, angle: Double): LatLng {
            val sinAngle = sin(angle)
            val cosAngle = cos(angle)
            val newX = x * cosAngle - y * sinAngle
            val newY = x * sinAngle + y * cosAngle
            val latOffset = newY / 111139.0
            val lonOffset = newX / (111139.0 * cos(currentPosition.latitude * PI / 180))
            return LatLng(currentPosition.latitude + latOffset, currentPosition.longitude + lonOffset)
        }

        // Draw hitch if applicable
        if (mf.isFirstHeadingSet && !mf.tool.isToolFrontFixed) {
            val hitchStart = rotatePoint(0.0, 0.0, heading)
            val hitchEnd = rotatePoint(0.0, mf.tool.hitchLength, heading)
            googleMap.addPolyline(
                PolylineOptions()
                    .add(hitchStart, hitchEnd)
                    .width(4f)
                    .color(android.graphics.Color.BLACK)
            )
            googleMap.addPolyline(
                PolylineOptions()
                    .add(hitchStart, hitchEnd)
                    .width(1f)
                    .color(android.graphics.Color.argb(255, 237, 37, 39))
            )
        }

        // Vehicle drawing based on type
        if (mf.isVehicleImage) {
            when (vehicleType) {
                0 -> { // Tractor
                    val leftAckerman: Double
                    val rightAckerman: Double
                    if (mf.timerSim.enabled) {
                        if (mf.sim.steerangleAve < 0) {
                            leftAckerman = 1.25 * -mf.sim.steerangleAve
                            rightAckerman = -mf.sim.steerangleAve
                        } else {
                            leftAckerman = -mf.sim.steerangleAve
                            rightAckerman = 1.25 * -mf.sim.steerangleAve
                        }
                    } else {
                        if (mf.mc.actualSteerAngleDegrees < 0) {
                            leftAckerman = 1.25 * -mf.mc.actualSteerAngleDegrees
                            rightAckerman = -mf.mc.actualSteerAngleDegrees
                        } else {
                            leftAckerman = -mf.mc.actualSteerAngleDegrees
                            rightAckerman = 1.25 * -mf.mc.actualSteerAngleDegrees
                        }
                    }

                    // Vehicle body
                    val bodyPoints = listOf(
                        rotatePoint(trackWidth, wheelbase * 1.5, heading),
                        rotatePoint(-trackWidth, wheelbase * 1.5, heading),
                        rotatePoint(-trackWidth, -wheelbase * 0.5, heading),
                        rotatePoint(trackWidth, -wheelbase * 0.5, heading)
                    )
                    googleMap.addPolygon(
                        PolygonOptions()
                            .addAll(bodyPoints)
                            .fillColor(android.graphics.Color.argb(vehicleOpacityByte, vehicleColorR, vehicleColorG, vehicleColorB))
                            .strokeWidth(0f)
                    )

                    // Right wheel
                    val rightWheelCenter = rotatePoint(trackWidth * 0.5, wheelbase, heading)
                    val rightWheelPoints = listOf(
                        rotatePoint(trackWidth * 0.5, wheelbase * 0.75, heading + rightAckerman * PI / 180),
                        rotatePoint(-trackWidth * 0.5, wheelbase * 0.75, heading + rightAckerman * PI / 180),
                        rotatePoint(-trackWidth * 0.5, -wheelbase * 0.75, heading + rightAckerman * PI / 180),
                        rotatePoint(trackWidth * 0.5, -wheelbase * 0.75, heading + rightAckerman * PI / 180)
                    )
                    googleMap.addPolygon(
                        PolygonOptions()
                            .addAll(rightWheelPoints)
                            .fillColor(android.graphics.Color.argb(vehicleOpacityByte, vehicleColorR, vehicleColorG, vehicleColorB))
                            .strokeWidth(0f)
                    )

                    // Left wheel
                    val leftWheelCenter = rotatePoint(-trackWidth * 0.5, wheelbase, heading)
                    val leftWheelPoints = listOf(
                        rotatePoint(trackWidth * 0.5, wheelbase * 0.75, heading + leftAckerman * PI / 180),
                        rotatePoint(-trackWidth * 0.5, wheelbase * 0.75, heading + leftAckerman * PI / 180),
                        rotatePoint(-trackWidth * 0.5, -wheelbase * 0.75, heading + leftAckerman * PI / 180),
                        rotatePoint(trackWidth * 0.5, -wheelbase * 0.75, heading + leftAckerman * PI / 180)
                    )
                    googleMap.addPolygon(
                        PolygonOptions()
                            .addAll(leftWheelPoints)
                            .fillColor(android.graphics.Color.argb(vehicleOpacityByte, vehicleColorR, vehicleColorG, vehicleColorB))
                            .strokeWidth(0f)
                    )
                }
            }
        } else {
            // Simple triangle representation
            val bodyPoints = listOf(
                rotatePoint(1.0, 0.0, heading),
                rotatePoint(0.0, wheelbase, heading),
                rotatePoint(-1.0, 0.0, heading)
            )
            googleMap.addPolygon(
                PolygonOptions()
                    .addAll(bodyPoints)
                    .fillColor(android.graphics.Color.argb((mf.vehicleOpacity * 255).toInt(), 120, 120, 0))
                    .strokeColor(android.graphics.Color.argb(255, 12, 12, 12))
                    .strokeWidth(3f)
            )
        }

        // Antenna dot
        if (mf.camera.camSetDistance > -75 && mf.isFirstHeadingSet) {
            val antennaPosition = rotatePoint(-antennaOffset, antennaPivot, heading)
            googleMap.addCircle(
                CircleOptions()
                    .center(antennaPosition)
                    .radius(0.16)
                    .fillColor(android.graphics.Color.BLACK)
                    .strokeWidth(0f)
            )
            googleMap.addCircle(
                CircleOptions()
                    .center(antennaPosition)
                    .radius(0.10)
                    .fillColor(android.graphics.Color.argb(255, 20, 98, 98))
                    .strokeWidth(0f)
            )
        }
    }
}