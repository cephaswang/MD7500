package com.agopengps.classes

import android.content.SharedPreferences
import android.opengl.GLES20
import android.opengl.Matrix

class CCamera(
    private val settings: SharedPreferences,
    private val mvpMatrixHandle: Int
) {
    // Camera position and orientation
    var camPosX: Double = 0.0
    var camPosY: Double = 0.0
    val camPosZ: Double = 0.0

    private var camYaw: Double = 0.0
    var camPitch: Double = 0.0
    var panX: Double = 0.0
    var panY: Double = 0.0
    var camSetDistance: Double = -75.0

    // Zoom and grid settings
    var gridZoom: Double = 0.0
    var zoomValue: Double = 15.0
    var previousZoom: Double = 25.0

    // Camera behavior flags
    var camFollowing: Boolean = true
    var camMode: Int = 0
    var camSmoothFactor: Double = 0.0

    // Matrices for OpenGL rendering
    private val viewMatrix = FloatArray(16)
    private val projectionMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)

    init {
        // Initialize camera settings from shared preferences
        loadCameraSettings()
    }

    private fun loadCameraSettings() {
        camPitch = settings.getFloat("setDisplay_camPitch", 0f).toDouble()
        zoomValue = settings.getFloat("setDisplay_camZoom", 15f).toDouble()
        camSmoothFactor = (settings.getInt("setDisplay_camSmooth", 0) * 0.004) + 0.2
    }

    fun setWorldCam(fixPosX: Double, fixPosY: Double, fixHeading: Double) {
        camPosX = fixPosX
        camPosY = fixPosY
        camYaw = fixHeading

        // Reset matrices to identity
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.setIdentityM(viewMatrix, 0)
        Matrix.setIdentityM(projectionMatrix, 0)

        // Apply camera transformations
        Matrix.translateM(viewMatrix, 0, 0f, 0f, (camSetDistance * 0.5).toFloat())
        Matrix.rotateM(viewMatrix, 0, camPitch.toFloat(), 1f, 0f, 0f)
        Matrix.translateM(viewMatrix, 0, panX.toFloat(), panY.toFloat(), 0f)

        if (camFollowing) {
            Matrix.rotateM(viewMatrix, 0, camYaw.toFloat(), 0f, 0f, 1f)
        }

        Matrix.translateM(viewMatrix, 0, (-camPosX).toFloat(), (-camPosY).toFloat(), (-camPosZ).toFloat())

        // Set the camera position (ModelViewProjection matrix)
        GLES20.glUniformMatrix4fv(
            mvpMatrixHandle, 1, false,
            calculateMVPMatrix(), 0
        )
    }

    private fun calculateMVPMatrix(): FloatArray {
        val mvpMatrix = FloatArray(16)
        Matrix.multiplyMM(mvpMatrix, 0, viewMatrix, 0, modelMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvpMatrix, 0)
        return mvpMatrix
    }

    fun updateProjection(width: Int, height: Int) {
        val ratio = width.toFloat() / height.toFloat()
        Matrix.orthoM(
            projectionMatrix, 0,
            -zoomValue.toFloat() * ratio,
            zoomValue.toFloat() * ratio,
            -zoomValue.toFloat(),
            zoomValue.toFloat(),
            0.1f, 100f
        )
    }

    fun saveSettings() {
        settings.edit().apply {
            putFloat("setDisplay_camPitch", camPitch.toFloat())
            putFloat("setDisplay_camZoom", zoomValue.toFloat())
            putInt("setDisplay_camSmooth", ((camSmoothFactor - 0.2) / 0.004).toInt())
            apply()
        }
    }

    // Camera movement controls
    fun zoomIn() {
        zoomValue = (zoomValue * 0.9).coerceAtLeast(1.0)
        saveSettings()
    }

    fun zoomOut() {
        zoomValue = (zoomValue * 1.1).coerceAtMost(100.0)
        saveSettings()
    }

    fun resetZoom() {
        zoomValue = 15.0
        saveSettings()
    }

    fun adjustPitch(amount: Double) {
        camPitch = (camPitch + amount).coerceIn(-89.0, 89.0)
        saveSettings()
    }

    fun resetPitch() {
        camPitch = 0.0
        saveSettings()
    }
}