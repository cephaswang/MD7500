package com.agopengps.classes

import android.util.Log
import com.agopengps.classes.glm.isPointInPolygon
import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import com.google.android.gms.maps.model.CircleOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.*

class CABCurve(private val mf: FormGPS) {
    var isBtnTrackOn: Boolean = false
    var isMakingCurve: Boolean = false
    var isRecordingCurve: Boolean = false

    var distanceFromCurrentLinePivot: Double = 0.0
    var distanceFromRefLine: Double = 0.0

    var isHeadingSameWay: Boolean = true
    var lastIsHeadingSameWay: Boolean = true

    var howManyPathsAway: Double = 0.0
    var lastHowManyPathsAway: Double = 0.0
    var refPoint1: vec2 = vec2(1.0, 1.0)
    var refPoint2: vec2 = vec2(2.0, 2.0)

    private var A: Int = 0
    private var B: Int = 0
    private var C: Int = 0
    private var rA: Int = 0
    private var rB: Int = 0

    var currentLocationIndex: Int = 0

    var goalPointCu: vec2 = vec2(0.0, 0.0)
    var radiusPointCu: vec2 = vec2(0.0, 0.0)
    var steerAngleCu: Double = 0.0
    var rEastCu: Double = 0.0
    var rNorthCu: Double = 0.0
    var ppRadiusCu: Double = 0.0
    var manualUturnHeading: Double = 0.0

    var isSmoothWindowOpen: Boolean = false
    var isLooping: Boolean = false
    val smooList: MutableList<vec3> = ArrayList()

    //var curList: MutableList<vec3> = ArrayList()

    private var isBusyWorking: Boolean = false

    var isCurveValid: Boolean = false

    var lastSecond: Double = 0.0

    var curList: ArrayList<vec3> = ArrayList()
    val desList: ArrayList<vec3> = ArrayList()
    var desName: String = "**"

    var pivotDistanceError: Double = 0.0
    var pivotDistanceErrorLast: Double = 0.0
    var pivotDerivative: Double = 0.0
    var pivotDerivativeSmoothed: Double = 0.0
    var lastCurveDistance: Double = 10000.0

    private var counter2: Int = 0

    var inty: Double = 0.0

    private var findGlobalNearestCurvePoint: Boolean = true

    init {
        desList.ensureCapacity(1024)
        curList.ensureCapacity(1024)
    }


    fun FindClosestPointOnCurve(point: vec3): Int {
        var minDist = Double.MAX_VALUE
        var closestIndex = 0

        for (i in curList.indices) {
            val dist = glm.distanceSquared(point, curList[i])
            if (dist < minDist) {
                minDist = dist
                closestIndex = i
            }
        }

        return closestIndex
    }

    suspend fun BuildCurveCurrentList(pivot: vec3) {
        var minDistA = 1000000.0
        var minDistB: Double

        val widthMinusOverlap = mf.tool.width - mf.tool.overlap
        val track = mf.trk.gArr[mf.trk.idx]

        if (!isCurveValid || ((mf.secondsSinceStart - lastSecond) > 0.66 && (!mf.isBtnAutoSteerOn || mf.mc.steerSwitchHigh))) {
            lastSecond = mf.secondsSinceStart
            findGlobalNearestCurvePoint = true
            if (track.mode != TrackMode.WaterPivot) {
                val refCount = track.curvePts.size
                if (refCount < 2) {
                    curList.clear()
                    return
                }

                var cc = 0
                var dd: Int

                for (j in 0 until refCount step 10) {
                    val dist = ((mf.guidanceLookPos.easting - track.curvePts[j].easting) *
                            (mf.guidanceLookPos.easting - track.curvePts[j].easting)) +
                            ((mf.guidanceLookPos.northing - track.curvePts[j].northing) *
                                    (mf.guidanceLookPos.northing - track.curvePts[j].northing))
                    if (dist < minDistA) {
                        minDistA = dist
                        cc = j
                    }
                }

                minDistA = 1000000.0
                minDistB = 1000000.0

                dd = cc + 7
                if (dd > refCount - 1) dd = refCount
                cc -= 7
                if (cc < 0) cc = 0

                for (j in cc until dd) {
                    val dist = ((mf.guidanceLookPos.easting - track.curvePts[j].easting) *
                            (mf.guidanceLookPos.easting - track.curvePts[j].easting)) +
                            ((mf.guidanceLookPos.northing - track.curvePts[j].northing) *
                                    (mf.guidanceLookPos.northing - track.curvePts[j].northing))
                    if (dist < minDistA) {
                        minDistB = minDistA
                        rB = rA
                        minDistA = dist
                        rA = j
                    } else if (dist < minDistB) {
                        minDistB = dist
                        rB = j
                    }
                }

                if (rA > rB) {
                    C = rA
                    rA = rB
                    rB = C
                }

                isHeadingSameWay =
                    PI - abs(abs(pivot.heading - track.curvePts[rA].heading) - PI) < glm.piBy2

                refPoint1.easting =
                    track.curvePts[rA].easting - (sin(track.curvePts[rA].heading) * 300.0)
                refPoint1.northing =
                    track.curvePts[rA].northing - (cos(track.curvePts[rA].heading) * 300.0)

                refPoint2.easting =
                    track.curvePts[rA].easting + (sin(track.curvePts[rA].heading) * 300.0)
                refPoint2.northing =
                    track.curvePts[rA].northing + (cos(track.curvePts[rA].heading) * 300.0)

                val dx = refPoint2.easting - refPoint1.easting
                val dz = refPoint2.northing - refPoint1.northing

                distanceFromRefLine =
                    ((dz * mf.guidanceLookPos.easting) - (dx * mf.guidanceLookPos.northing) +
                            (refPoint2.easting * refPoint1.northing) - (refPoint2.northing * refPoint1.easting)) /
                            sqrt((dz * dz) + (dx * dx))
            } else {
                isHeadingSameWay =
                    ((mf.pivotAxlePos.easting - track.ptA.easting) * (mf.steerAxlePos.northing - track.ptA.northing) -
                            (mf.pivotAxlePos.northing - track.ptA.northing) * (mf.steerAxlePos.easting - track.ptA.easting)) < 0

                // 修正 distance 調用
                distanceFromRefLine = -glm.distance(
                    vec2(mf.guidanceLookPos.easting, mf.guidanceLookPos.northing),
                    vec2(track.ptA.easting, track.ptA.northing)
                )
            }

            distanceFromRefLine -= (0.5 * widthMinusOverlap)

            val RefDist =
                (distanceFromRefLine + (if (isHeadingSameWay) mf.tool.offset else -mf.tool.offset) - track.nudgeDistance) / widthMinusOverlap

            howManyPathsAway =
                if (RefDist < 0) (RefDist - 0.5).toInt().toDouble() else (RefDist + 0.5).toInt()
                    .toDouble()
        }

        if (!isCurveValid || howManyPathsAway != lastHowManyPathsAway || (isHeadingSameWay != lastIsHeadingSameWay && mf.tool.offset != 0.0)) {
            if (!isBusyWorking) {
                isBusyWorking = true
                isCurveValid = true
                lastHowManyPathsAway = howManyPathsAway
                lastIsHeadingSameWay = isHeadingSameWay
                val distAway = widthMinusOverlap * howManyPathsAway +
                        (if (isHeadingSameWay) -mf.tool.offset else mf.tool.offset) +
                        track.nudgeDistance

                distAway + (0.5 * widthMinusOverlap)

                // 修正 ArrayList 類型轉換
                curList = withContext(Dispatchers.Default) {
                    ArrayList(BuildNewOffsetList(distAway, track)) // 使用構造函數轉換
                }

                isBusyWorking = false
                findGlobalNearestCurvePoint = true
            }
        }
    }

    fun BuildNewOffsetList(distAway: Double, track: CTrk): MutableList<vec3> {
        val newCurList = mutableListOf<vec3>()

        try {
            when (track.mode) {
                TrackMode.AB -> {
                    val nudgePtA = vec2(track.ptA)
                    val nudgePtB = vec2(track.ptB)

                    val point1 = vec2(
                        (cos(-track.heading) * distAway) + nudgePtA.easting,
                        (sin(-track.heading) * distAway) + nudgePtA.northing
                    )

                    val point2 = vec2(
                        (cos(-track.heading) * distAway) + nudgePtB.easting,
                        (sin(-track.heading) * distAway) + nudgePtB.northing
                    )

                    val easting1 = point1.easting - (sin(track.heading) * mf.ABLine.abLength)
                    val northing1 = point1.northing - (cos(track.heading) * mf.ABLine.abLength)
                    newCurList.add(vec3(easting1, northing1, track.heading))

                    val easting2 = point2.easting + (sin(track.heading) * mf.ABLine.abLength)
                    val northing2 = point2.northing + (cos(track.heading) * mf.ABLine.abLength)
                    newCurList.add(vec3(easting2, northing2, track.heading))
                }

                TrackMode.WaterPivot -> {
                    val Angle = glm.twoPI / minOf(
                        maxOf(ceil(glm.twoPI / (2 * acos(1 - (0.02 / abs(distAway))))), 50.0),
                        500.0
                    )

                    val centerPos = vec3(track.ptA.easting, track.ptA.northing, 0.0)
                    var rotation = 0.0

                    while (rotation < glm.twoPI) {
                        rotation += Angle
                        newCurList.add(
                            vec3(
                                centerPos.easting + distAway * sin(rotation),
                                centerPos.northing + distAway * cos(rotation),
                                0.0
                            )
                        )
                    }

                    if (newCurList.size > 1) {
                        val arr = newCurList.toTypedArray()
                        newCurList.clear()

                        for (i in 0 until arr.size - 1) {
                            arr[i].heading = atan2(
                                arr[i + 1].easting - arr[i].easting,
                                arr[i + 1].northing - arr[i].northing
                            )
                            if (arr[i].heading < 0) arr[i].heading += glm.twoPI
                            if (arr[i].heading >= glm.twoPI) arr[i].heading -= glm.twoPI
                        }

                        arr[arr.size - 1].heading = atan2(
                            arr[0].easting - arr[arr.size - 1].easting,
                            arr[0].northing - arr[arr.size - 1].northing
                        )

                        newCurList.addAll(arr)
                    }
                }

                else -> {
                    var point: vec3
                    var step = (mf.tool.width - mf.tool.overlap) * 0.48
                    if (step > 4) step = 4.0
                    if (step < 1) step = 1.0

                    val distSqAway = (distAway * distAway) - 0.01
                    val refCount = track.curvePts.size

                    for (i in 0 until refCount) {
                        point = vec3(
                            track.curvePts[i].easting + (sin(glm.piBy2 + track.curvePts[i].heading) * distAway),
                            track.curvePts[i].northing + (cos(glm.piBy2 + track.curvePts[i].heading) * distAway),
                            track.curvePts[i].heading
                        )
                        var add = true

                        for (t in 0 until refCount) {
                            val dist =
                                ((point.easting - track.curvePts[t].easting) * (point.easting - track.curvePts[t].easting)) +
                                        ((point.northing - track.curvePts[t].northing) * (point.northing - track.curvePts[t].northing))
                            if (dist < distSqAway) {
                                add = false
                                break
                            }
                        }

                        if (add) {
                            if (newCurList.size > 0) {
                                val dist =
                                    ((point.easting - newCurList.last().easting) * (point.easting - newCurList.last().easting)) +
                                            ((point.northing - newCurList.last().northing) * (point.northing - newCurList.last().northing))
                                if (dist > step) newCurList.add(point)
                            } else newCurList.add(point)
                        }
                    }

                    val cnt = newCurList.size
                    if (cnt > 6) {
                        val arr = newCurList.toTypedArray()
                        newCurList.clear()

                        for (i in 0 until arr.size - 1) {
                            arr[i].heading = atan2(
                                arr[i + 1].easting - arr[i].easting,
                                arr[i + 1].northing - arr[i].northing
                            )
                            if (arr[i].heading < 0) arr[i].heading += glm.twoPI
                            if (arr[i].heading >= glm.twoPI) arr[i].heading -= glm.twoPI
                        }
                        arr[arr.size - 1].heading = arr[arr.size - 2].heading

                        var distance: Double
                        newCurList.add(arr[0])

                        for (i in 0 until cnt - 3) {
                            newCurList.add(arr[i + 1])
                            distance = glm.distance(arr[i + 1], arr[i + 2])

                            if (distance > step) {
                                val loopTimes = (distance / step + 1).toInt()
                                for (j in 1 until loopTimes) {
                                    val pos = vec3(
                                        glm.catmull(
                                            j.toDouble() / loopTimes,
                                            arr[i],
                                            arr[i + 1],
                                            arr[i + 2],
                                            arr[i + 3]
                                        )
                                    )
                                    newCurList.add(pos)
                                }
                            }
                        }

                        newCurList.add(arr[cnt - 2])
                        newCurList.add(arr[cnt - 1])

                        val newCnt = newCurList.size - 1
                        val tempArr = newCurList.toTypedArray()
                        newCurList.clear()

                        newCurList.add(vec3(tempArr[0]))

                        for (i in 1 until newCnt) {
                            val pt3 = vec3(tempArr[i]).apply {
                                heading = atan2(
                                    tempArr[i + 1].easting - tempArr[i - 1].easting,
                                    tempArr[i + 1].northing - tempArr[i - 1].northing
                                )
                                if (heading < 0) heading += glm.twoPI
                            }
                            newCurList.add(pt3)
                        }

                        val k = tempArr.size - 1
                        val pt33 = vec3(tempArr[k]).apply {
                            heading = atan2(
                                tempArr[k].easting - tempArr[k - 1].easting,
                                tempArr[k].northing - tempArr[k - 1].northing
                            )
                            if (heading < 0) heading += glm.twoPI
                        }
                        newCurList.add(pt33)

                        if (mf.bnd.bndList.isNotEmpty() && track.mode != TrackMode.BndCurve) {
                            var ptCnt = newCurList.size - 1
                            var isAdding = false

                            while (mf.bnd.bndList[0].fenceLineEar.isPointInPolygon(newCurList.last())) {
                                isAdding = true
                                for (i in 1..10) {
                                    val pt = vec3(newCurList[ptCnt]).apply {
                                        easting += sin(heading) * i * 2
                                        northing += cos(heading) * i * 2
                                    }
                                    newCurList.add(pt)
                                }
                                ptCnt = newCurList.size - 1
                            }

                            if (isAdding) {
                                val pt = vec3(newCurList.last())
                                for (i in 1..4) {
                                    pt.easting += sin(pt.heading) * 2
                                    pt.northing += cos(pt.heading) * 2
                                    newCurList.add(pt)
                                }
                            }

                            isAdding = false
                            val pt33Start = vec3(newCurList[0])

                            while (mf.bnd.bndList[0].fenceLineEar.isPointInPolygon(newCurList[0])) {
                                isAdding = true
                                for (i in 1..10) {
                                    val pt = vec3(pt33Start).apply {
                                        easting -= sin(heading) * i * 2
                                        northing -= cos(heading) * i * 2
                                    }
                                    newCurList.add(0, pt)
                                }
                            }

                            if (isAdding) {
                                val pt = vec3(newCurList[0])
                                for (i in 1..4) {
                                    pt.easting -= sin(pt.heading) * 2
                                    pt.northing -= cos(pt.heading) * 2
                                    newCurList.add(0, pt)
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.d("EventWriter", "Exception Build new offset curve ${e.message}")
        }

        return newCurList
    }

    fun GetCurrentCurveLine(pivot: vec3, steer: vec3) {
        val track = mf.trk.gArr[mf.trk.idx]
        if (track.curvePts == null || track.curvePts.size < 5) {
            if (track.mode != TrackMode.WaterPivot) return
        }

        if (curList.isNotEmpty()) {
            val goalPointDistance = mf.vehicle.UpdateGoalPointDistance()
            val reverseHeading = if (mf.isReverse) !isHeadingSameWay else isHeadingSameWay

            when {
                mf.yt.isYouTurnTriggered && mf.yt.distanceFromYouTurnLine() -> {
                    steerAngleCu = mf.yt.steerAngleYT
                    distanceFromCurrentLinePivot = mf.yt.distanceFromCurrentLine
                    goalPointCu = mf.yt.goalPointYT
                    radiusPointCu.easting = mf.yt.radiusPointYT.easting
                    radiusPointCu.northing = mf.yt.radiusPointYT.northing
                    ppRadiusCu = mf.yt.ppRadiusYT
                    mf.vehicle.modeActualXTE = distanceFromCurrentLinePivot
                }

                mf.isStanleyUsed -> {
                    mf.gyd.stanleyGuidanceCurve(pivot, steer, curList)
                }

                else -> {
                    var minDistA: Double
                    var minDistB: Double

                    if (track.mode <= TrackMode.Curve) {
                        minDistB = Double.MAX_VALUE
                        val cc = if (findGlobalNearestCurvePoint) {
                            findGlobalNearestCurvePoint(pivot, 10)
                        } else {
                            findNearestLocalCurvePoint(
                                pivot,
                                currentLocationIndex,
                                goalPointDistance,
                                reverseHeading
                            )
                        }

                        findGlobalNearestCurvePoint = false
                        minDistA = Double.MAX_VALUE

                        val endIndex = minOf(cc + 8, curList.size)
                        val startIndex = maxOf(cc - 8, 0)

                        for (j in startIndex until endIndex) {
                            val dist = glm.distanceSquared(pivot, curList[j])
                            when {
                                dist < minDistA -> {
                                    minDistB = minDistA
                                    B = A
                                    minDistA = dist
                                    A = j
                                }

                                dist < minDistB -> {
                                    minDistB = dist
                                    B = j
                                }
                            }
                        }

                        if (A > B) {
                            C = A; A = B; B = C
                        }
                        currentLocationIndex = A
                        if (A > curList.size - 1 || B > curList.size - 1) return
                    } else {
                        A = if (findGlobalNearestCurvePoint) {
                            findGlobalNearestCurvePoint(pivot)
                        } else {
                            findNearestLocalCurvePoint(
                                pivot,
                                currentLocationIndex,
                                goalPointDistance,
                                reverseHeading
                            )
                        }
                        findGlobalNearestCurvePoint = false
                        currentLocationIndex = A
                        if (A > curList.size - 1) return

                        B = if (A == curList.size - 1) 0 else A + 1

                        if (glm.inRangeBetweenAB(
                                curList[A].easting,
                                curList[A].northing,
                                curList[B].easting,
                                curList[B].northing,
                                pivot.easting,
                                pivot.northing
                            )
                        ) {
                            // Segment found
                        } else {
                            A = if (A == 0) curList.size - 1 else A - 1
                            B = A + 1
                            if (!glm.inRangeBetweenAB(
                                    curList[A].easting,
                                    curList[A].northing,
                                    curList[B].easting,
                                    curList[B].northing,
                                    pivot.easting,
                                    pivot.northing
                                )
                            ) {
                                return
                            }
                        }
                    }

                    val dx = curList[B].easting - curList[A].easting
                    val dz = curList[B].northing - curList[A].northing

                    if (abs(dx) < Double.MIN_VALUE && abs(dz) < Double.MIN_VALUE) return

                    distanceFromCurrentLinePivot = ((dz * pivot.easting) - (dx * pivot.northing) +
                            (curList[B].easting * curList[A].northing) - (curList[B].northing * curList[A].easting)) /
                            sqrt((dz * dz) + (dx * dx))

                    if (mf.vehicle.purePursuitIntegralGain != 0.0 && !mf.isReverse) {
                        pivotDistanceError =
                            distanceFromCurrentLinePivot * 0.2 + pivotDistanceError * 0.8
                        if (counter2++ > 4) {
                            pivotDerivative = pivotDistanceError - pivotDistanceErrorLast
                            pivotDistanceErrorLast = pivotDistanceError
                            counter2 = 0
                            pivotDerivative *= 2
                        }

                        if (mf.isBtnAutoSteerOn && mf.avgSpeed > 2.5 && abs(pivotDerivative) < 0.1) {
                            inty =
                                if ((inty < 0 && distanceFromCurrentLinePivot < 0) || (inty > 0 && distanceFromCurrentLinePivot > 0)) {
                                    inty + pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.04
                                } else {
                                    if (abs(distanceFromCurrentLinePivot) > 0.02) {
                                        val newInty =
                                            inty + pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.02
                                        when {
                                            newInty > 0.2 -> 0.2
                                            newInty < -0.2 -> -0.2
                                            else -> newInty
                                        }
                                    } else inty
                                }
                        } else inty *= 0.95
                    } else inty = 0.0

                    val U = (((pivot.easting - curList[A].easting) * dx) +
                            ((pivot.northing - curList[A].northing) * dz)) /
                            ((dx * dx) + (dz * dz))

                    rEastCu = curList[A].easting + (U * dx)
                    rNorthCu = curList[A].northing + (U * dz)
                    manualUturnHeading = curList[A].heading

                    val count = if (reverseHeading) 1 else -1
                    var start = vec3(rEastCu, rNorthCu, 0.0)
                    var distSoFar = 0.0

                    var i = if (reverseHeading) B else A
                    while (i in 0 until curList.size) {
                        val tempDist = glm.distance(start, curList[i])
                        if ((tempDist + distSoFar) > goalPointDistance) {
                            val j = (goalPointDistance - distSoFar) / tempDist
                            goalPointCu.easting =
                                ((1 - j) * start.easting) + (j * curList[i].easting)
                            goalPointCu.northing =
                                ((1 - j) * start.northing) + (j * curList[i].northing)
                            break
                        }
                        distSoFar += tempDist
                        start = curList[i] // 更新 start
                        i += count
                        if (i < 0) i = curList.size - 1
                        if (i >= curList.size) i = 0
                    }

                    if (mf.isBtnAutoSteerOn && !mf.isReverse && track.mode <= TrackMode.Curve) {
                        val endPoint = if (isHeadingSameWay) curList.last() else curList[0]
                        if (glm.distance(goalPointCu, endPoint) < 0.5) {
                            mf.autoSteerButton.performClick()
                            mf.timedMessageBox(
                                mf,
                                2000,
                                mf.settings.gsGuidanceStopped,
                                mf.settings.gsPastEndOfCurve
                            )
                            Log.e("Autosteer", "Autosteer Stop, Past End of Curve")
                        }
                    }

                    val goalPointdistanceSquared = glm.distanceSquared(
                        goalPointCu.northing,
                        goalPointCu.easting,
                        pivot.northing,
                        pivot.easting
                    )
                    val localHeading =
                        if (reverseHeading) glm.twoPI - mf.fixHeading + inty else glm.twoPI - mf.fixHeading - inty

                    ppRadiusCu =
                        goalPointdistanceSquared / (2 * (((goalPointCu.easting - pivot.easting) * cos(
                            localHeading
                        )) +
                                ((goalPointCu.northing - pivot.northing) * sin(localHeading))))

                    steerAngleCu = glm.toDegrees(
                        atan(
                            2 * (((goalPointCu.easting - pivot.easting) * cos(localHeading)) +
                                    ((goalPointCu.northing - pivot.northing) * sin(localHeading))) * mf.vehicle.wheelbase / goalPointdistanceSquared
                        )
                    )

                    if (mf.ahrs.imuRoll != 88888.0) steerAngleCu += mf.ahrs.imuRoll * -mf.gyd.sideHillCompFactor

                    steerAngleCu =
                        steerAngleCu.coerceIn(-mf.vehicle.maxSteerAngle, mf.vehicle.maxSteerAngle)

                    if (!isHeadingSameWay) distanceFromCurrentLinePivot *= -1.0

                    mf.vehicle.modeActualXTE = distanceFromCurrentLinePivot
                    var steerHeadingError = pivot.heading - curList[A].heading
                    steerHeadingError = when {
                        steerHeadingError > PI -> steerHeadingError - PI
                        steerHeadingError < -PI -> steerHeadingError + PI
                        else -> steerHeadingError
                    }
                    steerHeadingError = when {
                        steerHeadingError > glm.piBy2 -> steerHeadingError - PI
                        steerHeadingError < -glm.piBy2 -> steerHeadingError + PI
                        else -> steerHeadingError
                    }

                    mf.vehicle.modeActualHeadingError = glm.toDegrees(steerHeadingError)
                    mf.guidanceLineDistanceOff =
                        (distanceFromCurrentLinePivot * 1000.0).roundToInt().toShort()
                    mf.guidanceLineSteerAngle = (steerAngleCu * 100).toInt().toShort()
                }
            }
        } else {
            distanceFromCurrentLinePivot = 32000.0
            mf.guidanceLineDistanceOff = 32000
        }
    }

    fun DrawCurveNew(googleMap: GoogleMap) {
        if (desList.isNotEmpty()) {
            val polylineOptions = PolylineOptions()
                .color(android.graphics.Color.rgb(243, 107, 191)) // Approx RGB: 0.95, 0.42, 0.75
                .width(4f)
                .addAll(desList.map { LatLng(it.northing, it.easting) })
            googleMap.addPolyline(polylineOptions)

            val lastPoint = LatLng(desList.last().northing, desList.last().easting)
            val pivotPoint = LatLng(mf.pivotAxlePos.northing, mf.pivotAxlePos.easting)
            googleMap.addPolyline(
                PolylineOptions()
                    .color(android.graphics.Color.YELLOW)
                    .width(4f)
                    .pattern(
                        listOf(
                            com.google.android.gms.maps.model.Dash(10f),
                            com.google.android.gms.maps.model.Gap(10f)
                        )
                    )
                    .add(lastPoint, pivotPoint)
            )
        }
    }

    fun DrawCurve(googleMap: GoogleMap) {
        if (mf.trk.idx == -1) return
        val track = mf.trk.gArr[mf.trk.idx]
        val ptCount = track.curvePts.size

        if (track.mode != TrackMode.WaterPivot) {
            if (track.curvePts.isEmpty()) return

            googleMap.addPolyline(
                PolylineOptions()
                    .color(android.graphics.Color.rgb(245, 51, 51)) // Approx RGB: 0.96, 0.2, 0.2
                    .width(4f)
                    .addAll(track.curvePts.map { LatLng(it.northing, it.easting) })
            )

            if (mf.font.isFontOn) {
                // Note: Google Maps doesn't have direct text drawing like OpenGL
                // You would need to use Markers for text, which isn't implemented here
            }

            if (isSmoothWindowOpen && smooList.isNotEmpty()) {
                googleMap.addPolyline(
                    PolylineOptions()
                        .color(
                            android.graphics.Color.rgb(
                                237,
                                235,
                                66
                            )
                        ) // Approx RGB: 0.93, 0.92, 0.26
                        .width(mf.ABLine.lineWidth.toFloat())
                        .addAll(smooList.map { LatLng(it.northing, it.easting) })
                )
            }
        }

        if (!isSmoothWindowOpen) {
            if (curList.isNotEmpty()) {
                googleMap.addPolyline(
                    PolylineOptions()
                        .color(android.graphics.Color.BLACK)
                        .width(mf.ABLine.lineWidth * 3f)
                        .addAll(curList.map { LatLng(it.northing, it.easting) })
                        .geodesic(track.mode > TrackMode.Curve)
                )

                val colorPurple =
                    android.graphics.Color.rgb(242, 51, 242) // Approx RGB: 0.95, 0.2, 0.95
                val polylineOptions = PolylineOptions()
                    .color(colorPurple)
                    .width(mf.ABLine.lineWidth.toFloat())
                    .addAll(curList.map { LatLng(it.northing, it.easting) })
                    .geodesic(track.mode > TrackMode.Curve)

                googleMap.addPolyline(polylineOptions)

                if (track.mode == TrackMode.WaterPivot) {
                    googleMap.addCircle(
                        CircleOptions()
                            .center(LatLng(track.ptA.northing, track.ptA.easting))
                            .radius(15.0)
                            .strokeColor(colorPurple)
                            .fillColor(colorPurple)
                    )
                }

                if (!mf.isStanleyUsed && mf.camera.camSetDistance > -200) {
                    googleMap.addCircle(
                        CircleOptions()
                            .center(LatLng(goalPointCu.northing, goalPointCu.easting))
                            .radius(4.0)
                            .strokeColor(
                                android.graphics.Color.rgb(
                                    255,
                                    242,
                                    50
                                )
                            ) // Approx RGB: 1.0, 0.95, 0.195
                            .fillColor(android.graphics.Color.rgb(255, 242, 50))
                    )
                }

                mf.yt.DrawYouTurn(googleMap)
            }
        }
    }

    fun BuildTram() {
        if (mf.tram.generateMode != 1) {
            mf.tram.buildTramBnd()
        } else {
            mf.tram.tramBndOuterArr.clear()
            mf.tram.tramBndInnerArr.clear()
        }

        mf.tram.tramList.clear()
        mf.tram.tramArr.clear()

        if (mf.tram.generateMode == 2) return

        val isBndExist = mf.bnd.bndList.isNotEmpty()
        val refCount = mf.trk.gArr[mf.trk.idx].curvePts.size

        val cntr = if (isBndExist && mf.tram.generateMode != 1) 1 else 0

        for (i in cntr..mf.tram.passes) {
           // mf.tram.tramArr = mutableListOf<vec2>().apply { ensureCapacity(128) }
            mf.tram.tramList.add(mf.tram.tramArr)

            var widd = (mf.tram.tramWidth * 0.5) - mf.tram.halfWheelTrack + (mf.tram.tramWidth * i)
            val distSqAway = widd * widd * 0.999999

            for (j in 0 until refCount step 1) {
                val point = vec2(
                    (sin(glm.piBy2 + mf.trk.gArr[mf.trk.idx].curvePts[j].heading) * widd) + mf.trk.gArr[mf.trk.idx].curvePts[j].easting,
                    (cos(glm.piBy2 + mf.trk.gArr[mf.trk.idx].curvePts[j].heading) * widd) + mf.trk.gArr[mf.trk.idx].curvePts[j].northing
                )

                var add = true
                for (t in 0 until refCount) {
                    val dist =
                        ((point.easting - mf.trk.gArr[mf.trk.idx].curvePts[t].easting) * (point.easting - mf.trk.gArr[mf.trk.idx].curvePts[t].easting)) +
                                ((point.northing - mf.trk.gArr[mf.trk.idx].curvePts[t].northing) * (point.northing - mf.trk.gArr[mf.trk.idx].curvePts[t].northing))
                    if (dist < distSqAway) {
                        add = false
                        break
                    }
                }

                if (add) {
                    val dist = if (mf.tram.tramArr!!.isNotEmpty()) {
                        ((point.easting - mf.tram.tramArr!!.last().easting) * (point.easting - mf.tram.tramArr!!.last().easting)) +
                                ((point.northing - mf.tram.tramArr!!.last().northing) * (point.northing - mf.tram.tramArr!!.last().northing))
                    } else 3.0
                    if (dist > 2) {
                        if (!isBndExist || mf.bnd.bndList[0].fenceLineEar.isPointInPolygon(point)) {
                            mf.tram.tramArr.add(point)
                        }
                    }
                }
            }
        }

        for (i in cntr..mf.tram.passes) {
        //    mf.tram.tramArr = mutableListOf<vec2>().apply { ensureCapacity(128) }
            mf.tram.tramList.add(mf.tram.tramArr)

            var widd = (mf.tram.tramWidth * 0.5) + mf.tram.halfWheelTrack + (mf.tram.tramWidth * i)
            val distSqAway = widd * widd * 0.999999

            for (j in 0 until refCount step 1) {
                val point = vec2(
                    (sin(glm.piBy2 + mf.trk.gArr[mf.trk.idx].curvePts[j].heading) * widd) + mf.trk.gArr[mf.trk.idx].curvePts[j].easting,
                    (cos(glm.piBy2 + mf.trk.gArr[mf.trk.idx].curvePts[j].heading) * widd) + mf.trk.gArr[mf.trk.idx].curvePts[j].northing
                )

                var add = true
                for (t in 0 until refCount) {
                    val dist =
                        ((point.easting - mf.trk.gArr[mf.trk.idx].curvePts[t].easting) * (point.easting - mf.trk.gArr[mf.trk.idx].curvePts[t].easting)) +
                                ((point.northing - mf.trk.gArr[mf.trk.idx].curvePts[t].northing) * (point.northing - mf.trk.gArr[mf.trk.idx].curvePts[t].northing))
                    if (dist < distSqAway) {
                        add = false
                        break
                    }
                }

                if (add) {
                    val dist = if (mf.tram.tramArr!!.isNotEmpty()) {
                        ((point.easting - mf.tram.tramArr!!.last().easting) * (point.easting - mf.tram.tramArr!!.last().easting)) +
                                ((point.northing - mf.tram.tramArr!!.last().northing) * (point.northing - mf.tram.tramArr!!.last().northing))
                    } else 3.0
                    if (dist > 2) {
                        if (!isBndExist || mf.bnd.bndList[0].fenceLineEar.isPointInPolygon(point)) {
                            mf.tram.tramArr!!.add(point)
                        }
                    }
                }
            }
        }
    }

    fun SmoothAB(smPts: Int) {
        val cnt = mf.trk.gArr[mf.trk.idx].curvePts.size
        if (cnt < 100) return

        val arr = Array(cnt) { vec3(0.0, 0.0, 0.0) }

        for (s in 0 until smPts / 2) {
            arr[s].easting = mf.trk.gArr[mf.trk.idx].curvePts[s].easting
            arr[s].northing = mf.trk.gArr[mf.trk.idx].curvePts[s].northing
            arr[s].heading = mf.trk.gArr[mf.trk.idx].curvePts[s].heading
        }

        for (s in cnt - (smPts / 2) until cnt) {
            arr[s].easting = mf.trk.gArr[mf.trk.idx].curvePts[s].easting
            arr[s].northing = mf.trk.gArr[mf.trk.idx].curvePts[s].northing
            arr[s].heading = mf.trk.gArr[mf.trk.idx].curvePts[s].heading
        }

        for (i in smPts / 2 until cnt - (smPts / 2)) {
            for (j in -smPts / 2 until smPts / 2) {
                arr[i].easting += mf.trk.gArr[mf.trk.idx].curvePts[j + i].easting
                arr[i].northing += mf.trk.gArr[mf.trk.idx].curvePts[j + i].northing
            }
            arr[i].easting /= smPts
            arr[i].northing /= smPts
            arr[i].heading = mf.trk.gArr[mf.trk.idx].curvePts[i].heading
        }

        smooList.clear()
        if (arr.isEmpty() || cnt < 1) return

        smooList.addAll(arr)
    }


    fun CalculateHeadings(xList: MutableList<vec3>) {
        val cnt = xList.size
        if (cnt > 3) {
            val arr = xList.toTypedArray()  // Replace copyInto with toTypedArray
            xList.clear()

            var pt3 = arr[0]
            pt3.heading = atan2(arr[1].easting - arr[0].easting, arr[1].northing - arr[0].northing)
            if (pt3.heading < 0) pt3.heading += glm.twoPI
            xList.add(pt3)

            for (i in 1 until cnt - 1) {
                pt3 = arr[i]
                pt3.heading = atan2(
                    arr[i + 1].easting - arr[i - 1].easting,
                    arr[i + 1].northing - arr[i - 1].northing
                )
                if (pt3.heading < 0) pt3.heading += glm.twoPI
                xList.add(pt3)
            }

            pt3 = arr[arr.size - 1]
            pt3.heading = atan2(
                arr[arr.size - 1].easting - arr[arr.size - 2].easting,
                arr[arr.size - 1].northing - arr[arr.size - 2].northing
            )
            if (pt3.heading < 0) pt3.heading += glm.twoPI
            xList.add(pt3)
        }
    }


    fun MakePointMinimumSpacing(xList: MutableList<vec3>, minDistance: Double) {
        val cnt = xList.size
        if (cnt > 3) {
            var i = 0
            while (i < cnt - 1) {
                val j = i + 1
                val distance = glm.distance(xList[i], xList[j])
                if (distance > minDistance) {
                    val pointB = vec3(
                        (xList[i].easting + xList[j].easting) / 2.0,
                        (xList[i].northing + xList[j].northing) / 2.0,
                        xList[i].heading
                    )
                    xList.add(j, pointB)
                    i = -1 // Reset to start to check all distances again
                }
                i++
            }
        }
    }

    fun SaveSmoothList() {
        if (smooList.isEmpty()) return
        val cnt = smooList.size
        if (cnt == 0) return

        mf.trk.gArr[mf.trk.idx].curvePts?.clear()
        val arr = smooList.toTypedArray()

        for (i in 1 until cnt - 1) {
            arr[i].heading =
                atan2(arr[i + 1].easting - arr[i].easting, arr[i + 1].northing - arr[i].northing)
            if (arr[i].heading < 0) arr[i].heading += glm.twoPI
            mf.trk.gArr[mf.trk.idx].curvePts?.add(arr[i])
        }
    }

    fun PointOnLine(pt1: vec3, pt2: vec3, pt: vec3): Boolean {
        var r = vec2(0.0, 0.0)
        var modifiedPt1 = pt1
        if (pt1.northing == pt2.northing && pt1.easting == pt2.easting) {
            modifiedPt1 = vec3(pt1.easting, pt1.northing - 0.00001, pt1.heading)
        }

        val U = ((pt.northing - modifiedPt1.northing) * (pt2.northing - modifiedPt1.northing)) +
                ((pt.easting - modifiedPt1.easting) * (pt2.easting - modifiedPt1.easting))
        val Udenom =
            (pt2.northing - modifiedPt1.northing).pow(2) + (pt2.easting - modifiedPt1.easting).pow(2)

        val uFinal = U / Udenom
        r.northing = modifiedPt1.northing + (uFinal * (pt2.northing - modifiedPt1.northing))
        r.easting = modifiedPt1.easting + (uFinal * (pt2.easting - modifiedPt1.easting))

        val minx = minOf(modifiedPt1.northing, pt2.northing)
        val maxx = maxOf(modifiedPt1.northing, pt2.northing)
        val miny = minOf(modifiedPt1.easting, pt2.easting)
        val maxy = maxOf(modifiedPt1.easting, pt2.easting)

        return r.northing in minx..maxx && r.easting in miny..maxy
    }

    fun AddFirstLastPoints(xList: MutableList<vec3>) {
        val ptCnt = xList.size - 1
        val start = vec3(xList[0])

        val iterations = if (mf.bnd.bndList.isNotEmpty()) 100 else 300
        for (i in 1..iterations) {
            val ptEnd = vec3(xList[ptCnt]).apply {
                easting += sin(heading) * i
                northing += cos(heading) * i
            }
            xList.add(ptEnd)
        }

        for (i in 1..iterations) {
            val ptStart = vec3(start).apply {
                easting -= sin(heading) * i
                northing -= cos(heading) * i
            }
            xList.add(0, ptStart)
        }
    }

    fun ResetCurveLine() {
        curList.clear()
        mf.trk.idx = -1
    }

    private fun findGlobalNearestCurvePoint(refPoint: vec3, increment: Int = 1): Int {
        var minDist = Double.MAX_VALUE
        var minDistIndex = 0

        for (i in 0 until curList.size step increment) {
            val dist = glm.distanceSquared(refPoint, curList[i])
            if (dist < minDist) {
                minDist = dist
                minDistIndex = i
            }
        }
        return minDistIndex
    }

    private fun findNearestLocalCurvePoint(
        refPoint: vec3,
        startIndex: Int,
        minSearchDistance: Double,
        reverseSearchDirection: Boolean
    ): Int {
        var minDist =
            glm.distanceSquared(refPoint, curList[(startIndex + curList.size) % curList.size])
        var minDistIndex = startIndex
        val directionMultiplier = if (reverseSearchDirection) 1 else -1
        var distSoFar = 0.0
        var start = curList[startIndex]

        var offset = 1
        while (offset < curList.size) {
            val pointIndex =
                (startIndex + (offset * directionMultiplier) + curList.size) % curList.size
            val dist = glm.distanceSquared(refPoint, curList[pointIndex])
            if (dist < minDist) {
                minDist = dist
                minDistIndex = pointIndex
            }
            distSoFar += glm.distance(start, curList[pointIndex])
            start = curList[pointIndex]
            offset++
            if (distSoFar > minSearchDistance) break
        }

        while (offset < curList.size) {
            val pointIndex =
                (startIndex + (offset * directionMultiplier) + curList.size) % curList.size
            val dist = glm.distanceSquared(refPoint, curList[pointIndex])
            if (dist < minDist) {
                minDist = dist
                minDistIndex = pointIndex
            } else break
            offset++
        }

        offset = 1
        while (offset < curList.size) {
            val pointIndex =
                (startIndex + (offset * -directionMultiplier) + curList.size) % curList.size
            val dist = glm.distanceSquared(refPoint, curList[pointIndex])
            if (dist < minDist) {
                minDist = dist
                minDistIndex = pointIndex
            } else break
            offset++
        }

        return minDistIndex
    }
}