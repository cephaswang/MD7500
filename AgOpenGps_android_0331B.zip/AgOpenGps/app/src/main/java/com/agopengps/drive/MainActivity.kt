package com.agopengps.drive


import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.content.res.Resources
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.agopengps.classes.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import java.util.*
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import androidx.core.content.edit
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity(), OnMapReadyCallback, SensorEventListener,
    LocationListener {

    lateinit var mMap: GoogleMap

    // 在 MainActivity 的屬性區域添加
    var mvpMatrixHandle: Int = 0

    //region 常量定义
    companion object {
        private const val TAG = "MainActivity"
        private const val PERMISSION_REQUEST_CODE = 1001
        private const val GPS_MIN_TIME_MS = 1000L
        private const val GPS_MIN_DISTANCE_M = 1f
        private const val FRAME_UPDATE_DELAY_MS = 16L
        private const val FPS_UPDATE_INTERVAL_MS = 1000L

        private val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
    }

    enum class SoundType {
        BOUNDARY_ALARM,
        UTURN_TOO_CLOSE,
        AUTO_STEER_ON,
        AUTO_STEER_OFF,
        HYD_LIFT_UP,
        HYD_LIFT_DOWN,
        RTK_ALARM,
        SECTION_ON,
        SECTION_OFF,
        BUTTON_CLICK
    }
    //endregion

    //region
    lateinit var settings: SettingsData
    private var menu: Menu? = null
    var glProgram: Int = 0
    var isJobStarted = false
    private var startCounter = 0
    var isBtnAutoSteerOn = false
    var manualBtnState = BtnStates.OFF
    var autoBtnState = BtnStates.AUTO
    private val triStrip = mutableListOf<CPatches>().apply { add(CPatches(this@MainActivity)) }
    private var m2InchOrCm = 0.01 // 默认为公制单位（米转厘米）
    var isReverse = false
    var avgSpeed = 0.0
    var guidanceLineDistanceOff: Short = 0
    var guidanceLineSteerAngle: Short = 0
    var fixHeading: Double = 0.0
    var isStanleyUsed: Boolean = true
    var contourSaveList: MutableList<MutableList<Vec3>> = mutableListOf()
    var patchCounter: Int = 0
    var secondsSinceStart: Double = 0.0
    var isPureDisplayOn: Boolean = false
    var steerAxlePos: Vec2 = Vec2(0.0, 0.0)
    var rpWidth: Double = 0.0
    var lookAheadDistanceOnPixelsRight: Double = 0.0
    var lookAheadDistanceOnPixelsLeft: Double = 0.0

    private var frameCount = 0
    private var lastFpsTime = System.currentTimeMillis()
    private var fps = 0.0
    //endregion

    //region 核心组件
    lateinit var camera: CCamera
    lateinit var worldGrid: CWorldGrid
    lateinit var vehicle: CVehicle
    lateinit var tool: CTool
    lateinit var pn: CNMEA
    lateinit var ABLine: CABLine
    lateinit var tram: CTram
    private lateinit var ct: CContour
    lateinit var trk: CTrack
    lateinit var curve: CABCurve
    lateinit var yt: CYouTurn
    lateinit var mc: CModuleComm
    lateinit var bnd: CBoundary
    private lateinit var hdl: CHeadLine
    lateinit var ahrs: CAHRS
    private lateinit var recPath: CRecordedPath
    lateinit var fd: CFieldData
    lateinit var sounds: CSound
    private lateinit var font: CFont
    lateinit var gyd: CGuidance
    lateinit var section: Array<CSection>
    lateinit var p_239: CModuleComm.PGN239
    lateinit var toolPivotPos: Vec3
    //endregion

    //region 视图组件
    private lateinit var glSurfaceView: GLSurfaceView
    private lateinit var glRenderer: GLRenderer
    private lateinit var mapView: MapView
    private lateinit var googleMap: GoogleMap
    lateinit var btnAutoSteer: ImageButton
    lateinit var btnSectionMasterAuto: ImageButton
    lateinit var btnSectionMasterManual: ImageButton
    private lateinit var btnHydLift: ImageButton
    private lateinit var btnAutoYouTurn: ImageButton
    private lateinit var btnContour: ImageButton
    private lateinit var btnTrack: ImageButton
    private lateinit var btnABDraw: ImageButton
    private lateinit var btnCycleLines: ImageButton
    private lateinit var btnCycleLinesBk: ImageButton
    private lateinit var btnAutoTrack: ImageButton
    private lateinit var btnFlag: ImageButton
    lateinit var btnResumePath: ImageButton
    private lateinit var btnFieldStats: Button
    private lateinit var btnBrightnessDn: Button
    private lateinit var btnBrightnessUp: Button
    private lateinit var btnChargeStatus: Button
    private lateinit var lblGuidanceLine: TextView
    private lateinit var lblHardwareMessage: TextView
    lateinit var displayFieldName: TextView
    private lateinit var txtGpsStatus: TextView
    private lateinit var txtVehicleSpeed: TextView
    private lateinit var txtSteerAngle: TextView
    private lateinit var panelRight: LinearLayout
    private lateinit var panelDrag: LinearLayout
    private lateinit var panelSim: LinearLayout
    private lateinit var oglZoom: GLSurfaceView
    //endregion

    //region 系统服务
    private lateinit var sensorManager: SensorManager
    private lateinit var locationManager: LocationManager
    private lateinit var mainHandler: Handler
    private lateinit var prefs: SharedPreferences
    //endregion

    //region 生命周期
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate")

        // 初始化 SettingsData
        settings = SettingsData()

        // 如果需要从 SharedPreferences 加载设置
        val sharedPreferences = getSharedPreferences("YourPreferencesName", Context.MODE_PRIVATE)
        settings.loadFromPreferences(sharedPreferences)

        // 初始化多语言支持
        initLanguage()

        setContentView(R.layout.activity_main)

        // 初始化时间戳
        secondsSinceStart = System.currentTimeMillis() / 1000.0

        // 初始化视图
        initViews()

        // 检查并请求权限
        if (checkAndRequestPermissions()) {
            initSystemServices()
        }

        // 初始化核心组件
        initComponents()

        // 设置事件监听
        setupListeners()

        // 启动主循环
        mainHandler.post(frameUpdateRunnable)
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume")
        mapView.onResume()
        registerSensors()
        updateSoundSettings()

        // 恢复主循环
        if (!mainHandler.hasCallbacks(frameUpdateRunnable)) {
            mainHandler.post(frameUpdateRunnable)
        }
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause")
        mapView.onPause()
        unregisterSensors()
        mainHandler.removeCallbacks(frameUpdateRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy")
        mapView.onDestroy()
        mainHandler.removeCallbacks(frameUpdateRunnable)
        sounds.releaseAll()
    }
    //endregion

    //region 声音功能
    fun playSound(type: SoundType) {
        runOnUiThread {
            when (type) {
                SoundType.BOUNDARY_ALARM -> sounds.playBoundaryAlarm()
                SoundType.UTURN_TOO_CLOSE -> sounds.playUTurnTooClose()
                SoundType.AUTO_STEER_ON -> sounds.playAutoSteerOn()
                SoundType.AUTO_STEER_OFF -> sounds.playAutoSteerOff()
                SoundType.HYD_LIFT_UP -> sounds.playHydLiftUp()
                SoundType.HYD_LIFT_DOWN -> sounds.playHydLiftDown()
                SoundType.RTK_ALARM -> sounds.playRTKAlarm()
                SoundType.SECTION_ON -> sounds.playSectionOn()
                SoundType.SECTION_OFF -> sounds.playSectionOff()
                SoundType.BUTTON_CLICK -> {
                    // 默认按钮点击音效使用SECTION_ON
                    sounds.playSectionOn()
                }
            }
        }
    }

    fun updateSoundSettings() {
        val prefs = getSharedPreferences("Settings", Context.MODE_PRIVATE)
        sounds.isSteerSoundOn = prefs.getBoolean("setSound_isAutoSteerOn", true)
        sounds.isHydLiftSoundOn = prefs.getBoolean("setSound_isHydLiftOn", true)
        sounds.isTurnSoundOn = prefs.getBoolean("setSound_isUturnOn", true)
        sounds.isSectionsSoundOn = prefs.getBoolean("setSound_isSectionsOn", true)
    }

    fun onHydLiftChanged(isUp: Boolean) {
        sounds.isHydLiftChange = true
        playSound(if (isUp) SoundType.HYD_LIFT_UP else SoundType.HYD_LIFT_DOWN)
        sounds.isHydLiftChange = false
    }
    //endregion

    //region 初始化方法
    private fun initLanguage() {
        prefs = getSharedPreferences("AppSettings", Context.MODE_PRIVATE)
        val langCode = prefs.getString("language", "en") ?: "en"

        // 设置默认值（如果尚未设置）
        if (!prefs.contains("setHeadland_isSectionControlled")) {
            prefs.edit { putBoolean("setHeadland_isSectionControlled", false) }
        }

        setAppLocale(langCode)
    }

    private fun setAppLocale(languageCode: String) {
        val resources: Resources = resources
        val dm: DisplayMetrics = resources.displayMetrics
        val config: Configuration = resources.configuration
        config.setLocale(Locale(languageCode))
        resources.updateConfiguration(config, dm)

        // 保存语言设置
        prefs.edit().putString("language", languageCode).apply()
    }

    private fun initViews() {
        initGLSurfaceView()
        initMapView()
        initControlButtons()
        initStatusDisplays()
        initPanels()
    }

    private fun initGLSurfaceView() {
        glSurfaceView = findViewById(R.id.glSurfaceView)
        glRenderer = GLRenderer(this)
        glSurfaceView.setRenderer(glRenderer)
        glSurfaceView.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
    }

    private fun initMapView() {
        mapView = findViewById(R.id.mapView)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)
    }

    private fun initControlButtons() {
        btnAutoSteer = findViewById(R.id.btnAutoSteer)
        btnSectionMasterAuto = findViewById(R.id.btnSectionMasterAuto)
        btnSectionMasterManual = findViewById(R.id.btnSectionMasterManual)
        btnHydLift = findViewById(R.id.btnHydLift)
        btnAutoYouTurn = findViewById(R.id.btnAutoYouTurn)
        btnContour = findViewById(R.id.btnContour)
        btnTrack = findViewById(R.id.btnTrack)
        btnABDraw = findViewById(R.id.btnABDraw)
        btnCycleLines = findViewById(R.id.btnCycleLines)
        btnCycleLinesBk = findViewById(R.id.btnCycleLinesBk)
        btnAutoTrack = findViewById(R.id.btnAutoTrack)
        btnFlag = findViewById(R.id.btnFlag)
        btnResumePath = findViewById(R.id.btnResumePath)
    }

    private fun initStatusDisplays() {
        lblGuidanceLine = findViewById(R.id.lblGuidanceLine)
        lblHardwareMessage = findViewById(R.id.lblHardwareMessage)
        displayFieldName = findViewById(R.id.displayFieldName)
        txtGpsStatus = findViewById(R.id.txtGpsStatus)
        txtVehicleSpeed = findViewById(R.id.txtVehicleSpeed)
        txtSteerAngle = findViewById(R.id.txtSteerAngle)
        btnFieldStats = findViewById(R.id.btnFieldStats)
        btnBrightnessDn = findViewById(R.id.btnBrightnessDn)
        btnBrightnessUp = findViewById(R.id.btnBrightnessUp)
        btnChargeStatus = findViewById(R.id.btnChargeStatus)
    }

    private fun initPanels() {
        panelRight = findViewById(R.id.panelRight)
        panelDrag = findViewById(R.id.panelDrag)
        panelSim = findViewById(R.id.panelSim)
        oglZoom = findViewById(R.id.oglZoom)
    }

    private fun initSystemServices() {
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        mainHandler = Handler(Looper.getMainLooper())

        registerSensors()
        startLocationUpdates()
    }

    private fun registerSensors() {
        sensorManager.registerListener(
            this,
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
            SensorManager.SENSOR_DELAY_GAME
        )
        sensorManager.registerListener(
            this,
            sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE),
            SensorManager.SENSOR_DELAY_GAME
        )
    }

    private fun unregisterSensors() {
        sensorManager.unregisterListener(this)
    }

    private fun startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                GPS_MIN_TIME_MS,
                GPS_MIN_DISTANCE_M,
                this
            )
        }
    }

    private fun initComponents() {
        // 初始化设置
        settings = SettingsData().apply {
            setVehicle_toolWidth = 10.0
            setVehicle_toolOverlap = 0.2
        }

        // 初始化核心组件
        worldGrid = CWorldGrid(this)
        vehicle = CVehicle(this)
        tool = CTool(this)
        pn = CNMEA(this)
        abLine = CABLine(this)
        tram = CTram(this)
        ct = CContour(this)
        curve = CABCurve(this)
        trk = CTrack(this)
        hdl = CHeadLine(this)
        yt = CYouTurn(this)
        mc = CModuleComm(this)
        bnd = CBoundary(this)
        ahrs = CAHRS(this)
        recPath = CRecordedPath(this)
        fd = CFieldData(this)
        sounds = CSound(this)
        font = CFont(this)
        gyd = CGuidance(this)
        //  camera = CCamera(this).apply { gridZoom = camSetDistance / -15 }

        // 在初始化部分
        camera = CCamera(
            settings = getSharedPreferences("CameraSettings", Context.MODE_PRIVATE),
            mvpMatrixHandle = mvpMatrixHandle
        ).apply {
            gridZoom = camSetDistance / -15
        }


        // 初始化 steerAxlePos
        steerAxlePos = Vec2(vehicle.easting, vehicle.northing)

        // 初始化 section 数组
        section = Array(16) { CSection(this, it) }

        updateUIState()
    }
    //endregion

    //region 权限管理
    private fun checkAndRequestPermissions(): Boolean {
        val missingPermissions = REQUIRED_PERMISSIONS.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        return if (missingPermissions.isEmpty()) {
            true
        } else {
            ActivityCompat.requestPermissions(
                this,
                missingPermissions.toTypedArray(),
                PERMISSION_REQUEST_CODE
            )
            false
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                initSystemServices()
            } else {
                showPermissionDeniedDialog()
            }
        }
    }

    private fun showPermissionDeniedDialog() {
        AlertDialog.Builder(this)
            .setTitle(R.string.permission_required)
            .setMessage(R.string.location_permission_denied_message)
            .setPositiveButton(R.string.settings) { _, _ ->
                openAppSettings()
            }
            .setNegativeButton(R.string.exit) { _, _ ->
                finish()
            }
            .setCancelable(false)
            .show()
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)
    }
    //endregion

    //region 菜单和多语言
    private fun fieldMenuButtonEnableDisable(isOn: Boolean) {
        val menu = menu ?: return
        menu.findItem(R.id.menu_smooth_ab)?.isEnabled = isOn
        menu.findItem(R.id.menu_boundaries)?.isEnabled = isOn
        menu.findItem(R.id.menu_headland)?.isEnabled = isOn
        menu.findItem(R.id.menu_tram_lines)?.isEnabled = isOn
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.language_menu, menu)
        this.menu = menu
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_language_en -> {
                setAppLocale("en")
                recreate()
                true
            }

            R.id.menu_language_zh -> {
                setAppLocale("zh")
                recreate()
                true
            }

            R.id.menu_language_es -> {
                setAppLocale("es")
                recreate()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }
    //endregion

    //region 作业管理
    fun jobNew() {
        isJobStarted = true
        startCounter = 0
        playSound(SoundType.SECTION_ON)

        runOnUiThread {
            btnFieldStats.visibility = View.VISIBLE
            btnSectionMasterManual.isEnabled = true
            btnSectionMasterAuto.isEnabled = true
            updateButtonStates()

            if (tool.isSectionsNotZones) lineUpIndividualSectionBtns() else lineUpAllZoneButtons()

            panelRight.isEnabled = true
            fieldMenuButtonEnableDisable(true)
            setZoom()
            updateUIState()
        }
    }

    private fun lineUpIndividualSectionBtns() {
        val sectionButtons = listOf(
            findViewById<ImageButton>(R.id.btnSection1Man),
            findViewById<ImageButton>(R.id.btnSection2Man),
            // ... 添加其他14个按钮
        )
        sectionButtons.forEachIndexed { index, button ->
            button.isEnabled = isJobStarted
            button.setBackgroundColor(if (isJobStarted) Color.RED else Color.GRAY)
            button.setImageResource(if (manualBtnState == BtnStates.ON) R.drawable.section_on else R.drawable.section_off)
        }
    }

    private fun lineUpAllZoneButtons() {
        val zoneButtons = listOf(
            findViewById<Button>(R.id.btnZone1),
            findViewById<Button>(R.id.btnZone2),
            // ... 添加其他6个按钮
        )
        zoneButtons.forEachIndexed { index, button ->
            button.isEnabled = isJobStarted
            button.setBackgroundColor(if (isJobStarted) Color.RED else Color.GRAY)
        }
    }

    private fun setZoom() {
        if (::camera.isInitialized) {
            camera.gridZoom = camera.camSetDistance / -15
            val gridToolSpacing = (camera.gridZoom / tool.width + 0.5).toInt().coerceAtLeast(1)
            camera.gridZoom = gridToolSpacing * tool.width
            glRenderer.updateProjectionMatrix()
            glSurfaceView.requestRender()
        }
        if (::googleMap.isInitialized) {
            googleMap.moveCamera(CameraUpdateFactory.zoomTo(15f))
        }
    }

    fun jobClose() {
        isJobStarted = false
        playSound(SoundType.SECTION_OFF)

        runOnUiThread {
            // 重置UI状态
            btnFieldStats.visibility = View.GONE
            btnSectionMasterManual.isEnabled = false
            btnSectionMasterAuto.isEnabled = false
            updateButtonStates()

            // 清理数据
            bnd.bndList.clear()
            recPath.recList.clear()
            triStrip.forEach { it.patchList?.clear() }

            panelRight.isEnabled = false
            fieldMenuButtonEnableDisable(false)
            updateUIState()
        }
    }
    //endregion

    //region UI更新
    private fun updateUIState() {
        // GPS状态
        val gpsStatusText = when (vehicle.gpsQuality) {
            1 -> getString(R.string.gps_status_3d)
            2 -> getString(R.string.gps_status_dgps)
            else -> getString(R.string.gps_status_default)
        }
        txtGpsStatus.text = gpsStatusText

        // 任务状态相关UI
        btnFieldStats.visibility = if (isJobStarted) View.VISIBLE else View.GONE
        btnSectionMasterManual.isEnabled = isJobStarted
        btnSectionMasterAuto.isEnabled = isJobStarted
        panelRight.isEnabled = isJobStarted

        // 自动转向按钮状态
        btnAutoSteer.setImageResource(
            if (isBtnAutoSteerOn) R.drawable.autosteer_on else R.drawable.autosteer_off
        )

        // 电源状态
        btnChargeStatus.text = if (isPowerOnline) {
            getString(R.string.power_status_default)
        } else {
            getString(R.string.power_status_offline)
        }

        // 速度和转向角度
        txtVehicleSpeed.text = String.format("%.1f km/h", vehicleSpeed ?: 0.0)
        txtSteerAngle.text = String.format("%.1f°", steerAngle ?: 0.0)
    }

    private fun updateButtonImage(button: ImageButton, isOn: Boolean, onResId: Int, offResId: Int) {
        button.setImageResource(if (isOn) onResId else offResId)
    }

    private fun updateButtonStates() {
        updateButtonImage(
            btnAutoSteer,
            isBtnAutoSteerOn,
            R.drawable.autosteer_on,
            R.drawable.autosteer_off
        )
        updateButtonImage(
            btnSectionMasterManual,
            manualBtnState == BtnStates.ON,
            R.drawable.manual_on,
            R.drawable.manual_off
        )
        updateButtonImage(
            btnSectionMasterAuto,
            autoBtnState == BtnStates.AUTO,
            R.drawable.section_master_auto,
            R.drawable.section_master_off
        )
    }

    private fun updateSteeringUI() {
        runOnUiThread {
            txtSteerAngle.text = String.format("%.1f°", vehicle.steerAngle)
            lblGuidanceLine.text = String.format("%.2fm", gyd.distanceFromCurrentLinePivot)

            // 当偏离路线时播放警告音
            if (gyd.distanceFromCurrentLinePivot > 1.0) {
                playSound(SoundType.UTURN_TOO_CLOSE)
            }
        }
    }

    private fun updateLocationUI() {
        runOnUiThread {
            txtGpsStatus.text = when (vehicle.gpsQuality) {
                1 -> getString(R.string.gps_status_3d)
                2 -> getString(R.string.gps_status_dgps)
                else -> getString(R.string.gps_status_default)
            }

            txtVehicleSpeed.text = getString(R.string.speed_format).format(
                vehicle.speed * 3.6,
                if (m2InchOrCm == 0.01) "km/h" else "mph"
            )

            if (::googleMap.isInitialized) {
                googleMap.moveCamera(
                    CameraUpdateFactory.newLatLng(
                        LatLng(vehicle.latitude, vehicle.longitude)
                    )
                )
            }

            // RTK信号检查
            if (vehicle.gpsQuality < 2) {
                playSound(SoundType.RTK_ALARM)
            }
        }
    }
    //endregion

    //region 事件监听
    private fun setupListeners() {
        btnAutoSteer.setOnClickListener {
            isBtnAutoSteerOn = !isBtnAutoSteerOn
            updateButtonImage(
                btnAutoSteer, isBtnAutoSteerOn,
                R.drawable.autosteer_on, R.drawable.autosteer_off
            )
            gyd.setAutoSteer(isBtnAutoSteerOn)
            playSound(if (isBtnAutoSteerOn) SoundType.AUTO_STEER_ON else SoundType.AUTO_STEER_OFF)
        }

        btnSectionMasterManual.setOnClickListener {
            manualBtnState = when (manualBtnState) {
                BtnStates.OFF -> BtnStates.ON
                BtnStates.ON -> BtnStates.OFF
            }
            updateButtonStates()
            playSound(SoundType.BUTTON_CLICK)
        }

        btnSectionMasterAuto.setOnClickListener {
            autoBtnState = when (autoBtnState) {
                BtnStates.OFF -> BtnStates.AUTO
                BtnStates.AUTO -> BtnStates.OFF
                BtnStates.ON -> TODO()
            }
            updateButtonStates()
            playSound(SoundType.BUTTON_CLICK)
        }

        btnContour.setOnClickListener {
            ct.isContourOn = !ct.isContourOn
            updateButtonImage(
                btnContour, ct.isContourOn,
                R.drawable.contour_on, R.drawable.contour_off
            )
            playSound(SoundType.BUTTON_CLICK)
        }

        btnHydLift.setOnClickListener {
            // 假设这是一个切换液压升降状态的按钮
            val isUp = !btnHydLift.isSelected
            btnHydLift.isSelected = isUp
            onHydLiftChanged(isUp)
            playSound(SoundType.BUTTON_CLICK)
        }

        // ... 其他按钮监听
    }
    //endregion

    //region 主循环
    private val frameUpdateRunnable = object : Runnable {
        override fun run() {
            val startTime = System.currentTimeMillis()

            updatePositionAndDraw()

            // 计算FPS
            frameCount++
            if (System.currentTimeMillis() - lastFpsTime >= FPS_UPDATE_INTERVAL_MS) {
                fps = frameCount * 1000.0 / (System.currentTimeMillis() - lastFpsTime)
                frameCount = 0
                lastFpsTime = System.currentTimeMillis()
                Log.d(TAG, "Current FPS: $fps")
            }

            // 边界检查
            if (bnd.isInsideBoundary(vehicle.easting, vehicle.northing)) {
                playSound(SoundType.BOUNDARY_ALARM)
            }

            // 计算下一帧时间
            val executionTime = System.currentTimeMillis() - startTime
            val delay = maxOf(0, FRAME_UPDATE_DELAY_MS - executionTime)
            mainHandler.postDelayed(this, delay)
        }
    }

    private fun updatePositionAndDraw() {
        vehicle.updateVehiclePosition()
        gyd.updateGuidance()
        if (autoBtnState == BtnStates.AUTO) updateSectionControl()
        glSurfaceView.requestRender()
        updateSteeringUI()

        // 更新导引线数据
        guidanceLineDistanceOff = gyd.distanceFromCurrentLinePivot.roundToInt().toShort()
        guidanceLineSteerAngle = (gyd.steerAngleGu * 100).toInt().toShort()
    }

    private fun updateSectionControl() {
        // 更新区段控制逻辑
        section.forEach {
            it.updateSection()
            if (it.isSectionOn) {
                playSound(SoundType.SECTION_ON)
            } else {
                playSound(SoundType.SECTION_OFF)
            }
        }
    }
    //endregion

    //region 回调接口
    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        googleMap.uiSettings.isZoomControlsEnabled = true

        if (::vehicle.isInitialized && vehicle.isGPSPositionInitialized) {
            val latLng = LatLng(vehicle.latitude, vehicle.longitude)
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f))
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            when (event.sensor.type) {
                Sensor.TYPE_ACCELEROMETER -> ahrs.updateAccelerometer(
                    event.values[0],
                    event.values[1],
                    event.values[2]
                )

                Sensor.TYPE_GYROSCOPE -> ahrs.updateGyroscope(
                    event.values[0],
                    event.values[1],
                    event.values[2]
                )
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onLocationChanged(location: Location) {
        fixHeading = Math.toRadians(location.bearing.toDouble())
        vehicle.updatePosition(
            location.latitude,
            location.longitude,
            location.speed.toDouble(),
            location.bearing.toDouble()
        )
        avgSpeed = location.speed.toDouble()
        steerAxlePos = Vec2(vehicle.easting, vehicle.northing)
        updateLocationUI()
    }
    //endregion

    //region 辅助功能
    fun setContourLockImage(isLocked: Boolean) {
        runOnUiThread {
            btnContour.setImageResource(if (isLocked) R.drawable.contour_locked else R.drawable.contour_unlocked)
            playSound(SoundType.BUTTON_CLICK)
        }
    }

    fun timedMessageBox(duration: Int, title: String, message: String) {
        runOnUiThread {
            val handler = Handler(Looper.getMainLooper())
            val dialog = AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .create()
            dialog.show()
            handler.postDelayed({ dialog.dismiss() }, duration.toLong())
            playSound(SoundType.BUTTON_CLICK)
        }
    }
    //endregion

    //region GLRenderer
    inner class GLRenderer(private val context: Context) : GLSurfaceView.Renderer {
        private val projectionMatrix = FloatArray(16)
        private val viewMatrix = FloatArray(16)
        private val modelMatrix = FloatArray(16)
        private val mvpMatrix = FloatArray(16)

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f)
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            mvpMatrixHandle = GLES20.glGetUniformLocation(glProgram, "uMVPMatrix")

            loadShaders()
            loadGLTextures()
            font.initFont()
        }

        private fun loadShaders() {
            try {
                glProgram = GLTools.loadShaderProgram(
                    context,
                    R.raw.vertex_shader,
                    R.raw.fragment_shader
                )
            } catch (e: Exception) {
                Log.e(TAG, "Error loading shaders: ${e.message}")
            }
        }

        private fun loadGLTextures() {
            // 加载纹理资源
            try {
                // 这里添加纹理加载逻辑
            } catch (e: Exception) {
                Log.e(TAG, "Error loading textures: ${e.message}")
            }
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            GLES20.glViewport(0, 0, width, height)
            updateProjectionMatrix()
        }

        fun updateProjectionMatrix() {
            val ratio = glSurfaceView.width.toFloat() / glSurfaceView.height.toFloat()
            Matrix.frustumM(projectionMatrix, 0, -ratio, ratio, -1f, 1f, 1f, 100f)
        }

        override fun onDrawFrame(gl: GL10?) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

            // 设置相机视图
            Matrix.setLookAtM(
                viewMatrix, 0,
                camera.camPosX.toFloat(), camera.camPosY.toFloat(), camera.camPosZ.toFloat(),
                camera.camLookX.toFloat(), camera.camLookY.toFloat(), camera.camLookZ.toFloat(),
                0f, 1f, 0f
            )

            // 绘制各组件
            drawWorldGrid()
            drawVehicle()
            drawTool()
            drawGuidanceLines()
            drawTextInfo()
        }

        private fun drawWorldGrid() {
            Matrix.setIdentityM(modelMatrix, 0)
            calculateMvpMatrix()
            worldGrid.draw(mvpMatrix, glProgram)
        }

        private fun drawVehicle() {
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(
                modelMatrix,
                0,
                vehicle.easting.toFloat(),
                0f,
                vehicle.northing.toFloat()
            )
            Matrix.rotateM(modelMatrix, 0, Math.toDegrees(vehicle.heading).toFloat(), 0f, 1f, 0f)
            calculateMvpMatrix()
            vehicle.draw(mvpMatrix, glProgram)
        }

        private fun drawTool() {
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, tool.easting.toFloat(), 0f, tool.northing.toFloat())
            Matrix.rotateM(modelMatrix, 0, Math.toDegrees(tool.heading).toFloat(), 0f, 1f, 0f)
            calculateMvpMatrix()
            tool.draw(mvpMatrix, glProgram)
        }

        private fun drawGuidanceLines() {
            if (abLine.isABLineSet) {
                Matrix.setIdentityM(modelMatrix, 0)
                calculateMvpMatrix()
                abLine.draw(mvpMatrix, glProgram)
            }
        }

        private fun calculateMvpMatrix() {
            Matrix.multiplyMM(mvpMatrix, 0, viewMatrix, 0, modelMatrix, 0)
            Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, mvpMatrix, 0)
        }

        private fun drawTextInfo() {
            // 使用CFont绘制文本信息
            val infoText = buildString {
                append("Speed: %.1f km/h\n".format(vehicle.speed * 3.6))
                append("Heading: %.1f°\n".format(Math.toDegrees(vehicle.heading)))
                append("Distance: %.2f m".format(gyd.distanceFromCurrentLinePivot))
            }
            font.drawText(infoText, 10f, 50f, Color.WHITE)
        }
    }
    //endregion
}