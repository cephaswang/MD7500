package com.agopengps.classes

import android.content.Context
import java.io.File
import java.io.FileWriter
import java.io.BufferedReader
import java.io.FileReader
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToLong

object CLog {
    private val sbEvents = StringBuilder()
    private val dateFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun eventWriter(message: String) {
        sbEvents.append(dateFormat.format(Date()))
        sbEvents.append("-> ")
        sbEvents.append(message)
        sbEvents.append("\n")
    }

    fun checkLogSize(context: Context, logFile: File, sizeLimit: Long) {
        if (logFile.exists()) {
            if (logFile.length() > sizeLimit) { // 0.5MB max file size
                val sbF = StringBuilder()
                var bytes = logFile.length() - sizeLimit
                bytes = (sizeLimit * 2 / 10 + bytes).roundToLong()
                sbEvents.append("Log File Reduced by: $bytes")

                // Create some extra space
                var bytesSoFar = 0

                try {
                    BufferedReader(FileReader(logFile)).use { reader ->
                        // Skip the first part of the file
                        while (true) {
                            val line = reader.readLine() ?: break
                            bytesSoFar += line.length
                            if (bytesSoFar > bytes) break
                        }

                        // Read the remaining content
                        while (true) {
                            val line = reader.readLine() ?: break
                            sbF.appendLine(line)
                        }
                    }

                    // Write the reduced content back
                    FileWriter(logFile, false).use { writer ->
                        writer.write(sbF.toString())
                    }
                } catch (e: Exception) {
                    eventWriter("Error reducing log file: ${e.message}")
                }
            }
        }
    }

    fun saveLogToFile(context: Context, filename: String) {
        try {
            val file = File(context.filesDir, filename)
            FileWriter(file, true).use { writer ->
                writer.write(sbEvents.toString())
            }
            sbEvents.clear()
        } catch (e: Exception) {
            eventWriter("Error saving log: ${e.message}")
        }
    }

    fun getLogContent(): String = sbEvents.toString()
}