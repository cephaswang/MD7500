package com.agopengps.classes

/*
import com.agopengps.drive.MainActivity
import kotlin.math.sin
import kotlin.math.cos

class CBoundary(private val mf: MainActivity) {
    var isHeadlandOn: Boolean = false
    var isToolInHeadland: Boolean = false
    var isToolOuterPointsInHeadland: Boolean = false
    var isSectionControlledByHeadland: Boolean = false

    fun setHydPosition() {
        if (mf.vehicle.isHydLiftOn && mf.avgSpeed > 0.2 && mf.autoBtnState == BtnStates.AUTO && !mf.isReverse) {
            if (isToolInHeadland) {
                mf.p_239.pgn[mf.p_239.hydLift] = 2
                if (mf.sounds.isHydLiftChange != isToolInHeadland) {
                    if (mf.sounds.isHydLiftSoundOn) mf.sounds.sndHydLiftUp.play()
                    mf.sounds.isHydLiftChange = isToolInHeadland
                }
            } else {
                mf.p_239.pgn[mf.p_239.hydLift] = 1
                if (mf.sounds.isHydLiftChange != isToolInHeadland) {
                    if (mf.sounds.isHydLiftSoundOn) mf.sounds.sndHydLiftDn.play()
                    mf.sounds.isHydLiftChange = isToolInHeadland
                }
            }
        }
    }

    fun whereAreToolCorners() {
        if (bndList.isNotEmpty() && bndList[0].hdLine.isNotEmpty()) {
            var isRightInWk = true

            for (j in 0 until mf.tool.numOfSections) {
                val isLeftInWk = if (j == 0) !isPointInsideHeadArea(mf.section[j].leftPoint) else isRightInWk
                isRightInWk = !isPointInsideHeadArea(mf.section[j].rightPoint)

                //save left side
                if (j == 0) {
                    mf.tool.isLeftSideInHeadland = isLeftInWk
                }

                //merge the two sides into in or out
                mf.section[j].isInHeadlandArea = isLeftInWk && isRightInWk
            }

            //save right side
            mf.tool.isRightSideInHeadland = isRightInWk

            //is the tool in or out based on endpoints
            isToolOuterPointsInHeadland = mf.tool.isLeftSideInHeadland && mf.tool.isRightSideInHeadland
        }
    }

    fun whereAreToolLookOnPoints() {
        if (bndList.isNotEmpty() && bndList[0].hdLine.isNotEmpty()) {
            var isLookRightIn = false

            val toolFix = mf.toolPivotPos
            val sinAB = sin(toolFix.heading)
            val cosAB = cos(toolFix.heading)

            //generated box for finding closest point
            var pos = 0.0
            val mOn = (mf.tool.lookAheadDistanceOnPixelsRight - mf.tool.lookAheadDistanceOnPixelsLeft) / mf.tool.rpWidth

            for (j in 0 until mf.tool.numOfSections) {
                val isLookLeftIn = if (j == 0) {
                    !isPointInsideHeadArea(
                        Vec2(
                            mf.section[j].leftPoint.easting + (sinAB * mf.tool.lookAheadDistanceOnPixelsLeft * 0.1),
                            mf.section[j].leftPoint.northing + (cosAB * mf.tool.lookAheadDistanceOnPixelsLeft * 0.1)
                        )
                    )
                } else {
                    isLookRightIn
                }

                pos += mf.section[j].rpSectionWidth
                val endHeight = (mf.tool.lookAheadDistanceOnPixelsLeft + (mOn * pos)) * 0.1

                isLookRightIn = !isPointInsideHeadArea(
                    Vec2(
                        mf.section[j].rightPoint.easting + (sinAB * endHeight),
                        mf.section[j].rightPoint.northing + (cosAB * endHeight)
                    )
                )

                mf.section[j].isLookOnInHeadland = isLookLeftIn && isLookRightIn
            }
        }
    }

    fun isPointInsideHeadArea(pt: Vec2): Boolean {
        //if inside outer boundary, then potentially add
        if (bndList[0].hdLine.isPointInPolygon(pt)) {
            for (i in 1 until bndList.size) {
                if (bndList[i].hdLine.isPointInPolygon(pt)) {
                    //point is in an inner turn area but inside outer
                    return false
                }
            }
            return true
        }
        return false
    }
}

// Assuming these exist in your project
enum class BtnStates {
    OFF,
    ON,
    AUTO
}

*/