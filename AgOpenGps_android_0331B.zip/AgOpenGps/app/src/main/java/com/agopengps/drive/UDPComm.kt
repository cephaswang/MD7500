package com.agopengps.drive

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

class UDPComm(private val context: Context) {

    // App Sockets
    private var loopBackSocket: DatagramSocket? = null
    private val epAgIO = InetSocketAddress("127.255.255.255", 17777)
    private val endPointLoopBack = InetSocketAddress("127.0.0.1", 15555)

    // Data stream
    private val loopBuffer = ByteArray(1024)

    // Status delegate
    var missedSentenceCount = 0
    var udpWatchLimit = 70
    private val udpWatch = Stopwatch()

    // Timer for checking UDP packets
    private val udpHandler = Handler(Looper.getMainLooper())
    private val udpRunnable = object : Runnable {
        override fun run() {
            checkUDPPackets()
            udpHandler.postDelayed(this, 100)
        }
    }

    private val isRunning = AtomicBoolean(false)

    // Interface for UDP callbacks
    interface UDPListener {
        fun onGPSDataReceived(lon: Double, lat: Double, heading: Float, speed: Float)
        fun onIMUDataReceived(heading: Double, roll: Double, pitch: Double)
        fun onSteerDataReceived(angle: Double, pwm: Int)
        fun onHardwareMessageReceived(message: String, colorCode: Int)
    }

    private var listener: UDPListener? = null

    fun setUDPListener(listener: UDPListener) {
        this.listener = listener
    }

    // Start the UDP server
    fun StartLoopbackServer() {
        try {
            loopBackSocket = DatagramSocket(15555, InetAddress.getByName("127.0.0.1"))
            loopBackSocket?.broadcast = true
            isRunning.set(true)
            udpHandler.post(udpRunnable)
            Log.d("UDP", "UDP Loopback network started: 127.0.0.1:15555")
        } catch (e: IOException) {
            Log.e("UDP", "Load UDP Loopback Error", e)
            showError("Load Error: ${e.message}")
        }
    }

    // Stop the UDP server
    fun StopLoopbackServer() {
        isRunning.set(false)
        udpHandler.removeCallbacks(udpRunnable)
        loopBackSocket?.close()
    }

    private fun checkUDPPackets() {
        if (!isRunning.get()) return

        val packet = DatagramPacket(loopBuffer, loopBuffer.size)
        try {
            loopBackSocket?.receive(packet)
            val data = packet.data.copyOf(packet.length)
            ReceiveFromAgIO(data)
        } catch (e: IOException) {
            Log.e("UDP", "Receive error", e)
        }
    }

    private fun ReceiveFromAgIO(data: ByteArray) {
        if (data.size > 4 && data[0] == 0x80.toByte() && data[1] == 0x81.toByte()) {
            val length = maxOf((data[4].toInt() + 5), 5)
            if (data.size > length) {
                var CK_A: Byte = 0
                for (j in 2 until length) {
                    //CK_A += data[j]
                    CK_A = (CK_A.toInt() + data[j].toInt()).toByte() // 修正类型转换
                }

                if (data[length] != CK_A) {
                    return
                }
            } else {
                return
            }

            when (data[3].toInt()) {
                0xD6 -> processGPSData(data)
                0xD3 -> processIMUData(data)
                0xD4 -> processIMUDisconnect(data)
                0xFD -> processSteerData(data)
                0xFA -> processSensorData(data)
                0xDD -> processHardwareMessage(data)
                0xEA -> processRemoteSwitches(data)
            }
        }
    }

    private fun processGPSData(data: ByteArray) {
        if (udpWatch.elapsedMillis() < udpWatchLimit) {
            missedSentenceCount++
            return
        }
        udpWatch.reset()
        udpWatch.start()

        val lon = ByteBuffer.wrap(data, 5, 8).order(ByteOrder.LITTLE_ENDIAN).double
        val lat = ByteBuffer.wrap(data, 13, 8).order(ByteOrder.LITTLE_ENDIAN).double

        if (lon != Double.MAX_VALUE && lat != Double.MAX_VALUE) {
            // DisableSim() would be called here in original code

            val heading = ByteBuffer.wrap(data, 21, 4).order(ByteOrder.LITTLE_ENDIAN).float
            val speed = ByteBuffer.wrap(data, 29, 4).order(ByteOrder.LITTLE_ENDIAN).float
            val roll = ByteBuffer.wrap(data, 33, 4).order(ByteOrder.LITTLE_ENDIAN).float
            val altitude = ByteBuffer.wrap(data, 37, 4).order(ByteOrder.LITTLE_ENDIAN).float

            listener?.onGPSDataReceived(lon, lat, heading, speed)

            // Original code would update pn, ahrs objects here
        }
    }

    private fun processIMUData(data: ByteArray) {
        if (data.size != 14) return

        val heading = ((data[6].toInt() shl 8) + data[5].toInt()).toShort() * 0.1
        var roll = ((data[8].toInt() shl 8) + data[7].toInt()).toShort() * 0.1
        val angVel = ((data[10].toInt() shl 8) + data[9].toInt()).toShort() / -2

        // Original code had roll inversion logic
        // if (ahrs.isRollInvert) roll *= -1

        listener?.onIMUDataReceived(heading.toDouble(), roll.toDouble(), 0.0)
    }

    private fun processIMUDisconnect(data: ByteArray) {
        if (data[5].toInt() == 1) {
            listener?.onIMUDataReceived(99999.0, 88888.0, 0.0)
        }
    }

    private fun processSteerData(data: ByteArray) {
        if (data.size != 14) return

        val steerAngle = ((data[6].toInt() shl 8) + data[5].toInt()).toShort() * 0.01
        val heading = ((data[8].toInt() shl 8) + data[7].toInt()).toShort()
        val roll = ((data[10].toInt() shl 8) + data[9].toInt()).toShort()
        val pwm = data[12].toInt()

        listener?.onSteerDataReceived(steerAngle, pwm)
    }

    private fun processSensorData(data: ByteArray) {
        if (data.size != 14) return
        val sensorData = data[5]
        // Original code would update mc.sensorData here
    }

    private fun processHardwareMessage(data: ByteArray) {
        if (data.size < 9) return

        val messageLength = data[4].toInt() - 2
        if (messageLength > 0) {
            val message = String(data, 7, messageLength, Charsets.UTF_8)
            val displayTime = data[5].toInt() * 10
            val colorCode = data[6].toInt()

            listener?.onHardwareMessageReceived(message, colorCode)
        }
    }

    private fun processRemoteSwitches(data: ByteArray) {
        if (data.size != 14) return
        // Original code would copy data to mc.ss array
    }

    fun SendPgnToLoop(byteData: ByteArray) {
        if (loopBackSocket != null && byteData.size > 2) {
            try {
                var crc = 0
                for (i in 2 until byteData.size - 1) {
                    crc += byteData[i].toInt()
                }
                byteData[byteData.size - 1] = crc.toByte()

                val packet = DatagramPacket(
                    byteData,
                    byteData.size,
                    epAgIO.address,
                    epAgIO.port
                )
                loopBackSocket?.send(packet)
            } catch (e: IOException) {
                Log.e("UDP", "Send error", e)
            }
        }
    }

    private fun showError(message: String) {
        // Would show Toast or AlertDialog in Android
        Log.e("UDP", message)
    }

    private class Stopwatch {
        private var startTime: Long = 0

        fun start() {
            startTime = System.currentTimeMillis()
        }

        fun reset() {
            startTime = System.currentTimeMillis()
        }

        fun elapsedMillis(): Long {
            return System.currentTimeMillis() - startTime
        }
    }
}