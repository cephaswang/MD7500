package com.agopengps.classes

import android.R.bool
import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin


class CTram(private val mf: FormGPS) {
    // 軌跡點列表
    val calculatedPoints = mutableListOf<LatLng>()
    private val boundaryOuterTrack = mutableListOf<LatLng>()
    private val boundaryInnerTrack = mutableListOf<LatLng>()

    var tramWidth: Double = 0.0

    // 電車軌跡點列表
//    var tramArr: MutableList<vec2> = mutableListOf()  // 空的 mutable list

    // 包含多個電車軌跡的列表
//    var tramList: MutableList<MutableList<vec2>> = mutableListOf()  // 空的 mutable list of mutable lists

    var tramArr: MutableList<vec2> = ArrayList(200)
    var tramList: MutableList<MutableList<vec2>> = ArrayList(200)

    // 邊界軌跡（使用 vec2）
    var tramBndOuterArr: MutableList<vec2> = mutableListOf()
    var tramBndInnerArr: MutableList<vec2> = mutableListOf()

    //   var displayMode: Int = 0
    var generateMode: kotlin.Int = 0


    var halfWheelTrack: Double = 0.0
    var alpha: kotlin.Double = 0.0
    var passes: Int = 0
    var isOuter: bool? = null

    // 設置參數
    var trackWidth: Double = 0.0
    var halfWheelTrackWidth: Double = 0.0
    var transparency: Float = 0.0f
    var numberOfPasses: Int = 0
    var isOuterTrack: Boolean = false
    var isLeftManualEnabled: Boolean = false
    var isRightManualEnabled: Boolean = false

    // 軌跡線
    var currentTrackPoints = mutableListOf<LatLng>()
    val allTrackLines = mutableListOf<MutableList<LatLng>>()

    // 顯示模式：0 off, 1 All, 2 Lines, 3 Outer
    var displayMode: Int = 0
    var generationMode: Int = 0

    init {
        trackWidth = mf.settings.setTram_tramWidth  // 從 SettingsData 獲取電車寬度
        halfWheelTrackWidth = mf.settings.setVehicle_trackWidth * 0.5  // 從 SettingsData 獲取車輛軌寬的一半
        determineTrackOrientation()
        numberOfPasses = mf.settings.setTram_passes  // 從 SettingsData 獲取通過次數
        displayMode = 0
        transparency = mf.settings.setTram_alpha.toFloat()  // 從 SettingsData 獲取透明度並轉為 Float
    }

    fun buildTramBnd() {
        val isBndExist = mf.bnd.bndList.isNotEmpty()

        if (isBndExist) {
            createBndOuterTramTrack()
            createBndInnerTramTrack()
        } else {
            tramBndOuterArr.clear()
            tramBndInnerArr.clear()
        }
    }

    private fun createBndOuterTramTrack() {
        val ptCount = mf.bnd.bndList[0].fenceLine.size
        tramBndOuterArr.clear()

        val distSq = ((trackWidth * 0.5) - halfWheelTrackWidth).pow(2) * 0.999

        for (i in 0 until ptCount) {
            val pt3 = vec2(
                mf.bnd.bndList[0].fenceLine[i].easting - (sin(glm.piBy2 + mf.bnd.bndList[0].fenceLine[i].heading) * (trackWidth * 0.5 - halfWheelTrackWidth)),
                mf.bnd.bndList[0].fenceLine[i].northing - (cos(glm.piBy2 + mf.bnd.bndList[0].fenceLine[i].heading) * (trackWidth * 0.5 - halfWheelTrackWidth))
            )

            val shouldAdd = (0 until ptCount).none { j ->
                glm.distanceSquared(
                    pt3.northing, pt3.easting,
                    mf.bnd.bndList[0].fenceLine[j].northing, mf.bnd.bndList[0].fenceLine[j].easting
                ) < distSq
            }

            if (shouldAdd) {
                if (tramBndOuterArr.isNotEmpty()) {

                    val dist = (pt3.easting - tramBndOuterArr.last().easting).pow(2) +
                            (pt3.northing - tramBndOuterArr.last().northing).pow(2)
                    if (dist > 2) tramBndOuterArr.add(pt3)
                } else {
                    tramBndOuterArr.add(pt3)
                }
            }
        }
    }

    private fun createBndInnerTramTrack() {
        // 計算邊界點數量
        val ptCount = mf.bnd.bndList[0].fenceLine.size
        tramBndInnerArr.clear()

        // 計算距離閾值的平方
        val distSq = ((trackWidth * 0.5) + halfWheelTrackWidth).pow(2) * 0.999

        // 建立內部電車軌跡陣列
        for (i in 0 until ptCount) {
            // 計算內部點座標
            val pt3 = vec2(
                easting = mf.bnd.bndList[0].fenceLine[i].easting -
                        (sin(glm.piBy2 + mf.bnd.bndList[0].fenceLine[i].heading) * (trackWidth * 0.5 + halfWheelTrackWidth)),
                northing = mf.bnd.bndList[0].fenceLine[i].northing -
                        (cos(glm.piBy2 + mf.bnd.bndList[0].fenceLine[i].heading) * (trackWidth * 0.5 + halfWheelTrackWidth))
            )

            // 檢查是否需要添加該點
            var shouldAdd = true
            for (j in 0 until ptCount) {
                val check = glm.distanceSquared(
                    pt3.northing, pt3.easting,
                    mf.bnd.bndList[0].fenceLine[j].northing, mf.bnd.bndList[0].fenceLine[j].easting
                )
                if (check < distSq) {
                    shouldAdd = false
                    break
                }
            }

            // 如果需要添加，檢查與前一點的距離
            if (shouldAdd) {
                if (tramBndInnerArr.isNotEmpty()) {
                    val dist = ((pt3.easting - tramBndInnerArr.last().easting).pow(2)) +
                            ((pt3.northing - tramBndInnerArr.last().northing).pow(2))
                    if (dist > 2) {
                        tramBndInnerArr.add(pt3)
                    }
                } else {
                    tramBndInnerArr.add(pt3)
                }
            }
        }
    }

    fun determineTrackOrientation() {
        isOuterTrack = ((trackWidth / mf.tool.width + 0.5).toInt() % 2 == 0)
        if (mf.settings.setTool_isTramOuterInverted) isOuterTrack = !isOuterTrack  // 從 SettingsData 獲取是否反轉外部軌道
    }


    // 在 Google Maps 上繪製軌跡線
    fun drawTram(googleMap: GoogleMap) {
        googleMap.clear() // 清空地圖上的現有圖層

        // 根據顯示模式繪製軌跡線
        if (displayMode == 1 || displayMode == 2) {
            if (allTrackLines.isNotEmpty()) {
                for (trackLine in allTrackLines) {
                    googleMap.addPolyline(
                        PolylineOptions()
                            .addAll(trackLine)
                            .width(10f) // 線寬
                            .color(android.graphics.Color.argb((transparency * 255).toInt(), 0, 0, 0)) // 黑色，帶透明度
                    )
                    googleMap.addPolyline(
                        PolylineOptions()
                            .addAll(trackLine)
                            .width(4f) // 較細的線
                            .color(android.graphics.Color.argb((transparency * 255).toInt(), 237, 183, 187)) // 淺紅色
                    )
                }
            }
        }

        if (displayMode == 1 || displayMode == 3) {
            if (boundaryOuterTrack.isNotEmpty()) {
                googleMap.addPolyline(
                    PolylineOptions()
                        .addAll(boundaryOuterTrack)
                        .width(10f)
                        .color(android.graphics.Color.argb((transparency * 255).toInt(), 0, 0, 0))
                )
                googleMap.addPolyline(
                    PolylineOptions()
                        .addAll(boundaryInnerTrack)
                        .width(10f)
                        .color(android.graphics.Color.argb((transparency * 255).toInt(), 0, 0, 0))
                )
            }
        }
    }

    fun buildBoundaryTracks() {
        val isBoundaryExists = mf.bnd.bndList.isNotEmpty()

        if (isBoundaryExists) {
            createBoundaryOuterTrack()
            createBoundaryInnerTrack()
        } else {
            boundaryOuterTrack.clear()
            boundaryInnerTrack.clear()
        }
    }

    private fun createBoundaryInnerTrack() {
        val pointCount = mf.bnd.bndList[0].fenceLine.size
        boundaryInnerTrack.clear()

        val distanceThresholdSquared = ((trackWidth * 0.5) + halfWheelTrackWidth).let { it * it } * 0.999

        for (i in 0 until pointCount) {
            val fencePoint = mf.bnd.bndList[0].fenceLine[i]
            // 假設 easting 和 northing 是 UTM 座標，需轉換為經緯度
            val point = utmToLatLng(
                fencePoint.easting - (sin(glm.piBy2 + fencePoint.heading) * (trackWidth * 0.5 + halfWheelTrackWidth)),
                fencePoint.northing - (cos(glm.piBy2 + fencePoint.heading) * (trackWidth * 0.5 + halfWheelTrackWidth))
            )

            val shouldAdd = (0 until pointCount).none { j ->
                val refPoint = utmToLatLng(mf.bnd.bndList[0].fenceLine[j].easting, mf.bnd.bndList[0].fenceLine[j].northing)
                distanceSquared(point, refPoint) < distanceThresholdSquared
            }

            if (shouldAdd) {
                if (boundaryInnerTrack.isNotEmpty()) {
                    val lastPoint = boundaryInnerTrack.last()
                    val distance = distanceSquared(point, lastPoint)
                    if (distance > 2) {
                        boundaryInnerTrack.add(point)
                    }
                } else {
                    boundaryInnerTrack.add(point)
                }
            }
        }
    }

    private fun createBoundaryOuterTrack() {
        val pointCount = mf.bnd.bndList[0].fenceLine.size
        boundaryOuterTrack.clear()

        val distanceThresholdSquared = ((trackWidth * 0.5) - halfWheelTrackWidth).let { it * it } * 0.999

        for (i in 0 until pointCount) {
            val fencePoint = mf.bnd.bndList[0].fenceLine[i]
            val point = utmToLatLng(
                fencePoint.easting - (sin(glm.piBy2 + fencePoint.heading) * (trackWidth * 0.5 - halfWheelTrackWidth)),
                fencePoint.northing - (cos(glm.piBy2 + fencePoint.heading) * (trackWidth * 0.5 - halfWheelTrackWidth))
            )

            val shouldAdd = (0 until pointCount).none { j ->
                val refPoint = utmToLatLng(mf.bnd.bndList[0].fenceLine[j].easting, mf.bnd.bndList[0].fenceLine[j].northing)
                distanceSquared(point, refPoint) < distanceThresholdSquared
            }

            if (shouldAdd) {
                if (boundaryOuterTrack.isNotEmpty()) {
                    val lastPoint = boundaryOuterTrack.last()
                    val distance = distanceSquared(point, lastPoint)
                    if (distance > 2) {
                        boundaryOuterTrack.add(point)
                    }
                } else {
                    boundaryOuterTrack.add(point)
                }
            }
        }
    }

    // 假設的 UTM 轉經緯度方法（需要根據實際 UTM 區域實現）
    private fun utmToLatLng(easting: Double, northing: Double): LatLng {
        // 此處需要根據 UTM 區域編號和投影參數進行轉換
        // 這是一個簡化的占位符，實際應用中需要使用地理轉換庫（如 Proj4j）
        return LatLng(northing / 111320.0, easting / (111320.0 * cos(northing / 111320.0)))
    }

    // 計算兩點之間的平方距離（簡化版）
    private fun distanceSquared(p1: LatLng, p2: LatLng): Double {
        val dLat = p1.latitude - p2.latitude
        val dLng = p1.longitude - p2.longitude
        return dLat.pow(2) + dLng.pow(2)
    }
}