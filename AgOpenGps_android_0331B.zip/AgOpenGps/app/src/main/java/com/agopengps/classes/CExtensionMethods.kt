package com.agopengps.classes

import android.graphics.Color
import android.graphics.Path
import android.graphics.RectF
import android.widget.Button
import android.widget.ProgressBar

// Custom Round Button for Android
class RoundButton(context: android.content.Context) : androidx.appcompat.widget.AppCompatButton(context) {
    override fun onDraw(canvas: android.graphics.Canvas) {
        val path = Path()
        path.addOval(RectF(0f, 0f, width.toFloat(), height.toFloat()), Path.Direction.CW)
        canvas.clipPath(path)
        super.onDraw(canvas)
    }
}

// Custom NumericUpDown equivalent for Android
class NudlessNumberPicker(context: android.content.Context) : android.widget.NumberPicker(context) {
    init {
        // Hide the increment/decrement buttons
        val children = getChildAt(0) as? android.view.ViewGroup
        children?.getChildAt(0)?.visibility = android.view.View.GONE
        children?.getChildAt(1)?.visibility = android.view.View.GONE
    }

    // Custom value setter with bounds checking
    override fun setValue(value: Int) {
        when {
            value < minValue -> super.setValue(minValue)
            value > maxValue -> super.setValue(maxValue)
            else -> super.setValue(value)
        }
    }
}

// Extension methods for Android
object ExtensionMethods {
    /**
     * Sets the progress bar value without animation
     */
    fun ProgressBar.setProgressNoAnimation(value: Int) {
        if (value == max) {
            // Special case for maximum value
            max = value + 1
            progress = value + 1
            max = value
        } else {
            progress = value + 1
        }
        progress = value
    }

    /**
     * Adjusts color components to avoid pure white (255)
     */
    fun Color.checkColorFor255(): Int {
        var red = Color.red(this)
        var green = Color.green(this)
        var blue = Color.blue(this)

        if (red == 255) red = 254
        if (green == 255) green = 254
        if (blue == 255) blue = 254

        return Color.argb(Color.alpha(this), red, green, blue)
    }
}

// Extension functions as top-level functions
fun ProgressBar.setProgressNoAnimationExtension(value: Int) {
    ExtensionMethods.setProgressNoAnimation(this, value)
}

fun Int.checkColorFor255Extension(): Int {
    return ExtensionMethods.checkColorFor255(this)
}