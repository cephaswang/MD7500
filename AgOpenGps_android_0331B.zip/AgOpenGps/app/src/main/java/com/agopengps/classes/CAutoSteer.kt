package com.agopengps.classes

class CAutoSteer {
    // Add your auto-steer properties and methods here
}