package com.agopengps.drive

import android.app.AlertDialog
import android.content.Context
import android.content.res.Resources
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.agopengps.classes.*
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.*
import java.util.*
import kotlin.math.roundToInt

class FormGPS : AppCompatActivity(), OnMapReadyCallback {
    companion object {
        const val MAXSECTIONS = 64
        const val MAXBOUNDARIES = 6
        const val MAXHEADS = 6
    }

    // Class properties
    private val buttonOrder = mutableListOf<Int>()
    private var btnCounter = 0
    private lateinit var flpRight: ViewGroup
    lateinit var autoSteerButton: Button // Modified button name

    // 宣告按鈕變數
    private lateinit var btnAutoSteer: Button


    var makeUTurnCounter: Int = 0

    var guidanceLineDistanceOff: Short = 0
    var guidanceLineSteerAngle: kotlin.Short = 0

    var fixHeading = 0.0
    var isReverse = false
    var avgSpeed: Double = 0.0

    var guidanceLookPos: vec2 = vec2(0.0, 0.0)

    // Properties
    lateinit var settings: SettingsData
    var currentFieldDirectory: String? = null
    var displayFieldName: String? = null
    private var leftMouseDownOnOpenGL = false
    var flagNumberPicked = 0
    var isJobStarted = false
    var isBtnAutoSteerOn = false
    var isLidarBtnOn = true
    var isSavingFile = false
    var isSideGuideLines = false

    val secondsSinceStart: Double
        get() = SystemClock.elapsedRealtime() / 1000.0
    var gridToolSpacing = 0.0

    var frameTime = 0.0
    var gpsHz = 10.0
    var isStanleyUsed = true

    var pbarSteer = 0
    var pbarMachine = 0
    var pbarUDP = 0
    var nudNumber = 0.0

    var m2InchOrCm = 0.0
    var inchOrCm2m = 0.0
    var m2FtOrM = 0.0
    var ftOrMtoM = 0.0
    var cm2CmOrIn = 0.0
    var inOrCm2Cm = 0.0
    var unitsFtM: String? = null
    var unitsInCm: String? = null
    var unitsInCmNS: String? = null

    var hotkeys: CharArray? = null
    var filePickerFileAndDirectory: String? = null

    var GPSDataWindowLeft = 80
    var GPSDataWindowTopOffset = 220
    var isInAutoDrive = true
    var isGPSSentencesOn = false
    var isKeepOffsetsOn = false

    var pivotAxlePos: vec3 = vec3(0.0, 0.0, 0.0)
    var steerAxlePos: vec3 = vec3(0.0, 0.0, 0.0)
    var toolPivotPos: vec3 = vec3(0.0, 0.0, 0.0)
    var toolPos: vec3 = vec3(0.0, 0.0, 0.0)
    var tankPos: vec3 = vec3(0.0, 0.0, 0.0)
    var hitchPos: vec2 = vec2(0.0, 0.0)

    // Class instances
    lateinit var camera: CCamera
    lateinit var worldGrid: CWorldGrid
    lateinit var pn: CNMEA
    lateinit var section: Array<CSection>
    val triStrip = mutableListOf<CPatches>()
    lateinit var ABLine: CABLine
    lateinit var tram: CTram
    lateinit var ct: CContour
    lateinit var trk: CTrack
    lateinit var curve: CABCurve
    lateinit var yt: CYouTurn
    lateinit var vehicle: CVehicle
    lateinit var tool: CTool
    lateinit var mc: CModuleComm
    lateinit var bnd: CBoundary
    lateinit var hdl: CHeadLine
    lateinit var sim: CSim
    lateinit var _rm: Resources
    lateinit var ahrs: CAHRS
    lateinit var recPath: CRecordedPath
    lateinit var fd: CFieldData
    lateinit var sounds: CSound
    lateinit var font: CFont
    lateinit var gyd: CGuidance
    lateinit var displayBrightness: CWindowsSettingsBrightnessController

    val p_239: CPGN_EF = CPGN_EF()

    var distancePivotToTurnLine: Double = -2222.0
    var distanceToolToTurnLine: Double = -2222.0

    var isFirstHeadingSet = false

    var frameDayColor: Color? = null
    var frameNightColor: Color? = null
    var sectionColorDay: Color? = null
    var fieldColorDay: Color? = null
    var fieldColorNight: Color? = null

    var textColorDay: Color? = null
    var textColorNight: Color? = null

    // Added properties for vehicle appearance
    var vehicleOpacityByte: Int = 255  // Default to fully opaque
    var vehicleColor: Int = Color.rgb(237, 37, 39)  // Default to a reddish color
    var vehicleOpacity: Double = 1.0  // Normalized opacity for simple triangle

    // Added properties from CVehicle references
    var isVehicleImage: Boolean = true  // Default to true to draw vehicle as image
    lateinit var timerSim: CSim  // Already declared as a class instance, reusing it
    var fixLat: Double = 0.0  // Default latitude
    var fixLon: Double = 0.0  // Default longitude

    // Google Maps
    lateinit var mMap: GoogleMap
    private lateinit var mapFragment: SupportMapFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form_gps)

        initializeComponents()
        // 初始化 SettingsData
        settings = SettingsData()

        // Setup Google Maps
        mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        setupPowerModeListener()

        // 初始化按鈕
        btnAutoSteer = findViewById(R.id.btnAutoSteer)
        // 設定點擊事件
        btnAutoSteer.setOnClickListener {
            // 點擊後執行的程式碼
            println("AutoSteer 按鈕被點擊了")
            // 在這裡添加你的邏輯
        }

        // Initialize with new button name
        autoSteerButton = findViewById(R.id.autoSteerButton) // Note: ID needs to match XML
        flpRight = findViewById(R.id.flpRight)

        setupAutoSteerButtonListener()
    }


    // Modified function name to match new button name
    private fun setupAutoSteerButtonListener() {
        autoSteerButton.setOnClickListener {
            flpRight.addView(createAutoSteerView())
            autoSteerButton.isEnabled = false
            buttonOrder.add(0)
            btnCounter++
        }
    }

    // Helper function remains the same
    private fun createAutoSteerView(): View {
        val autoSteerView = Button(this).apply {
            text = "Auto Steer"
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        return autoSteerView
    }

    private fun initializeComponents() {
        camera = CCamera()
        worldGrid = CWorldGrid(this)
        vehicle = CVehicle(this)
        tool = CTool(this)

        section = Array(MAXSECTIONS) { CSection() }
        triStrip.add(CPatches(this))

        pn = CNMEA(this)
        ABLine = CABLine(this)
        ct = CContour(this)
        curve = CABCurve(this)
        trk = CTrack(this)
        hdl = CHeadLine(this)
        yt = CYouTurn(this)
        mc = CModuleComm(this)
        bnd = CBoundary(this)
        sim = CSim(this)
        timerSim = sim  // Assign sim instance to timerSim
        ahrs = CAHRS()
        recPath = CRecordedPath(this)
        fd = CFieldData(this)
        tram = CTram(this)
        _rm = resources
        font = CFont(this)
        gyd = CGuidance(this)
        sounds = CSound(this)
        displayBrightness = CWindowsSettingsBrightnessController(false)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        setupMap()
        loadMapData()
    }

    private fun setupMap() {
        mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isCompassEnabled = true
    }

    private fun loadMapData() {
        val vehiclePosition = LatLng(pn.latitude, pn.longitude)
        mMap.addMarker(
            MarkerOptions()
                .position(vehiclePosition)
                .title("Vehicle")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.tractor_icon))
        )

        if (bnd.bndList.isNotEmpty()) {
            val polygonOptions = PolygonOptions()
            bnd.bndList.forEach { boundary ->
                boundary.points.forEach { point ->
                    polygonOptions.add(LatLng(point.latitude, point.longitude))
                }
            }
            mMap.addPolygon(polygonOptions.strokeColor(android.graphics.Color.RED))
        }

        setZoom()
    }

    private fun setupPowerModeListener() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
    }

    fun jobNew() {
        isJobStarted = true
        findViewById<View>(R.id.btnSectionMasterManual)?.isEnabled = true
        findViewById<View>(R.id.btnSectionMasterAuto)?.isEnabled = true
        findViewById<View>(R.id.btnContour)?.isEnabled = true
        findViewById<View>(R.id.btnTrack)?.isEnabled = true
        findViewById<View>(R.id.btnABDraw)?.isEnabled = true
        findViewById<View>(R.id.btnAutoSteer)?.isEnabled = true
        findViewById<View>(R.id.btnFlag)?.isEnabled = true

        ABLine.abHeading = 0.00
        fileSaveCounter = 25

        updateMapDisplay()
    }

    fun jobClose() {
        recPath.resumeState = 0
        bnd.isHeadlandOn = false

        mMap.clear()

        isJobStarted = false
        triStrip.clear()
        triStrip.add(CPatches(this))
        flagPts.clear()
        tram.tramList?.clear()
        curve.resetCurveLine()
        trk.gArr?.clear()
        trk.idx = -1

        updateMapDisplay()
    }

    private fun updateMapDisplay() {
        mMap.clear()

        val vehiclePosition = LatLng(pn.latitude, pn.longitude)
        mMap.addMarker(
            MarkerOptions()
                .position(vehiclePosition)
                .title("Vehicle")
                .rotation(vehicle.heading.toFloat())
        )

        section.forEach { sec ->
            if (sec.isSectionOn) {
                val polygon = PolygonOptions()
                sec.points.forEach { point ->
                    polygon.add(LatLng(point.latitude, point.longitude))
                }
                mMap.addPolygon(polygon.fillColor(android.graphics.Color.argb(100, 0, 255, 0)))
            }
        }
    }

    fun setZoom() {
        val zoomLevel = when {
            camera.camSetDistance < 100 -> 18f
            camera.camSetDistance < 500 -> 15f
            camera.camSetDistance < 2000 -> 12f
            else -> 10f
        }

        gridToolSpacing = (camera.gridZoom / tool.width + 0.5).roundToInt().toDouble()
        if (gridToolSpacing < 1) gridToolSpacing = 1.0
        camera.gridZoom = gridToolSpacing * tool.width

        mMap.animateCamera(CameraUpdateFactory.zoomTo(zoomLevel))
    }

    fun timedMessageBox(context: Context, timeout: Int, s1: String, s2: String) {
        AlertDialog.Builder(context)
            .setTitle(s1)
            .setMessage(s2)
            .setCancelable(true)
            .create()
            .apply {
                show()
                Handler(Looper.getMainLooper()).postDelayed({
                    dismiss()
                }, timeout.toLong())
            }
    }

    fun yesMessageBox(s1: String) {
        android.app.AlertDialog.Builder(this)
            .setMessage(s1)
            .setPositiveButton("OK") { _, _ -> }
            .show()
    }

    fun randomNumber(min: Double, max: Double): Double {
        return min + Random().nextDouble() * (max - min)
    }

    private var fileSaveCounter = 0

    val flagPts = mutableListOf<Any>()
}