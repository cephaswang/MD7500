package com.agopengps.drive

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.agopengps.classes.*

class Sections : AppCompatActivity() {

    // Off, Manual, and Auto, 3 states possible
    var manualBtnState = btnStates.Off
    var autoBtnState = btnStates.Off

    // UI Elements
    private lateinit var btnSectionMasterManual: Button
    private lateinit var btnSectionMasterAuto: Button
    private lateinit var btnZone1: Button
    private lateinit var btnZone2: Button
    private lateinit var btnZone3: Button
    private lateinit var btnZone4: Button
    private lateinit var btnZone5: Button
    private lateinit var btnZone6: Button
    private lateinit var btnZone7: Button
    private lateinit var btnZone8: Button
    private lateinit var btnSection1Man: Button
    private lateinit var btnSection2Man: Button
    private lateinit var btnSection3Man: Button
    private lateinit var btnSection4Man: Button
    private lateinit var btnSection5Man: Button
    private lateinit var btnSection6Man: Button
    private lateinit var btnSection7Man: Button
    private lateinit var btnSection8Man: Button
    private lateinit var btnSection9Man: Button
    private lateinit var btnSection10Man: Button
    private lateinit var btnSection11Man: Button
    private lateinit var btnSection12Man: Button
    private lateinit var btnSection13Man: Button
    private lateinit var btnSection14Man: Button
    private lateinit var btnSection15Man: Button
    private lateinit var btnSection16Man: Button

    // Assuming these are defined in com.agopengps.classes
    lateinit var section: Array<Section> // Assuming Section is a data class
    lateinit var tool: Tool // Assuming Tool is a data class
    lateinit var sounds: Sounds // Assuming Sounds is a class with sound resources
    var isDay: Boolean = true // Day/Night mode
    var isJobStarted: Boolean = false // Job status
    var isPanelBottomHidden: Boolean = false // Panel visibility
    lateinit var oglMain: View // Main OpenGL view
    lateinit var panelSim: View // Simulation panel
    lateinit var statusStripLeft: View // Status strip
    lateinit var p_254: PGN254 // PGN data classes
    lateinit var p_239: PGN239
    lateinit var p_229: PGN229
    lateinit var mc: MachineControl // Machine control
    var avgSpeed: Double = 0.0 // Average speed
    lateinit var tram: Tram // Tram control

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sections)

        // Initialize UI elements
        initializeViews()

        // Set click listeners
        setupClickListeners()

        // Check day/night mode
        isDay = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_NO
    }

    private fun initializeViews() {
        btnSectionMasterManual = findViewById(R.id.btnSectionMasterManual)
        btnSectionMasterAuto = findViewById(R.id.btnSectionMasterAuto)
        btnZone1 = findViewById(R.id.btnZone1)
        btnZone2 = findViewById(R.id.btnZone2)
        btnZone3 = findViewById(R.id.btnZone3)
        btnZone4 = findViewById(R.id.btnZone4)
        btnZone5 = findViewById(R.id.btnZone5)
        btnZone6 = findViewById(R.id.btnZone6)
        btnZone7 = findViewById(R.id.btnZone7)
        btnZone8 = findViewById(R.id.btnZone8)
        btnSection1Man = findViewById(R.id.btnSection1Man)
        btnSection2Man = findViewById(R.id.btnSection2Man)
        btnSection3Man = findViewById(R.id.btnSection3Man)
        btnSection4Man = findViewById(R.id.btnSection4Man)
        btnSection5Man = findViewById(R.id.btnSection5Man)
        btnSection6Man = findViewById(R.id.btnSection6Man)
        btnSection7Man = findViewById(R.id.btnSection7Man)
        btnSection8Man = findViewById(R.id.btnSection8Man)
        btnSection9Man = findViewById(R.id.btnSection9Man)
        btnSection10Man = findViewById(R.id.btnSection10Man)
        btnSection11Man = findViewById(R.id.btnSection11Man)
        btnSection12Man = findViewById(R.id.btnSection12Man)
        btnSection13Man = findViewById(R.id.btnSection13Man)
        btnSection14Man = findViewById(R.id.btnSection14Man)
        btnSection15Man = findViewById(R.id.btnSection15Man)
        btnSection16Man = findViewById(R.id.btnSection16Man)

        // Initialize other views (these would need actual IDs in the layout)
        oglMain = findViewById(R.id.oglMain)
        panelSim = findViewById(R.id.panelSim)
        statusStripLeft = findViewById(R.id.statusStripLeft)
    }

    private fun setupClickListeners() {
        btnSectionMasterManual.setOnClickListener { btnSectionMasterManual_Click() }
        btnSectionMasterAuto.setOnClickListener { btnSectionMasterAuto_Click() }
        btnZone1.setOnClickListener { btnZone1_Click() }
        btnZone2.setOnClickListener { btnZone2_Click() }
        btnZone3.setOnClickListener { btnZone3_Click() }
        btnZone4.setOnClickListener { btnZone4_Click() }
        btnZone5.setOnClickListener { btnZone5_Click() }
        btnZone6.setOnClickListener { btnZone6_Click() }
        btnZone7.setOnClickListener { btnZone7_Click() }
        btnZone8.setOnClickListener { btnZone8_Click() }
        btnSection1Man.setOnClickListener { btnSection1Man_Click() }
        btnSection2Man.setOnClickListener { btnSection2Man_Click() }
        btnSection3Man.setOnClickListener { btnSection3Man_Click() }
        btnSection4Man.setOnClickListener { btnSection4Man_Click() }
        btnSection5Man.setOnClickListener { btnSection5Man_Click() }
        btnSection6Man.setOnClickListener { btnSection6Man_Click() }
        btnSection7Man.setOnClickListener { btnSection7Man_Click() }
        btnSection8Man.setOnClickListener { btnSection8Man_Click() }
        btnSection9Man.setOnClickListener { btnSection9Man_Click() }
        btnSection10Man.setOnClickListener { btnSection10Man_Click() }
        btnSection11Man.setOnClickListener { btnSection11Man_Click() }
        btnSection12Man.setOnClickListener { btnSection12Man_Click() }
        btnSection13Man.setOnClickListener { btnSection13Man_Click() }
        btnSection14Man.setOnClickListener { btnSection14Man_Click() }
        btnSection15Man.setOnClickListener { btnSection15Man_Click() }
        btnSection16Man.setOnClickListener { btnSection16Man_Click() }
    }

    private fun btnSectionMasterManual_Click() {
        if (sounds.isSectionsSoundOn) sounds.sndSectionOff.play()
        autoBtnState = btnStates.Off
        btnSectionMasterAuto.setBackgroundResource(R.drawable.sectionmasteroff)

        when (manualBtnState) {
            btnStates.Off -> {
                manualBtnState = btnStates.On
                btnSectionMasterManual.setBackgroundResource(R.drawable.manualon)
            }
            btnStates.On -> {
                manualBtnState = btnStates.Off
                btnSectionMasterManual.setBackgroundResource(R.drawable.manualoff)
            }
            else -> {}
        }

        if (tool.isSectionsNotZones)
            AllSectionsAndButtonsToState(manualBtnState)
        else
            AllZonesAndButtonsToState(manualBtnState)
    }

    private fun btnSectionMasterAuto_Click() {
        manualBtnState = btnStates.Off
        btnSectionMasterManual.setBackgroundResource(R.drawable.manualoff)

        when (autoBtnState) {
            btnStates.Off -> {
                autoBtnState = btnStates.Auto
                btnSectionMasterAuto.setBackgroundResource(R.drawable.sectionmasteron)
                if (sounds.isSectionsSoundOn) sounds.sndSectionOn.play()
            }
            btnStates.Auto -> {
                autoBtnState = btnStates.Off
                btnSectionMasterAuto.setBackgroundResource(R.drawable.sectionmasteroff)
                if (sounds.isSectionsSoundOn) sounds.sndSectionOn.play()
            }
            else -> {}
        }

        if (tool.isSectionsNotZones)
            AllSectionsAndButtonsToState(autoBtnState)
        else
            AllZonesAndButtonsToState(autoBtnState)
    }

    private fun GetNextState(state: btnStates): btnStates {
        return when (state) {
            btnStates.Off -> btnStates.Auto
            btnStates.Auto -> btnStates.On
            btnStates.On -> btnStates.Off
        }
    }

    private fun btnZone1_Click() {
        val state = GetNextState(section[tool.zoneRanges[1] - 1].sectionBtnState)
        IndividualZoneAndButtonToState(state, 0, tool.zoneRanges[1], btnZone1)
    }

    private fun btnZone2_Click() {
        val state = GetNextState(section[tool.zoneRanges[2] - 1].sectionBtnState)
        IndividualZoneAndButtonToState(state, tool.zoneRanges[1], tool.zoneRanges[2], btnZone2)
    }

    private fun btnZone3_Click() {
        val state = GetNextState(section[tool.zoneRanges[3] - 1].sectionBtnState)
        IndividualZoneAndButtonToState(state, tool.zoneRanges[2], tool.zoneRanges[3], btnZone3)
    }

    private fun btnZone4_Click() {
        val state = GetNextState(section[tool.zoneRanges[4] - 1].sectionBtnState)
        IndividualZoneAndButtonToState(state, tool.zoneRanges[3], tool.zoneRanges[4], btnZone4)
    }

    private fun btnZone5_Click() {
        val state = GetNextState(section[tool.zoneRanges[5] - 1].sectionBtnState)
        IndividualZoneAndButtonToState(state, tool.zoneRanges[4], tool.zoneRanges[5], btnZone5)
    }

    private fun btnZone6_Click() {
        val state = GetNextState(section[tool.zoneRanges[6] - 1].sectionBtnState)
        IndividualZoneAndButtonToState(state, tool.zoneRanges[5], tool.zoneRanges[6], btnZone6)
    }

    private fun btnZone7_Click() {
        val state = GetNextState(section[tool.zoneRanges[7] - 1].sectionBtnState)
        IndividualZoneAndButtonToState(state, tool.zoneRanges[6], tool.zoneRanges[7], btnZone7)
    }

    private fun btnZone8_Click() {
        val state = GetNextState(section[tool.zoneRanges[8] - 1].sectionBtnState)
        IndividualZoneAndButtonToState(state, tool.zoneRanges[7], tool.zoneRanges[8], btnZone8)
    }

    private fun btnSection1Man_Click() {
        val state = GetNextState(section[0].sectionBtnState)
        IndividualSectionAndButonToState(state, 0, btnSection1Man)
    }

    private fun btnSection2Man_Click() {
        val state = GetNextState(section[1].sectionBtnState)
        IndividualSectionAndButonToState(state, 1, btnSection2Man)
    }

    private fun btnSection3Man_Click() {
        val state = GetNextState(section[2].sectionBtnState)
        IndividualSectionAndButonToState(state, 2, btnSection3Man)
    }

    private fun btnSection4Man_Click() {
        val state = GetNextState(section[3].sectionBtnState)
        IndividualSectionAndButonToState(state, 3, btnSection4Man)
    }

    private fun btnSection5Man_Click() {
        val state = GetNextState(section[4].sectionBtnState)
        IndividualSectionAndButonToState(state, 4, btnSection5Man)
    }

    private fun btnSection6Man_Click() {
        val state = GetNextState(section[5].sectionBtnState)
        IndividualSectionAndButonToState(state, 5, btnSection6Man)
    }

    private fun btnSection7Man_Click() {
        val state = GetNextState(section[6].sectionBtnState)
        IndividualSectionAndButonToState(state, 6, btnSection7Man)
    }

    private fun btnSection8Man_Click() {
        val state = GetNextState(section[7].sectionBtnState)
        IndividualSectionAndButonToState(state, 7, btnSection8Man)
    }

    private fun btnSection9Man_Click() {
        val state = GetNextState(section[8].sectionBtnState)
        IndividualSectionAndButonToState(state, 8, btnSection9Man)
    }

    private fun btnSection10Man_Click() {
        val state = GetNextState(section[9].sectionBtnState)
        IndividualSectionAndButonToState(state, 9, btnSection10Man)
    }

    private fun btnSection11Man_Click() {
        val state = GetNextState(section[10].sectionBtnState)
        IndividualSectionAndButonToState(state, 10, btnSection11Man)
    }

    private fun btnSection12Man_Click() {
        val state = GetNextState(section[11].sectionBtnState)
        IndividualSectionAndButonToState(state, 11, btnSection12Man)
    }

    private fun btnSection13Man_Click() {
        val state = GetNextState(section[12].sectionBtnState)
        IndividualSectionAndButonToState(state, 12, btnSection13Man)
    }

    private fun btnSection14Man_Click() {
        val state = GetNextState(section[13].sectionBtnState)
        IndividualSectionAndButonToState(state, 13, btnSection14Man)
    }

    private fun btnSection15Man_Click() {
        val state = GetNextState(section[14].sectionBtnState)
        IndividualSectionAndButonToState(state, 14, btnSection15Man)
    }

    private fun btnSection16Man_Click() {
        val state = GetNextState(section[15].sectionBtnState)
        IndividualSectionAndButonToState(state, 15, btnSection16Man)
    }

    fun AllSectionsAndButtonsToState(state: btnStates) {
        IndividualSectionAndButonToState(state, 0, btnSection1Man)
        IndividualSectionAndButonToState(state, 1, btnSection2Man)
        IndividualSectionAndButonToState(state, 2, btnSection3Man)
        IndividualSectionAndButonToState(state, 3, btnSection4Man)
        IndividualSectionAndButonToState(state, 4, btnSection5Man)
        IndividualSectionAndButonToState(state, 5, btnSection6Man)
        IndividualSectionAndButonToState(state, 6, btnSection7Man)
        IndividualSectionAndButonToState(state, 7, btnSection8Man)
        IndividualSectionAndButonToState(state, 8, btnSection9Man)
        IndividualSectionAndButonToState(state, 9, btnSection10Man)
        IndividualSectionAndButonToState(state, 10, btnSection11Man)
        IndividualSectionAndButonToState(state, 11, btnSection12Man)
        IndividualSectionAndButonToState(state, 12, btnSection13Man)
        IndividualSectionAndButonToState(state, 13, btnSection14Man)
        IndividualSectionAndButonToState(state, 14, btnSection15Man)
        IndividualSectionAndButonToState(state, 15, btnSection16Man)
    }

    fun IndividualSectionAndButonToState(state: btnStates, sectNumber: Int, btn: Button) {
        section[sectNumber].sectionBtnState = state

        when (section[sectNumber].sectionBtnState) {
            btnStates.Off -> {
                if (isDay) {
                    btn.setTextColor(Color.BLACK)
                    btn.setBackgroundColor(Color.RED)
                } else {
                    btn.setBackgroundColor(Color.parseColor("#DC143C")) // Crimson
                    btn.setTextColor(Color.WHITE)
                }
            }
            btnStates.Auto -> {
                if (isDay) {
                    btn.setBackgroundColor(Color.LIME)
                    btn.setTextColor(Color.BLACK)
                } else {
                    btn.setBackgroundColor(Color.parseColor("#228B22")) // ForestGreen
                    btn.setTextColor(Color.WHITE)
                }
            }
            btnStates.On -> {
                if (isDay) {
                    btn.setBackgroundColor(Color.YELLOW)
                    btn.setTextColor(Color.BLACK)
                } else {
                    btn.setBackgroundColor(Color.parseColor("#B8860B")) // DarkGoldenrod
                    btn.setTextColor(Color.WHITE)
                }
            }
        }
    }

    fun LineUpIndividualSectionBtns() {
        if (!isJobStarted) {
            btnSection1Man.visibility = View.GONE
            btnSection2Man.visibility = View.GONE
            btnSection3Man.visibility = View.GONE
            btnSection4Man.visibility = View.GONE
            btnSection5Man.visibility = View.GONE
            btnSection6Man.visibility = View.GONE
            btnSection7Man.visibility = View.GONE
            btnSection8Man.visibility = View.GONE
            btnSection9Man.visibility = View.GONE
            btnSection10Man.visibility = View.GONE
            btnSection11Man.visibility = View.GONE
            btnSection12Man.visibility = View.GONE
            btnSection13Man.visibility = View.GONE
            btnSection14Man.visibility = View.GONE
            btnSection15Man.visibility = View.GONE
            btnSection16Man.visibility = View.GONE
            btnZone1.visibility = View.GONE
            btnZone2.visibility = View.GONE
            btnZone3.visibility = View.GONE
            btnZone4.visibility = View.GONE
            btnZone5.visibility = View.GONE
            btnZone6.visibility = View.GONE
            btnZone7.visibility = View.GONE
            btnZone8.visibility = View.GONE
            return
        }

        btnZone1.visibility = View.GONE
        btnZone2.visibility = View.GONE
        btnZone3.visibility = View.GONE
        btnZone4.visibility = View.GONE
        btnZone5.visibility = View.GONE
        btnZone6.visibility = View.GONE
        btnZone7.visibility = View.GONE
        btnZone8.visibility = View.GONE

        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        val height = displayMetrics.heightPixels
        val oglCenter = if (isPanelBottomHidden) oglMain.width / 2 + 30 else statusStripLeft.width + oglMain.width / 2
        var top = 140

        val buttonMaxWidth = 360
        val buttonHeight = 35

        if ((height - oglMain.height) < 80) {
            top = height - 85
            if (panelSim.visibility == View.VISIBLE) {
                top = height - 120
                panelSim.top = height - 78
            }
        } else {
            top = height - 135
            if (panelSim.visibility == View.VISIBLE) {
                top = height - 185
                panelSim.top = height - 128
            }
        }

        if (tool.isSectionsNotZones) {
            val buttons = arrayOf(
                btnSection1Man, btnSection2Man, btnSection3Man, btnSection4Man,
                btnSection5Man, btnSection6Man, btnSection7Man, btnSection8Man,
                btnSection9Man, btnSection10Man, btnSection11Man, btnSection12Man,
                btnSection13Man, btnSection14Man, btnSection15Man, btnSection16Man
            )

            val oglButtonWidth = oglMain.width * 3 / 4
            var buttonWidth = oglButtonWidth / tool.numOfSections
            if (buttonWidth > buttonMaxWidth) buttonWidth = buttonMaxWidth

            buttons.forEachIndexed { index, btn ->
                btn.top = top
                btn.layoutParams = btn.layoutParams.apply {
                    width = buttonWidth
                    height = buttonHeight
                }
                if (index == 0) {
                    btn.left = oglCenter - (tool.numOfSections * buttonWidth) / 2
                } else {
                    btn.left = buttons[index - 1].left + buttonWidth
                }
                btn.visibility = if (tool.numOfSections > index) View.VISIBLE else View.GONE
            }
        }
    }

    fun AllZonesAndButtonsToState(state: btnStates) {
        if (tool.zoneRanges[0] == 0) return
        if (tool.zoneRanges[1] != 0) IndividualZoneAndButtonToState(state, 0, tool.zoneRanges[1], btnZone1)
        if (tool.zoneRanges[2] != 0) IndividualZoneAndButtonToState(state, tool.zoneRanges[1], tool.zoneRanges[2], btnZone2)
        if (tool.zoneRanges[3] != 0) IndividualZoneAndButtonToState(state, tool.zoneRanges[2], tool.zoneRanges[3], btnZone3)
        if (tool.zoneRanges[4] != 0) IndividualZoneAndButtonToState(state, tool.zoneRanges[3], tool.zoneRanges[4], btnZone4)
        if (tool.zoneRanges[5] != 0) IndividualZoneAndButtonToState(state, tool.zoneRanges[4], tool.zoneRanges[5], btnZone5)
        if (tool.zoneRanges[6] != 0) IndividualZoneAndButtonToState(state, tool.zoneRanges[5], tool.zoneRanges[6], btnZone6)
        if (tool.zoneRanges[7] != 0) IndividualZoneAndButtonToState(state, tool.zoneRanges[6], tool.zoneRanges[7], btnZone7)
        if (tool.zoneRanges[8] != 0) IndividualZoneAndButtonToState(state, tool.zoneRanges[7], tool.zoneRanges[8], btnZone8)
    }

    fun IndividualZoneAndButtonToState(state: btnStates, sectionStartNumber: Int, sectionEndNumber: Int, btn: Button) {
        for (i in sectionStartNumber until sectionEndNumber) {
            section[i].sectionBtnState = state
        }

        when (state) {
            btnStates.Auto -> {
                if (isDay) {
                    btn.setBackgroundColor(Color.LIME)
                    btn.setTextColor(Color.BLACK)
                } else {
                    btn.setBackgroundColor(Color.parseColor("#228B22"))
                    btn.setTextColor(Color.WHITE)
                }
            }
            btnStates.On -> {
                if (isDay) {
                    btn.setBackgroundColor(Color.YELLOW)
                    btn.setTextColor(Color.BLACK)
                } else {
                    btn.setBackgroundColor(Color.parseColor("#B8860B"))
                    btn.setTextColor(Color.WHITE)
                }
            }
            btnStates.Off -> {
                if (isDay) {
                    btn.setTextColor(Color.BLACK)
                    btn.setBackgroundColor(Color.RED)
                } else {
                    btn.setBackgroundColor(Color.parseColor("#DC143C"))
                    btn.setTextColor(Color.WHITE)
                }
            }
        }
    }

    fun LineUpAllZoneButtons() {
        if (!isJobStarted) {
            btnSection1Man.visibility = View.GONE
            btnSection2Man.visibility = View.GONE
            btnSection3Man.visibility = View.GONE
            btnSection4Man.visibility = View.GONE
            btnSection5Man.visibility = View.GONE
            btnSection6Man.visibility = View.GONE
            btnSection7Man.visibility = View.GONE
            btnSection8Man.visibility = View.GONE
            btnSection9Man.visibility = View.GONE
            btnSection10Man.visibility = View.GONE
            btnSection11Man.visibility = View.GONE
            btnSection12Man.visibility = View.GONE
            btnSection13Man.visibility = View.GONE
            btnSection14Man.visibility = View.GONE
            btnSection15Man.visibility = View.GONE
            btnSection16Man.visibility = View.GONE
            btnZone1.visibility = View.GONE
            btnZone2.visibility = View.GONE
            btnZone3.visibility = View.GONE
            btnZone4.visibility = View.GONE
            btnZone5.visibility = View.GONE
            btnZone6.visibility = View.GONE
            btnZone7.visibility = View.GONE
            btnZone8.visibility = View.GONE
            return
        }

        val displayMetrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        val height = displayMetrics.heightPixels
        val oglCenter = if (isPanelBottomHidden) oglMain.width / 2 + 30 else statusStripLeft.width + oglMain.width / 2
        var top = 130

        val buttonMaxWidth = 400
        val buttonHeight = 30

        if ((height - oglMain.height) < 80) {
            top = height - 70
            if (panelSim.visibility == View.VISIBLE) {
                top = height - 100
                panelSim.top = height - 60
            }
        } else {
            top = height - 130
            if (panelSim.visibility == View.VISIBLE) {
                top = height - 160
                panelSim.top = height - 120
            }
        }

        val zoneButtons = arrayOf(btnZone1, btnZone2, btnZone3, btnZone4, btnZone5, btnZone6, btnZone7, btnZone8)
        zoneButtons.forEachIndexed { index, btn ->
            btn.visibility = if (tool.zones > index) View.VISIBLE else View.GONE
            btn.top = top
            if (isJobStarted) btn.setBackgroundColor(Color.RED) else btn.setBackgroundColor(Color.parseColor("#C0C0C0"))
        }

        val oglButtonWidth = oglMain.width * 3 / 4
        var buttonWidth = oglButtonWidth / tool.zones
        if (buttonWidth > buttonMaxWidth) buttonWidth = buttonMaxWidth

        zoneButtons.forEachIndexed { index, btn ->
            btn.layoutParams = btn.layoutParams.apply {
                width = buttonWidth
                height = buttonHeight
            }
            if (index == 0) {
                btn.left = oglCenter - (tool.zones * buttonWidth) / 2
            } else {
                btn.left = zoneButtons[index - 1].left + buttonWidth
            }
        }
    }

    fun SectionSetPosition() {
        if (tool.isSectionsNotZones) {
            val settings = getSharedPreferences("Settings", Context.MODE_PRIVATE)
            val toolOffset = settings.getFloat("setVehicle_toolOffset", 0f).toDouble()

            section[0].positionLeft = settings.getFloat("setSection_position1", 0f).toDouble() + toolOffset
            section[0].positionRight = settings.getFloat("setSection_position2", 0f).toDouble() + toolOffset
            section[1].positionLeft = settings.getFloat("setSection_position2", 0f).toDouble() + toolOffset
            section[1].positionRight = settings.getFloat("setSection_position3", 0f).toDouble() + toolOffset
            section[2].positionLeft = settings.getFloat("setSection_position3", 0f).toDouble() + toolOffset
            section[2].positionRight = settings.getFloat("setSection_position4", 0f).toDouble() + toolOffset
            section[3].positionLeft = settings.getFloat("setSection_position4", 0f).toDouble() + toolOffset
            section[3].positionRight = settings.getFloat("setSection_position5", 0f).toDouble() + toolOffset
            section[4].positionLeft = settings.getFloat("setSection_position5", 0f).toDouble() + toolOffset
            section[4].positionRight = settings.getFloat("setSection_position6", 0f).toDouble() + toolOffset
            section[5].positionLeft = settings.getFloat("setSection_position6", 0f).toDouble() + toolOffset
            section[5].positionRight = settings.getFloat("setSection_position7", 0f).toDouble() + toolOffset
            section[6].positionLeft = settings.getFloat("setSection_position7", 0f).toDouble() + toolOffset
            section[6].positionRight = settings.getFloat("setSection_position8", 0f).toDouble() + toolOffset
            section[7].positionLeft = settings.getFloat("setSection_position8", 0f).toDouble() + toolOffset
            section[7].positionRight = settings.getFloat("setSection_position9", 0f).toDouble() + toolOffset
            section[8].positionLeft = settings.getFloat("setSection_position9", 0f).toDouble() + toolOffset
            section[8].positionRight = settings.getFloat("setSection_position10", 0f).toDouble() + toolOffset
            section[9].positionLeft = settings.getFloat("setSection_position10", 0f).toDouble() + toolOffset
            section[9].positionRight = settings.getFloat("setSection_position11", 0f).toDouble() + toolOffset
            section[10].positionLeft = settings.getFloat("setSection_position11", 0f).toDouble() + toolOffset
            section[10].positionRight = settings.getFloat("setSection_position12", 0f).toDouble() + toolOffset
            section[11].positionLeft = settings.getFloat("setSection_position12", 0f).toDouble() + toolOffset
            section[11].positionRight = settings.getFloat("setSection_position13", 0f).toDouble() + toolOffset
            section[12].positionLeft = settings.getFloat("setSection_position13", 0f).toDouble() + toolOffset
            section[12].positionRight = settings.getFloat("setSection_position14", 0f).toDouble() + toolOffset
            section[13].positionLeft = settings.getFloat("setSection_position14", 0f).toDouble() + toolOffset
            section[13].positionRight = settings.getFloat("setSection_position15", 0f).toDouble() + toolOffset
            section[14].positionLeft = settings.getFloat("setSection_position15", 0f).toDouble() + toolOffset
            section[14].positionRight = settings.getFloat("setSection_position16", 0f).toDouble() + toolOffset
            section[15].positionLeft = settings.getFloat("setSection_position16", 0f).toDouble() + toolOffset
            section[15].positionRight = settings.getFloat("setSection_position17", 0f).toDouble() + toolOffset
        }
    }

    fun SectionCalcWidths() {
        if (tool.isSectionsNotZones) {
            for (j in 0 until MAXSECTIONS) {
                section[j].sectionWidth = section[j].positionRight - section[j].positionLeft
                section[j].rpSectionPosition = 250 + (section[j].positionLeft * 10).toInt()
                section[j].rpSectionWidth = (section[j].sectionWidth * 10).toInt()
            }

            tool.width = section[tool.numOfSections - 1].positionRight - section[0].positionLeft
            tool.farLeftPosition = section[0].positionLeft
            tool.farRightPosition = section[tool.numOfSections - 1].positionRight
            tool.rpXPosition = 250 + (tool.farLeftPosition * 10).toInt()
            tool.rpWidth = (tool.width * 10).toInt()
        }
    }

    fun SectionCalcMulti() {
        val settings = getSharedPreferences("Settings", Context.MODE_PRIVATE)
        val defaultSectionWidth = settings.getFloat("setTool_sectionWidthMulti", 0f).toDouble()
        val offset = settings.getFloat("setVehicle_toolOffset", 0f).toDouble()
        var leftside = tool.width / -2.0
        section[0].positionLeft = leftside + offset

        for (i in 0 until tool.numOfSections - 1) {
            leftside += defaultSectionWidth
            section[i].positionRight = leftside + offset
            section[i + 1].positionLeft = leftside + offset
            section[i].sectionWidth = defaultSectionWidth
            section[i].rpSectionPosition = 250 + (section[i].positionLeft * 10).toInt()
            section[i].rpSectionWidth = (section[i].sectionWidth * 10).toInt()
        }

        leftside += defaultSectionWidth
        section[tool.numOfSections - 1].positionRight = leftside + offset
        section[tool.numOfSections - 1].sectionWidth = defaultSectionWidth
        section[tool.numOfSections - 1].rpSectionPosition = 250 + (section[tool.numOfSections - 1].positionLeft * 10).toInt()
        section[tool.numOfSections - 1].rpSectionWidth = (section[tool.numOfSections - 1].sectionWidth * 10).toInt()

        tool.width = section[tool.numOfSections - 1].positionRight - section[0].positionLeft
        tool.farLeftPosition = section[0].positionLeft
        tool.farRightPosition = section[tool.numOfSections - 1].positionRight
        tool.rpXPosition = 250 + (tool.farLeftPosition * 10).toInt()
        tool.rpWidth = (tool.width * 10).toInt()
    }

    fun BuildMachineByte() {
        if (tool.isSectionsNotZones) {
            p_254.pgn[p_254.sc1to8] = 0
            p_254.pgn[p_254.sc9to16] = 0

            var number = 0
            for (j in 0 until 8) {
                if (section[j].isSectionOn) number = number or (1 shl j)
            }
            p_254.pgn[p_254.sc1to8] = number.toByte()

            number = 0
            for (j in 8 until 16) {
                if (section[j].isSectionOn) number = number or (1 shl (j - 8))
            }
            p_254.pgn[p_254.sc9to16] = number.toByte()

            p_239.pgn[p_239.sc1to8] = p_254.pgn[p_254.sc1to8]
            p_239.pgn[p_239.sc9to16] = p_254.pgn[p_254.sc9to16]
            p_229.pgn[p_229.sc1to8] = p_254.pgn[p_254.sc1to8]
            p_229.pgn[p_229.sc9to16] = p_254.pgn[p_254.sc9to16]
            p_229.pgn[p_229.toolLSpeed] = (tool.farLeftSpeed * 10).toInt().toByte()
            p_229.pgn[p_229.toolRSpeed] = (tool.farRightSpeed * 10).toInt().toByte()
        } else {
            for (i in 5..12) {
                p_229.pgn[i] = 0
            }

            var number = 0
            for (k in 0 until 8) {
                for (j in 0 until 8) {
                    if (section[j + k * 8].isSectionOn) number = number or (1 shl j)
                }
                p_229.pgn[5 + k] = number.toByte()
                number = 0
            }

            p_229.pgn[p_229.toolLSpeed] = (tool.farLeftSpeed * 10).toInt().toByte()
            p_229.pgn[p_229.toolRSpeed] = (tool.farRightSpeed * 10).toInt().toByte()

            p_239.pgn[p_239.sc1to8] = p_229.pgn[p_229.sc1to8]
            p_239.pgn[p_239.sc9to16] = p_229.pgn[p_229.sc9to16]
            p_254.pgn[p_254.sc1to8] = p_229.pgn[p_229.sc1to8]
            p_254.pgn[p_254.sc9to16] = p_229.pgn[p_229.sc9to16]
        }

        p_239.pgn[p_239.speed] = (avgSpeed * 10).toInt().toByte()
        p_239.pgn[p_239.tram] = tram.controlByte
    }

    fun DoRemoteSwitches() {
        if (isJobStarted) {
            if (mc.ss[mc.swMain] != mc.ssP[mc.swMain]) {
                if (mc.ss[mc.swMain] and 1 == 1) {
                    autoBtnState = btnStates.Off
                    btnSectionMasterAuto.performClick()
                }
                if (mc.ss[mc.swMain] and 2 == 2) {
                    autoBtnState = btnStates.Auto
                    btnSectionMasterAuto.performClick()
                }
                mc.ssP[mc.swMain] = mc.ss[mc.swMain]
            }

            if (tool.isSectionsNotZones) {
                if (mc.ss[mc.swOnGr0] != 0) {
                    val buttons = arrayOf(
                        btnSection1Man, btnSection2Man, btnSection3Man, btnSection4Man,
                        btnSection5Man, btnSection6Man, btnSection7Man, btnSection8Man
                    )
                    for (i in 0 until 8) {
                        if (mc.ss[mc.swOnGr0] and (1 shl i) == (1 shl i) && tool.numOfSections > i) {
                            if (section[i].sectionBtnState != btnStates.Auto) section[i].sectionBtnState = btnStates.Auto
                            buttons[i].performClick()
                        }
                    }
                    mc.ssP[mc.swOnGr0] = mc.ss[mc.swOnGr0]
                } else if (mc.ssP[mc.swOnGr0] != 0) mc.ssP[mc.swOnGr0] = 0

                if (mc.ss[mc.swOnGr1] != 0) {
                    val buttons = arrayOf(
                        btnSection9Man, btnSection10Man, btnSection11Man, btnSection12Man,
                        btnSection13Man, btnSection14Man, btnSection15Man, btnSection16Man
                    )
                    for (i in 0 until 8) {
                        if (mc.ss[mc.swOnGr1] and (1 shl i) == (1 shl i) && tool.numOfSections > (i + 8)) {
                            if (section[i + 8].sectionBtnState != btnStates.Auto) section[i + 8].sectionBtnState = btnStates.Auto
                            buttons[i].performClick()
                        }
                    }
                    mc.ssP[mc.swOnGr1] = mc.ss[mc.swOnGr1]
                } else if (mc.ssP[mc.swOnGr1] != 0) mc.ssP[mc.swOnGr1] = 0

                if (mc.ss[mc.swOffGr0] != mc.ssP[mc.swOffGr0]) {
                    if (autoBtnState == btnStates.Auto) {
                        val buttons = arrayOf(
                            btnSection1Man, btnSection2Man, btnSection3Man, btnSection4Man,
                            btnSection5Man, btnSection6Man, btnSection7Man, btnSection8Man
                        )
                        for (i in 0 until 8) {
                            if (mc.ssP[mc.swOffGr0] and (1 shl i) == (1 shl i) &&
                                mc.ss[mc.swOffGr0] and (1 shl i) != (1 shl i) &&
                                section[i].sectionBtnState == btnStates.Off) {
                                buttons[i].performClick()
                            }
                        }
                    }
                    mc.ssP[mc.swOffGr0] = mc.ss[mc.swOffGr0]
                }

                if (mc.ss[mc.swOffGr1] != mc.ssP[mc.swOffGr1]) {
                    if (autoBtnState == btnStates.Auto) {
                        val buttons = arrayOf(
                            btnSection9Man, btnSection10Man, btnSection11Man, btnSection12Man,
                            btnSection13Man, btnSection14Man, btnSection15Man, btnSection16Man
                        )
                        for (i in 0 until 8) {
                            if (mc.ssP[mc.swOffGr1] and (1 shl i) == (1 shl i) &&
                                mc.ss[mc.swOffGr1] and (1 shl i) != (1 shl i) &&
                                section[i + 8].sectionBtnState == btnStates.Off) {
                                buttons[i].performClick()
                            }
                        }
                    }
                    mc.ssP[mc.swOffGr1] = mc.ss[mc.swOffGr1]
                }

                if (mc.ss[mc.swOffGr0] != 0) {
                    val buttons = arrayOf(
                        btnSection1Man, btnSection2Man, btnSection3Man, btnSection4Man,
                        btnSection5Man, btnSection6Man, btnSection7Man, btnSection8Man
                    )
                    for (i in 0 until 8) {
                        if (mc.ss[mc.swOffGr0] and (1 shl i) == (1 shl i) && section[i].sectionBtnState != btnStates.Off) {
                            section[i].sectionBtnState = btnStates.On
                            buttons[i].performClick()
                        }
                    }
                }

                if (mc.ss[mc.swOffGr1] != 0) {
                    val buttons = arrayOf(
                        btnSection9Man, btnSection10Man, btnSection11Man, btnSection12Man,
                        btnSection13Man, btnSection14Man, btnSection15Man, btnSection16Man
                    )
                    for (i in 0 until 8) {
                        if (mc.ss[mc.swOffGr1] and (1 shl i) == (1 shl i) && section[i + 8].sectionBtnState != btnStates.Off) {
                            section[i + 8].sectionBtnState = btnStates.On
                            buttons[i].performClick()
                        }
                    }
                }
            } else {
                DoZones()
            }
        }
    }

    fun DoZones() {
        if (mc.ss[mc.swOnGr0] != 0) {
            val buttons = arrayOf(btnZone1, btnZone2, btnZone3, btnZone4, btnZone5, btnZone6, btnZone7, btnZone8)
            for (i in 0 until 8) {
                val bit = 1 shl i
                if (tool.zoneRanges[i + 1] > 0 && mc.ss[mc.swOnGr0] and bit == bit) {
                    if (section[tool.zoneRanges[i + 1] - 1].sectionBtnState != btnStates.Auto)
                        section[tool.zoneRanges[i + 1] - 1].sectionBtnState = btnStates.Auto
                    buttons[i].performClick()
                }
            }
            mc.ssP[mc.swOnGr0] = mc.ss[mc.swOnGr0]
        } else if (mc.ssP[mc.swOnGr0] != 0) mc.ssP[mc.swOnGr0] = 0

        if (mc.ss[mc.swOffGr0] != mc.ssP[mc.swOffGr0]) {
            if (autoBtnState == btnStates.Auto) {
                val buttons = arrayOf(btnZone1, btnZone2, btnZone3, btnZone4, btnZone5, btnZone6, btnZone7, btnZone8)
                for (i in 0 until 8) {
                    val bit = 1 shl i
                    if (tool.zoneRanges[i + 1] > 0 && mc.ssP[mc.swOffGr0] and bit == bit &&
                        mc.ss[mc.swOffGr0] and bit != bit && section[tool.zoneRanges[i + 1] - 1].sectionBtnState == btnStates.Off) {
                        buttons[i].performClick()
                    }
                }
            }
            mc.ssP[mc.swOffGr0] = mc.ss[mc.swOffGr0]
        }

        if (mc.ss[mc.swOffGr0] != 0) {
            val buttons = arrayOf(btnZone1, btnZone2, btnZone3, btnZone4, btnZone5, btnZone6, btnZone7, btnZone8)
            for (i in 0 until 8) {
                val bit = 1 shl i
                if (tool.zoneRanges[i + 1] > 0 && mc.ss[mc.swOffGr0] and bit == bit &&
                    section[tool.zoneRanges[i + 1] - 1].sectionBtnState != btnStates.Off) {
                    section[tool.zoneRanges[i + 1] - 1].sectionBtnState = btnStates.On
                    buttons[i].performClick()
                }
            }
        }
    }

    private fun PerformZoneClick(Btn: Int) {
        when (Btn) {
            0 -> btnZone1.performClick()
            1 -> btnZone2.performClick()
            2 -> btnZone3.performClick()
            3 -> btnZone4.performClick()
            4 -> btnZone5.performClick()
            5 -> btnZone6.performClick()
            6 -> btnZone7.performClick()
            7 -> btnZone8.performClick()
        }
    }

    companion object {
        const val MAXSECTIONS = 16 // Assuming this is defined somewhere
    }
}

enum class btnStates {
    Off, Auto, On
}


// Placeholder classes (these should be defined in com.agopengps.classes)
data class Section(
    var sectionBtnState: btnStates = btnStates.Off,
    var positionLeft: Double = 0.0,
    var positionRight: Double = 0.0,
    var sectionWidth: Double = 0.0,
    var rpSectionPosition: Int = 0,
    var rpSectionWidth: Int = 0,
    var isSectionOn: Boolean = false
)

data class Tool(
    var isSectionsNotZones: Boolean = true,
    var numOfSections: Int = 0,
    var zones: Int = 0,
    var zoneRanges: IntArray = IntArray(9),
    var width: Double = 0.0,
    var farLeftPosition: Double = 0.0,
    var farRightPosition: Double = 0.0,
    var rpXPosition: Int = 0,
    var rpWidth: Int = 0,
    var farLeftSpeed: Double = 0.0,
    var farRightSpeed: Double = 0.0
)

data class Sounds(
    var isSectionsSoundOn: Boolean = false,
    val sndSectionOn: SoundPool, // Simplified for this example
    val sndSectionOff: SoundPool
)

data class PGN254(var pgn: ByteArray = ByteArray(13)) {
    val sc1to8 = 5
    val sc9to16 = 6
}

data class PGN239(var pgn: ByteArray = ByteArray(13)) {
    val sc1to8 = 5
    val sc9to16 = 6
    val speed = 7
    val tram = 8
}

data class PGN229(var pgn: ByteArray = ByteArray(13)) {
    val sc1to8 = 5
    val sc9to16 = 6
    val toolLSpeed = 7
    val toolRSpeed = 8
}

data class MachineControl(
    var ss: ByteArray = ByteArray(16),
    var ssP: ByteArray = ByteArray(16),
    val swMain: Int = 0,
    val swOnGr0: Int = 1,
    val swOnGr1: Int = 2,
    val swOffGr0: Int = 3,
    val swOffGr1: Int = 4
)

data class Tram(var controlByte: Byte = 0)
