package com.agopengps.drive

import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.agopengps.classes.Properties // 假設這是自定義的類，用於存取設置
import java.nio.ByteBuffer

class PGN : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form_gps)

        val layout = findViewById<LinearLayout>(R.id.pgn_layout)

        // 動態添加一個 TextView 來展示 PGN 數據的描述（多語言）
        val pgnDescription = TextView(this).apply {
            text = getString(R.string.pgn_data_placeholder)
            textSize = 18f
        }
        layout.addView(pgnDescription)
    }

    // Latitude
    class CPGN_D0 {
        var latLong = byteArrayOf(
            0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xD0.toByte(),
            8.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0xCC.toByte()
        )

        fun loadLatitudeLongitude(lat: Double, lon: Double) {
            var encodedAngle = (lat * (0x7FFFFFFF / 90.0)).toInt()
            val latBytes = ByteBuffer.allocate(4).putInt(encodedAngle).array()
            latBytes.copyInto(latLong, 5, 0, 4)

            encodedAngle = (lon * (0x7FFFFFFF / 180.0)).toInt()
            val lonBytes = ByteBuffer.allocate(4).putInt(encodedAngle).array()
            lonBytes.copyInto(latLong, 9, 0, 4)
        }
    }

    // AutoSteerData
    class CPGN_FE {
        var pgn = byteArrayOf(
            0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xFE.toByte(),
            8.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0xCC.toByte()
        )
        val speedLo = 5
        val speedHi = 6
        val status = 7
        val steerAngleLo = 8
        val steerAngleHi = 9
        val lineDistance = 10
        val sc1to8 = 11
        val sc9to16 = 12

        fun reset() {}
    }

    class CPGN_FD {
        var pgn = byteArrayOf(
            0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xFD.toByte(),
            8.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0xCC.toByte()
        )
        val actualLo = 5
        val actualHi = 6
        val headLo = 7
        val headHi = 8
        val rollLo = 9
        val rollHi = 10
        val switchStatus = 11
        val pwm = 12

        fun reset() {}
    }

    class CPGN_FC {
        var pgn = byteArrayOf(
            0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xFC.toByte(),
            8.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0xCC.toByte()
        )
        val gainProportional = 5
        val highPWM = 6
        val lowPWM = 7
        val minPWM = 8
        val countsPerDegree = 9
        val wasOffsetLo = 10
        val wasOffsetHi = 11
        val ackerman = 12

        init {
            pgn[gainProportional] = Properties.Settings.Default.setAS_Kp
            pgn[highPWM] = Properties.Settings.Default.setAS_highSteerPWM
            pgn[lowPWM] = Properties.Settings.Default.setAS_lowSteerPWM
            pgn[minPWM] = Properties.Settings.Default.setAS_minSteerPWM
            pgn[countsPerDegree] = Properties.Settings.Default.setAS_countsPerDegree
            pgn[wasOffsetHi] = (Properties.Settings.Default.setAS_wasOffset shr 8).toByte()
            pgn[wasOffsetLo] = Properties.Settings.Default.setAS_wasOffset.toByte()
            pgn[ackerman] = Properties.Settings.Default.setAS_ackerman
        }

        fun reset() {}
    }

    class CPGN_FB {
        var pgn = byteArrayOf(
            0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xFB.toByte(),
            8.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0xCC.toByte()
        )
        val set0 = 5
        val maxPulse = 6
        val minSpeed = 7
        val set1 = 8
        val angVel = 9

        init {
            pgn[set0] = 0.toByte()
            pgn[maxPulse] = 0.toByte()
            pgn[minSpeed] = 0.toByte()
            pgn[set1] = 0.toByte()
            pgn[angVel] = 0.toByte()
        }

        fun reset() {}
    }

    class CPGN_EF {
        var pgn = byteArrayOf(
            0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xEF.toByte(),
            8.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0xCC.toByte()
        )
        val uturn = 5
        val speed = 6
        val hydLift = 7
        val tram = 8
        val geoStop = 9
        val sc1to8 = 11
        val sc9to16 = 12

        fun reset() {}
    }

    class CPGN_E5 {
        var pgn = byteArrayOf(
            0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xE5.toByte(),
            10.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0xCC.toByte()
        )
        val sc1to8 = 5
        val sc9to16 = 6
        val sc17to24 = 7
        val sc25to32 = 8
        val sc33to40 = 9
        val sc41to48 = 10
        val sc49to56 = 11
        val sc57to64 = 12
        val toolLSpeed = 13
        val toolRSpeed = 14

        fun reset() {}
    }

    class CPGN_EE {
        var pgn = byteArrayOf(
            0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xEE.toByte(),
            8.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0xCC.toByte()
        )
        val raiseTime = 5
        val lowerTime = 6
        val enableHyd = 7
        val set0 = 8
        val user1 = 9
        val user2 = 10
        val user3 = 11
        val user4 = 12

        private var crc = 0

        init {
            pgn[raiseTime] = Properties.Settings.Default.setArdMac_hydRaiseTime
            pgn[lowerTime] = Properties.Settings.Default.setArdMac_hydLowerTime
            pgn[enableHyd] = Properties.Settings.Default.setArdMac_isHydEnabled
            pgn[set0] = Properties.Settings.Default.setArdMac_setting0
            pgn[user1] = Properties.Settings.Default.setArdMac_user1
            pgn[user2] = Properties.Settings.Default.setArdMac_user2
            pgn[user3] = Properties.Settings.Default.setArdMac_user3
            pgn[user4] = Properties.Settings.Default.setArdMac_user4
        }

        fun makeCRC() {
            crc = 0
            for (i in 2 until pgn.size - 1) {
                crc += pgn[i].toInt() and 0xFF
            }
            pgn[pgn.size - 1] = crc.toByte()
        }

        fun reset() {}
    }

    class CPGN_EC {
        var pgn = byteArrayOf(
            0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xEC.toByte(), 24.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0xCC.toByte()
        )

        val pin0 = 5
        val pin1 = 6
        val pin2 = 7
        val pin3 = 8
        val pin4 = 9
        val pin5 = 10
        val pin6 = 11
        val pin7 = 12
        val pin8 = 13
        val pin9 = 14
        val pin10 = 15
        val pin11 = 16
        val pin12 = 17
        val pin13 = 18
        val pin14 = 19
        val pin15 = 20
        val pin16 = 21
        val pin17 = 22
        val pin18 = 23
        val pin19 = 24
        val pin20 = 25
        val pin21 = 26
        val pin22 = 27
        val pin23 = 28

        private var crc = 0

        init {
            val words = Properties.Settings.Default.setRelay_pinConfig.split(",")
            pgn[pin0] = words[0].toInt().toByte()
            pgn[pin1] = words[1].toInt().toByte()
            pgn[pin2] = words[2].toInt().toByte()
            pgn[pin3] = words[3].toInt().toByte()
            pgn[pin4] = words[4].toInt().toByte()
            pgn[pin5] = words[5].toInt().toByte()
            pgn[pin6] = words[6].toInt().toByte()
            pgn[pin7] = words[7].toInt().toByte()
            pgn[pin8] = words[8].toInt().toByte()
            pgn[pin9] = words[9].toInt().toByte()
            pgn[pin10] = words[10].toInt().toByte()
            pgn[pin11] = words[11].toInt().toByte()
            pgn[pin12] = words[12].toInt().toByte()
            pgn[pin13] = words[13].toInt().toByte()
            pgn[pin14] = words[14].toInt().toByte()
            pgn[pin15] = words[15].toInt().toByte()
            pgn[pin16] = words[16].toInt().toByte()
            pgn[pin17] = words[17].toInt().toByte()
            pgn[pin18] = words[18].toInt().toByte()
            pgn[pin19] = words[19].toInt().toByte()
            pgn[pin20] = words[20].toInt().toByte()
            pgn[pin21] = words[21].toInt().toByte()
            pgn[pin22] = words[22].toInt().toByte()
            pgn[pin23] = words[23].toInt().toByte()
        }

        fun makeCRC() {
            crc = 0
            for (i in 2 until pgn.size - 1) {
                crc += pgn[i].toInt() and 0xFF
            }
            pgn[pgn.size - 1] = crc.toByte()
        }

        fun reset() {}
    }

    class CPGN_EB {
        var pgn = byteArrayOf(
            0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xEB.toByte(), 33.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0xCC.toByte()
        )

        val sec0Lo = 5
        val sec1Lo = 7
        val sec2Lo = 9
        val sec3Lo = 11
        val sec4Lo = 13
        val sec5Lo = 15
        val sec6Lo = 17
        val sec7Lo = 19
        val sec8Lo = 21
        val sec9Lo = 23
        val sec10Lo = 25
        val sec11Lo = 27
        val sec12Lo = 29
        val sec13Lo = 31
        val sec14Lo = 33
        val sec15Lo = 35

        val sec0Hi = 6
        val sec1Hi = 8
        val sec2Hi = 10
        val sec3Hi = 12
        val sec4Hi = 14
        val sec5Hi = 16
        val sec6Hi = 18
        val sec7Hi = 20
        val sec8Hi = 22
        val sec9Hi = 24
        val sec10Hi = 26
        val sec11Hi = 28
        val sec12Hi = 30
        val sec13Hi = 32
        val sec14Hi = 34
        val sec15Hi = 36

        val numSections = 37

        init {
            pgn[sec0Lo] = 0.toByte()
            pgn[sec1Lo] = 0.toByte()
            pgn[sec2Lo] = 0.toByte()
            pgn[sec3Lo] = 0.toByte()
            pgn[sec4Lo] = 0.toByte()
            pgn[sec5Lo] = 0.toByte()
            pgn[sec6Lo] = 0.toByte()
            pgn[sec7Lo] = 0.toByte()
            pgn[sec8Lo] = 0.toByte()
            pgn[sec9Lo] = 0.toByte()
            pgn[sec10Lo] = 0.toByte()
            pgn[sec11Lo] = 0.toByte()
            pgn[sec12Lo] = 0.toByte()
            pgn[sec13Lo] = 0.toByte()
            pgn[sec14Lo] = 0.toByte()
            pgn[sec15Lo] = 0.toByte()

            pgn[sec0Hi] = 0.toByte()
            pgn[sec1Hi] = 0.toByte()
            pgn[sec2Hi] = 0.toByte()
            pgn[sec3Hi] = 0.toByte()
            pgn[sec4Hi] = 0.toByte()
            pgn[sec5Hi] = 0.toByte()
            pgn[sec6Hi] = 0.toByte()
            pgn[sec7Hi] = 0.toByte()
            pgn[sec8Hi] = 0.toByte()
            pgn[sec9Hi] = 0.toByte()
            pgn[sec10Hi] = 0.toByte()
            pgn[sec11Hi] = 0.toByte()
            pgn[sec12Hi] = 0.toByte()
            pgn[sec13Hi] = 0.toByte()
            pgn[sec14Hi] = 0.toByte()
            pgn[sec15Hi] = 0.toByte()

            pgn[numSections] = 0.toByte()
        }

        fun reset() {}
    }

    class CPGN_E4 {
        var pgn = byteArrayOf(
            0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xE4.toByte(),
            8.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
            0.toByte(), 0xCC.toByte()
        )
        val rate0 = 5
        val rate1 = 6
        val rate2 = 7
    }

    val p_254 = CPGN_FE()
    val p_252 = CPGN_FC()
    val p_251 = CPGN_FB()
    val p_239 = CPGN_EF()
    val p_238 = CPGN_EE()
    val p_236 = CPGN_EC()
    val p_235 = CPGN_EB()
    val p_228 = CPGN_E4()
    val p_229 = CPGN_E5()
}