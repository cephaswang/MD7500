package com.agopengps.classes

import android.content.Context
import androidx.core.content.edit

class CAHRS(context: Context) {
    // IMU data
    var imuHeading: Double = 99999.0
    var prevIMUHeading: Double = 0.0
    var imuRoll: Double = 0.0
    var imuPitch: Double = 0.0
    var imuYawRate: Double = 0.0
    var angVel: Short = 0

    // Configuration values
    var rollZero: Double = 0.0
    var rollFilter: Double = 0.0
    var fusionWeight: Double = 0.0
    var forwardComp: Double = 0.0
    var reverseComp: Double = 0.0

    // Status flags
    var isAutoSteerAuto: Boolean = true
    var isRollInvert: Boolean = false
    var isReverseOn: Boolean = false

    init {
        // Load settings from SharedPreferences
        val prefs = context.getSharedPreferences("Settings", Context.MODE_PRIVATE)

        rollZero = prefs.getFloat("setIMU_rollZero", 0f).toDouble()
        rollFilter = prefs.getFloat("setIMU_rollFilter", 0f).toDouble()
        fusionWeight = prefs.getFloat("setIMU_fusionWeight2", 0f).toDouble()
        forwardComp = prefs.getFloat("setGPS_forwardComp", 0f).toDouble()
        reverseComp = prefs.getFloat("setGPS_reverseComp", 0f).toDouble()
        isRollInvert = prefs.getBoolean("setIMU_invertRoll", false)
        isReverseOn = prefs.getBoolean("setIMU_isReverseOn", false)

        // Default to true as per original code
        isAutoSteerAuto = true
    }

    fun updateIMUData(
        heading: Double,
        roll: Double,
        pitch: Double,
        yawRate: Double,
        angularVelocity: Short
    ) {
        prevIMUHeading = imuHeading
        imuHeading = heading
        imuRoll = if (isRollInvert) -roll else roll
        imuPitch = pitch
        imuYawRate = yawRate
        angVel = angularVelocity
    }

    fun saveSettings(context: Context) {
        context.getSharedPreferences("Settings", Context.MODE_PRIVATE).edit() {
            putFloat("setIMU_rollZero", rollZero.toFloat())
            putFloat("setIMU_rollFilter", rollFilter.toFloat())
            putFloat("setIMU_fusionWeight2", fusionWeight.toFloat())
            putFloat("setGPS_forwardComp", forwardComp.toFloat())
            putFloat("setGPS_reverseComp", reverseComp.toFloat())
            putBoolean("setIMU_invertRoll", isRollInvert)
            putBoolean("setIMU_isReverseOn", isReverseOn)
        }
    }
}