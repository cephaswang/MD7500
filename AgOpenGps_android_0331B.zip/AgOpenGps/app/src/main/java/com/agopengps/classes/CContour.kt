package com.agopengps.classes

import android.opengl.GLES10.glPointSize
import android.opengl.GLES20.*
import com.agopengps.drive.MainActivity
import java.nio.FloatBuffer
import kotlin.math.*

class CContour(private val mf: MainActivity) {
    // 屬性定義
    var isContourOn: Boolean = false
    var isContourBtnOn: Boolean = false
    var isRightPriority: Boolean = true

    var minDistance: Double = 99999.0
    var refX: Double = 0.0
    var refZ: Double = 0.0

    var distanceFromCurrentLinePivot: Double = 0.0

    private var a: Int = 0
    private var b: Int = 0
    private var c: Int = 0
    private var stripNum: Int = 0
    private var lastLockPt: Int = Int.MAX_VALUE

    var abFixHeadingDelta: Double = 0.0
    var abHeading: Double = 0.0

    var boxA: Vec2 = Vec2(0.0, 0.0)
    var boxB: Vec2 = Vec2(0.0, 2.0)

    var isHeadingSameWay: Boolean = true

    var goalPointCT: Vec2 = Vec2(0.0, 0.0)
    var steerAngleCT: Double = 0.0
    var rEastCT: Double = 0.0
    var rNorthCT: Double = 0.0
    var ppRadiusCT: Double = 0.0

    var pivotDistanceError: Double = 0.0
    var pivotDistanceErrorLast: Double = 0.0
    var pivotDerivative: Double = 0.0
    var pivotDerivativeSmoothed: Double = 0.0

    private var counter2: Int = 0

    var inty: Double = 0.0
    var steerAngleSmoothed: Double = 0.0
    var pivotErrorTotal: Double = 0.0
    var distSteerError: Double = 0.0
    var lastDistSteerError: Double = 0.0
    var derivativeDistError: Double = 0.0

    private val ptList: MutableList<Vec3> = ArrayList(128)
    private val stripList: MutableList<MutableList<Vec3>> = mutableListOf()
    private val ctList: MutableList<Vec3> = ArrayList(128)

    var isLocked: Boolean = false
    private var lastSecond: Double = 0.0
    private var pt: Int = 0

    // 方法：鎖定到線
    fun setLockToLine(): Boolean {
        if (ctList.size > 5) isLocked = !isLocked
        mf.setContourLockImage(isLocked)
        return isLocked
    }

    // 方法：構建等高線導航線
    fun buildContourGuidanceLine(pivot: Vec3) {
        if (ctList.isEmpty()) {
            if ((mf.secondsSinceStart - lastSecond) < 0.3) return
        } else {
            if ((mf.secondsSinceStart - lastSecond) < 2) return
        }

        lastSecond = mf.secondsSinceStart
        var ptCount: Int
        minDistance = Double.MAX_VALUE
        var start: Int
        var stop: Int

        val toolContourDistance = (mf.tool.width * 3 + abs(mf.tool.offset))
        val stripCount = stripList.size
        if (stripCount < 1) return

        val sinH = sin(pivot.heading) * 0.2
        val cosH = cos(pivot.heading) * 0.2
        val sin2HL = sin(pivot.heading + PI / 2)
        val cos2HL = cos(pivot.heading + PI / 2)

        boxA.easting = pivot.easting - sin2HL + sinH
        boxA.northing = pivot.northing - cos2HL + cosH
        boxB.easting = pivot.easting + sin2HL + sinH
        boxB.northing = pivot.northing + cos2HL + cosH

        if (!isLocked) {
            stripNum = -1
            for (s in 0 until stripCount) {
                ptCount = stripList[s].size
                if (ptCount == 0) continue
                var dist: Double
                var p = 0
                while (p < ptCount) {
                    if ((((boxA.easting - boxB.easting) * (stripList[s][p].northing - boxB.northing))
                                - ((boxA.northing - boxB.northing) * (stripList[s][p].easting - boxB.easting))) > 0
                    ) {
                        p += 3
                        continue
                    }
                    dist = ((pivot.easting - stripList[s][p].easting) * (pivot.easting - stripList[s][p].easting)) +
                            ((pivot.northing - stripList[s][p].northing) * (pivot.northing - stripList[s][p].northing))
                    if (dist < minDistance) {
                        minDistance = dist
                        stripNum = s
                        pt = p
                        lastLockPt = p
                    }
                    p += 3
                }
            }
            minDistance = sqrt(minDistance)
            if (stripNum < 0 || minDistance > toolContourDistance || stripList[stripNum].size < 4) {
                ctList.clear()
                isLocked = false
                mf.setContourLockImage(isLocked)
                return
            }
        } else {
            ptCount = stripList[stripNum].size
            if (ptCount < 2) {
                ctList.clear()
                isLocked = false
                mf.setContourLockImage(isLocked)
                return
            }
            start = lastLockPt - 20
            if (start < 0) start = 0
            stop = lastLockPt + 20
            if (stop > ptCount) stop = ptCount
            minDistance = Double.MAX_VALUE
            var i = start
            while (i < stop) {
                val dist = ((pivot.easting - stripList[stripNum][i].easting) * (pivot.easting - stripList[stripNum][i].easting)) +
                        ((pivot.northing - stripList[stripNum][i].northing) * (pivot.northing - stripList[stripNum][i].northing))
                if (minDistance >= dist) {
                    minDistance = dist
                    pt = i
                    lastLockPt = i
                }
                i += 3
            }
            minDistance = sqrt(minDistance)
            if (minDistance > toolContourDistance) {
                ctList.clear()
                isLocked = false
                mf.setContourLockImage(isLocked)
                return
            }
        }

        refX = stripList[stripNum][pt].easting
        refZ = stripList[stripNum][pt].northing

        val dx: Double
        val dz: Double
        val distanceFromRefLine: Double

        if (pt < stripList[stripNum].size - 1) {
            dx = stripList[stripNum][pt + 1].easting - refX
            dz = stripList[stripNum][pt + 1].northing - refZ
            distanceFromRefLine = ((dz * pivot.easting) - (dx * pivot.northing) + (stripList[stripNum][pt + 1].easting * refZ) -
                    (stripList[stripNum][pt + 1].northing * refX)) / sqrt((dz * dz) + (dx * dx))
        } else if (pt > 0) {
            dx = refX - stripList[stripNum][pt - 1].easting
            dz = refZ - stripList[stripNum][pt - 1].northing
            distanceFromRefLine = ((dz * pivot.easting) - (dx * pivot.northing) + (refX * stripList[stripNum][pt - 1].northing) -
                    (refZ * stripList[stripNum][pt - 1].easting)) / sqrt((dz * dz) + (dx * dx))
        } else return

        val isSameWay = PI - abs(abs(mf.fixHeading - stripList[stripNum][pt].heading) - PI) < 1.57
        val refDist = (distanceFromRefLine + (if (isSameWay) mf.tool.offset else -mf.tool.offset)) / (mf.tool.width - mf.tool.overlap)

        val howManyPathsAway: Double = when {
            abs(distanceFromRefLine) > mf.tool.halfWidth || abs(mf.tool.offset) > mf.tool.halfWidth -> {
                if (refDist < 0) -1.0 else 1.0
            }
            else -> 0.0
        }

        if (howManyPathsAway in -1.0..1.0) {
            ctList.clear()
            ptCount = stripList[stripNum].size
            if (isSameWay) {
                start = pt - 20
                if (start < 0) start = 0
                stop = pt + 70
                if (stop > ptCount) stop = ptCount
            } else {
                start = pt - 70
                if (start < 0) start = 0
                stop = pt + 20
                if (stop > ptCount) stop = ptCount
            }

            val distAway = (mf.tool.width - mf.tool.overlap) * howManyPathsAway + (if (isSameWay) -mf.tool.offset else mf.tool.offset)
            val distSqAway = (distAway * distAway) * 0.97

            for (i in start until stop) {
                val point = Vec3(
                    stripList[stripNum][i].easting + (cos(stripList[stripNum][i].heading) * distAway),
                    stripList[stripNum][i].northing - (sin(stripList[stripNum][i].heading) * distAway),
                    stripList[stripNum][i].heading
                )
                var isOkToAdd = true
                for (j in start until stop) {
                    val check = glmDistanceSquared(point.northing, point.easting, stripList[stripNum][j].northing, stripList[stripNum][j].easting)
                    if (check < distSqAway) {
                        isOkToAdd = false
                        break
                    }
                }
                if (isOkToAdd) {
                    if (ctList.isNotEmpty()) {
                        val dist = ((point.easting - ctList.last().easting) * (point.easting - ctList.last().easting)) +
                                ((point.northing - ctList.last().northing) * (point.northing - ctList.last().northing))
                        if (dist > 0.2) ctList.add(point)
                    } else ctList.add(point)
                }
            }

            val ptc = ctList.size
            if (ptc < 5) {
                ctList.clear()
                isLocked = false
                mf.setContourLockImage(isLocked)
                return
            }
        } else {
            ctList.clear()
            isLocked = false
            mf.setContourLockImage(isLocked)
            return
        }
    }

    // 方法：計算距離等高線的距離
    fun distanceFromContourLine(pivot: Vec3, steer: Vec3) {
        var minDistA = 1000000.0
        var minDistB = 1000000.0
        val ptCount = ctList.size
        if (ptCount > 8) {
            if (mf.isStanleyUsed) {
                for (t in 0 until ptCount) {
                    val dist = ((steer.easting - ctList[t].easting) * (steer.easting - ctList[t].easting)) +
                            ((steer.northing - ctList[t].northing) * (steer.northing - ctList[t].northing))
                    when {
                        dist < minDistA -> {
                            minDistB = minDistA
                            b = a
                            minDistA = dist
                            a = t
                        }
                        dist < minDistB -> {
                            minDistB = dist
                            b = t
                        }
                    }
                }
                if (a > b) {
                    c = a
                    a = b
                    b = c
                }
                val dx = ctList[b].easting - ctList[a].easting
                val dy = ctList[b].northing - ctList[a].northing
                if (abs(dx) < Double.MIN_VALUE && abs(dy) < Double.MIN_VALUE) return

                distanceFromCurrentLinePivot = ((dy * steer.easting) - (dx * steer.northing) + (ctList[b].easting * ctList[a].northing) -
                        (ctList[b].northing * ctList[a].easting)) / sqrt((dy * dy) + (dx * dx))

                abHeading = atan2(dx, dy)
                if (abHeading < 0) abHeading += 2 * PI
                isHeadingSameWay = PI - abs(abs(pivot.heading - abHeading) - PI) < PI / 2

                val u = (((steer.easting - ctList[a].easting) * dx) + ((steer.northing - ctList[a].northing) * dy)) /
                        ((dx * dx) + (dy * dy))
                rEastCT = ctList[a].easting + (u * dx)
                rNorthCT = ctList[a].northing + (u * dy)

                abFixHeadingDelta = if (isHeadingSameWay) (steer.heading - abHeading) else {
                    distanceFromCurrentLinePivot *= -1.0
                    (steer.heading - abHeading + PI)
                }
                abFixHeadingDelta = when {
                    abFixHeadingDelta > PI -> abFixHeadingDelta - PI
                    abFixHeadingDelta < -PI -> abFixHeadingDelta + PI
                    else -> abFixHeadingDelta
                }
                abFixHeadingDelta = when {
                    abFixHeadingDelta > PI / 2 -> abFixHeadingDelta - PI
                    abFixHeadingDelta < -PI / 2 -> abFixHeadingDelta + PI
                    else -> abFixHeadingDelta
                }
                if (mf.isReverse) abFixHeadingDelta *= -1
                abFixHeadingDelta *= mf.vehicle.stanleyHeadingErrorGain
                if (abFixHeadingDelta > 0.74) abFixHeadingDelta = 0.74
                if (abFixHeadingDelta < -0.74) abFixHeadingDelta = -0.74

                steerAngleCT = atan((distanceFromCurrentLinePivot * mf.vehicle.stanleyDistanceErrorGain) /
                        ((abs(mf.avgSpeed) * 0.277777) + 1))
                if (steerAngleCT > 0.74) steerAngleCT = 0.74
                if (steerAngleCT < -0.74) steerAngleCT = -0.74
                steerAngleCT = toDegrees((steerAngleCT + abFixHeadingDelta) * -1.0)

                if (steerAngleCT < -mf.vehicle.maxSteerAngle) steerAngleCT = -mf.vehicle.maxSteerAngle
                if (steerAngleCT > mf.vehicle.maxSteerAngle) steerAngleCT = mf.vehicle.maxSteerAngle
            } else {
                for (t in 0 until ptCount) {
                    val dist = ((pivot.easting - ctList[t].easting) * (pivot.easting - ctList[t].easting)) +
                            ((pivot.northing - ctList[t].northing) * (pivot.northing - ctList[t].northing))
                    when {
                        dist < minDistA -> {
                            minDistB = minDistA
                            b = a
                            minDistA = dist
                            a = t
                        }
                        dist < minDistB -> {
                            minDistB = dist
                            b = t
                        }
                    }
                }
                if (a > b) {
                    c = a
                    a = b
                    b = c
                }
                if (isLocked && (a < 2 || b > ptCount - 3)) {
                    isLocked = false
                    mf.setContourLockImage(isLocked)
                    lastLockPt = Int.MAX_VALUE
                    return
                }
                val dx = ctList[b].easting - ctList[a].easting
                val dy = ctList[b].northing - ctList[a].northing
                if (abs(dx) < Double.MIN_VALUE && abs(dy) < Double.MIN_VALUE) return

                distanceFromCurrentLinePivot = ((dy * mf.pn.fix.easting) - (dx * mf.pn.fix.northing) + (ctList[b].easting * ctList[a].northing) -
                        (ctList[b].northing * ctList[a].easting)) / sqrt((dy * dy) + (dx * dx))

                if (mf.vehicle.purePursuitIntegralGain != 0.0) {
                    pivotDistanceError = distanceFromCurrentLinePivot * 0.2 + pivotDistanceError * 0.8
                    if (counter2++ > 4) {
                        pivotDerivative = pivotDistanceError - pivotDistanceErrorLast
                        pivotDistanceErrorLast = pivotDistanceError
                        counter2 = 0
                        pivotDerivative *= 2
                    }
                    if (mf.isBtnAutoSteerOn && abs(pivotDerivative) < 0.1 && mf.avgSpeed > 2.5 && !mf.yt.isYouTurnTriggered) {
                        if ((inty < 0 && distanceFromCurrentLinePivot < 0) || (inty > 0 && distanceFromCurrentLinePivot > 0)) {
                            inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.06
                        } else {
                            if (abs(distanceFromCurrentLinePivot) > 0.02) {
                                inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.02
                                if (inty > 0.2) inty = 0.2
                                else if (inty < -0.2) inty = -0.2
                            }
                        }
                    } else inty *= 0.95
                } else inty = 0.0

                if (mf.isReverse) inty = 0.0
                isHeadingSameWay = PI - abs(abs(pivot.heading - ctList[a].heading) - PI) < PI / 2
                if (!isHeadingSameWay) distanceFromCurrentLinePivot *= -1.0

                val u = (((pivot.easting - ctList[a].easting) * dx) + ((pivot.northing - ctList[a].northing) * dy)) /
                        ((dx * dx) + (dy * dy))
                rEastCT = ctList[a].easting + (u * dx)
                rNorthCT = ctList[a].northing + (u * dy)

                val goalPointDistance = mf.vehicle.updateGoalPointDistance()
                val reverseHeading = if (mf.isReverse) !isHeadingSameWay else isHeadingSameWay
                val count = if (reverseHeading) 1 else -1
                val start = Vec3(rEastCT, rNorthCT, 0.0)
                var distSoFar = 0.0

                val range = if (reverseHeading) b until ptCount else a downTo 0
                for (i in range step count) {
                    val tempDist = glmDistance(start, ctList[i])
                    if ((tempDist + distSoFar) > goalPointDistance) {
                        val j = (goalPointDistance - distSoFar) / tempDist
                        goalPointCT.easting = (((1 - j) * start.easting) + (j * ctList[i].easting))
                        goalPointCT.northing = (((1 - j) * start.northing) + (j * ctList[i].northing))
                        break
                    } else {
                        distSoFar += tempDist
                        start.easting = ctList[i].easting
                        start.northing = ctList[i].northing
                        start.heading = ctList[i].heading
                    }
                }

                val goalPointDistanceSquared = glmDistanceSquared(goalPointCT.northing, goalPointCT.easting, pivot.northing, pivot.easting)
                val localHeading = if (isHeadingSameWay) 2 * PI - mf.fixHeading + inty else 2 * PI - mf.fixHeading - inty
                steerAngleCT = toDegrees(
                    atan(
                        2 * (((goalPointCT.easting - pivot.easting) * cos(localHeading)) +
                                ((goalPointCT.northing - pivot.northing) * sin(localHeading))) * mf.vehicle.wheelbase / goalPointDistanceSquared
                    )
                )

                if (mf.ahrs.imuRoll != 88888.0) steerAngleCT += mf.ahrs.imuRoll * -mf.gyd.sideHillCompFactor
                if (steerAngleCT < -mf.vehicle.maxSteerAngle) steerAngleCT = -mf.vehicle.maxSteerAngle
                if (steerAngleCT > mf.vehicle.maxSteerAngle) steerAngleCT = mf.vehicle.maxSteerAngle
            }

            mf.vehicle.modeActualXTE = distanceFromCurrentLinePivot
            mf.guidanceLineDistanceOff = (distanceFromCurrentLinePivot * 1000.0).roundToInt().toShort()
            mf.guidanceLineSteerAngle = (steerAngleCT * 100).toInt().toShort()
        } else {
            distanceFromCurrentLinePivot = 0.0
            mf.guidanceLineDistanceOff = 0
        }
    }

    // 方法：開始等高線
    fun startContourLine() {
        ptList.clear()
        stripList.add(ptList)
        isContourOn = true
    }

    // 方法：添加點
    fun addPoint(pivot: Vec3) {
        ptList.add(
            Vec3(
                pivot.easting + cos(pivot.heading) * mf.tool.offset,
                pivot.northing - sin(pivot.heading) * mf.tool.offset,
                pivot.heading
            )
        )
    }

    // 方法：停止等高線
    fun stopContourLine() {
        if (ptList.size > 5) {
            mf.contourSaveList.add(ptList)
        } else {
            mf.contourSaveList.remove(ptList)
        }
        isContourOn = false
    }

    // 方法：構建邊界等高線
    fun buildFenceContours(spacingInt: Double) {
        val adjustedSpacing = spacingInt * 0.01
        if (mf.bnd.bndList.isEmpty()) {
            mf.timedMessageBox(1500, "Boundary Contour Error", "No Boundaries Made")
            return
        }
        if (mf.patchCounter != 0) {
            mf.timedMessageBox(1500, "Section Control On", "Turn Off Section Control")
            return
        }
        val totalHeadWidth = ((mf.tool.width - mf.tool.overlap) * 0.5) - adjustedSpacing
        val signPass = -1

        for (j in mf.bnd.bndList.indices) {
            val ptCount = mf.bnd.bndList[j].fenceLine.size
            ptList.clear()
            stripList.add(ptList)
            for (i in ptCount - 1 downTo 0) {
                val point = Vec3(
                    mf.bnd.bndList[j].fenceLine[i].easting - (signPass * sin(PI / 2 + mf.bnd.bndList[j].fenceLine[i].heading) * totalHeadWidth),
                    mf.bnd.bndList[j].fenceLine[i].northing - (signPass * cos(PI / 2 + mf.bnd.bndList[j].fenceLine[i].heading) * totalHeadWidth),
                    mf.bnd.bndList[j].fenceLine[i].heading - PI
                )
                if (point.heading < -2 * PI) point.heading += 2 * PI
                ptList.add(point)
            }
        }
        mf.timedMessageBox(1500, "Boundary Contour", "Contour Path Created")
    }

    // 方法：繪製等高線（已修正）
    fun drawContourLine() {
        val ptCount = ctList.size
        if (ptCount < 2) return

        // 繪製線條
        glLineWidth(mf.abLine.lineWidth.toFloat())
        glUniform4f(glGetUniformLocation(mf.glProgram, "color"), 0.98f, 0.2f, 0.980f, 1.0f)
        val lineVertices = FloatBuffer.allocate(ptCount * 3)
        for (h in 0 until ptCount) {
            lineVertices.put(h * 3, ctList[h].easting.toFloat())
            lineVertices.put(h * 3 + 1, ctList[h].northing.toFloat())
            lineVertices.put(h * 3 + 2, 0f)
        }
        lineVertices.position(0)
        glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, lineVertices)
        glEnableVertexAttribArray(0)
        glDrawArrays(GL_LINE_STRIP, 0, ptCount)
        glDisableVertexAttribArray(0)

        // 繪製點
        glPointSize(mf.abLine.lineWidth.toFloat())
        glUniform4f(glGetUniformLocation(mf.glProgram, "color"), 0.87f, 0.87f, 0.25f, 1.0f)
        val pointVertices = FloatBuffer.allocate(ptCount * 3)
        for (h in 0 until ptCount) {
            pointVertices.put(h * 3, ctList[h].easting.toFloat())
            pointVertices.put(h * 3 + 1, ctList[h].northing.toFloat())
            pointVertices.put(h * 3 + 2, 0f)
        }
        pointVertices.position(0)
        glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, pointVertices)
        glEnableVertexAttribArray(0)
        glDrawArrays(GL_POINTS, 0, ptCount)
        glDisableVertexAttribArray(0)

        // 繪製 stripList[stripNum] 的點
        if (isLocked) {
            glUniform4f(glGetUniformLocation(mf.glProgram, "color"), 0.983f, 0.92f, 0.420f, 1.0f)
            glLineWidth(4f)
        } else {
            glUniform4f(glGetUniformLocation(mf.glProgram, "color"), 0.3f, 0.982f, 0.0f, 1.0f)
            glLineWidth(mf.abLine.lineWidth.toFloat())
        }
        if (stripNum > -1) {
            val stripPtCount = stripList[stripNum].size
            val stripVertices = FloatBuffer.allocate(stripPtCount * 3)
            for (h in 0 until stripPtCount) {
                stripVertices.put(h * 3, stripList[stripNum][h].easting.toFloat())
                stripVertices.put(h * 3 + 1, stripList[stripNum][h].northing.toFloat())
                stripVertices.put(h * 3 + 2, 0f)
            }
            stripVertices.position(0)
            glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, stripVertices)
            glEnableVertexAttribArray(0)
            glDrawArrays(GL_POINTS, 0, stripPtCount)
            glDisableVertexAttribArray(0)
        }

        // 繪製特定點
        glUniform4f(glGetUniformLocation(mf.glProgram, "color"), 0.35f, 0.30f, 0.90f, 1.0f)
        glPointSize(6.0f)
        val specificPoint = stripList[stripNum][pt]
        val specificVertices = floatArrayOf(
            specificPoint.easting.toFloat(),
            specificPoint.northing.toFloat(),
            0f
        )
        val specificBuffer = FloatBuffer.wrap(specificVertices)
        glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, specificBuffer)
        glEnableVertexAttribArray(0)
        glDrawArrays(GL_POINTS, 0, 1)
        glDisableVertexAttribArray(0)

        // 繪製目標點
        if (mf.isPureDisplayOn && distanceFromCurrentLinePivot != 32000.0 && !mf.isStanleyUsed) {
            glPointSize(6.0f)
            glUniform4f(glGetUniformLocation(mf.glProgram, "color"), 1.0f, 0.95f, 0.095f, 1.0f)
            val goalVertices = floatArrayOf(
                goalPointCT.easting.toFloat(),
                goalPointCT.northing.toFloat(),
                0f
            )
            val goalBuffer = FloatBuffer.wrap(goalVertices)
            glVertexAttribPointer(0, 3, GL_FLOAT, false, 0, goalBuffer)
            glEnableVertexAttribArray(0)
            glDrawArrays(GL_POINTS, 0, 1)
            glDisableVertexAttribArray(0)
            glPointSize(1.0f)
        }
    }

    // 方法：重置等高線
    fun resetContour() {
        stripList.clear()
        ptList.clear()
        ctList.clear()
    }
}

// 工具函數
fun glmDistance(v1: Vec3, v2: Vec3): Double {
    return sqrt((v1.easting - v2.easting) * (v1.easting - v2.easting) + (v1.northing - v2.northing) * (v1.northing - v2.northing))
}

fun glmDistanceSquared(n1: Double, e1: Double, n2: Double, e2: Double): Double {
    return (e1 - e2) * (e1 - e2) + (n1 - n2) * (n1 - n2)
}

fun toDegrees(radians: Double): Double = radians * 180 / PI