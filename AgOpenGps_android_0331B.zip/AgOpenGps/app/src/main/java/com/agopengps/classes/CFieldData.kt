package com.agopengps.classes

import com.agopengps.drive.MainActivity
import java.text.DecimalFormat
import java.util.*
import kotlin.math.round

class CFieldData(private val mf: MainActivity) {
    //all the section area added up
    var workedAreaTotal: Double = 0.0

    //just a cumulative tally based on distance and eq width
    var workedAreaTotalUser: Double = 0.0

    //accumulated user distance
    var distanceUser: Double = 0.0

    var barPercent: Double = 0.0
    var overlapPercent: Double = 0.0

    //Outside area minus inner boundaries areas (m)
    var areaBoundaryOuterLessInner: Double = 0.0

    //used for overlap calcs - total done minus overlap
    var actualAreaCovered: Double = 0.0

    //Inner area of outer boundary(m)
    var areaOuterBoundary: Double = 0.0

    //not really used - but if needed
    var userSquareMetersAlarm: Double = 0.0

    //Area inside Boundary less inside boundary areas
    val areaBoundaryLessInnersHectares: String
        get() = DecimalFormat("N2").format(areaBoundaryOuterLessInner * glm.m2ha)

    val areaBoundaryLessInnersAcres: String
        get() = DecimalFormat("N2").format(areaBoundaryOuterLessInner * glm.m2ac)

    //User tally string
    val workedUserHectares: String
        get() = DecimalFormat("N2").format(workedAreaTotalUser * glm.m2ha)

    //user tally string
    val workedUserAcres: String
        get() = DecimalFormat("N2").format(workedAreaTotalUser * glm.m2ac)

    //String of Area worked
    val workedAcres: String
        get() = DecimalFormat("N2").format(workedAreaTotal * 0.000247105)

    val workedHectares: String
        get() = DecimalFormat("N2").format(workedAreaTotal * 0.0001)

    // User Distance strings
    val distanceUserMeters: String
        get() = (round(distanceUser * 10) / 10.0).toString()

    val distanceUserFeet: String
        get() = (round(distanceUser * glm.m2ft * 10) / 10.0).toString()

    //remaining area to be worked
    val workedAreaRemainHectares: String
        get() = DecimalFormat("N2").format((areaBoundaryOuterLessInner - workedAreaTotal) * glm.m2ha)

    val workedAreaRemainAcres: String
        get() = DecimalFormat("N2").format((areaBoundaryOuterLessInner - workedAreaTotal) * glm.m2ac)

    val workedAreaRemainPercentage: String
        get() {
            return if (areaBoundaryOuterLessInner > 10) {
                barPercent = (areaBoundaryOuterLessInner - workedAreaTotal) * 100 / areaBoundaryOuterLessInner
                DecimalFormat("N1").format(barPercent) + "%"
            } else {
                barPercent = 0.0
                "0%"
            }
        }

    //overlap strings
    val actualAreaWorkedHectares: String
        get() = DecimalFormat("N2").format(actualAreaCovered * glm.m2ha)

    val actualAreaWorkedAcres: String
        get() = DecimalFormat("N2").format(actualAreaCovered * glm.m2ac)

    val actualRemainHectares: String
        get() = DecimalFormat("N2").format((areaBoundaryOuterLessInner - actualAreaCovered) * glm.m2ha)

    val actualRemainAcres: String
        get() = DecimalFormat("N2").format((areaBoundaryOuterLessInner - actualAreaCovered) * glm.m2ac)

    val actualOverlapPercent: String
        get() = DecimalFormat("N1").format(overlapPercent) + "% "

    val timeTillFinished: String
        get() {
            return if (mf.avgSpeed > 2) {
                val hours = (areaBoundaryOuterLessInner - workedAreaTotal) * glm.m2ha /
                        (mf.tool.width * mf.avgSpeed * 0.1)
                val timeSpan = (hours * 3600).toLong()
                val hoursPart = timeSpan / 3600
                val minutesPart = (timeSpan % 3600) / 60
                String.format(Locale.getDefault(), "%02d:%02d\"", hoursPart, minutesPart)
            } else {
                "∞ Hrs"
            }
        }

    val workRateHectares: String
        get() = DecimalFormat("N1").format(mf.tool.width * mf.avgSpeed * 0.1) + " ha/hr"

    val workRateAcres: String
        get() = DecimalFormat("N1").format(mf.tool.width * mf.avgSpeed * 0.2471) + " ac/hr"

    init {
        workedAreaTotal = 0.0
        workedAreaTotalUser = 0.0
        userSquareMetersAlarm = 0.0
    }

    fun updateFieldBoundaryGUIAreas() {
        if (mf.bnd.bndList.isNotEmpty()) {
            areaOuterBoundary = mf.bnd.bndList[0].area
            areaBoundaryOuterLessInner = areaOuterBoundary

            for (i in 1 until mf.bnd.bndList.size) {
                areaBoundaryOuterLessInner -= mf.bnd.bndList[i].area
            }
        } else {
            areaOuterBoundary = 0.0
            areaBoundaryOuterLessInner = 0.0
        }
    }

    fun getDescription(): String {
        return buildString {
            appendLine("Field: ${mf.displayFieldName}")
            appendLine("Total Hectares: $areaBoundaryLessInnersHectares")
            appendLine("Worked Hectares: $workedHectares")
            appendLine("Missing Hectares: $workedAreaRemainHectares")
            appendLine("Total Acres: $areaBoundaryLessInnersAcres")
            appendLine("Worked Acres: $workedAcres")
            appendLine("Missing Acres: $workedAreaRemainAcres")
            appendLine("Tool Width: ${mf.tool.width}")
            appendLine("Sections: ${mf.tool.numOfSections}")
            appendLine("Section Overlap: ${mf.tool.overlap}")
        }
    }
}