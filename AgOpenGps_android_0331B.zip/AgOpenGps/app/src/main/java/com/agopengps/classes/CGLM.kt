package com.agopengps.classes

import android.graphics.Bitmap
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import java.lang.Math.pow
import kotlin.math.*
import kotlin.math.pow

object glm {

    const val fileRegex = "^(?!.{256,})(?!(aux|clock\\$|con|nul|prn|com[1-9]|lpt[1-9])(?:$|\\.)[^ ][ \\.\\w-$()+=[\\];#@~,&']+[^\\. ]$/i"

    const val in2m = 0.0254
    const val m2in = 39.3701
    const val m2ft = 3.28084
    const val ft2m = 0.3048
    const val ha2ac = 2.47105
    const val ac2ha = 0.404686
    const val m2ac = 0.000247105
    const val m2ha = 0.0001
    const val galAc2Lha = 9.35396
    const val lHa2galAc = 0.106907
    const val l2Gal = 0.264172
    const val gal2L = 3.785412534258
    const val twoPI = 6.28318530717958647692
    const val piBy2 = 1.57079632679489661923

    // UTM 到經緯度轉換
 //   data class LatLon(val latitude: Double, val longitude: Double)

    // WGS84 橢球參數
    private const val a = 6378137.0 // 長半軸 (meters)
    private const val f = 1 / 298.257223563 // 扁率
    private const val b = a * (1 - f) // 短半軸
    //private const val e = sqrt(2 * f - f * f) // 第一偏心率
    private val e = sqrt(2 * f - f * f) // 第一偏心率，運行時計算
    private const val k0 = 0.9996 // UTM 比例因子
    private const val falseEasting = 500000.0 // UTM 假東距
    private const val falseNorthing = 10000000.0 // 南半球假北距

    fun vec2.getClosestSegmentLooping(
        curList: List<vec3>,
        start: Int = 0,
        end: Int = Int.MAX_VALUE
    ): Triple<Int, Int, Double> {
        val isLoop = true
        var aa = -1
        var bb = -1
        var minDistA = Double.MAX_VALUE
        var a = if (start > 0) start - 1 else curList.size - 1
        val looping = isLoop && start > end

        var b = if (start > 0) start else 0
        while (b < end || looping) {
            if (b == curList.size) {
                if (looping) {
                    b = -1
                    continue
                } else break
            }
            if (b == 0 && !isLoop) {
                b++
                continue
            } else if (b == 0) a = curList.size - 1

            val dist2 = distanceSquared(curList[a], curList[b])
            if (dist2 < minDistA) {
                minDistA = dist2
                aa = a
                bb = b
            }
            a = b++
        }
        return Triple(aa, bb, minDistA)
    }

    fun inRangeBetweenAB(
        startX: Double, startY: Double, endX: Double, endY: Double,
        pointX: Double, pointY: Double
    ): Boolean {
        val dx = endX - startX
        val dy = endY - startY
        val innerProduct = (pointX - startX) * dx + (pointY - startY) * dy
        return innerProduct in 0.0..(dx * dx + dy * dy)
    }

    fun List<vec3>.isPointInPolygon(testPoint: vec3): Boolean {
        var result = false
        var j = size - 1
        for (i in indices) {
            if ((this[i].easting < testPoint.easting && this[j].easting >= testPoint.easting) ||
                (this[j].easting < testPoint.easting && this[i].easting >= testPoint.easting)
            ) {
                if (this[i].northing + (testPoint.easting - this[i].easting) /
                    (this[j].easting - this[i].easting) * (this[j].northing - this[i].northing) < testPoint.northing
                ) {
                    result = !result
                }
            }
            j = i
        }
        return result
    }

    fun List<vec3>.isPointInPolygon(testPoint: vec2): Boolean {
        var result = false
        var j = size - 1
        for (i in indices) {
            if ((this[i].easting < testPoint.easting && this[j].easting >= testPoint.easting) ||
                (this[j].easting < testPoint.easting && this[i].easting >= testPoint.easting)
            ) {
                if (this[i].northing + (testPoint.easting - this[i].easting) /
                    (this[j].easting - this[i].easting) * (this[j].northing - this[i].northing) < testPoint.northing
                ) {
                    result = !result
                }
            }
            j = i
        }
        return result
    }

    fun List<vec2>.isPointInPolygon(testPoint: vec2): Boolean {
        var result = false
        var j = size - 1
        for (i in indices) {
            if ((this[i].easting < testPoint.easting && this[j].easting >= testPoint.easting) ||
                (this[j].easting < testPoint.easting && this[i].easting >= testPoint.easting)
            ) {
                if (this[i].northing + (testPoint.easting - this[i].easting) /
                    (this[j].easting - this[i].easting) * (this[j].northing - this[i].northing) < testPoint.northing
                ) {
                    result = !result
                }
            }
            j = i
        }
        return result
    }

    fun List<vec2>.isPointInPolygon(testPoint: vec3): Boolean {
        var result = false
        var j = size - 1
        for (i in indices) {
            if ((this[i].easting < testPoint.easting && this[j].easting >= testPoint.easting) ||
                (this[j].easting < testPoint.easting && this[i].easting >= testPoint.easting)
            ) {
                if (this[i].northing + (testPoint.easting - this[i].easting) /
                    (this[j].easting - this[i].easting) * (this[j].northing - this[i].northing) < testPoint.northing
                ) {
                    result = !result
                }
            }
            j = i
        }
        return result
    }

    // Modified to use Google Maps Polyline instead of OpenGL
    fun List<vec3>.drawPolygon(googleMap: GoogleMap) {
        if (size > 2) {
            val polylineOptions = PolylineOptions()
                .addAll(map { LatLng(it.northing, it.easting) }) // Note: LatLng uses (lat, lon), so northing -> lat, easting -> lon
                .color(android.graphics.Color.BLUE) // Default color, can be customized
                .width(4f) // Line width in pixels
            googleMap.addPolyline(polylineOptions)
        }
    }

    // Modified to use Google Maps Polyline instead of OpenGL
    fun List<vec2>.drawPolygon(googleMap: GoogleMap) {
        if (size > 2) {
            val polylineOptions = PolylineOptions()
                .addAll(map { LatLng(it.northing, it.easting) })
                .color(android.graphics.Color.BLUE)
                .width(4f)
            googleMap.addPolyline(polylineOptions)
        }
    }

    fun catmull(t: Double, p0: vec3, p1: vec3, p2: vec3, p3: vec3): vec3 {
        val tt = t * t
        val ttt = tt * t

        val q1 = -ttt + 2.0 * tt - t
        val q2 = 3.0 * ttt - 5.0 * tt + 2.0
        val q3 = -3.0 * ttt + 4.0 * tt + t
        val q4 = ttt - tt

        val tx = 0.5 * (p0.easting * q1 + p1.easting * q2 + p2.easting * q3 + p3.easting * q4)
        val ty = 0.5 * (p0.northing * q1 + p1.northing * q2 + p2.northing * q3 + p3.northing * q4)

        return vec3(tx, ty, 0.0)
    }

    fun catmullGradient(t: Double, p0: vec3, p1: vec3, p2: vec3, p3: vec3): Double {
        val tt = t * t

        val q1 = -3.0 * tt + 4.0 * t - 1
        val q2 = 9.0 * tt - 10.0 * t
        val q3 = -9.0 * tt + 8.0 * t + 1.0
        val q4 = 3.0 * tt - 2.0 * t

        val tx = 0.5 * (p0.easting * q1 + p1.easting * q2 + p2.easting * q3 + p3.easting * q4)
        val ty = 0.5 * (p0.northing * q1 + p1.northing * q2 + p2.northing * q3 + p3.northing * q4)

        return atan2(tx, ty)
    }


    fun toDegrees(radians: Double): Double = radians * 57.295779513082325225835265587528

    fun toRadians(degrees: Double): Double = degrees * 0.01745329251994329576923690768489

    fun distance(east1: Double, north1: Double, east2: Double, north2: Double): Double =
        sqrt((east1 - east2).pow(2) + (north1 - north2).pow(2))

    fun distance(first: vec2, second: vec2): Double =
        sqrt((first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2))

    fun distance(first: vec2, second: vec3): Double =
        sqrt((first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2))

    fun distance(first: vec3, second: vec2): Double =
        sqrt((first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2))

    fun distance(first: vec3, second: vec3): Double =
        sqrt((first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2))

    fun distance(first: vec2, east: Double, north: Double): Double =
        sqrt((first.easting - east).pow(2) + (first.northing - north).pow(2))

    fun distance(first: vec3, east: Double, north: Double): Double =
        sqrt((first.easting - east).pow(2) + (first.northing - north).pow(2))

    fun distance(first: vecFix2Fix, second: vec2): Double =
        sqrt((first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2))

    fun distance(first: vecFix2Fix, second: vecFix2Fix): Double =
        sqrt((first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2))

    fun distanceSquared(northing1: Double, easting1: Double, northing2: Double, easting2: Double): Double =
        (easting1 - easting2).pow(2) + (northing1 - northing2).pow(2)

    fun distanceSquared(first: vec3, second: vec2): Double =
        (first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2)

    fun distanceSquared(first: vec2, second: vec3): Double =
        (first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2)

    fun distanceSquared(first: vec3, second: vec3): Double =
        (first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2)

    fun distanceSquared(first: vec2, second: vec2): Double =
        (first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2)

    fun distanceSquared(first: vecFix2Fix, second: vec2): Double =
        (first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2)

    fun makeGrayscale3(original: Bitmap): Bitmap {
        val newBitmap = Bitmap.createBitmap(original.width, original.height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(newBitmap)
        val paint = Paint()
        val colorMatrix = ColorMatrix(
            floatArrayOf(
                0.3f, 0.3f, 0.3f, 0f, 0f,
                0.59f, 0.59f, 0.59f, 0f, 0f,
                0.11f, 0.11f, 0.11f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
                0f, 0f, 0f, 0f, 1f
            )
        )
        paint.colorFilter = ColorMatrixColorFilter(colorMatrix)
        canvas.drawBitmap(original, 0f, 0f, paint)
        return newBitmap
    }

    data class LatLon(val latitude: Double, val longitude: Double)

    fun UTM2LatLon(easting: Double, northing: Double, zone: Int, isNorthernHemisphere: Boolean = true): LatLon {
        // 調整 Northing（南半球需減去假北距）
        val n = if (isNorthernHemisphere) northing else northing + falseNorthing

        // 計算中央經線
        val centralMeridian = toRadians(-183.0 + (zone * 6.0)) // 每個 Zone 6 度，從 -180 開始

        // 調整 Easting，去除假東距並計算 x
        val x = easting - falseEasting
        val y = n

        // 計算足點緯度 (Footprint Latitude)
        val m = y / k0
        val mu = m / (a * (1.0 - e * e / 4.0 - 3.0 * e * e * e * e / 64.0 - 5.0 * e * e * e * e * e * e / 256.0))

        val e1 = (1.0 - sqrt(1.0 - e * e)) / (1.0 + sqrt(1.0 - e * e))
        val phi1 = mu + (3.0 * e1 / 2.0 - 27.0 * e1 * e1 * e1 / 32.0) * sin(2.0 * mu) +
                (21.0 * e1 * e1 / 16.0 - 55.0 * e1 * e1 * e1 * e1 / 32.0) * sin(4.0 * mu) +
                (151.0 * e1 * e1 * e1 / 96.0) * sin(6.0 * mu)

        // 計算中間變量
        val c1 = cos(phi1)
        val t1 = tan(phi1)
        val n1 = a / sqrt(1.0 - e * e * sin(phi1) * sin(phi1))
        val r1 = a * (1.0 - e * e) / pow(1.0 - e * e * sin(phi1) * sin(phi1), 1.5)
        val d = x / (n1 * k0)

        // 計算緯度 (Latitude)
        val latitudeRad = phi1 - (n1 * t1 / r1) * (d * d / 2.0 -
                (5.0 + 3.0 * t1 * t1 + 10.0 * c1 * c1 - 4.0 * c1 * c1 * c1 * c1 - 9.0 * e * e) * d * d * d * d / 24.0 +
                (61.0 + 90.0 * t1 * t1 + 298.0 * c1 * c1 + 45.0 * t1 * t1 * t1 * t1 - 252.0 * e * e - 3.0 * c1 * c1 * c1 * c1) * d * d * d * d * d * d / 720.0)

        // 計算經度 (Longitude)
        val longitudeRad = centralMeridian + (d -
                (1.0 + 2.0 * t1 * t1 + c1 * c1) * d * d * d / 6.0 +
                (5.0 - 2.0 * c1 * c1 + 28.0 * t1 * t1 - 3.0 * c1 * c1 * c1 * c1 + 8.0 * e * e + 24.0 * t1 * t1 * t1 * t1) * d * d * d * d * d / 120.0) / c1

        // 轉換為度數
        val latitude = toDegrees(latitudeRad)
        val longitude = toDegrees(longitudeRad)

        return LatLon(latitude, longitude)
    }


}