package com.agopengps.classes // 假設的包名，您可以根據實際情況調整

// Machine Data
class CPGN_EF {
    /// <summary>
    /// PGN - 239 - EF
    /// uturn=5  tree=6  hydLift = 8
    /// </summary>
    // 在 Kotlin 中，byte 陣列需要使用 UByteArray 或 ByteArray，因為 Kotlin 的 Byte 是帶符號的
    var pgn: ByteArray = byteArrayOf(
        0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xEF.toByte(),
        8.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
        0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(),
        0.toByte(), 0xCC.toByte()
    )

    var uturn: Int = 5
    var speed: Int = 6
    var hydLift: Int = 7
    var tram: Int = 8
    var geoStop: Int = 9 // out of bounds etc
    // var  = 10; // C# 中這一行是註解掉的，未定義變數名，Kotlin 中也保持註解狀態
    var sc1to8: Int = 11
    var sc9to16: Int = 12

    // 构造函数，Kotlin 中主构造函数通常在類名後定義，這裡使用次构造函数
    constructor() {
        // 空的构造函数
    }
    fun Reset() {
        pgn = byteArrayOf(0x80.toByte(), 0x81.toByte(), 0x7F.toByte(), 0xEF.toByte(), 8.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0.toByte(), 0xCC.toByte())
        uturn = 5
        speed = 6
        hydLift = 7
        tram = 8
        geoStop = 9
        sc1to8 = 11
        sc9to16 = 12
    }
}