package com.agopengps.classes


import android.provider.ContactsContract
import android.util.Log
import java.nio.file.Path

class CFeatureSettings {
    var isHeadlandOn: Boolean = true
    var isTramOn: Boolean = false
    var isBoundaryOn: Boolean = true
    var isBndContourOn: Boolean = false
    var isRecPathOn: Boolean = false
    var isABSmoothOn: Boolean = false
    var isHideContourOn: Boolean = false
    var isWebCamOn: Boolean = false
    var isOffsetFixOn: Boolean = false
    var isAgIOOn: Boolean = true
    var isContourOn: Boolean = true
    var isYouTurnOn: Boolean = true
    var isSteerModeOn: Boolean = true
    var isManualSectionOn: Boolean = true
    var isAutoSectionOn: Boolean = true
    var isCycleLinesOn: Boolean = true
    var isABLineOn: Boolean = true
    var isCurveOn: Boolean = true
    var isAutoSteerOn: Boolean = true
    var isUTurnOn: Boolean = true
    var isLateralOn: Boolean = true

    constructor()

    constructor(feature: CFeatureSettings) {
        isHeadlandOn = feature.isHeadlandOn
        isTramOn = feature.isTramOn
        isBoundaryOn = feature.isBoundaryOn
        isBndContourOn = feature.isBndContourOn
        isRecPathOn = feature.isRecPathOn
        isABSmoothOn = feature.isABSmoothOn
        isHideContourOn = feature.isHideContourOn
        isWebCamOn = feature.isWebCamOn
        isOffsetFixOn = feature.isOffsetFixOn
        isAgIOOn = feature.isAgIOOn
        isContourOn = feature.isContourOn
        isYouTurnOn = feature.isYouTurnOn
        isSteerModeOn = feature.isSteerModeOn
        isManualSectionOn = feature.isManualSectionOn
        isAutoSectionOn = feature.isAutoSectionOn
        isCycleLinesOn = feature.isCycleLinesOn
        isABLineOn = feature.isABLineOn
        isCurveOn = feature.isCurveOn
        isAutoSteerOn = feature.isAutoSteerOn
        isLateralOn = feature.isLateralOn
        isUTurnOn = feature.isUTurnOn
    }
}

object SettingsIO {
    fun importSingle(settingFile: String, settingsFilePath: String) {
        if (!File.Exists(settingsFilePath)) {
            throw FileNotFoundException()
        }

        try {
            val config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal)
            var sectionName = ""

            if (settingFile == "Settings") {
                sectionName = Properties.Settings.Default.Context["GroupName"].toString()
            }

            val document = XDocument.Load(Path.Combine(settingsFilePath))
            val settingsSection = document.XPathSelectElements("//$sectionName").Single().toString()
            config.GetSectionGroup("userSettings").Sections[sectionName].SectionInformation.SetRawXml(settingsSection)
            config.Save(ConfigurationSaveMode.Modified)

            if (settingFile == "Settings") {
                Properties.Settings.Default.Reload()
            }
        } catch {
            if (settingFile == "Settings") {
                Properties.Settings.Default.Reload()
            }
        }
    }

    fun exportSingle(settingsFilePath: String) {
        Properties.Settings.Default.Save()
        val config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal)
        config.SaveAs(settingsFilePath)
    }

    fun exportAll(settingsFilePath: String) {
        Properties.Settings.Default.Save()
        val config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal)
        config.SaveAs(settingsFilePath)
    }

    fun importAll(settingsFilePath: String): Boolean {
        if (!File.Exists(settingsFilePath)) {
            return false
        }

        try {
            StreamReader(settingsFilePath).use { xmlFile ->
                StreamWriter("Output999.xml").use { output ->
                    var line: String?
                    var step = 0

                    line = xmlFile.ReadLine()
                    output.WriteLine(line)
                    line = xmlFile.ReadLine()
                    output.WriteLine(line)
                    line = xmlFile.ReadLine()
                    output.WriteLine(line)
                    line = xmlFile.ReadLine()
                    if (line == null) {
                        MessageBox.Show("Fatal Error with Settings File")
                        return false
                    }

                    if (line.contains("ies.Vehicle")) {
                        output.WriteLine("        <AgOpenGPS.Properties.Settings>")

                        while (!xmlFile.EndOfStream) {
                            line = xmlFile.ReadLine()

                            if (step < 2) {
                                if (line.contains("ies.Vehicle") || line.contains("ies.Settings")) {
                                    step++
                                } else {
                                    output.WriteLine(line)
                                }
                            } else {
                                output.WriteLine(line)
                            }
                        }
                        settingsFilePath = "Output999.xml"
                    }
                }
            }
        } catch {
            MessageBox.Show("Fatal Error with Settings File")
            return false
        }

        try {
            var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal)
            var sectionName = Properties.Settings.Default.Context["GroupName"].toString()

            val document = XDocument.Load(Path.Combine(settingsFilePath))
            var settingsA = document.XPathSelectElements("//$sectionName").Single().toString()

            config.GetSectionGroup("userSettings").Sections[sectionName].SectionInformation.SetRawXml(settingsA)
            config.Save(ConfigurationSaveMode.Modified)
            Properties.Settings.Default.Reload()

            config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal)
            sectionName = Properties.Settings.Default.Context["GroupName"].toString()

            document = XDocument.Load(Path.Combine(settingsFilePath))
            settingsA = document.XPathSelectElements("//$sectionName").Single().toString()

            config.GetSectionGroup("userSettings").Sections[sectionName].SectionInformation.SetRawXml(settingsA)
            config.Save(ConfigurationSaveMode.Modified)

            Properties.Settings.Default.Reload()
            return true
        } catch {
            Properties.Settings.Default.Reload()
            MessageBox.Show("Fatal Error with Settings File")
            return false
        }
    }
}

object RegistrySettings {
    var culture: String = "en"
    var vehiclesDirectory: String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "AgOpenGPS", "Vehicles")
    var logsDirectory: String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "AgOpenGPS", "Logs")
    var vehicleFileName: String = "Default Vehicle"
    var workingDirectory: String = "Default"
    var baseDirectory: String = workingDirectory
    var fieldsDirectory: String = workingDirectory

    fun load() {
        try {
            var regKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\AgOpenGPS")

            if (regKey == null) {
                val key = Registry.CurrentUser.CreateSubKey("SOFTWARE\\AgOpenGPS")
                key.SetValue("Language", "en")
                key.SetValue("VehicleFileName", "Default Vehicle")
                key.SetValue("WorkingDirectory", "Default")
                key.SetValue("ProfileName", "Default Profile")
                key.Close()
            }

            regKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\AgOpenGPS")

            if (regKey.GetValue("WorkingDirectory") == null || regKey.GetValue("WorkingDirectory").toString() == "") {
                val key = Registry.CurrentUser.CreateSubKey("SOFTWARE\\AgOpenGPS")
                key.SetValue("WorkingDirectory", "Default")
                key.Close()
            }
            workingDirectory = regKey.GetValue("WorkingDirectory").toString()

            baseDirectory = if (workingDirectory == "Default") {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "AgOpenGPS")
            } else {
                Path.Combine(workingDirectory, "AgOpenGPS")
            }

            if (regKey.GetValue("VehicleFileName") == null || regKey.GetValue("VehicleFileName").toString() == "") {
                val key = Registry.CurrentUser.CreateSubKey("SOFTWARE\\AgOpenGPS")
                key.SetValue("VehicleFileName", "Default Vehicle")
                key.Close()
            }

            vehicleFileName = regKey.GetValue("VehicleFileName").toString()

            if (regKey.GetValue("Language") == null || regKey.GetValue("Language").toString() == "") {
                val key = Registry.CurrentUser.CreateSubKey("SOFTWARE\\AgOpenGPS")
                key.SetValue("Language", "en")
                key.Close()
            }

            culture = regKey.GetValue("Language").toString()
            regKey.Close()
        } catch (ex: Exception) {
            Log.EventWriter("Registry -> Catch, Serious Problem Creating Registry keys: $ex")
            reset()
        }

        createDirectories()
        Log.checkLogSize(Path.Combine(logsDirectory, "AgOpenGPS_Events_Log.txt"), 1000000)

        try {
            val dinfo = DirectoryInfo(vehiclesDirectory)
            val vehicleFiles = dinfo.GetFiles("*.xml")

            var isVehicleExist = false

            for (file in vehicleFiles) {
                val temp = Path.GetFileNameWithoutExtension(file.Name).trim()

                if (temp == vehicleFileName) {
                    isVehicleExist = true
                }
            }

            if (isVehicleExist && vehicleFileName != "Default Vehicle") {
                SettingsIO.importAll(Path.Combine(vehiclesDirectory, "$vehicleFileName.XML"))
            } else {
                vehicleFileName = "Default Vehicle"
                Log.EventWriter("Vehicle file does not exist or is Default, Default Vehicle selected")
            }
        } catch (ex: Exception) {
            Log.EventWriter("Registry -> Catch, Serious Problem Loading Vehicle, Doing Registry Reset: $ex")
            reset()
            Settings.Default.Reset()
            Settings.Default.Save()
        }
    }

    fun save() {
        Properties.Settings.Default.Save()

        val key = Registry.CurrentUser.CreateSubKey("SOFTWARE\\AgOpenGPS")
        try {
            key.SetValue("VehicleFileName", vehicleFileName)
            key.SetValue("Language", culture)
            key.SetValue("WorkingDirectory", workingDirectory)
        } catch (ex: Exception) {
            Log.EventWriter("Registry -> Catch, Serious Problem Saving keys: $ex")
        }
        key.Close()

        try {
            if (vehicleFileName != "Default Vehicle") {
                Thread.Sleep(500)
                SettingsIO.exportAll(Path.Combine(vehiclesDirectory, "$vehicleFileName.xml"))
            } else {
                Log.EventWriter("Default Vehicle Not saved to Vehicles")
            }
        } catch (ex: Exception) {
            Log.EventWriter("Registry -> Catch, Unable to save Vehicle FileName: $ex")
        }
    }

    fun reset() {
        try {
            Registry.CurrentUser.DeleteSubKeyTree("SOFTWARE\\AgOpenGPS")

            val key = Registry.CurrentUser.CreateSubKey("SOFTWARE\\AgOpenGPS")
            key.SetValue("Language", "en")
            key.SetValue("VehicleFileName", "Default Vehicle")
            key.SetValue("WorkingDirectory", "Default")
            key.Close()

            Log.EventWriter("Registry -> Resetting Registry SubKey Tree and Full Default Reset")

            culture = "en"
            vehiclesDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "AgOpenGPS", "Vehicles")
            logsDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "AgOpenGPS", "Logs")
            vehicleFileName = "Default Vehicle"
            workingDirectory = "Default"
            baseDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "AgOpenGPS")
            fieldsDirectory = Path.Combine(baseDirectory, "Fields")

            createDirectories()
        } catch (ex: Exception) {
            Log.EventWriter("\"Registry -> Catch, Serious Problem Resetting Registry keys: $ex")
        }
    }

    fun createDirectories() {
        try {
            vehiclesDirectory = Path.Combine(baseDirectory, "Vehicles")
            if (!vehiclesDirectory.isNullOrEmpty() && !ContactsContract.Directory.Exists(vehiclesDirectory)) {
                Directory.CreateDirectory(vehiclesDirectory)
                Log.EventWriter("Vehicles Dir Created")
            }
        } catch (ex: Exception) {
            Log.EventWriter("Catch, Serious Problem Making Vehicles Directory: $ex")
        }

        try {
            fieldsDirectory = Path.Combine(baseDirectory, "Fields")
            if (!fieldsDirectory.isNullOrEmpty() && !Directory.Exists(fieldsDirectory)) {
                Directory.CreateDirectory(fieldsDirectory)
                Log.EventWriter("Fields Dir Created")
            }
        } catch (ex: Exception) {
            Log.EventWriter("Catch, Serious Problem Making Fields Directory: $ex")
        }

        try {
            if (!logsDirectory.isNullOrEmpty() && !Directory.Exists(logsDirectory)) {
                Directory.CreateDirectory(logsDirectory)
                Log.EventWriter("Logs Dir Created")
            }
        } catch (ex: Exception) {
            Log.EventWriter("Catch, Serious Problem Making Logs Directory: $ex")
        }
    }
}