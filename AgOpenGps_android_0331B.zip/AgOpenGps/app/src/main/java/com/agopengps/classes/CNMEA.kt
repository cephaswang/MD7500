package com.agopengps.classes

import com.agopengps.drive.FormGPS
import java.util.Locale
import kotlin.math.cos

class CNMEA(private val mf: FormGPS) {
    // WGS84 Lat Long
    var latitude: Double = 0.0
    var longitude: Double = 0.0
    var prevLatitude: Double = 0.0
    var prevLongitude: Double = 0.0

    // local plane geometry
    var latStart: Double = 0.0
    var lonStart: Double = 0.0
    var mPerDegreeLat: Double = 0.0
    var mPerDegreeLon: Double = 0.0

    // UTM Zone
    var zone: Int = 0  // 新增 UTM Zone 屬性，初始值為 0（無效值）

    // our current fix
    var fix: vec2 = vec2(0.0, 0.0)
    var prevSpeedFix: vec2 = vec2(0.0, 0.0)

    // used to offset the antenna position to compensate for drift
    var fixOffset: vec2 = vec2(0.0, 0.0)

    // other GIS Info
    var altitude: Double = 0.0
    var speed: Double = 0.0
    var newSpeed: Double = 0.0
    var vtgSpeed: Double = Double.MAX_VALUE
    var headingTrueDual: Double = 0.0
    var headingTrue: Double = 0.0
    var hdop: Double = 0.0
    var age: Double = 0.0
    var headingTrueDualOffset: Double = 0.0
    var fixQuality: Int = 0
    var ageAlarm: Int = 0
    var satellitesTracked: Int = 0

    init {
        // Load default settings
        ageAlarm = mf.settings.getInt("setGPS_ageAlarm", 0)
        // 初始化時計算初始 zone（若有經緯度數據）
        updateZone()
    }

    fun averageTheSpeed() {
        // average the speed
        mf.avgSpeed = (mf.avgSpeed * 0.75) + (speed * 0.25)
    }

    fun setLocalMetersPerDegree() {
        val latRad = Math.toRadians(latStart)

        mPerDegreeLat = 111132.92 - 559.82 * cos(2.0 * latRad) + 1.175 *
                cos(4.0 * latRad) - 0.0023 * cos(6.0 * latRad)

        mPerDegreeLon = 111412.84 * cos(latRad) - 93.5 *
                cos(3.0 * latRad) + 0.118 * cos(5.0 * latRad)

        convertWGS84ToLocal(latitude, longitude).let { (northing, easting) ->
            mf.worldGrid.checkZoomWorldGrid(northing, easting)
        }
        updateZone() // 更新 zone
    }

    fun convertWGS84ToLocal(lat: Double, lon: Double): Pair<Double, Double> {
        val latRad = Math.toRadians(lat)
        mPerDegreeLon = 111412.84 * cos(latRad) - 93.5 *
                cos(3.0 * latRad) + 0.118 * cos(5.0 * latRad)

        val northing = (lat - latStart) * mPerDegreeLat
        val easting = (lon - lonStart) * mPerDegreeLon

        return Pair(northing, easting)
    }

    fun convertLocalToWGS84(northing: Double, easting: Double): Pair<Double, Double> {
        var lat = ((northing + fixOffset.northing) / mPerDegreeLat) + latStart
        val latRad = Math.toRadians(lat)

        mPerDegreeLon = 111412.84 * cos(latRad) - 93.5 *
                cos(3.0 * latRad) + 0.118 * cos(5.0 * latRad)

        val lon = ((easting + fixOffset.easting) / mPerDegreeLon) + lonStart

        return Pair(lat, lon)
    }

    fun getLocalToWSG84_KML(easting: Double, northing: Double): String {
        var lat = (northing / mPerDegreeLat) + latStart
        val latRad = Math.toRadians(lat)

        mPerDegreeLon = 111412.84 * cos(latRad) - 93.5 *
                cos(3.0 * latRad) + 0.118 * cos(5.0 * latRad)

        val lon = (easting / mPerDegreeLon) + lonStart

        return "%.7f,%.7f,0 ".format(locale = Locale.US, lon, lat)
    }

    // 新增計算 UTM Zone 的方法
    private fun updateZone() {
        if (longitude != 0.0) { // 若有有效的經度數據
            zone = calculateUTMZone(longitude)
        } else if (prevLongitude != 0.0) { // 若當前無經度，使用前一次的經度
            zone = calculateUTMZone(prevLongitude)
        } else if (lonStart != 0.0) { // 若無前次經度，使用基準經度
            zone = calculateUTMZone(lonStart)
        } else {
            zone = 51 // 預設值，例如台灣區域
        }
    }

    // 計算 UTM Zone 的輔助函數
    private fun calculateUTMZone(longitude: Double): Int {
        val zone = ((longitude + 180.0) / 6.0).toInt() + 1
        return zone.coerceIn(1, 60) // 確保在 1 到 60 之間
    }

    // 提供外部訪問 zone 的方法（可選）
    fun getZone(): Int {
        updateZone() // 確保 zone 是最新的
        return zone
    }
}