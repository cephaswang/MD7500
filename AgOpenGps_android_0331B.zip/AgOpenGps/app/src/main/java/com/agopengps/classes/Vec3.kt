package com.agopengps.classes

data class vecRGB(
    var red: Byte,
    var grn: Byte,
    var blu: Byte,
    var alpha: Byte
)

/**
 * Represents a three dimensional vector.
 */
data class vec3(
    var easting: Double = 0.0,  // Default value
    var northing: Double = 0.0, // Default value
    var heading: Double = 0.0   // Default value
) {
    constructor(v: vec3) : this(v.easting, v.northing, v.heading)

    fun copyFrom(other: vec3) {
        easting = other.easting
        northing = other.northing
        heading = other.heading
    }

    fun headingXZ(): Double = Math.atan2(easting, northing)

    fun normalize() {
        val length = getLength()
        if (Math.abs(length) < 0.0000000000001) {
            throw ArithmeticException("Trying to normalize a vector with length of zero.")
        }
        easting /= length
        northing /= length
        heading /= length
    }

    fun getLength(): Double = Math.sqrt((easting * easting) + (heading * heading) + (northing * northing))

    fun getLengthSquared(): Double = (easting * easting) + (heading * heading) + (northing * northing)

    operator fun minus(rhs: vec3) = vec3(
        easting - rhs.easting,
        northing - rhs.northing,
        heading - rhs.heading
    )
}

data class vecFix2Fix(
    var easting: Double,  // easting
    var distance: Double, // distance since last point
    var northing: Double, // northing
    var isSet: Int       // altitude
)

/**
 * easting, northing, heading, boundary#
 */
class vec4(
    var easting: Double,  // easting
    var heading: Double,  // heading etc
    var northing: Double, // northing
    var index: Int       // altitude
)

data class vec2(
    var easting: Double = 0.0,  // Default value
    var northing: Double = 0.0  // Default value
) {
    constructor(v: vec2) : this(v.easting, v.northing)

    operator fun minus(rhs: vec2) = vec2(
        easting - rhs.easting,
        northing - rhs.northing
    )

    fun headingXZ(): Double = Math.atan2(easting, northing)

    fun normalize(): vec2 {
        val length = getLength()
        if (Math.abs(length) < 0.000000000001) {
            throw ArithmeticException("Trying to normalize a vector with length of zero.")
        }
        return vec2(easting / length, northing / length)
    }

    fun getLength(): Double = Math.sqrt((easting * easting) + (northing * northing))

    fun getLengthSquared(): Double = (easting * easting) + (northing * northing)

    operator fun times(s: Double) = vec2(easting * s, northing * s)

    operator fun plus(rhs: vec2) = vec2(
        easting + rhs.easting,
        northing + rhs.northing
    )
}

// structure for contour guidance
data class cvec(
    var x: Double,
    var z: Double,
    var h: Double,
    var strip: Int,
    var pt: Int
) {
    constructor(v: vec3) : this(v.easting, v.northing, v.heading, 99999, 99999)
}