package com.agopengps.classes

import kotlin.math.round

class CFlag(
    latitude: Double,
    longitude: Double,
    easting: Double,
    northing: Double,
    heading: Double,
    val color: Int,
    val id: Int,
    val notes: String = "Notes"
) {
    // WGS84 coordinates (rounded to 7 decimal places)
    val latitude: Double = round(latitude * 1e7) / 1e7
    val longitude: Double = round(longitude * 1e7) / 1e7

    // UTM coordinates (rounded to 7 decimal places)
    val easting: Double = round(easting * 1e7) / 1e7
    val northing: Double = round(northing * 1e7) / 1e7
    val heading: Double = round(heading * 1e7) / 1e7

    companion object {
        // Color constants for better type safety
        const val COLOR_RED = 0
        const val COLOR_GREEN = 1
        const val COLOR_PURPLE = 2
    }
}