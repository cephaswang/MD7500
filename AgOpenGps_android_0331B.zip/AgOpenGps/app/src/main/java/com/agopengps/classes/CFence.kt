package com.agopengps.classes

import javax.microedition.khronos.opengles.GL10
import com.agopengps.classes.*
import com.agopengps.drive.MainActivity

class CFence(private val mf: MainActivity) {
    val bndBeingMadePts = mutableListOf<Vec3>(128)
    var createBndOffset: Double = 0.0
    var isBndBeingMade: Boolean = false
    var isDrawRightSide: Boolean = true
    var isDrawAtPivot: Boolean = true
    var isOkToAddPoints: Boolean = false
    var isRecBoundaryWhenSectionOn: Boolean = false
    var closestFenceNum: Int = 0
    val closestFencePt: Vec3 = Vec3(-10000.0, -10000.0, 9.0)

    fun isPointInsideFenceArea(testPoint: Vec3): Boolean {
        if (mf.bnd.bndList.isEmpty()) return false

        // First check if inside outer boundary
        if (mf.bnd.bndList[0].fenceLineEar.isPointInPolygon(testPoint)) {
            // Then check not inside any inner non-drivethru boundaries
            for (i in 1 until mf.bnd.bndList.size) {
                if (mf.bnd.bndList[i].fenceLineEar.isPointInPolygon(testPoint)) {
                    return false
                }
            }
            return true
        }
        return false
    }

    fun isPointInsideFenceArea(testPoint: Vec2): Boolean {
        if (mf.bnd.bndList.isEmpty()) return false

        // First check if inside outer boundary
        if (mf.bnd.bndList[0].fenceLineEar.isPointInPolygon(testPoint)) {
            // Then check not inside any inner non-drivethru boundaries
            for (i in 1 until mf.bnd.bndList.size) {
                if (mf.bnd.bndList[i].fenceLineEar.isPointInPolygon(testPoint)) {
                    return false
                }
            }
            return true
        }
        return false
    }

    fun drawFenceLines(gl: GL10) {
        if (!mf.mc.isOutOfBounds) {
            // Normal boundary drawing
            gl.glColor4f(0f, 0f, 0f, 0.8f)
            gl.glLineWidth(6f)

            for (boundary in mf.bnd.bndList) {
                boundary.fenceLineEar.drawPolygon(gl)
            }

            gl.glColor4f(0.95f, 0.44f, 0.350f, 0.8f)
            gl.glLineWidth(2f)

            for (boundary in mf.bnd.bndList) {
                boundary.fenceLineEar.drawPolygon(gl)
            }
        } else {
            // Out of bounds warning drawing
            gl.glLineWidth(mf.abLine.lineWidth * 3)
            gl.glColor3f(0.95f, 0.25f, 0.250f)

            for (boundary in mf.bnd.bndList) {
                boundary.fenceLineEar.drawPolygon(gl)
            }
        }

        // Draw boundary being created
        if (bndBeingMadePts.isNotEmpty()) {
            val pivot = mf.pivotAxlePos

            // The boundary so far
            gl.glLineWidth(mf.abLine.lineWidth)
            gl.glColor3f(0.825f, 0.22f, 0.90f)
            gl.glBegin(GL10.GL_LINE_STRIP)
            for (point in bndBeingMadePts) {
                gl.glVertex3f(point.easting.toFloat(), point.northing.toFloat(), 0f)
            }
            gl.glColor3f(0.295f, 0.972f, 0.290f)
            gl.glVertex3f(bndBeingMadePts[0].easting.toFloat(), bndBeingMadePts[0].northing.toFloat(), 0f)
            gl.glEnd()

            // Line from last point to pivot marker
            gl.glColor3f(0.825f, 0.842f, 0.0f)
            gl.glEnable(GL10.GL_LINE_STIPPLE)
            gl.glLineStipple(1, 0x0700)
            gl.glBegin(GL10.GL_LINE_STRIP)

            if (isDrawAtPivot) {
                if (isDrawRightSide) {
                    gl.glVertex3f(bndBeingMadePts[0].easting.toFloat(), bndBeingMadePts[0].northing.toFloat(), 0f)
                    gl.glVertex3f(
                        (pivot.easting + sin(pivot.heading - glm.PIBy2) * -createBndOffset).toFloat(),
                        (pivot.northing + cos(pivot.heading - glm.PIBy2) * -createBndOffset).toFloat(),
                        0f
                    )
                    gl.glVertex3f(
                        bndBeingMadePts.last().easting.toFloat(),
                        bndBeingMadePts.last().northing.toFloat(),
                        0f
                    )
                } else {
                    gl.glVertex3f(bndBeingMadePts[0].easting.toFloat(), bndBeingMadePts[0].northing.toFloat(), 0f)
                    gl.glVertex3f(
                        (pivot.easting + sin(pivot.heading - glm.PIBy2) * createBndOffset).toFloat(),
                        (pivot.northing + cos(pivot.heading - glm.PIBy2) * createBndOffset).toFloat(),
                        0f
                    )
                    gl.glVertex3f(
                        bndBeingMadePts.last().easting.toFloat(),
                        bndBeingMadePts.last().northing.toFloat(),
                        0f
                    )
                }
            } else {
                // Draw from tool
                if (isDrawRightSide) {
                    gl.glVertex3f(bndBeingMadePts[0].easting.toFloat(), bndBeingMadePts[0].northing.toFloat(), 0f)
                    gl.glVertex3f(
                        mf.section[mf.tool.numOfSections - 1].rightPoint.easting.toFloat(),
                        mf.section[mf.tool.numOfSections - 1].rightPoint.northing.toFloat(),
                        0f
                    )
                    gl.glVertex3f(
                        bndBeingMadePts.last().easting.toFloat(),
                        bndBeingMadePts.last().northing.toFloat(),
                        0f
                    )
                } else {
                    gl.glVertex3f(bndBeingMadePts[0].easting.toFloat(), bndBeingMadePts[0].northing.toFloat(), 0f)
                    gl.glVertex3f(
                        mf.section[0].leftPoint.easting.toFloat(),
                        mf.section[0].leftPoint.northing.toFloat(),
                        0f
                    )
                    gl.glVertex3f(
                        bndBeingMadePts.last().easting.toFloat(),
                        bndBeingMadePts.last().northing.toFloat(),
                        0f
                    )
                }
            }
            gl.glEnd()
            gl.glDisable(GL10.GL_LINE_STIPPLE)

            // Boundary points
            gl.glColor3f(0.0f, 0.95f, 0.95f)
            gl.glPointSize(6.0f)
            gl.glBegin(GL10.GL_POINTS)
            for (point in bndBeingMadePts) {
                gl.glVertex3f(point.easting.toFloat(), point.northing.toFloat(), 0f)
            }
            gl.glEnd()
        }
    }
}