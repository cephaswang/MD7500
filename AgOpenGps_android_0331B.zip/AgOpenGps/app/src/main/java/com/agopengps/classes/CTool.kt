package com.agopengps.classes

import android.graphics.Color
import android.opengl.GLES20
import com.agopengps.drive.MainActivity
import timber.log.Timber
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

enum class BtnStates {
    OFF,
    AUTO,
    ON
}

class CTool(private val mf: MainActivity) {
    var width: Double = 0.0
    var halfWidth: Double = 0.0
    var contourWidth: Double = 0.0
    private var farLeftPosition: Double = 0.0
    var farLeftSpeed: Double = 0.0
    private var farRightPosition: Double = 0.0
    var farRightSpeed: Double = 0.0

    var overlap: Double = 0.0
    private var trailingHitchLength: Double = 0.0
    private var tankTrailingHitchLength: Double = 0.0
    private var trailingToolToPivotLength: Double = 0.0
    var offset: Double = 0.0

    private var lookAheadOffSetting: Double = 0.0
    private var lookAheadOnSetting: Double = 0.0
    private var turnOffDelay: Double = 0.0

    var lookAheadDistanceOnPixelsLeft: Double = 0.0
    var lookAheadDistanceOnPixelsRight: Double = 0.0
    private var lookAheadDistanceOffPixelsLeft: Double = 0.0
    private var lookAheadDistanceOffPixelsRight: Double = 0.0

    private var isToolTrailing: Boolean = false
    private var isToolTBT: Boolean = false
    var isToolRearFixed: Boolean = false
    var isToolFrontFixed: Boolean = false

    var isMultiColoredSections: Boolean = false
    private var isSectionOffWhenOut: Boolean = false
    var toolAttachType: String = ""

    var hitchLength: Double = 0.0
    var numOfSections: Int = 0
    private var minCoverage: Int = 0
    var areAllSectionBtnsOn: Boolean = true
    var isLeftSideInHeadland: Boolean = true
    var isRightSideInHeadland: Boolean = true
    var isSectionsNotZones: Boolean = false

    var rpXPosition: Int = 0
    var rpWidth: Int = 0
    private var textRotate: Double = 0.0

    val secColors = Array(16) { Color.BLACK }
    private var zones: Int = 0
    private val zoneRanges = IntArray(9)
    private var isDisplayTramControl: Boolean = false

    init {
        // Initialize settings safely
        trailingToolToPivotLength = mf.settings.getDouble("setTool_trailingToolToPivotLength", 0.0)
        width = mf.settings.getDouble("setVehicle_toolWidth", 0.0)
        overlap = mf.settings.getDouble("setVehicle_toolOverlap", 0.0)
        offset = mf.settings.getDouble("setVehicle_toolOffset", 0.0)
        trailingHitchLength = mf.settings.getDouble("setTool_toolTrailingHitchLength", 0.0)
        tankTrailingHitchLength = mf.settings.getDouble("setVehicle_tankTrailingHitchLength", 0.0)
        hitchLength = mf.settings.getDouble("setVehicle_hitchLength", 0.0)

        isToolRearFixed = mf.settings.getBoolean("setTool_isToolRearFixed", false)
        isToolTrailing = mf.settings.getBoolean("setTool_isToolTrailing", false)
        isToolTBT = mf.settings.getBoolean("setTool_isToolTBT", false)
        isToolFrontFixed = mf.settings.getBoolean("setTool_isToolFront", false)

        lookAheadOnSetting = mf.settings.getDouble("setVehicle_toolLookAheadOn", 0.0)
        lookAheadOffSetting = mf.settings.getDouble("setVehicle_toolLookAheadOff", 0.0)
        turnOffDelay = mf.settings.getDouble("setVehicle_toolOffDelay", 0.0)

        isSectionOffWhenOut = mf.settings.getBoolean("setTool_isSectionOffWhenOut", false)
        isSectionsNotZones = mf.settings.getBoolean("setTool_isSectionsNotZones", false)

        numOfSections = if (isSectionsNotZones) {
            mf.settings.getInt("setVehicle_numSections", 0)
        } else {
            mf.settings.getInt("setTool_numSectionsMulti", 0)
        }

        minCoverage = mf.settings.getInt("setVehicle_minCoverage", 0)
        isMultiColoredSections = mf.settings.getBoolean("setColor_isMultiColorSections", false)

        // Load section colors
        for (i in 0..15) {
            secColors[i] = mf.settings.getInt("setColor_sec${"%02d".format(i+1)}", Color.BLACK)
        }

        // Load zones
        val zonesStr = mf.settings.getString("setTool_zones", "0") ?: "0"
        zonesStr.split(",").forEachIndexed { i, value ->
            if (i < zoneRanges.size) zoneRanges[i] = value.toIntOrNull() ?: 0
        }

        isDisplayTramControl = mf.settings.getBoolean("setTool_isDisplayTramControl", false)
        halfWidth = width / 2
    }

    fun drawTool() {
        if (!mf.isGLSurfaceValid()) {
            Timber.tag("CTool").w("GLSurface not valid, skipping draw")
            return
        }

        try {
            GLES20.glMatrixMode(GLES20.GL_MODELVIEW)
            GLES20.glPushMatrix()

            // Translate to pivot axle position
            GLES20.glTranslatef(
                mf.pivotAxlePos.easting.toFloat(),
                mf.pivotAxlePos.northing.toFloat(),
                0f
            )

            // Translate to hitch pin
            GLES20.glTranslatef(
                sin(mf.fixHeading).toFloat() * hitchLength.toFloat(),
                cos(mf.fixHeading).toFloat() * hitchLength.toFloat(),
                0f
            )

            val (trailingTank, trailingTool) = if (isToolTrailing) {
                Pair(tankTrailingHitchLength, trailingHitchLength)
            } else {
                Pair(0.0, 0.0)
            }

            if (isToolTBT && isToolTrailing) {
                drawTankHitch(trailingTank)
                drawToolWheels(trailingTank)
                adjustForTankHitch(trailingTank)
            } else {
                GLES20.glRotatef((-mf.toolPivotPos.heading).toDegrees(), 0f, 0f, 1f)
            }

            var adjustedTrailingTool = if (isToolTrailing) {
                drawTrailingHitch(trailingTool)
                trailingTool - trailingToolToPivotLength
            } else {
                0.0
            }

            if (mf.isJobStarted) {
                drawLookAheadLines(adjustedTrailingTool)
            }

            drawSections(adjustedTrailingTool)
            drawZones(adjustedTrailingTool)
            drawTramDots(adjustedTrailingTool)

        } catch (e: Exception) {
            Timber.tag("CTool").e("Error in drawTool: ${e.message}")
        } finally {
            GLES20.glPopMatrix()
        }
    }

    private fun drawTankHitch(trailingTank: Double) {
        GLES20.glRotatef((-mf.tankPos.heading).toDegrees(), 0f, 0f, 1f)

        GLES20.glLineWidth(6f)
        GLES20.glColor3f(0f, 0f, 0f)
        GLES20.glBegin(GLES20.GL_LINE_LOOP).apply {
            GLES20.glVertex3f(-0.57f, trailingTank.toFloat(), 0f)
            GLES20.glVertex3f(0f, 0f, 0f)
            GLES20.glVertex3f(0.57f, trailingTank.toFloat(), 0f)
            GLES20.glEnd()
        }

        GLES20.glLineWidth(1f)
        GLES20.glColor3f(0.765f, 0.76f, 0.32f)
        GLES20.glBegin(GLES20.GL_LINE_LOOP).apply {
            GLES20.glVertex3f(-0.57f, trailingTank.toFloat(), 0f)
            GLES20.glVertex3f(0f, 0f, 0f)
            GLES20.glVertex3f(0.57f, trailingTank.toFloat(), 0f)
            GLES20.glEnd()
        }
    }

    private fun drawToolWheels(trailingTank: Double) {
        GLES20.glEnable(GLES20.GL_TEXTURE_2D)
        GLES20.glColor4f(1f, 1f, 1f, 0.75f)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mf.textures[MainActivity.Textures.ToolWheels.ordinal])
        GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP).apply {
            GLES20.glTexCoord2f(1f, 0f); GLES20.glVertex2f(1.5f, (trailingTank + 1).toFloat())
            GLES20.glTexCoord2f(0f, 0f); GLES20.glVertex2f(-1.5f, (trailingTank + 1).toFloat())
            GLES20.glTexCoord2f(1f, 1f); GLES20.glVertex2f(1.5f, (trailingTank - 1).toFloat())
            GLES20.glTexCoord2f(0f, 1f); GLES20.glVertex2f(-1.5f, (trailingTank - 1).toFloat())
            GLES20.glEnd()
        }
        GLES20.glDisable(GLES20.GL_TEXTURE_2D)
    }

    private fun adjustForTankHitch(trailingTank: Double) {
        GLES20.glTranslatef(0f, trailingTank.toFloat(), 0f)
        GLES20.glRotatef(mf.tankPos.heading.toDegrees(), 0f, 0f, 1f)
        GLES20.glRotatef((-mf.toolPivotPos.heading).toDegrees(), 0f, 0f, 1f)
    }

    private fun drawTrailingHitch(trailingTool: Double): Double {
        GLES20.glLineWidth(6f)
        GLES20.glColor3f(0f, 0f, 0f)
        GLES20.glBegin(GLES20.GL_LINE_LOOP).apply {
            GLES20.glVertex3f((-0.65 + offset).toFloat(), trailingTool.toFloat(), 0f)
            GLES20.glVertex3f(0f, 0f, 0f)
            GLES20.glVertex3f((0.65 + offset).toFloat(), trailingTool.toFloat(), 0f)
            GLES20.glEnd()
        }

        GLES20.glLineWidth(1f)
        GLES20.glColor3f(0.7f, 0.4f, 0.2f)
        GLES20.glBegin(GLES20.GL_LINE_LOOP).apply {
            GLES20.glVertex3f((-0.65 + offset).toFloat(), trailingTool.toFloat(), 0f)
            GLES20.glVertex3f(0f, 0f, 0f)
            GLES20.glVertex3f((0.65 + offset).toFloat(), trailingTool.toFloat(), 0f)
            GLES20.glEnd()
        }

        if (abs(trailingToolToPivotLength) > 1 && mf.camera.camSetDistance > -100) {
            drawTires(trailingTool)
        }
        return trailingTool
    }

    private fun drawTires(trailingTool: Double) {
        textRotate += mf.sim.stepDistance
        GLES20.glEnable(GLES20.GL_TEXTURE_2D)
        GLES20.glColor4f(1f, 1f, 1f, 0.75f)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mf.textures[mf.Textures.Tire.ordinal])

        // Right tire
        GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP).apply {
            GLES20.glTexCoord2f(1f, (0 + textRotate).toFloat())
            GLES20.glVertex2f((1.4 + offset).toFloat(), (trailingTool + 0.51).toFloat())
            GLES20.glTexCoord2f(0f, (0 + textRotate).toFloat())
            GLES20.glVertex2f((0.75 + offset).toFloat(), (trailingTool + 0.51).toFloat())
            GLES20.glTexCoord2f(1f, (1 + textRotate).toFloat())
            GLES20.glVertex2f((1.4 + offset).toFloat(), (trailingTool - 0.51).toFloat())
            GLES20.glTexCoord2f(0f, (1 + textRotate).toFloat())
            GLES20.glVertex2f((0.75 + offset).toFloat(), (trailingTool - 0.51).toFloat())
            GLES20.glEnd()
        }

        // Left tire
        GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP).apply {
            GLES20.glTexCoord2f(1f, (0 + textRotate).toFloat())
            GLES20.glVertex2f((-1.4 + offset).toFloat(), (trailingTool + 0.51).toFloat())
            GLES20.glTexCoord2f(0f, (0 + textRotate).toFloat())
            GLES20.glVertex2f((-0.75 + offset).toFloat(), (trailingTool + 0.51).toFloat())
            GLES20.glTexCoord2f(1f, (1 + textRotate).toFloat())
            GLES20.glVertex2f((-1.4 + offset).toFloat(), (trailingTool - 0.51).toFloat())
            GLES20.glTexCoord2f(0f, (1 + textRotate).toFloat())
            GLES20.glVertex2f((-0.75 + offset).toFloat(), (trailingTool - 0.51).toFloat())
            GLES20.glEnd()
        }

        GLES20.glDisable(GLES20.GL_TEXTURE_2D)
    }

    private fun drawLookAheadLines(adjustedTrailingTool: Double) {
        GLES20.glLineWidth(3f)
        GLES20.glBegin(GLES20.GL_LINES).apply {
            // Lookahead section on
            GLES20.glColor3f(0.20f, 0.7f, 0.2f)
            GLES20.glVertex3f(farLeftPosition.toFloat(), (lookAheadDistanceOnPixelsLeft * 0.1 + adjustedTrailingTool).toFloat(), 0f)
            GLES20.glVertex3f(farRightPosition.toFloat(), (lookAheadDistanceOnPixelsRight * 0.1 + adjustedTrailingTool).toFloat(), 0f)

            // Lookahead section off
            GLES20.glColor3f(0.70f, 0.2f, 0.2f)
            GLES20.glVertex3f(farLeftPosition.toFloat(), (lookAheadDistanceOffPixelsLeft * 0.1 + adjustedTrailingTool).toFloat(), 0f)
            GLES20.glVertex3f(farRightPosition.toFloat(), (lookAheadDistanceOffPixelsRight * 0.1 + adjustedTrailingTool).toFloat(), 0f)

            if (mf.vehicle.isHydLiftOn) {
                GLES20.glColor3f(0.70f, 0.2f, 0.72f)
                GLES20.glVertex3f(
                    mf.section[0].positionLeft.toFloat(),
                    (mf.vehicle.hydLiftLookAheadDistanceLeft * 0.1 + adjustedTrailingTool).toFloat(),
                    0f
                )
                GLES20.glVertex3f(
                    mf.section[numOfSections - 1].positionRight.toFloat(),
                    (mf.vehicle.hydLiftLookAheadDistanceRight * 0.1 + adjustedTrailingTool).toFloat(),
                    0f
                )
            }
            GLES20.glEnd()
        }
    }

    private fun drawSections(adjustedTrailingTool: Double) {
        val hite = (mf.camera.camSetDistance / -150.0).coerceIn(1.0, 8.0)
        GLES20.glLineWidth(2f)

        for (j in 0 until numOfSections) {
            // Set section color based on state
            when {
                mf.section[j].isSectionOn && mf.section[j].sectionBtnState == BtnStates.AUTO -> {
                    if (mf.section[j].isMappingOn) GLES20.glColor3f(0.0f, 0.95f, 0.0f)
                    else GLES20.glColor3f(0.970f, 0.30f, 0.970f)
                }
                mf.section[j].isSectionOn -> GLES20.glColor3f(0.97f, 0.97f, 0f)
                !mf.section[j].isMappingOn -> GLES20.glColor3f(0.950f, 0.2f, 0.2f)
                else -> GLES20.glColor3f(0.00f, 0.250f, 0.97f)
            }

            val mid = (mf.section[j].positionRight - mf.section[j].positionLeft) / 2 + mf.section[j].positionLeft

            // Draw section
            GLES20.glBegin(GLES20.GL_TRIANGLE_FAN).apply {
                GLES20.glVertex3f(mf.section[j].positionLeft.toFloat(), adjustedTrailingTool.toFloat(), 0f)
                GLES20.glVertex3f(mf.section[j].positionLeft.toFloat(), (adjustedTrailingTool - hite).toFloat(), 0f)
                GLES20.glVertex3f(mid.toFloat(), (adjustedTrailingTool - hite * 1.5).toFloat(), 0f)
                GLES20.glVertex3f(mf.section[j].positionRight.toFloat(), (adjustedTrailingTool - hite).toFloat(), 0f)
                GLES20.glVertex3f(mf.section[j].positionRight.toFloat(), adjustedTrailingTool.toFloat(), 0f)
                GLES20.glEnd()
            }

            // Draw section outline if close enough
            if (mf.camera.camSetDistance > -width * 200) {
                GLES20.glBegin(GLES20.GL_LINE_LOOP).apply {
                    GLES20.glColor3f(0.0f, 0.0f, 0.0f)
                    GLES20.glVertex3f(mf.section[j].positionLeft.toFloat(), adjustedTrailingTool.toFloat(), 0f)
                    GLES20.glVertex3f(mf.section[j].positionLeft.toFloat(), (adjustedTrailingTool - hite).toFloat(), 0f)
                    GLES20.glVertex3f(mid.toFloat(), (adjustedTrailingTool - hite * 1.5).toFloat(), 0f)
                    GLES20.glVertex3f(mf.section[j].positionRight.toFloat(), (adjustedTrailingTool - hite).toFloat(), 0f)
                    GLES20.glVertex3f(mf.section[j].positionRight.toFloat(), adjustedTrailingTool.toFloat(), 0f)
                    GLES20.glEnd()
                }
            }
        }
    }

    private fun drawZones(adjustedTrailingTool: Double) {
        if (!isSectionsNotZones && zones > 0 && mf.camera.camSetDistance > -150) {
            GLES20.glBegin(GLES20.GL_LINES).apply {
                for (i in 1 until zones) {
                    if (i < zoneRanges.size) {
                        GLES20.glColor3f(0.5f, 0.80f, 0.950f)
                        GLES20.glVertex3f(
                            mf.section[zoneRanges[i]].positionLeft.toFloat(),
                            (adjustedTrailingTool - 0.4).toFloat(),
                            0f
                        )
                        GLES20.glVertex3f(
                            mf.section[zoneRanges[i]].positionLeft.toFloat(),
                            (adjustedTrailingTool + 0.2).toFloat(),
                            0f
                        )
                    }
                }
                GLES20.glEnd()
            }
        }
    }

    private fun drawTramDots(adjustedTrailingTool: Double) {
        if (isDisplayTramControl && mf.tram.displayMode != 0 && mf.camera.camSetDistance > -300) {
            GLES20.glPointSize(if (mf.camera.camSetDistance > -100) 12f else 8f)
            GLES20.glBegin(GLES20.GL_POINTS).apply {
                if (mf.tram.isOuter) {
                    // Right side
                    if ((mf.tram.controlByte and 1) == 1) GLES20.glColor3f(0.0f, 0.900f, 0.39630f)
                    else GLES20.glColor3f(0f, 0f, 0f)
                    GLES20.glVertex3f(
                        (farRightPosition - mf.tram.halfWheelTrack).toFloat(),
                        adjustedTrailingTool.toFloat(),
                        0f
                    )

                    // Left side
                    if ((mf.tram.controlByte and 2) == 2) GLES20.glColor3f(0.0f, 0.900f, 0.3930f)
                    else GLES20.glColor3f(0f, 0f, 0f)
                    GLES20.glVertex3f(
                        (farLeftPosition + mf.tram.halfWheelTrack).toFloat(),
                        adjustedTrailingTool.toFloat(),
                        0f
                    )
                } else {
                    // Right side
                    if ((mf.tram.controlByte and 1) == 1) GLES20.glColor3f(0.0f, 0.900f, 0.39630f)
                    else GLES20.glColor3f(0f, 0f, 0f)
                    GLES20.glVertex3f(
                        mf.tram.halfWheelTrack.toFloat(),
                        adjustedTrailingTool.toFloat(),
                        0f
                    )

                    // Left side
                    if ((mf.tram.controlByte and 2) == 2) GLES20.glColor3f(0.0f, 0.900f, 0.3930f)
                    else GLES20.glColor3f(0f, 0f, 0f)
                    GLES20.glVertex3f(
                        (-mf.tram.halfWheelTrack).toFloat(),
                        adjustedTrailingTool.toFloat(),
                        0f
                    )
                }
                GLES20.glEnd()
            }
        }
    }

    private fun Double.toDegrees(): Float {
        return Math.toDegrees(this).toFloat()
    }
}