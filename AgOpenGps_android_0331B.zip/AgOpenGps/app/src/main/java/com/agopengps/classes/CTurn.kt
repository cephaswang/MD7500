package com.agopengps.classes

import com.agopengps.drive.MainActivity
import com.agopengps.classes.*
import com.agopengps.classes.glm.isPointInPolygon
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

class CTurn(private val mf: MainActivity) {
    var turnSelected = 0
    var closestTurnNum = 0
    var iE = 0.0
    var iN = 0.0

    fun isPointInsideTurnArea(pt: vec3): Int {
        if (mf.bnd.bndList.isNotEmpty() && mf.bnd.bndList[0].turnLine.isPointInPolygon(pt)) {
            for (i in 1 until mf.bnd.bndList.size) {
                if (mf.bnd.bndList[i].isDriveThru) continue
                if (mf.bnd.bndList[i].turnLine.isPointInPolygon(pt)) {
                    return i
                }
            }
            return 0
        }
        return -1 // is outside border turn
    }

    fun buildTurnLines() {
        if (mf.bnd.bndList.isEmpty()) {
            return
        }

        // Update the GUI values for boundaries
        mf.fd.updateFieldBoundaryGUIAreas()

        // Determine how wide a headland space
        val totalHeadWidth = mf.yt.uturnDistanceFromBoundary

        // Inside boundaries
        for (boundary in mf.bnd.bndList) {
            boundary.turnLine.clear()
            if (boundary.isDriveThru) continue

            val ptCount = boundary.fenceLine.size

            for (i in ptCount - 1 downTo 0) {
                val fencePoint = boundary.fenceLine[i]
                // Calculate the point outside the boundary
                val point = vec3(
                    fencePoint.easting + (-sin(glm.piBy2 + fencePoint.heading) * totalHeadWidth),
                    fencePoint.northing + (-cos(glm.piBy2 + fencePoint.heading) * totalHeadWidth),
                    fencePoint.heading.normalizeAngle()
                )

                // Only add if outside actual field boundary
                if ((boundary == mf.bnd.bndList[0]) == boundary.fenceLineEar.isPointInPolygon(point)) {
                    boundary.turnLine.add(vec3(point))
                }
            }

            boundary.fixTurnLine(totalHeadWidth, 2)

            // The temp array
            val arr = boundary.turnLine.toTypedArray()
            boundary.turnLine.clear()

            var delta = 0.0
            for (i in arr.indices) {
                if (i == 0) {
                    boundary.turnLine.add(arr[i])
                    continue
                }
                delta += (arr[i - 1].heading - arr[i].heading)
                if (abs(delta) > 0.005) {
                    boundary.turnLine.add(arr[i])
                    delta = 0.0
                }
            }

            if (boundary.turnLine.isNotEmpty()) {
                boundary.turnLine.add(vec3(boundary.turnLine[0]))
            }
        }
    }

    private fun Double.normalizeAngle(): Double {
        var angle = this
        while (angle < -glm.twoPI) angle += glm.twoPI
        while (angle >= glm.twoPI) angle -= glm.twoPI
        return angle
    }
}