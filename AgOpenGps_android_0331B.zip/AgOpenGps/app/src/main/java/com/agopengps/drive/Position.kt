package com.agopengps.drive

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.agopengps.drive.FormGPS

class Position : AppCompatActivity() {

    // 聲明控件變量，保持原命名
    private lateinit var btnZeroRoll: Button
    private lateinit var btnZeroPitch: Button
    private lateinit var btnZeroYaw: Button
    private lateinit var btnZeroX: Button
    private lateinit var btnZeroY: Button
    private lateinit var btnZeroZ: Button
    private lateinit var btnSaveIMUOffsets: Button
    private lateinit var btnSaveIMUOffsets2: Button
    private lateinit var btnCancelIMUOffsets: Button
    private lateinit var btnManualEntry: Button
    private lateinit var btnOKManual: Button
    private lateinit var btnCancelManual: Button
    private lateinit var btnAdjLeft: Button
    private lateinit var btnAdjRight: Button

    private lateinit var lblRoll: TextView
    private lateinit var lblPitch: TextView
    private lateinit var lblimuHeading: TextView
    private lateinit var lblX: TextView
    private lateinit var lbly: TextView
    private lateinit var lblZ: TextView
    private lateinit var lblLat: TextView
    private lateinit var lblLon: TextView
    private lateinit var lblLatManual: TextView
    private lateinit var lblLonManual: TextView

    private lateinit var txtLatManual: EditText
    private lateinit var txtLonManual: EditText

    // FormGPS 的引用，保持原結構
    private lateinit var formGPS: FormGPS

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_position)

        // 初始化控件，使用 findViewById
        initializeControls()

        // 初始化 FormGPS 實例
        formGPS = FormGPS()

        // 設置按鈕點擊事件
        setupButtonListeners()

        // 設置多語言文字
        setLocalizedText()
    }

    private fun initializeControls() {
        btnZeroRoll = findViewById(R.id.btnZeroRoll)
        btnZeroPitch = findViewById(R.id.btnZeroPitch)
        btnZeroYaw = findViewById(R.id.btnZeroYaw)
        btnZeroX = findViewById(R.id.btnZeroX)
        btnZeroY = findViewById(R.id.btnZeroY)
        btnZeroZ = findViewById(R.id.btnZeroZ)
        btnSaveIMUOffsets = findViewById(R.id.btnSaveIMUOffsets)
        btnSaveIMUOffsets2 = findViewById(R.id.btnSaveIMUOffsets2)
        btnCancelIMUOffsets = findViewById(R.id.btnCancelIMUOffsets)
        btnManualEntry = findViewById(R.id.btnManualEntry)
        btnOKManual = findViewById(R.id.btnOKManual)
        btnCancelManual = findViewById(R.id.btnCancelManual)
        btnAdjLeft = findViewById(R.id.btnAdjLeft)
        btnAdjRight = findViewById(R.id.btnAdjRight)

        lblRoll = findViewById(R.id.lblRoll)
        lblPitch = findViewById(R.id.lblPitch)
        lblimuHeading = findViewById(R.id.lblimuHeading)
        lblX = findViewById(R.id.lblX)
        lbly = findViewById(R.id.lbly)
        lblZ = findViewById(R.id.lblZ)
        lblLat = findViewById(R.id.lblLat)
        lblLon = findViewById(R.id.lblLon)
        lblLatManual = findViewById(R.id.lblLatManual)
        lblLonManual = findViewById(R.id.lblLonManual)

        txtLatManual = findViewById(R.id.txtLatManual)
        txtLonManual = findViewById(R.id.txtLonManual)
    }

    private fun setLocalizedText() {
        // 設置多語言文字
        lblRoll.text = getString(R.string.lblRoll)
        lblPitch.text = getString(R.string.lblPitch)
        lblimuHeading.text = getString(R.string.lblimuHeading)
        lblX.text = getString(R.string.lblX)
        lbly.text = getString(R.string.lbly)
        lblZ.text = getString(R.string.lblZ)
        lblLat.text = getString(R.string.lblLat)
        lblLon.text = getString(R.string.lblLon)
        lblLatManual.text = getString(R.string.lblLatManual)
        lblLonManual.text = getString(R.string.lblLonManual)

        btnZeroRoll.text = getString(R.string.btnZeroRoll)
        btnZeroPitch.text = getString(R.string.btnZeroPitch)
        btnZeroYaw.text = getString(R.string.btnZeroYaw)
        btnZeroX.text = getString(R.string.btnZeroX)
        btnZeroY.text = getString(R.string.btnZeroY)
        btnZeroZ.text = getString(R.string.btnZeroZ)
        btnSaveIMUOffsets.text = getString(R.string.btnSaveIMUOffsets)
        btnSaveIMUOffsets2.text = getString(R.string.btnSaveIMUOffsets2)
        btnCancelIMUOffsets.text = getString(R.string.btnCancelIMUOffsets)
        btnManualEntry.text = getString(R.string.btnManualEntry)
        btnOKManual.text = getString(R.string.btnOKManual)
        btnCancelManual.text = getString(R.string.btnCancelManual)
        btnAdjLeft.text = getString(R.string.btnAdjLeft)
        btnAdjRight.text = getString(R.string.btnAdjRight)
    }

    private fun setupButtonListeners() {
        btnZeroRoll.setOnClickListener {
            // TODO: 實現 Zero Roll 邏輯
        }

        btnZeroPitch.setOnClickListener {
            // TODO: 實現 Zero Pitch 邏輯
        }

        btnZeroYaw.setOnClickListener {
            // TODO: 實現 Zero Yaw 邏輯
        }

        btnZeroX.setOnClickListener {
            // TODO: 實現 Zero X 邏輯
        }

        btnZeroY.setOnClickListener {
            // TODO: 實現 Zero Y 邏輯
        }

        btnZeroZ.setOnClickListener {
            // TODO: 實現 Zero Z 邏輯
        }

        btnSaveIMUOffsets.setOnClickListener {
            // TODO: 實現 Save IMU Offsets 邏輯
        }

        btnSaveIMUOffsets2.setOnClickListener {
            // TODO: 實現 Save IMU Offsets 2 邏輯
        }

        btnCancelIMUOffsets.setOnClickListener {
            finish() // 關閉當前 Activity
        }

        btnManualEntry.setOnClickListener {
            // TODO: 實現 Manual Entry 邏輯
        }

        btnOKManual.setOnClickListener {
            // TODO: 實現 OK Manual 邏輯
        }

        btnCancelManual.setOnClickListener {
            // TODO: 實現 Cancel Manual 邏輯
        }

        btnAdjLeft.setOnClickListener {
            // TODO: 實現 Adjust Left 邏輯
        }

        btnAdjRight.setOnClickListener {
            // TODO: 實現 Adjust Right 邏輯
        }
    }

    // 可選：實現 Dispose 方法模擬資源清理
    fun dispose() {
        // TODO: 清理資源邏輯
    }
}