package com.agopengps.drive

import android.os.Bundle
import android.os.Handler
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class FormGPSData : AppCompatActivity() {
    private val handler = Handler()
    private lateinit var timerRunnable: Runnable

    // UI elements
    private lateinit var lblSatsTracked: TextView
    private lateinit var lblLatitude: TextView
    private lateinit var lblLongitude: TextView
    private lateinit var lblAltitude: TextView
    private lateinit var lblHDOP: TextView
    private lateinit var lblEastingField: TextView
    private lateinit var lblNorthingField: TextView
    private lateinit var lblHz: TextView
    private lateinit var lblTimeSlice: TextView
    private lateinit var lblFrameTime: TextView
    private lateinit var lbludpWatchCounts: TextView
    private lateinit var lblFix2FixHeading: TextView
    private lateinit var lblIMUHeading: TextView
    private lateinit var lblFuzeHeading: TextView
    private lateinit var lblAngularVelocity: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gps_data) // You'll need to create this layout XML

        // Initialize views
        lblSatsTracked = findViewById(R.id.lblSatsTracked)
        lblLatitude = findViewById(R.id.lblLatitude)
        lblLongitude = findViewById(R.id.lblLongitude)
        lblAltitude = findViewById(R.id.lblAltitude)
        lblHDOP = findViewById(R.id.lblHDOP)
        lblEastingField = findViewById(R.id.lblEastingField)
        lblNorthingField = findViewById(R.id.lblNorthingField)
        lblHz = findViewById(R.id.lblHz)
        lblTimeSlice = findViewById(R.id.lblTimeSlice)
        lblFrameTime = findViewById(R.id.lblFrameTime)
        lbludpWatchCounts = findViewById(R.id.lbludpWatchCounts)
        lblFix2FixHeading = findViewById(R.id.lblFix2FixHeading)
        lblIMUHeading = findViewById(R.id.lblIMUHeading)
        lblFuzeHeading = findViewById(R.id.lblFuzeHeading)
        lblAngularVelocity = findViewById(R.id.lblAngularVelocity)

        // Setup timer to update UI every second
        timerRunnable = object : Runnable {
            override fun run() {
                updateUI()
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(timerRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(timerRunnable)
    }

    private fun updateUI() {
        // Here you would update all the TextViews with actual data
        // For example:
        // lblLatitude.text = gpsData.latitude.toString()
        // lblLongitude.text = gpsData.longitude.toString()
        // etc.
    }

    // You'll need to implement the actual data fetching logic
    // and connect it to your GPS/IMU data sources
}