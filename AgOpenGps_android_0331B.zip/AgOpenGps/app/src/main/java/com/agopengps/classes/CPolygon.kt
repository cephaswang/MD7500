package com.agopengps.classes

import android.util.Log
import timber.log.Timber
import kotlin.math.abs
import kotlin.math.atan2


class Triangle(p0: Vec2, p1: Vec2, p2: Vec2) : CPolygon() {
    init {
        polygonPoints = arrayOf(p0, p1, p2)
    }
}

open class CPolygon {
    var polygonPoints: Array<Vec2> = emptyArray()

    constructor()

    constructor(points: Array<Vec2>) {
        polygonPoints = points
    }

    fun triangulate(): List<Triangle> {
        // Copy the points into a scratch array
        val pts = polygonPoints.copyOf()

        // Make a scratch polygon
        val polygon = CPolygon(pts)

        // Orient the polygon clockwise
        polygon.orientPolygonClockwise()

        // Make room for the triangles
        val triangles = mutableListOf<Triangle>()

        // While the polygon has more than three points, remove an ear
        while (polygon.polygonPoints.size > 3) {
            polygon.removeEar(triangles)
        }

        // Copy the last three points into their own triangle
        triangles.add(Triangle(
            polygon.polygonPoints[0],
            polygon.polygonPoints[1],
            polygon.polygonPoints[2]
        ))

        return triangles
    }

    private fun findEar(): Triple<Int, Int, Int> {
        val numPoints = polygonPoints.size

        for (a in 0 until numPoints) {
            val b = (a + 1) % numPoints
            val c = (b + 1) % numPoints

            if (formsEar(polygonPoints, a, b, c)) {
                return Triple(a, b, c)
            }
        }

        // We should never get here because there should always be at least two ears
        Timber.tag("CPolygon").e("No ear found in polygon")
        return Triple(0, 1, 2)
    }

    private fun formsEar(points: Array<Vec2>, a: Int, b: Int, c: Int): Boolean {
        // See if the angle ABC is concave
        if (getAngle(
                points[a].easting, points[a].northing,
                points[b].easting, points[b].northing,
                points[c].easting, points[c].northing
            ) > 0
        ) {
            // This is a concave corner so the triangle cannot be an ear
            return false
        }

        // Make the triangle A, B, C
        val triangle = Triangle(points[a], points[b], points[c])

        // Check other points to see if they lie in triangle A, B, C
        for (i in points.indices) {
            if (i != a && i != b && i != c) {
                if (triangle.pointInPolygon(points[i].easting, points[i].northing)) {
                    // This point is in the triangle so this is not an ear
                    return false
                }
            }
        }

        // This is an ear
        return true
    }

    private fun removeEar(triangles: MutableList<Triangle>) {
        // Find an ear
        val (a, b, c) = findEar()

        // Create a new triangle for the ear
        triangles.add(Triangle(polygonPoints[a], polygonPoints[b], polygonPoints[c]))

        // Remove the ear from the polygon
        removePointFromArray(b)
    }

    private fun removePointFromArray(target: Int) {
        val newPoints = Array(polygonPoints.size - 1) { Vec2(0.0,0.0) }
        System.arraycopy(polygonPoints, 0, newPoints, 0, target)
        System.arraycopy(polygonPoints, target + 1, newPoints, target, polygonPoints.size - target - 1)
        polygonPoints = newPoints
    }

    fun getAngle(ax: Double, ay: Double, bx: Double, by: Double, cx: Double, cy: Double): Double {
        // Get the dot product
        val dotProduct = dotProduct(ax, ay, bx, by, cx, cy)

        // Get the cross product
        val crossProduct = crossProductLength(ax, ay, bx, by, cx, cy)

        // Calculate the angle
        return atan2(crossProduct, dotProduct)
    }

    fun pointInPolygon(x: Double, y: Double): Boolean {
        // Get the angle between the point and the first and last vertices
        val maxPoint = polygonPoints.size - 1
        var totalAngle = getAngle(
            polygonPoints[maxPoint].easting, polygonPoints[maxPoint].northing,
            x, y,
            polygonPoints[0].easting, polygonPoints[0].northing
        )

        // Add the angles from the point to each other pair of vertices
        for (i in 0 until maxPoint) {
            totalAngle += getAngle(
                polygonPoints[i].easting, polygonPoints[i].northing,
                x, y,
                polygonPoints[i + 1].easting, polygonPoints[i + 1].northing
            )
        }

        // The total angle should be 2*PI or -2*PI if the point is in the polygon
        return abs(totalAngle) > 1
    }

    fun polygonIsOrientedClockwise(): Boolean {
        return signedPolygonArea() < 0
    }

    fun orientPolygonClockwise() {
        if (!polygonIsOrientedClockwise()) {
            polygonPoints.reverse()
        }
    }

    companion object {
        fun crossProductLength(ax: Double, ay: Double, bx: Double, by: Double, cx: Double, cy: Double): Double {
            // Get the vectors' coordinates
            val bax = ax - bx
            val bay = ay - by
            val bcx = cx - bx
            val bcy = cy - by

            // Calculate the Z coordinate of the cross product
            return bax * bcy - bay * bcx
        }

        fun dotProduct(ax: Double, ay: Double, bx: Double, by: Double, cx: Double, cy: Double): Double {
            // Get the vectors' coordinates
            val bax = ax - bx
            val bay = ay - by
            val bcx = cx - bx
            val bcy = cy - by

            // Calculate the dot product
            return bax * bcx + bay * bcy
        }
    }

    fun polygonArea(): Double {
        // Return the absolute value of the signed area
        return abs(signedPolygonArea())
    }

    private fun signedPolygonArea(): Double {
        // Add the first point to the end
        val numPoints = polygonPoints.size
        val pts = Array(numPoints + 1) { Vec2(0.0,0.0) }
        System.arraycopy(polygonPoints, 0, pts, 0, numPoints)
        pts[numPoints] = polygonPoints[0]

        // Get the areas
        var area = 0.0
        for (i in 0 until numPoints) {
            area += (pts[i + 1].easting - pts[i].easting) *
                    (pts[i + 1].northing + pts[i].northing) / 2
        }

        // Return the result
        return area
    }

    fun polygonIsConvex(): Boolean {
        var gotNegative = false
        var gotPositive = false
        val numPoints = polygonPoints.size

        for (a in 0 until numPoints) {
            val b = (a + 1) % numPoints
            val c = (b + 1) % numPoints

            val crossProduct = crossProductLength(
                polygonPoints[a].easting, polygonPoints[a].northing,
                polygonPoints[b].easting, polygonPoints[b].northing,
                polygonPoints[c].easting, polygonPoints[c].northing
            )

            when {
                crossProduct < 0 -> gotNegative = true
                crossProduct > 0 -> gotPositive = true
            }

            if (gotNegative && gotPositive) return false
        }

        // If we got this far, the polygon is convex
        return true
    }
}