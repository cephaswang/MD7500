package com.agopengps.classes

class CTrk {
    val curvePts = mutableListOf<vec3>()
    var heading: Double = 3.0
    var name: String = "New Track"
    var isVisible: Boolean = true
    var ptA: vec2 = vec2()
    var ptB: vec2 = vec2()
    var endPtA: vec2 = vec2()
    var endPtB: vec2 = vec2()
    var mode: TrackMode = TrackMode.None
    var nudgeDistance: Double = 0.0

    constructor()

    constructor(trk: CTrk) {
        curvePts.addAll(trk.curvePts)
        heading = trk.heading
        name = trk.name
        isVisible = trk.isVisible
        ptA = trk.ptA
        ptB = trk.ptB
        endPtA = vec2()
        endPtB = vec2()
        mode = trk.mode
        nudgeDistance = trk.nudgeDistance
    }
}