package com.agopengps.drive

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class OpenGL(context: Context) : GLSurfaceView(context) {

    // Extracted Near, Far, Right, Left clipping planes of frustum
    val frustum = DoubleArray(24)

    private var isInit = false
    private var fovy = 0.7
    private var camDistanceFactor = -4.0

    var mouseX = 0
    var mouseY = 0
    var steerModuleConnectedCounter = 0

    // Data buffers for pixels read from off screen buffer
    private val rateRed = ByteArray(1)
    private val rateGrn = ByteArray(1)
    private val rateBlu = ByteArray(1)
    private val grnPixels = ByteArray(150001)

    private var isHeadlandClose = false
    private var deadCam = 0

    private val sb = StringBuilder()
    private var left = vec2()
    private var right = vec2()
    private var ptTip = vec2()

    private var bbCounter = 0
    private var number = 0UL
    private var lastNumber = 0UL

    private var avgPivDistance = 0.0
    private var lightbarDistance = 0.0
    private var longAvgPivDistance = 0.0

    var maxFieldX = 0.0
    var maxFieldY = 0.0
    var minFieldX = 0.0
    var minFieldY = 0.0
    var fieldCenterX = 0.0
    var fieldCenterY = 0.0
    var maxFieldDistance = 0.0
    var maxCrossFieldLength = 0.0

    init {
        setRenderer(Renderer())
    }

    inner class Renderer : GLSurfaceView.Renderer {
        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glClearColor(0.14f, 0.14f, 0.37f, 1.0f)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            GLES20.glCullFace(GLES20.GL_BACK)
            // SetZoom() would be called here
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            GLES20.glViewport(0, 0, width, height)
            GLES20.glMatrixMode(GLES20.GL_PROJECTION)
            GLES20.glLoadIdentity()

            val ratio = width.toFloat() / height.toFloat()
            val mat = FloatArray(16)
            Matrix.perspectiveM(mat, 0, fovy.toFloat(), ratio, 1.0f, (-camDistanceFactor * camera.camSetDistance).toFloat())
            GLES20.glLoadMatrixf(mat, 0)

            GLES20.glMatrixMode(GLES20.GL_MODELVIEW)
            if (isLineSmooth) {
                GLES20.glEnable(GLES20.GL_LINE_SMOOTH)
            } else {
                GLES20.glDisable(GLES20.GL_LINE_SMOOTH)
            }
        }

        override fun onDrawFrame(gl: GL10?) {
            if (sentenceCounter < 299) {
                if (isGPSPositionInitialized) {
                    if (!isInit) {
                        onSurfaceChanged(gl, width, height)
                        isInit = true
                    }

                    GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT or GLES20.GL_COLOR_BUFFER_BIT)
                    if (isDay) {
                        GLES20.glClearColor(0.27f, 0.4f, 0.7f, 1.0f)
                    } else {
                        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f)
                    }

                    GLES20.glLoadIdentity()

                    // Position the camera
                    camera.SetWorldCam(pivotAxlePos.easting, pivotAxlePos.northing, camHeading)

                    // The bounding box of the camera for culling
                    CalcFrustum()
                    GLES20.glDisable(GLES20.GL_BLEND)

                    worldGrid.DrawFieldSurface()

                    if (isGridOn) worldGrid.DrawWorldGrid(camera.gridZoom)

                    if (isDrawPolygons) {
                        GLES20.glPolygonMode(GLES20.GL_FRONT, GLES20.GL_LINE)
                    }

                    GLES20.glEnable(GLES20.GL_BLEND)

                    // Rest of the drawing code would be implemented similarly...
                    // This is just a skeleton showing the structure

                    // 2D Ortho section
                    GLES20.glMatrixMode(GLES20.GL_PROJECTION)
                    GLES20.glPushMatrix()
                    GLES20.glLoadIdentity()

                    val left = -width / 2.0
                    val right = width / 2.0
                    val bottom = height.toDouble()
                    val top = 0.0
                    Matrix.orthoM(floatArrayOf(0f), 0, left.toFloat(), right.toFloat(), bottom.toFloat(), top.toFloat(), -1f, 1f)

                    GLES20.glMatrixMode(GLES20.GL_MODELVIEW)
                    GLES20.glPushMatrix()
                    GLES20.glLoadIdentity()

                    if (isLightBarNotSteerBar) {
                        DrawLightBarText()
                    } else {
                        if (isLightbarOn) DrawSteerBarText()
                    }

                    // Pop matrices
                    GLES20.glPopMatrix()
                    GLES20.glMatrixMode(GLES20.GL_PROJECTION)
                    GLES20.glPopMatrix()
                    GLES20.glMatrixMode(GLES20.GL_MODELVIEW)

                    GLES20.glFlush()
                }
            } else {
                // No GPS connection handling
                GLES20.glEnable(GLES20.GL_BLEND)
                GLES20.glClearColor(0.122f, 0.1258f, 0.1275f, 1.0f)
                GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT or GLES20.GL_COLOR_BUFFER_BIT)
                GLES20.glLoadIdentity()

                deadCam += 5

                // Draw no GPS texture
                GLES20.glFlush()
            }
        }
    }

    private fun oglBack_Load() {
        GLES20.glEnable(GLES20.GL_CULL_FACE)
        GLES20.glCullFace(GLES20.GL_BACK)
        // Set pixel store parameters
    }

    private fun oglBack_Resize(width: Int, height: Int) {
        GLES20.glViewport(0, 0, 500, 300)
        val mat = FloatArray(16)
        Matrix.perspectiveM(mat, 0, 0.06f, 1.6666666666f, 50.0f, 520.0f)
        GLES20.glLoadMatrixf(mat, 0)
    }

    private fun oglBack_Paint() {
        GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT or GLES20.GL_COLOR_BUFFER_BIT)
        GLES20.glLoadIdentity()

        // Rest of the back buffer drawing code...
    }

    private fun oglZoom_Load() {
        GLES20.glEnable(GLES20.GL_CULL_FACE)
        GLES20.glCullFace(GLES20.GL_BACK)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glClearColor(0f, 0f, 0f, 1.0f)
    }

    private fun oglZoom_Resize(width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val mat = FloatArray(16)
        Matrix.perspectiveM(mat, 0, 1.0f, 1.0f, 100.0f, 5000.0f)
        GLES20.glLoadMatrixf(mat, 0)
    }

    private fun oglZoom_Paint() {
        if (isJobStarted) {
            GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT or GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glLoadIdentity()

            CalculateMinMax()
            // Rest of the zoom paint code...
        }
    }

    private fun DrawManUTurnBtn() {
        // Implementation for manual U-turn button drawing
    }

    private fun DrawUTurnBtn() {
        // Implementation for U-turn button drawing
    }

    private fun DrawSteerCircle() {
        // Implementation for steering circle drawing
    }

    private fun DrawTramMarkers() {
        // Implementation for tram markers drawing
    }

    private fun MakeFlagMark() {
        // Implementation for flag marking
    }

    private fun DrawFlags() {
        // Implementation for flags drawing
    }

    private fun DrawLightBar(Width: Double, Height: Double, offlineDistance: Double) {
        // Implementation for light bar drawing
    }

    private fun DrawLightBarText() {
        // Implementation for light bar text drawing
    }

    private fun DrawSteerBarText() {
        // Implementation for steer bar text drawing
    }

    private fun DrawTrackInfo() {
        // Implementation for track info drawing
    }

    private fun DrawCompassText() {
        // Implementation for compass text drawing
    }

    private fun DrawCompass() {
        // Implementation for compass drawing
    }

    private fun DrawReverse() {
        // Implementation for reverse indicator drawing
    }

    private fun DrawLiftIndicator() {
        // Implementation for lift indicator drawing
    }

    private fun DrawSpeedo() {
        // Implementation for speedometer drawing
    }

    private fun DrawLostRTK() {
        // Implementation for lost RTK indicator drawing
    }

    private fun DrawBeta() {
        // Implementation for beta indicator drawing
    }

    private fun DrawAge() {
        // Implementation for age indicator drawing
    }

    private fun DrawGuidanceLineText() {
        // Implementation for guidance line text drawing
    }

    private fun DrawHardwareMessageText() {
        // Implementation for hardware message text drawing
    }

    private fun CalcFrustum() {
        val proj = FloatArray(16) // For Grabbing The PROJECTION Matrix
        val modl = FloatArray(16) // For Grabbing The MODELVIEW Matrix
        val clip = FloatArray(16) // Result Of Concatenating PROJECTION and MODELVIEW

        GLES20.glGetFloatv(GLES20.GL_PROJECTION_MATRIX, proj, 0)
        GLES20.glGetFloatv(GLES20.GL_MODELVIEW_MATRIX, modl, 0)

        // Concatenate (Multiply) The Two Matrices
        clip[0] = modl[0] * proj[0] + modl[1] * proj[4] + modl[2] * proj[8] + modl[3] * proj[12]
        clip[1] = modl[0] * proj[1] + modl[1] * proj[5] + modl[2] * proj[9] + modl[3] * proj[13]
        clip[2] = modl[0] * proj[2] + modl[1] * proj[6] + modl[2] * proj[10] + modl[3] * proj[14]
        clip[3] = modl[0] * proj[3] + modl[1] * proj[7] + modl[2] * proj[11] + modl[3] * proj[15]

        // Rest of the frustum calculation...
    }

    fun CalculateMinMax() {
        minFieldX = 9999999.0
        minFieldY = 9999999.0
        maxFieldX = -9999999.0
        maxFieldY = -9999999.0

        if (bnd.bndList.isNotEmpty()) {
            val bndCnt = bnd.bndList[0].fenceLine.size
            for (i in 0 until bndCnt) {
                val x = bnd.bndList[0].fenceLine[i].easting
                val y = bnd.bndList[0].fenceLine[i].northing

                if (minFieldX > x) minFieldX = x
                if (maxFieldX < x) maxFieldX = x
                if (minFieldY > y) minFieldY = y
                if (maxFieldY < y) maxFieldY = y
            }
        } else {
            for (j in triStrip.indices) {
                val patchCount = triStrip[j].patchList.size
                if (patchCount > 0) {
                    for (triList in triStrip[j].patchList) {
                        val count2 = triList.size
                        for (i in 1 until count2 step 3) {
                            val x = triList[i].easting
                            val y = triList[i].northing

                            if (minFieldX > x) minFieldX = x
                            if (maxFieldX < x) maxFieldX = x
                            if (minFieldY > y) minFieldY = y
                            if (maxFieldY < y) maxFieldY = y
                        }
                    }
                }
            }
        }

        if (maxFieldX == -9999999.0 || minFieldX == 9999999.0 || maxFieldY == -9999999.0 || minFieldY == 9999999.0) {
            maxFieldX = 0.0
            minFieldX = 0.0
            maxFieldY = 0.0
            minFieldY = 0.0
            maxFieldDistance = 1500.0
        } else {
            val dist = Math.abs(minFieldX - maxFieldX)
            val dist2 = Math.abs(minFieldY - maxFieldY)

            maxCrossFieldLength = Math.sqrt(dist * dist + dist2 * dist2) * 1.0

            maxFieldDistance = if (dist > dist2) dist else dist2

            if (maxFieldDistance < 100) maxFieldDistance = 100.0
            if (maxFieldDistance > 5000) maxFieldDistance = 5000.0

            fieldCenterX = (maxFieldX + minFieldX) / 2.0
            fieldCenterY = (maxFieldY + minFieldY) / 2.0
        }
    }

    private fun DistanceToFieldOriginCheck() {
        if (Math.abs(pivotAxlePos.easting) > 20000 || Math.abs(pivotAxlePos.northing) > 20000) {
            // Show warning message
        }
    }
}

// Supporting classes
class vec2(var easting: Double = 0.0, var northing: Double = 0.0)

// Other supporting classes would be defined in their respective files