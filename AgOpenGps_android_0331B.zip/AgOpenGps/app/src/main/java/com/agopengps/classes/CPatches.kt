//Please, if you use this, share the improvements
package com.agopengps.classes

import com.agopengps.drive.MainActivity

class CPatches(private val mf: MainActivity) {
    //list of patch data individual triangles
    var triangleList: MutableList<Vec3> = mutableListOf()

    //list of the list of patch data individual triangles for that entire section activity
    val patchList: MutableList<MutableList<Vec3>> = mutableListOf()

    //mapping
    var isDrawing = false

    //points in world space that start and end of section are in
    var leftPoint: Vec2 = Vec2(0.0,0.0)
    var rightPoint: Vec2 = Vec2(0.0,0.0)

    var numTriangles = 0
    var currentStartSectionNum = 0
    var currentEndSectionNum = 0
    var newStartSectionNum = 0
    var newEndSectionNum = 0

    init {
        (patchList as ArrayList).ensureCapacity(2048)
    }

    fun turnMappingOn(j: Int) {
        numTriangles = 0

        //do not tally square meters on initial point, that would be silly
        if (!isDrawing) {
            //set the section bool to on
            isDrawing = true

            //starting a new patch chunk so create a new triangle list
            triangleList = ArrayList(64)

            patchList.add(triangleList)

            if (!mf.tool.isMultiColoredSections) {
                triangleList.add(Vec3(mf.sectionColorDay.r.toDouble(), mf.sectionColorDay.g.toDouble(), mf.sectionColorDay.b.toDouble()))
            } else {
                if (mf.tool.isSectionsNotZones) {
                    triangleList.add(Vec3(mf.tool.secColors[j].r.toDouble(), mf.tool.secColors[j].g.toDouble(), mf.tool.secColors[j].b.toDouble()))
                } else {
                    triangleList.add(Vec3(mf.sectionColorDay.r.toDouble(), mf.sectionColorDay.g.toDouble(), mf.sectionColorDay.b.toDouble()))
                }
            }

            leftPoint = mf.section[currentStartSectionNum].leftPoint
            rightPoint = mf.section[currentEndSectionNum].rightPoint

            //left side of triangle
            triangleList.add(Vec3(leftPoint.easting, leftPoint.northing, 0.0))

            //Right side of triangle
            triangleList.add(Vec3(rightPoint.easting, rightPoint.northing, 0.0))
        }
    }

    fun turnMappingOff() {
        addMappingPoint(0)

        isDrawing = false
        numTriangles = 0

        if (triangleList.size > 4) {
            //save the triangle list in a patch list to add to saving file
            mf.patchSaveList.add(triangleList)
        } else {
            triangleList.clear()
            if (patchList.isNotEmpty()) patchList.removeAt(patchList.size - 1)
        }
    }

    //every time a new fix, a new patch point from last point to this point
    //only need prev point on the first points of triangle strip that makes a box (2 triangles)
    fun addMappingPoint(j: Int) {
        leftPoint = mf.section[currentStartSectionNum].leftPoint
        rightPoint = mf.section[currentEndSectionNum].rightPoint

        //add two triangles for next step.
        //left side

        //add the point to List
        triangleList.add(Vec3(leftPoint.easting, leftPoint.northing, 0.0))

        //Right side
        triangleList.add(Vec3(rightPoint.easting, rightPoint.northing, 0.0))

        //count the triangle pairs
        numTriangles++

        //quick count the triangleList.size - 1
        val c = triangleList.size - 1

        //when closing a job the triangle patches all are emptied but the section delay keeps going.
        //Prevented by quick check. 4 points plus colour
        //if (c >= 5)
        {
            //calculate area of these 2 new triangles - AbsoluteValue of (Ax(By-Cy) + Bx(Cy-Ay) + Cx(Ay-By)/2)
            run {
                var temp = Math.abs((triangleList[c].easting * (triangleList[c - 1].northing - triangleList[c - 2].northing))
                        + (triangleList[c - 1].easting * (triangleList[c - 2].northing - triangleList[c].northing))
                        + (triangleList[c - 2].easting * (triangleList[c].northing - triangleList[c - 1].northing)))

                temp += Math.abs((triangleList[c - 1].easting * (triangleList[c - 2].northing - triangleList[c - 3].northing))
                        + (triangleList[c - 2].easting * (triangleList[c - 3].northing - triangleList[c - 1].northing))
                        + (triangleList[c - 3].easting * (triangleList[c - 1].northing - triangleList[c - 2].northing)))

                temp *= 0.5
                mf.fd.workedAreaTotal += temp
                mf.fd.workedAreaTotalUser += temp
            }
        }

        if (numTriangles > 61) {
            numTriangles = 0

            //save the cutoff patch to be saved later
            mf.patchSaveList.add(triangleList)

            triangleList = ArrayList(64)

            patchList.add(triangleList)

            //Add Patch colour
            if (!mf.tool.isMultiColoredSections) {
                triangleList.add(Vec3(mf.sectionColorDay.r.toDouble(), mf.sectionColorDay.g.toDouble(), mf.sectionColorDay.b.toDouble()))
            } else {
                triangleList.add(Vec3(mf.tool.secColors[j].r.toDouble(), mf.tool.secColors[j].g.toDouble(), mf.tool.secColors[j].b.toDouble()))
            }

            //add the points to List, yes its more points, but breaks up patches for culling
            triangleList.add(Vec3(leftPoint.easting, leftPoint.northing, 0.0))
            triangleList.add(Vec3(rightPoint.easting, rightPoint.northing, 0.0))
        }
    }
}