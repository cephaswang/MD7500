package com.agopengps.classes

import android.opengl.GLES20
import com.agopengps.*
import com.agopengps.drive.MainActivity
import kotlin.math.*
import com.agopengps.classes.*


class CRecPathPt(
    var easting: Double,
    var northing: Double,
    var heading: Double,
    var speed: Double,
    var autoBtnState: Boolean
)

class CRecordedPath(private val mf: MainActivity) {
    //the recorded path from driving around
    val recList = mutableListOf<CRecPathPt>()

    //the dubins path to get there
    val shuttleDubinsList = mutableListOf<CRecPathPt>()

    var shuttleListCount = 0

    //list of vec3 points of Dubins shortest path between 2 points - To be converted to RecPt
    var shortestDubinsList = mutableListOf<Vec3>()

    //generated reference line
    var refPoint1 = Vec2(1.0, 1.0)
    var refPoint2 = Vec2(2.0, 2.0)

    var distanceFromRefLine = 0.0
    var distanceFromCurrentLinePivot = 0.0
    private var A = 0
    private var B = 0
    private var C = 0

    var currentPositonIndex = 0

    //pure pursuit values
    var pivotAxlePosRP = Vec3(0.0, 0.0, 0.0)

    var homePos =  Vec3(0.0, 0.0, 0.0)
    var goalPointRP = Vec2(0.0, 0.0)
    var steerAngleRP = 0.0
    var rEastRP = 0.0
    var rNorthRP = 0.0
    var ppRadiusRP = 0.0
    var radiusPointRP = Vec2(0.0, 0.0)

    var isBtnFollowOn = false
    var isEndOfTheRecLine = false
    var isRecordOn = false
    var isDrivingRecordedPath = false
    var isFollowingDubinsToPath = false
    var isFollowingRecPath = false
    var isFollowingDubinsHome = false

    var pivotDistanceError = 0.0
    var pivotDistanceErrorLast = 0.0
    var pivotDerivative = 0.0
    var pivotDerivativeSmoothed = 0.0

    //derivative counters
    private var counter2 = 0

    var inty = 0.0
    var steerAngleSmoothed = 0.0
    var pivotErrorTotal = 0.0
    var distSteerError = 0.0
    var lastDistSteerError = 0.0
    var derivativeDistError = 0.0

    var resumeState = 0

    private var starPathIndx = 0

    var trig = false
    var north = 0.0
    var pathCount = 0

    fun StartDrivingRecordedPath(): Boolean {
        //create the dubins path based on start and goal to start of recorded path
        A = 0
        B = 0
        C = 0

        if (recList.size < 5) return false

        //save a copy of where we started.
        homePos = mf.pivotAxlePos

        // Try to find the nearest point of the recorded path in relation to the current position:
        var distance = Double.MAX_VALUE
        var idx = 0
        var i = 0

        when (resumeState) {
            0 -> { //start at the start
                currentPositonIndex = 0
                idx = 0
                starPathIndx = 0
            }
            1 -> { //resume from where stopped mid path
                if (currentPositonIndex + 5 > recList.size) {
                    currentPositonIndex = 0
                    idx = 0
                    starPathIndx = 0
                } else {
                    idx = starPathIndx
                    starPathIndx = currentPositonIndex
                }
            }
            else -> { //find closest point
                for (pt in recList) {
                    val temp = (pt.easting - homePos.easting) * (pt.easting - homePos.easting) +
                            (pt.northing - homePos.northing) * (pt.northing - homePos.northing)

                    if (temp < distance) {
                        distance = temp
                        idx = i
                    }
                    i++
                }

                //scootch down the line a bit
                if (idx + 5 < recList.size) idx += 5
                else idx = recList.size - 1

                starPathIndx = currentPositonIndex
                currentPositonIndex = idx
            }
        }

        //the goal is the first point of path, the start is the current position
        val goal = Vec3(recList[idx].easting, recList[idx].northing, recList[idx].heading)

        //get the dubins for approach to recorded path
        GetDubinsPath(goal)
        shuttleListCount = shuttleDubinsList.size

        //has a valid dubins path been created?
        if (shuttleListCount == 0) return false

        //technically all good if we get here so set all the flags
        isFollowingDubinsHome = false
        isFollowingRecPath = false
        isFollowingDubinsToPath = true
        isEndOfTheRecLine = false
        isDrivingRecordedPath = true
        return true
    }

    fun UpdatePosition() {
        when {
            isFollowingDubinsToPath -> {
                //set a speed of 10 kmh
                mf.sim.stepDistance = shuttleDubinsList[C].speed / 50

                pivotAxlePosRP = mf.pivotAxlePos

                PurePursuitDubins(shuttleListCount)

                //check if close to recorded path
                val cnt = shuttleDubinsList.size
                pathCount = cnt - B
                if (pathCount < 8) {
                    val distSqr = glm.DistanceSquared(
                        pivotAxlePosRP.northing, pivotAxlePosRP.easting,
                        recList[starPathIndx].northing, recList[starPathIndx].easting
                    )
                    if (distSqr < 2) {
                        isFollowingRecPath = true
                        isFollowingDubinsToPath = false
                        shuttleDubinsList.clear()
                        shortestDubinsList.clear()
                        C = starPathIndx
                        A = C + 3
                        B = A + 1
                    }
                }
            }
            isFollowingRecPath -> {
                pivotAxlePosRP = mf.pivotAxlePos

                PurePursuitRecPath(recList.size)

                //if end of the line then stop
                if (!isEndOfTheRecLine) {
                    mf.sim.stepDistance = recList[C].speed / 34.86
                    north = recList[C].northing

                    pathCount = recList.size - C

                    //section control - only if different click the button
                    val autoBtn = mf.autoBtnState == BtnStates.AUTO
                    trig = autoBtn
                    if (autoBtn != recList[C].autoBtnState) mf.btnSectionMasterAuto.performClick()
                } else {
                    StopDrivingRecordedPath()
                    return
                }
            }
            isFollowingDubinsHome -> {
                val cnt = shuttleDubinsList.size
                pathCount = cnt - B
                if (pathCount < 3) {
                    StopDrivingRecordedPath()
                    return
                }

                mf.sim.stepDistance = shuttleDubinsList[C].speed / 35
                pivotAxlePosRP = mf.pivotAxlePos

                PurePursuitDubins(shuttleListCount)
            }
        }
    }

    fun StopDrivingRecordedPath() {
        isFollowingDubinsHome = false
        isFollowingRecPath = false
        isFollowingDubinsToPath = false
        shuttleDubinsList.clear()
        shortestDubinsList.clear()
        mf.sim.stepDistance = 0.0
        isDrivingRecordedPath = false
        mf.btnPathGoStop.setImageResource(R.drawable.boundary_play)
        mf.btnPathRecordStop.isEnabled = true
        mf.btnPickPath.isEnabled = true
        mf.btnResumePath.isEnabled = true
    }

    private fun GetDubinsPath(goal: Vec3) {
        CDubins.turningRadius = mf.yt.youTurnRadius * 1.2
        val dubPath = CDubins(mf.settings)

        // current position
        pivotAxlePosRP = mf.pivotAxlePos

        //bump it forward
        val pt2 = Vec3(
            pivotAxlePosRP.easting + (sin(pivotAxlePosRP.heading) * 3),
            pivotAxlePosRP.northing + (cos(pivotAxlePosRP.heading) * 3),
            pivotAxlePosRP.heading
        )

        //get the dubins path Vec3 point coordinates of turn
        shortestDubinsList.clear()
        shuttleDubinsList.clear()

        shortestDubinsList = dubPath.GenerateDubins(pt2, goal).toMutableList()

        //if Dubins returns 0 elements, there is an unavoidable blockage in the way.
        if (shortestDubinsList.isNotEmpty()) {
            shortestDubinsList.add(0, mf.pivotAxlePos)

            //transfer point list to recPath class point style
            for (pt in shortestDubinsList) {
                val recPt = CRecPathPt(pt.easting, pt.northing, pt.heading, 9.0, false)
                shuttleDubinsList.add(recPt)
            }
        }
    }

    private fun PurePursuitRecPath(ptCount: Int) {
        //find the closest 2 points to current fix
        var minDistA = 9999999999.0
        var dist: Double
        var dx: Double
        var dz: Double

        //set the search range close to current position
        var top = currentPositonIndex + 5
        if (top > ptCount) top = ptCount

        for (t in currentPositonIndex until top) {
            dist = (pivotAxlePosRP.easting - recList[t].easting) * (pivotAxlePosRP.easting - recList[t].easting) +
                    (pivotAxlePosRP.northing - recList[t].northing) * (pivotAxlePosRP.northing - recList[t].northing)
            if (dist < minDistA) {
                minDistA = dist
                A = t
            }
        }

        //Save the closest point
        C = A

        //next point is the next in list
        B = A + 1
        if (B == ptCount) {
            //don't go past the end of the list - "end of the line" trigger
            A--
            B--
            isEndOfTheRecLine = true
        }

        //save current position
        currentPositonIndex = A

        //get the distance from currently active AB line
        dx = recList[B].easting - recList[A].easting
        dz = recList[B].northing - recList[A].northing

        if (abs(dx) < Double.MIN_VALUE && abs(dz) < Double.MIN_VALUE) return

        //how far from current AB Line is fix
        distanceFromCurrentLinePivot = (dz * pivotAxlePosRP.easting - dx * pivotAxlePosRP.northing + recList[B].easting *
                recList[A].northing - recList[B].northing * recList[A].easting) / sqrt(dz * dz + dx * dx)

        //integral slider is set to 0
        if (mf.vehicle.purePursuitIntegralGain != 0.0) {
            pivotDistanceError = distanceFromCurrentLinePivot * 0.2 + pivotDistanceError * 0.8

            if (counter2++ > 4) {
                pivotDerivative = pivotDistanceError - pivotDistanceErrorLast
                pivotDistanceErrorLast = pivotDistanceError
                counter2 = 0
                pivotDerivative *= 2.0
            }

            if (isFollowingRecPath && abs(pivotDerivative) < 0.1 && mf.avgSpeed > 2.5) {
                //if over the line heading wrong way, rapidly decrease integral
                if (inty < 0 && distanceFromCurrentLinePivot < 0 || inty > 0 && distanceFromCurrentLinePivot > 0) {
                    inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.04
                } else {
                    if (abs(distanceFromCurrentLinePivot) > 0.02) {
                        inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.02
                        if (inty > 0.2) inty = 0.2
                        else if (inty < -0.2) inty = -0.2
                    }
                }
            } else inty *= 0.95
        } else inty = 0.0

        if (mf.isReverse) inty = 0.0

        // ** Pure pursuit ** - calc point on ABLine closest to current position
        val U = (pivotAxlePosRP.easting - recList[A].easting) * dx + (pivotAxlePosRP.northing - recList[A].northing) * dz /
                (dx * dx + dz * dz)

        rEastRP = recList[A].easting + U * dx
        rNorthRP = recList[A].northing + U * dz

        //update base on autosteer settings and distance from line
        val goalPointDistance = mf.vehicle.UpdateGoalPointDistance()

        val ReverseHeading = !mf.isReverse

        val count = if (ReverseHeading) 1 else -1
        var start = CRecPathPt(rEastRP, rNorthRP, 0.0, 0.0, false)
        var distSoFar = 0.0

        var i = if (ReverseHeading) B else A
        while (i in 0..<ptCount) {
            // used for calculating the length squared of next segment.
            val tempDist = sqrt(
                (start.easting - recList[i].easting) * (start.easting - recList[i].easting) +
                        (start.northing - recList[i].northing) * (start.northing - recList[i].northing)
            )

            //will we go too far?
            if (tempDist + distSoFar > goalPointDistance) {
                val j = (goalPointDistance - distSoFar) / tempDist // the remainder to yet travel

                goalPointRP.easting = (1 - j) * start.easting + j * recList[i].easting
                goalPointRP.northing = (1 - j) * start.northing + j * recList[i].northing
                break
            } else distSoFar += tempDist
            start = recList[i]
            i += count
        }

        //calc "D" the distance from pivotAxlePosRP axle to lookahead point
        val goalPointDistanceSquared = glm.DistanceSquared(
            goalPointRP.northing, goalPointRP.easting,
            pivotAxlePosRP.northing, pivotAxlePosRP.easting
        )

        //calculate the the delta x in local coordinates and steering angle degrees based on wheelbase
        val localHeading = glm.TWO_PI - mf.fixHeading + inty

        ppRadiusRP = goalPointDistanceSquared / (2 * ((goalPointRP.easting - pivotAxlePosRP.easting) * cos(localHeading) +
                (goalPointRP.northing - pivotAxlePosRP.northing) * sin(localHeading)))

        steerAngleRP = glm.toDegrees(
            atan(
                2 * ((goalPointRP.easting - pivotAxlePosRP.easting) * cos(localHeading) +
                        (goalPointRP.northing - pivotAxlePosRP.northing) * sin(localHeading)) * mf.vehicle.wheelbase /
                        goalPointDistanceSquared
            )
        )

        if (steerAngleRP < -mf.vehicle.maxSteerAngle) steerAngleRP = -mf.vehicle.maxSteerAngle
        if (steerAngleRP > mf.vehicle.maxSteerAngle) steerAngleRP = mf.vehicle.maxSteerAngle

        //used for smooth mode
        mf.vehicle.modeActualXTE = distanceFromCurrentLinePivot

        //Convert to centimeters
        mf.guidanceLineDistanceOff = (distanceFromCurrentLinePivot * 1000.0).roundToInt().toShort()
        mf.guidanceLineSteerAngle = (steerAngleRP * 100).roundToInt().toShort()
    }

    private fun PurePursuitDubins(ptCount: Int) {
        var dist: Double
        var dx: Double
        var dz: Double
        var minDistA = 1000000.0
        var minDistB = 1000000.0

        //find the closest 2 points to current fix
        for (t in 0 until ptCount) {
            dist = (pivotAxlePosRP.easting - shuttleDubinsList[t].easting) * (pivotAxlePosRP.easting - shuttleDubinsList[t].easting) +
                    (pivotAxlePosRP.northing - shuttleDubinsList[t].northing) * (pivotAxlePosRP.northing - shuttleDubinsList[t].northing)
            if (dist < minDistA) {
                minDistB = minDistA
                B = A
                minDistA = dist
                A = t
            } else if (dist < minDistB) {
                minDistB = dist
                B = t
            }
        }

        //just need to make sure the points continue ascending or heading switches all over the place
        if (A > B) {
            C = A
            A = B
            B = C
        }

        //get the distance from currently active AB line
        dx = shuttleDubinsList[B].easting - shuttleDubinsList[A].easting
        dz = shuttleDubinsList[B].northing - shuttleDubinsList[A].northing

        if (abs(dx) < Double.MIN_VALUE && abs(dz) < Double.MIN_VALUE) return

        //how far from current AB Line is fix
        distanceFromCurrentLinePivot = (dz * pivotAxlePosRP.easting - dx * pivotAxlePosRP.northing + shuttleDubinsList[B].easting *
                shuttleDubinsList[A].northing - shuttleDubinsList[B].northing * shuttleDubinsList[A].easting) / sqrt(dz * dz + dx * dx)

        //integral slider is set to 0
        if (mf.vehicle.purePursuitIntegralGain != 0.0) {
            pivotDistanceError = distanceFromCurrentLinePivot * 0.2 + pivotDistanceError * 0.8

            if (counter2++ > 4) {
                pivotDerivative = pivotDistanceError - pivotDistanceErrorLast
                pivotDistanceErrorLast = pivotDistanceError
                counter2 = 0
                pivotDerivative *= 2.0
            }

            if (mf.isBtnAutoSteerOn && abs(pivotDerivative) < 0.1 && mf.avgSpeed > 2.5 && !mf.yt.isYouTurnTriggered) {
                //if over the line heading wrong way, rapidly decrease integral
                if (inty < 0 && distanceFromCurrentLinePivot < 0 || inty > 0 && distanceFromCurrentLinePivot > 0) {
                    inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.04
                } else {
                    if (abs(distanceFromCurrentLinePivot) > 0.02) {
                        inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.02
                        if (inty > 0.2) inty = 0.2
                        else if (inty < -0.2) inty = -0.2
                    }
                }
            } else inty *= 0.95
        } else inty = 0.0

        if (mf.isReverse) inty = 0.0

        // ** Pure pursuit ** - calc point on ABLine closest to current position
        val U = (pivotAxlePosRP.easting - shuttleDubinsList[A].easting) * dx + (pivotAxlePosRP.northing - shuttleDubinsList[A].northing) * dz /
                (dx * dx + dz * dz)

        rEastRP = shuttleDubinsList[A].easting + U * dx
        rNorthRP = shuttleDubinsList[A].northing + U * dz

        //update base on autosteer settings and distance from line
        val goalPointDistance = mf.vehicle.UpdateGoalPointDistance()

        val ReverseHeading = !mf.isReverse

        val count = if (ReverseHeading) 1 else -1
        var start = CRecPathPt(rEastRP, rNorthRP, 0.0, 0.0, false)
        var distSoFar = 0.0

        var i = if (ReverseHeading) B else A
        while (i < ptCount && i >= 0) {
            // used for calculating the length squared of next segment.
            val tempDist = sqrt(
                (start.easting - shuttleDubinsList[i].easting) * (start.easting - shuttleDubinsList[i].easting) +
                        (start.northing - shuttleDubinsList[i].northing) * (start.northing - shuttleDubinsList[i].northing)
            )

            //will we go too far?
            if (tempDist + distSoFar > goalPointDistance) {
                val j = (goalPointDistance - distSoFar) / tempDist // the remainder to yet travel

                goalPointRP.easting = (1 - j) * start.easting + j * shuttleDubinsList[i].easting
                goalPointRP.northing = (1 - j) * start.northing + j * shuttleDubinsList[i].northing
                break
            } else distSoFar += tempDist
            start = shuttleDubinsList[i]
            i += count
        }

        //calc "D" the distance from pivotAxlePosRP axle to lookahead point
        val goalPointDistanceSquared = glm.DistanceSquared(
            goalPointRP.northing, goalPointRP.easting,
            pivotAxlePosRP.northing, pivotAxlePosRP.easting
        )

        //calculate the the delta x in local coordinates and steering angle degrees based on wheelbase
        val localHeading = glm.TWO_PI - mf.fixHeading + inty

        ppRadiusRP = goalPointDistanceSquared / (2 * ((goalPointRP.easting - pivotAxlePosRP.easting) * cos(localHeading) +
                (goalPointRP.northing - pivotAxlePosRP.northing) * sin(localHeading)))

        steerAngleRP = glm.toDegrees(
            atan(
                2 * ((goalPointRP.easting - pivotAxlePosRP.easting) * cos(localHeading) +
                        (goalPointRP.northing - pivotAxlePosRP.northing) * sin(localHeading)) * mf.vehicle.wheelbase /
                        goalPointDistanceSquared
            )
        )

        if (steerAngleRP < -mf.vehicle.maxSteerAngle) steerAngleRP = -mf.vehicle.maxSteerAngle
        if (steerAngleRP > mf.vehicle.maxSteerAngle) steerAngleRP = mf.vehicle.maxSteerAngle

        if (ppRadiusRP < -500) ppRadiusRP = -500.0
        if (ppRadiusRP > 500) ppRadiusRP = 500.0

        radiusPointRP.easting = pivotAxlePosRP.easting + ppRadiusRP * cos(localHeading)
        radiusPointRP.northing = pivotAxlePosRP.northing + ppRadiusRP * sin(localHeading)

        //Convert to centimeters
        mf.guidanceLineDistanceOff = (distanceFromCurrentLinePivot * 1000.0).roundToInt().toShort()
        mf.guidanceLineSteerAngle = (steerAngleRP * 100).roundToInt().toShort()
    }

    fun DrawRecordedLine() {
        val ptCount = recList.size
        if (ptCount < 1) return
        GLES20.glLineWidth(1f)
        GLES20.glColor4f(0.98f, 0.92f, 0.460f, 1f)
        GLES20.glBegin(GLES20.GL_LINE_STRIP)
        for (h in 0 until ptCount) {
            GLES20.glVertex3f(recList[h].easting.toFloat(), recList[h].northing.toFloat(), 0f)
        }
        GLES20.glEnd()

        if (!isRecordOn) {
            //Draw lookahead Point
            GLES20.glPointSize(16f)
            GLES20.glBegin(GLES20.GL_POINTS)
            GLES20.glColor4f(1.0f, 0.5f, 0.95f, 1f)
            GLES20.glVertex3f(
                recList[currentPositonIndex].easting.toFloat(),
                recList[currentPositonIndex].northing.toFloat(),
                0f
            )
            GLES20.glEnd()
            GLES20.glPointSize(1f)
        }
    }

    fun DrawDubins() {
        if (shuttleDubinsList.size > 1) {
            GLES20.glPointSize(2f)
            GLES20.glColor4f(0.298f, 0.96f, 0.2960f, 1f)
            GLES20.glBegin(GLES20.GL_POINTS)
            for (h in shuttleDubinsList.indices) {
                GLES20.glVertex3f(
                    shuttleDubinsList[h].easting.toFloat(),
                    shuttleDubinsList[h].northing.toFloat(),
                    0f
                )
            }
            GLES20.glEnd()
        }
    }
}