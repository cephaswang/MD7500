package com.agopengps.classes

import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import kotlin.math.*

enum class TrackMode { None, AB, Curve, BndTrackOuter, BndTrackInner, BndCurve, WaterPivot }

class CTrack(private val mf: FormGPS) {
    private lateinit var mMap: GoogleMap // GoogleMap instance as per request

    val gArr = mutableListOf<CTrk>()
    var idx: Int = -1
    var autoTrack3SecTimer: Int = 0

    var isLine: Boolean = false
    var isAutoTrack: Boolean = false
    var isAutoSnapToPivot: Boolean = false
    var isAutoSnapped: Boolean = false

    // Function to set the GoogleMap instance
    fun setMap(map: GoogleMap) {
        mMap = map
    }

    fun findClosestRefTrack(pivot: vec3): Int {
        if (idx < 0 || gArr.isEmpty()) return -1

        if (gArr.size == 1) return idx

        var trak = -1
        var cntr = 0

        for (i in gArr.indices) {
            if (gArr[i].isVisible) {
                cntr++
                trak = i
            }
        }

        if (cntr == 1) return trak
        if (cntr == 0) return -1

        val isAlignedArr = BooleanArray(gArr.size)
        for (i in gArr.indices) {
            isAlignedArr[i] = if (gArr[i].mode == TrackMode.Curve) {
                true
            } else {
                val diff = Math.PI - abs(abs(pivot.heading - gArr[i].heading) - Math.PI)
                diff < 1 || diff > 2.14
            }
        }

        var minDistA = Double.MAX_VALUE
        var dist: Double

        for (i in gArr.indices) {
            if (!isAlignedArr[i] || !gArr[i].isVisible) continue

            when (gArr[i].mode) {
                TrackMode.AB -> {
                    val abHeading = gArr[i].heading

                    val endPtA = vec2(
                        easting = gArr[i].ptA.easting - (sin(abHeading) * 2000),
                        northing = gArr[i].ptA.northing - (cos(abHeading) * 2000)
                    )
                    val endPtB = vec2(
                        easting = gArr[i].ptB.easting + (sin(abHeading) * 2000),
                        northing = gArr[i].ptB.northing + (cos(abHeading) * 2000)
                    )

                    val dx = endPtB.easting - endPtA.easting
                    val dy = endPtB.northing - endPtA.northing

                    dist = ((dy * mf.steerAxlePos.easting) - (dx * mf.steerAxlePos.northing) +
                            (endPtB.easting * endPtA.northing) - (endPtB.northing * endPtA.easting)) /
                            sqrt((dy * dy) + (dx * dx))

                    dist *= dist

                    if (dist < minDistA) {
                        minDistA = dist
                        trak = i
                    }
                }
                else -> {
                    for (j in gArr[i].curvePts.indices) {
                        dist = glm.distanceSquared(gArr[i].curvePts[j], pivot)
                        if (dist < minDistA) {
                            minDistA = dist
                            trak = i
                        }
                    }
                }
            }
        }
        return trak
    }

    fun nudgeTrack(dist: Double) {
        if (idx > -1) {
            when (gArr[idx].mode) {
                TrackMode.AB -> {
                    mf.ABLine.isABValid = false
                    gArr[idx].nudgeDistance += if (mf.ABLine.isHeadingSameWay) dist else -dist
                }
                else -> {
                    mf.curve.isCurveValid = false
                    gArr[idx].nudgeDistance += if (mf.curve.isHeadingSameWay) dist else -dist
                }
            }
            drawTrackOnMap() // Redraw the updated track
        }
    }

    fun nudgeDistanceReset() {
        if (idx > -1 && gArr.isNotEmpty()) {
            when (gArr[idx].mode) {
                TrackMode.AB -> mf.ABLine.isABValid = false
                else -> mf.curve.isCurveValid = false
            }
            gArr[idx].nudgeDistance = 0.0
            drawTrackOnMap()
        }
    }

    fun snapToPivot() {
        if (idx > -1) {
            nudgeTrack(
                if (gArr[idx].mode == TrackMode.AB) mf.ABLine.distanceFromCurrentLinePivot
                else mf.curve.distanceFromCurrentLinePivot
            )
        }
    }

    fun nudgeRefTrack(dist: Double) {
        if (idx > -1) {
            when (gArr[idx].mode) {
                TrackMode.AB -> {
                    mf.ABLine.isABValid = false
                    nudgeRefABLine(if (mf.ABLine.isHeadingSameWay) dist else -dist)
                }
                else -> {
                    mf.curve.isCurveValid = false
                    nudgeRefCurve(if (mf.curve.isHeadingSameWay) dist else -dist)
                }
            }
            drawTrackOnMap()
        }
    }

    private fun nudgeRefABLine(dist: Double) {
        val head = gArr[idx].heading
        gArr[idx].ptA.easting += (sin(head + glm.piBy2) * dist)
        gArr[idx].ptA.northing += (cos(head + glm.piBy2) * dist)
        gArr[idx].ptB.easting += (sin(head + glm.piBy2) * dist)
        gArr[idx].ptB.northing += (cos(head + glm.piBy2) * dist)
    }

    private fun nudgeRefCurve(distAway: Double) {
        mf.curve.isCurveValid = false
        val curList = mutableListOf<vec3>()
        val distSqAway = (distAway * distAway) - 0.01

        for (i in gArr[idx].curvePts.indices) {
            val point = vec3(
                easting = gArr[idx].curvePts[i].easting + (sin(glm.piBy2 + gArr[idx].curvePts[i].heading) * distAway),
                northing = gArr[idx].curvePts[i].northing + (cos(glm.piBy2 + gArr[idx].curvePts[i].heading) * distAway),
                heading = gArr[idx].curvePts[i].heading
            )
            var add = true

            for (t in gArr[idx].curvePts.indices) {
                val dist = ((point.easting - gArr[idx].curvePts[t].easting).pow(2) +
                        (point.northing - gArr[idx].curvePts[t].northing).pow(2))
                if (dist < distSqAway) {
                    add = false
                    break
                }
            }

            if (add) {
                if (curList.isNotEmpty()) {
                    val dist = ((point.easting - curList.last().easting).pow(2) +
                            (point.northing - curList.last().northing).pow(2))
                    if (dist > 1.0) curList.add(point)
                } else curList.add(point)
            }
        }

        if (curList.size > 6) {
            val arr = curList.toTypedArray()
            curList.clear()

            for (i in 0 until arr.size - 1) {
                arr[i].heading = atan2(arr[i + 1].easting - arr[i].easting, arr[i + 1].northing - arr[i].northing)
                if (arr[i].heading < 0) arr[i].heading += glm.twoPI
                if (arr[i].heading >= glm.twoPI) arr[i].heading -= glm.twoPI
            }
            arr[arr.size - 1].heading = arr[arr.size - 2].heading

            val cnt = arr.size
            val spacing = 1.2

            curList.add(arr[0])
            for (i in 0 until cnt - 3) {
                curList.add(arr[i + 1])
                val distance = glm.distance(arr[i + 1], arr[i + 2])
                if (distance > spacing) {
                    val loopTimes = (distance / spacing + 1).toInt()
                    for (j in 1 until loopTimes) {
                        val pos = vec3(glm.catmull(j.toDouble() / loopTimes, arr[i], arr[i + 1], arr[i + 2], arr[i + 3]))
                        curList.add(pos)
                    }
                }
            }
            curList.add(arr[cnt - 2])
            curList.add(arr[cnt - 1])

            mf.curve.CalculateHeadings(curList)

            gArr[idx].curvePts.clear()
            gArr[idx].curvePts.addAll(curList)
        }
    }

    // Draw the track on Google Maps
    private fun drawTrackOnMap() {
        if (!this::mMap.isInitialized || idx < 0 || gArr.isEmpty()) return

        mMap.clear() // Clear previous drawings
        val track = gArr[idx]

        when (track.mode) {
            TrackMode.AB -> {
                val polyline = PolylineOptions()
                    .add(LatLng(track.ptA.northing, track.ptA.easting))
                    .add(LatLng(track.ptB.northing, track.ptB.easting))
                    .color(android.graphics.Color.BLUE)
                    .width(5f)
                mMap.addPolyline(polyline)
            }
            TrackMode.Curve -> {
                val polyline = PolylineOptions()
                track.curvePts.forEach { point ->
                    polyline.add(LatLng(point.northing, point.easting))
                }
                polyline.color(android.graphics.Color.RED).width(5f)
                mMap.addPolyline(polyline)
            }
            else -> {}
        }
    }
}



