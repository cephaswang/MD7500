package tw.ibiz.gpsinfo

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class ListSurveyingActivity : AppCompatActivity() {

    private lateinit var dbHelper: SurveyingDBHelper
    private lateinit var db: SQLiteDatabase
    private lateinit var linearLayout: LinearLayout
    private lateinit var editTextOwner: EditText
    private var selectedRecordView: View? = null // 當前選中的記錄視圖
    private var listArray: MutableList<String> = mutableListOf() // 全域變量，記錄陣列 ListArray[JsonString]

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_surveying)

        // 初始化視圖
        linearLayout = findViewById(R.id.linearLayout)
        editTextOwner = findViewById(R.id.editTextOwner)

        // 初始化數據庫
        dbHelper = SurveyingDBHelper(this)
        db = dbHelper.readableDatabase

        // 設置 ImageView 按鈕事件
        findViewById<ImageView>(R.id.buttonExit).setOnClickListener {
            finish() // 結束 Activity
        }

        findViewById<ImageView>(R.id.buttonQuery).setOnClickListener {
            queryData() // 查詢資料表
        }

        findViewById<ImageView>(R.id.buttonPrintNewRecord).setOnClickListener {
            // 跳轉到 SurveyingActivity
            val intent = Intent(this, SurveyingActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onStart() {
        super.onStart()
        // 刷新頁面，重新載入查詢記錄
        queryData()
    }

    private fun queryData() {
        val owner = editTextOwner.text.toString()
        val query: String
        val selectionArgs: Array<String>?

        if (owner.isNotEmpty()) {
            query = "SELECT * FROM ${SurveyingDBHelper.TABLE_NAME} WHERE ${SurveyingDBHelper.COLUMN_OWNER} LIKE ?"
            selectionArgs = arrayOf("%$owner%")
        } else {
            query = "SELECT * FROM ${SurveyingDBHelper.TABLE_NAME}"
            selectionArgs = null
        }

        val cursor = db.rawQuery(query, selectionArgs)

        // 清空之前的列表
        linearLayout.removeAllViews()
        selectedRecordView = null // 重置選中的記錄視圖
        listArray.clear() // 清空記錄陣列

        // 顯示查詢結果
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_ID))
                val owner = cursor.getString(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_OWNER))
                val location = cursor.getString(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_LOCATION))
                val areaFen = cursor.getDouble(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_AREA_FEN))
                val coordinatesJson = cursor.getString(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_COORDINATES))
                val createdAt = cursor.getString(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_CREATED_AT))
                val zoom = cursor.getFloat(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_ZOOM))
                val center = cursor.getString(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_CENTER))
                val bearing = cursor.getFloat(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_BEARING))
                val areaSqm = cursor.getDouble(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_AREA_SQM))
                val areaPing = cursor.getDouble(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_AREA_PING))

                // 格式化 area_fen 為 %.04f
                val formattedAreaFen = String.format(Locale.getDefault(), "%.04f", areaFen)

                // 將完整記錄轉換為 JSON 並添加到 listArray
                val recordJson = """
                    {
                        "id": $id,
                        "owner": "$owner",
                        "location": "$location",
                        "area_fen": $areaFen,
                        "coordinates": $coordinatesJson,
                        "created_at": "$createdAt",
                        "zoom": $zoom,
                        "center": $center,
                        "bearing": $bearing,
                        "area_sqm": $areaSqm,
                        "area_ping": $areaPing
                    }
                """.trimIndent()
                listArray.add(recordJson)

                // 創建並添加記錄視圖
                val recordView = createRecordView(id, owner, location, formattedAreaFen, coordinatesJson)
                linearLayout.addView(recordView)
            } while (cursor.moveToNext())
        }

        cursor.close()
    }

    private fun createRecordView(
        id: Int,
        owner: String,
        location: String,
        areaFen: String,
        coordinates: String
    ): View {
        val recordView = TextView(this).apply {
            text = "流水號: $id, 業主: $owner, 地點: $location, 面積[分地]: $areaFen"
            setPadding(32, 16, 32, 16)
            setBackgroundColor(if (id % 2 == 0) 0xFFDDDDDD.toInt() else 0xFFEEEEEE.toInt()) // 單雙列交替底色
            setOnClickListener {
                // 選取列時改變底色
                selectedRecordView?.setBackgroundColor(if ((selectedRecordView?.tag as Int) % 2 == 0) 0xFFDDDDDD.toInt() else 0xFFEEEEEE.toInt())
                setBackgroundColor(Color.CYAN) // 選中底色
                selectedRecordView = this

                // 獲取點擊的記錄索引
                val index = linearLayout.indexOfChild(this)
                if (index != -1 && index < listArray.size) {
                    // 打印欄位記錄
                    printRecord(index, listArray[index])
                }
            }
            tag = id // 設置標籤以便區分單雙列
        }

        return recordView
    }

    private fun printRecord(index: Int, recordJson: String) {
        // 解析 JSON 記錄
        val jsonObject = org.json.JSONObject(recordJson)

        // 提取需要的欄位
        val owner = jsonObject.getString("owner")
        val location = jsonObject.getString("location")
        val areaFen = jsonObject.getDouble("area_fen")
        val center = jsonObject.getString("center")
        val bearing = jsonObject.getDouble("bearing")
        val zoom = jsonObject.getDouble("zoom")
        val coordinates = jsonObject.getString("coordinates")

        // 格式化 area_fen 為 %.04f
        val formattedAreaFen = String.format(Locale.getDefault(), "%.04f", areaFen)

        // 打印欄位記錄
        println("打印記錄: 流水號=${index + 1}")
        println("業主: $owner")
        println("地點: $location")
        println("面積[分地]: $formattedAreaFen")
        println("中心座標: $center")
        println("傾角: $bearing")
        println("縮放比: $zoom")
        println("座標列表: $coordinates")
        println("完整 JSON 記錄: $recordJson")

        // 跳轉到 RouteActivity
        val intent = Intent(this, RouteActivity::class.java)
        intent.putExtra("PointsJsonString", coordinates)
        intent.putExtra("bearing", bearing)
        intent.putExtra("center", center)
        intent.putExtra("zoom", zoom)
        startActivity(intent)
    }

    override fun onDestroy() {
        db.close()
        dbHelper.close()
        super.onDestroy()
    }
}