package `0305`

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolygonOptions
import com.google.android.gms.maps.model.PolylineOptions
import org.json.JSONArray
import android.graphics.Color
import com.google.android.gms.maps.model.LatLngBounds
import kotlin.math.*

class RouteActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var edtVehicleWidth: EditText
    private lateinit var edtVehicleLength: EditText
    private lateinit var edtPathOverlap: EditText
    private lateinit var btnGeneratePath: Button
    private lateinit var btnClear: Button
    private lateinit var dbHelper: RouteDBHelper

    private var fieldCoordinates = ArrayList<LatLng>()
    private var generatedPaths = ArrayList<ArrayList<LatLng>>()

    private lateinit var pointsJsonString: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_route)

        // 獲取傳遞過來的參數
        pointsJsonString = intent.getStringExtra("PointsJsonString").toString()

        // 你可以使用 PointsJsonString 進行後續操作
        println("Received PointsJsonString: $pointsJsonString")


        // Initialize UI components
        edtVehicleWidth = findViewById(R.id.edt_vehicle_width)
        edtVehicleLength = findViewById(R.id.edt_vehicle_length)
        edtPathOverlap = findViewById(R.id.edt_path_overlap)
        btnGeneratePath = findViewById(R.id.btn_generate_path)
        btnClear = findViewById(R.id.btn_clear)

        // Set default values
        edtVehicleWidth.setText("2.0")
        edtVehicleLength.setText("2.0")
        edtPathOverlap.setText("0.3")

        // Initialize database helper
        dbHelper = RouteDBHelper(this)

        // Initialize map
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        // Set button click listeners
        btnGeneratePath.setOnClickListener {
            generateRoutePath()
        }

        btnClear.setOnClickListener {
            clearGeneratedPaths()
        }

        // Load route points from intent or example
        loadRoutePoints()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Enable zoom controls and compass
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isCompassEnabled = true
        mMap.uiSettings.isRotateGesturesEnabled = true
        mMap.uiSettings.isZoomGesturesEnabled = true

        // Draw initial field boundary if data exists
        drawFieldBoundary()
    }

    private fun loadRoutePoints() {
        try {
            // Example JSON string from requirements
           // val jsonString = "[{\"latitude\":24.313921051943023,\"longitude\":120.66187217831612},{\"latitude\":24.31415906600008,\"longitude\":120.66204082220794},{\"latitude\":24.313785698435336,\"longitude\":120.66240526735783},{\"latitude\":24.313453272051635,\"longitude\":120.66231105476618},{\"latitude\":24.313690675909076,\"longitude\":120.66218264400958},{\"latitude\":24.313495130936506,\"longitude\":120.66192850470541}]"

            val jsonArray = JSONArray(pointsJsonString)
            fieldCoordinates.clear()

            for (i in 0 until jsonArray.length()) {
                val point = jsonArray.getJSONObject(i)
                val latitude = point.getDouble("latitude")
                val longitude = point.getDouble("longitude")
                fieldCoordinates.add(LatLng(latitude, longitude))
            }

            // Save to database
            saveRoutePointsToDB()

        } catch (e: Exception) {
            Toast.makeText(this, "Error parsing route data: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveRoutePointsToDB() {
        val db = dbHelper.writableDatabase

        // Clear existing points first
        db.delete("route_points", null, null)

        // Insert new points
        for (point in fieldCoordinates) {
            val values = android.content.ContentValues().apply {
                put("latitude", point.latitude)
                put("longitude", point.longitude)
            }
            db.insert("route_points", null, values)
        }
        db.close()
    }

    private fun drawFieldBoundary() {
        if (fieldCoordinates.isEmpty() || !::mMap.isInitialized) return

        // Clear previous boundary
        mMap.clear()

        // Create polygon options for the field boundary
        val polygonOptions = PolygonOptions()
            .addAll(fieldCoordinates)
            .strokeColor(Color.RED)
            .strokeWidth(5f)
            .fillColor(Color.argb(30, 255, 0, 0))

        // Add the polygon to the map
        mMap.addPolygon(polygonOptions)

        // Move camera to field center and zoom appropriately
        centerMapOnField()
    }

    private fun centerMapOnField() {
        if (fieldCoordinates.isEmpty()) return

        val boundsBuilder = LatLngBounds.Builder()
        for (point in fieldCoordinates) {
            boundsBuilder.include(point)
        }

        val bounds = boundsBuilder.build()
        val padding = 100 // offset from edges of the map in pixels

        val cameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, padding)
        mMap.animateCamera(cameraUpdate)
    }

    private fun generateRoutePath() {
        if (fieldCoordinates.size < 3) {
            Toast.makeText(this, "需要至少三個座標點來生成路徑", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val vehicleWidth = edtVehicleWidth.text.toString().toFloat()
            val vehicleLength = edtVehicleLength.text.toString().toFloat()
            val pathOverlap = edtPathOverlap.text.toString().toFloat()

            // Generate the path
            generatedPaths = generateSpiralPath(fieldCoordinates, vehicleWidth, pathOverlap)

            // Draw the path on the map
            drawGeneratedPaths()

            // Adjust map to center on the field
            mMap.animateCamera(CameraUpdateFactory.zoomTo(20f))

        } catch (e: Exception) {
            Toast.makeText(this, "生成路徑時發生錯誤: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun generateSpiralPath(
        boundaryPoints: ArrayList<LatLng>,
        vehicleWidth: Float,
        pathOverlap: Float
    ): ArrayList<ArrayList<LatLng>> {
        val paths = ArrayList<ArrayList<LatLng>>()
        var currentBoundary = ArrayList(boundaryPoints)

        // Calculate effective width (vehicle width minus overlap)
        val effectiveWidth = vehicleWidth - pathOverlap

        // Convert vehicle width from meters to degrees (approximate)
        val metersToDegreesLat = 1.0 / (111111.0) // approximate conversion
        val effectiveWidthDegrees = effectiveWidth * metersToDegreesLat

        // Generate spiral paths until we can't anymore
        var iteration = 0
        val maxIterations = 100 // Safety limit

        while (currentBoundary.size >= 3 && iteration < maxIterations) {
            // Add current boundary as a path
            paths.add(ArrayList(currentBoundary))

            // Generate inner boundary for next path
            val innerBoundary = generateInnerBoundary(currentBoundary, effectiveWidthDegrees)

            // If inner boundary is too small or invalid, break
            if (innerBoundary.size < 3 || !isValidPolygon(innerBoundary)) {
                break
            }

            // Update current boundary for next iteration
            currentBoundary = innerBoundary
            iteration++
        }

        return paths
    }

    private fun generateInnerBoundary(
        boundary: ArrayList<LatLng>,
        insetDistance: Double
    ): ArrayList<LatLng> {
        val innerBoundary = ArrayList<LatLng>()
        val n = boundary.size

        for (i in 0 until n) {
            val prev = boundary[(i - 1 + n) % n]
            val current = boundary[i]
            val next = boundary[(i + 1) % n]

            // Calculate bisector direction
            val inDirection = getBisectorDirection(prev, current, next, insetDistance)

            // Move the point inward
            val newLat = current.latitude + inDirection.first
            val newLng = current.longitude + inDirection.second

            innerBoundary.add(LatLng(newLat, newLng))
        }

        // Check for self-intersections and fix if needed
        return removeIntersections(innerBoundary)
    }

    private fun getBisectorDirection(
        prev: LatLng,
        current: LatLng,
        next: LatLng,
        distance: Double
    ): Pair<Double, Double> {
        // Calculate vectors
        val v1x = prev.longitude - current.longitude
        val v1y = prev.latitude - current.latitude
        val v2x = next.longitude - current.longitude
        val v2y = next.latitude - current.latitude

        // Normalize vectors
        val len1 = sqrt(v1x * v1x + v1y * v1y)
        val len2 = sqrt(v2x * v2x + v2y * v2y)

        val u1x = v1x / len1
        val u1y = v1y / len1
        val u2x = v2x / len2
        val u2y = v2y / len2

        // Calculate bisector direction (inward)
        var bisectorX = (u1x + u2x) / 2
        var bisectorY = (u1y + u2y) / 2

        // Normalize bisector
        val lenBisector = sqrt(bisectorX * bisectorX + bisectorY * bisectorY)
        if (lenBisector > 0) {
            bisectorX /= lenBisector
            bisectorY /= lenBisector
        }

        // Adjust for longitude/latitude distortion at current latitude
        val latFactor = cos(Math.toRadians(current.latitude))

        return Pair(
            bisectorY * distance,
            bisectorX * distance / latFactor
        )
    }

    private fun removeIntersections(path: ArrayList<LatLng>): ArrayList<LatLng> {
        if (path.size < 3) return path // 至少需要 3 個點才能形成多邊形

        val n = path.size
        val newPath = ArrayList(path) // 複製原始路徑

        // 檢查每一對線段是否相交
        for (i in 0 until n) {
            val p1 = newPath[i]
            val p2 = newPath[(i + 1) % n]

            for (j in i + 2 until n) {
                val p3 = newPath[j]
                val p4 = newPath[(j + 1) % n]

                // 檢查線段 (p1, p2) 和 (p3, p4) 是否相交
                if (doSegmentsIntersect(p1, p2, p3, p4)) {
                    // 如果相交，修正路徑
                    return fixIntersection(newPath, i, j)
                }
            }
        }

        // 如果沒有自交點，返回原始路徑
        return newPath
    }

    private fun doSegmentsIntersect(p1: LatLng, p2: LatLng, p3: LatLng, p4: LatLng): Boolean {
        // 計算方向
        val o1 = orientation(p1, p2, p3)
        val o2 = orientation(p1, p2, p4)
        val o3 = orientation(p3, p4, p1)
        val o4 = orientation(p3, p4, p2)

        // 一般情況：線段相交
        if (o1 != o2 && o3 != o4) return true

        // 特殊情況：共線且重疊
        if (o1 == 0 && isOnSegment(p1, p3, p2)) return true
        if (o2 == 0 && isOnSegment(p1, p4, p2)) return true
        if (o3 == 0 && isOnSegment(p3, p1, p4)) return true
        if (o4 == 0 && isOnSegment(p3, p2, p4)) return true

        return false
    }

    private fun orientation(p1: LatLng, p2: LatLng, p3: LatLng): Int {
        val value = (p2.longitude - p1.longitude) * (p3.latitude - p2.latitude) -
                (p2.latitude - p1.latitude) * (p3.longitude - p2.longitude)

        return when {
            value == 0.0 -> 0  // 共線
            value > 0 -> 1     // 順時針
            else -> -1         // 逆時針
        }
    }

    private fun isOnSegment(p1: LatLng, p2: LatLng, p3: LatLng): Boolean {
        return (p2.latitude <= max(p1.latitude, p3.latitude) &&
                (p2.latitude >= min(p1.latitude, p3.latitude)) &&
                (p2.longitude <= max(p1.longitude, p3.longitude)) &&
                (p2.longitude >= min(p1.longitude, p3.longitude)))
    }

    /*
    private fun isOnSegment(p1: LatLng, p2: LatLng, p3: LatLng): Boolean {
        // 檢查點 p2 是否在 p1 和 p3 的矩形範圍內
        val isWithinBounds = (p2.latitude <= max(p1.latitude, p3.latitude) &&
                (p2.latitude >= min(p1.latitude, p3.latitude)) &&
                (p2.longitude <= max(p1.longitude, p3.longitude)) &&
                (p2.longitude >= min(p1.longitude, p3.longitude)))

        // 檢查點 p2 是否在 p1 和 p3 的直線上
        if (!isWithinBounds) return false

        // 計算斜率
        val slopeLat = (p3.latitude - p1.latitude)
        val slopeLng = (p3.longitude - p1.longitude)

        // 避免除以零的情況
        if (slopeLat == 0.0 && slopeLng == 0.0) {
            return p2.latitude == p1.latitude && p2.longitude == p1.longitude
        }

        // 檢查點 p2 是否在直線上
        val isOnLine = abs((p2.latitude - p1.latitude) * slopeLng - (p2.longitude - p1.longitude) * slopeLat) < 1e-9

        return isOnLine
    }
    */

    private fun fixIntersection(path: ArrayList<LatLng>, i: Int, j: Int): ArrayList<LatLng> {
        val newPath = ArrayList<LatLng>()

        // 從起點到第一個交點
        for (k in 0..i) {
            newPath.add(path[k])
        }

        // 從第二個交點到第一個交點（逆序）
        for (k in j downTo i + 1) {
            newPath.add(path[k])
        }

        // 從第二個交點到終點
        for (k in j + 1 until path.size) {
            newPath.add(path[k])
        }

        return newPath
    }


  /*
    private fun removeIntersections(path: ArrayList<LatLng>): ArrayList<LatLng> {
        // Simple implementation: if self-intersections are detected,
        // we can return a simplified version of the path
        // In a real application, this would need more sophisticated geometry algorithms

        // For now, just return the original path
        return path
    }
*/
    private fun isValidPolygon(points: ArrayList<LatLng>): Boolean {
        if (points.size < 3) return false

        // Calculate the area of the polygon to check if it's valid
        var area = 0.0
        val n = points.size

        for (i in 0 until n) {
            val j = (i + 1) % n
            area += points[i].latitude * points[j].longitude
            area -= points[j].latitude * points[i].longitude
        }

        area = abs(area) / 2.0

        // If area is too small, consider it invalid
        val minArea = 1e-8 // Arbitrary small threshold
        return area > minArea
    }

    private fun drawGeneratedPaths() {
        // Clear previous paths (keep the boundary)
        mMap.clear()
        drawFieldBoundary()

        // Draw each generated path
        for (i in generatedPaths.indices) {
            val path = generatedPaths[i]

            // Create a polyline for each path
            val polylineOptions = PolylineOptions()
                .addAll(path)
                .width(5f)
                .color(Color.GREEN)
                .geodesic(true)

            // Add the polyline to the map
            mMap.addPolyline(polylineOptions)

            // Connect the last point to the first to close the path
            if (path.size > 0) {
                val closingLine = PolylineOptions()
                    .add(path.last())
                    .add(path.first())
                    .width(5f)
                    .color(Color.GREEN)
                    .geodesic(true)

                mMap.addPolyline(closingLine)
            }
        }
    }


    private fun clearGeneratedPaths() {
        generatedPaths.clear()
        // Redraw only the boundary
        mMap.clear()
        drawFieldBoundary()
        Toast.makeText(this, "已清除生成的路徑", Toast.LENGTH_SHORT).show()
    }
}