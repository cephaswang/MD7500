package tw.ibiz.gpsinfo

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.google.android.gms.maps.model.LatLng
import com.google.gson.Gson

class SurveyingDBHelper(context: Context) : SQLiteOpenHelper(context, "gpsinfo", null, 1) {

    companion object {
        const val TABLE_NAME = "Surveying"
        const val COLUMN_ID = "id"
        const val COLUMN_COORDINATES = "coordinates"
        const val COLUMN_OWNER = "owner"
        const val COLUMN_LOCATION = "location"
        const val COLUMN_CREATED_AT = "created_at"
        const val COLUMN_ZOOM = "zoom"
        const val COLUMN_CENTER = "center"
        const val COLUMN_BEARING = "bearing"
        const val COLUMN_AREA_SQM = "area_sqm" // 面積（平方公尺）
        const val COLUMN_AREA_PING = "area_ping" // 面積（坪）
        const val COLUMN_AREA_FEN = "area_fen" // 面積（分地）
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_NAME (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_COORDINATES TEXT,
                $COLUMN_OWNER TEXT,
                $COLUMN_LOCATION TEXT,
                $COLUMN_CREATED_AT TEXT,
                $COLUMN_ZOOM REAL,
                $COLUMN_CENTER TEXT,
                $COLUMN_BEARING REAL,
                $COLUMN_AREA_SQM REAL,
                $COLUMN_AREA_PING REAL,
                $COLUMN_AREA_FEN REAL
            )
        """.trimIndent()
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun insertSurveyingData(
        coordinates: List<LatLng>,
        owner: String,
        location: String,
        zoom: Float,
        center: LatLng,
        bearing: Float,
        areaSqm: Double,
        areaPing: Double,
        areaFen: Double
    ): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_COORDINATES, Gson().toJson(coordinates))
            put(COLUMN_OWNER, owner)
            put(COLUMN_LOCATION, location)
            put(COLUMN_CREATED_AT, System.currentTimeMillis().toString())
            put(COLUMN_ZOOM, zoom)
            put(COLUMN_CENTER, Gson().toJson(center))
            put(COLUMN_BEARING, bearing)
            put(COLUMN_AREA_SQM, areaSqm)
            put(COLUMN_AREA_PING, areaPing)
            put(COLUMN_AREA_FEN, areaFen)
        }
        return db.insert(TABLE_NAME, null, values)
    }
}