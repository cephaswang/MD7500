package tw.ibiz.gpsinfo




import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.PolylineOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import java.util.UUID
import kotlin.math.abs
import kotlin.math.sqrt

class MainActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var map: GoogleMap
    private lateinit var dbHelper: DatabaseHelper
    private var pathList = mutableListOf<LatLng>()
    private var currentStep = 0
    private var isPathCleared = false

    // UI Elements
    private lateinit var widthInput: EditText
    private lateinit var lengthInput: EditText
    private lateinit var overlapInput: EditText
    private lateinit var clearButton: Button
    private lateinit var loadButton: Button
    private lateinit var centerButton: Button
    private lateinit var stepButton: Button

    // Base coordinates and conversion
    private val baseLat = 25.0
    private val baseLng = 121.0
    private val meterToDegree = 1.0 / 111111.0

    private val field = generateExampleField()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)

        widthInput = findViewById(R.id.width_input)
        lengthInput = findViewById(R.id.length_input)
        overlapInput = findViewById(R.id.overlap_input)
        clearButton = findViewById(R.id.clear_button)
        loadButton = findViewById(R.id.load_button)
        centerButton = findViewById(R.id.center_button)
        stepButton = findViewById(R.id.step_button)

        widthInput.setText("2")
        lengthInput.setText("3")
        overlapInput.setText("0.3")

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        setupButtons()
    }

    private fun generateExampleField(): List<LatLng> {
        val scale = 10.0
        return listOf(
            LatLng(baseLat, baseLng),
            LatLng(baseLat, baseLng + 80 * meterToDegree * scale),
            LatLng(baseLat + 50 * meterToDegree * scale, baseLng + 100 * meterToDegree * scale),
            LatLng(baseLat + 90 * meterToDegree * scale, baseLng + 60 * meterToDegree * scale),
            LatLng(baseLat + 70 * meterToDegree * scale, baseLng)
        )
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        drawFieldBoundary()
        generateAndDrawPathAsync()
    }

    private fun drawFieldBoundary() {
        map.addPolyline(
            PolylineOptions()
                .addAll(field)
                .add(field[0])
                .color(android.graphics.Color.GREEN)
                .width(5f)
        )
    }

    private fun generateAndDrawPathAsync() {
        CoroutineScope(Dispatchers.Main).launch {
            pathList.clear()
            map.clear()
            drawFieldBoundary()

            val width = widthInput.text.toString().toDoubleOrNull() ?: 2.0
            val overlap = overlapInput.text.toString().toDoubleOrNull() ?: 0.3
            val effectiveWidth = width * (1 - overlap)

            Toast.makeText(this@MainActivity, "Generating path...", Toast.LENGTH_SHORT).show()
            try {
                val generatedPath = withContext(Dispatchers.Default) {
                    generateContinuousPath(field, effectiveWidth)
                }
                pathList.addAll(generatedPath)

                if (pathList.isNotEmpty()) {
                    val pathId = UUID.randomUUID().toString()
                    savePathToDatabase(pathId, listOf(pathList))

                    // Draw path in segments only if pathList has points
                    val segmentSize = 500
                    for (i in 0 until pathList.size step segmentSize) {
                        val endIndex = minOf(i + segmentSize, pathList.size)
                        if (i < endIndex) { // Ensure valid range
                            map.addPolyline(
                                PolylineOptions()
                                    .addAll(pathList.subList(i, endIndex))
                                    .color(android.graphics.Color.RED)
                                    .width(10f)
                            )
                            yield()
                        }
                    }

                    Log.d("PATH", "Generated path ID: $pathId with ${pathList.size} points")
                    pathList.take(5).forEachIndexed { index, point ->
                        Log.d("PATH", "Point $index: $point")
                    }
                } else {
                    Log.d("PATH", "No path generated. Effective width: $effectiveWidth, Field size: ${field.size}")
                    Toast.makeText(this@MainActivity, "Failed to generate path", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                Log.e("PATH_ERROR", "Error generating path: ${e.message}", e)
                Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }

            centerMap()
            isPathCleared = false
            Toast.makeText(this@MainActivity, "Path generation complete", Toast.LENGTH_SHORT).show()
        }
    }

    private fun generateContinuousPath(boundary: List<LatLng>, effectiveWidth: Double): List<LatLng> {
        val points = mutableListOf<LatLng>()
        var currentBoundary = boundary.toMutableList()
        var offset = 0.0
        val maxPoints = 2000

        while (currentBoundary.size >= 3 && points.size < maxPoints) {
            for (i in currentBoundary.indices) {
                val start = currentBoundary[i]
                val end = currentBoundary[(i + 1) % currentBoundary.size]

                val dx = end.longitude - start.longitude
                val dy = end.latitude - start.latitude
                val length = sqrt(dx * dx + dy * dy)
                val steps = (length / (effectiveWidth * meterToDegree)).toInt().coerceAtLeast(1)

                if (points.isEmpty() && i == 0) {
                    points.add(start)
                }

                for (step in 1..steps) {
                    if (points.size >= maxPoints) break
                    val fraction = step.toDouble() / steps
                    val lat = start.latitude + dy * fraction
                    val lng = start.longitude + dx * fraction
                    points.add(LatLng(lat, lng))
                }
            }

            offset += effectiveWidth
            val newBoundary = shrinkPolygon(currentBoundary, offset)

            if (newBoundary.size < 3) break

            val lastOuter = points.last()
            val firstInner = newBoundary[0]
            val dx = firstInner.longitude - lastOuter.longitude
            val dy = firstInner.latitude - lastOuter.latitude
            val length = sqrt(dx * dx + dy * dy)
            val steps = (length / (effectiveWidth * meterToDegree)).toInt().coerceAtLeast(1)

            for (step in 1..steps) {
                if (points.size >= maxPoints) break
                val fraction = step.toDouble() / steps
                val lat = lastOuter.latitude + dy * fraction
                val lng = lastOuter.longitude + dx * fraction
                points.add(LatLng(lat, lng))
            }

            currentBoundary = newBoundary
        }

        return points
    }

    private fun shrinkPolygon(polygon: List<LatLng>, distance: Double): MutableList<LatLng> {
        val newPolygon = mutableListOf<LatLng>()
        val distanceDegree = distance * meterToDegree

        for (i in polygon.indices) {
            val prev = polygon[(i - 1 + polygon.size) % polygon.size]
            val curr = polygon[i]
            val next = polygon[(i + 1) % polygon.size]

            val dx1 = curr.longitude - prev.longitude
            val dy1 = curr.latitude - prev.latitude
            val dx2 = next.longitude - curr.longitude
            val dy2 = next.latitude - curr.latitude

            val len1 = sqrt(dx1 * dx1 + dy1 * dy1)
            val len2 = sqrt(dx2 * dx2 + dy2 * dy2)
            val nx1 = if (len1 > 0) -dy1 / len1 else 0.0
            val ny1 = if (len1 > 0) dx1 / len1 else 0.0
            val nx2 = if (len2 > 0) -dy2 / len2 else 0.0
            val ny2 = if (len2 > 0) dx2 / len2 else 0.0

            val nx = (nx1 + nx2) / 2
            val ny = (ny1 + ny2) / 2
            val len = sqrt(nx * nx + ny * ny)
            val normX = if (len > 0) nx / len else 0.0
            val normY = if (len > 0) ny / len else 0.0

            val newLat = curr.latitude + normY * distanceDegree
            val newLng = curr.longitude + normX * distanceDegree
            newPolygon.add(LatLng(newLat, newLng))
        }

        if (calculateArea(newPolygon) < 0.000001) return mutableListOf()

        return newPolygon
    }

    private fun calculateArea(points: List<LatLng>): Double {
        var area = 0.0
        for (i in points.indices) {
            val j = (i + 1) % points.size
            area += points[i].longitude * points[j].latitude
            area -= points[j].longitude * points[i].latitude
        }
        return abs(area) / 2
    }

    private fun savePathToDatabase(pathId: String, paths: List<List<LatLng>>) {
        paths.forEachIndexed { index, path ->
            dbHelper.insertPath(pathId, index, path, "CONTINUOUS")
        }
    }

    private fun setupButtons() {
        clearButton.setOnClickListener {
            if (!isPathCleared) {
                map.clear()
                pathList.clear()
                currentStep = 0
                drawFieldBoundary()
                isPathCleared = true
                Toast.makeText(this, "Path cleared", Toast.LENGTH_SHORT).show()
            } else {
                generateAndDrawPathAsync()
                Toast.makeText(this, "Path redrawn", Toast.LENGTH_SHORT).show()
            }
        }

        loadButton.setOnClickListener {
            val paths = dbHelper.getPath("some_path_id")
            map.clear()
            drawFieldBoundary()
            paths.forEach { path ->
                map.addPolyline(
                    PolylineOptions()
                        .addAll(path)
                        .color(android.graphics.Color.RED)
                        .width(10f)
                )
            }
            Toast.makeText(this, "Loaded path with ${paths.size} segments", Toast.LENGTH_SHORT).show()
            isPathCleared = false
        }

        centerButton.setOnClickListener {
            centerMap()
        }

        stepButton.setOnClickListener {
            if (currentStep == 0) {
                map.clear()
                drawFieldBoundary()
            }
            if (currentStep < pathList.size) {
                drawStep(currentStep)
                currentStep++
            } else {
                Toast.makeText(this, "Path complete", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun centerMap() {
        val bounds = LatLngBounds.Builder()
        field.forEach { bounds.include(it) }
        val center = bounds.build().center
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(center, 18f))
    }

    private fun drawStep(step: Int) {
        val point = pathList[step]
        if (step > 0) {
            map.addPolyline(
                PolylineOptions()
                    .add(pathList[step - 1], point)
                    .width(10f)
                    .color(android.graphics.Color.RED)
            )
        }

        drawTractorOutline(point)

        Log.d("STEP", "Drawing step $step at $point")
    }

    private fun drawTractorOutline(center: LatLng) {
        val width = widthInput.text.toString().toDoubleOrNull() ?: 2.0
        val length = lengthInput.text.toString().toDoubleOrNull() ?: 3.0
        val halfWidth = width * meterToDegree / 2
        val halfLength = length * meterToDegree / 2

        map.addPolyline(
            PolylineOptions()
                .add(
                    LatLng(center.latitude - halfLength, center.longitude - halfWidth),
                    LatLng(center.latitude + halfLength, center.longitude - halfWidth),
                    LatLng(center.latitude + halfLength, center.longitude + halfWidth),
                    LatLng(center.latitude - halfLength, center.longitude + halfWidth),
                    LatLng(center.latitude - halfLength, center.longitude - halfWidth)
                )
                .color(android.graphics.Color.BLUE)
                .width(2f)
        )
    }
}

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "PathDB", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE paths (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                path_id TEXT,
                segment_index INTEGER,
                latitude REAL,
                longitude REAL,
                type TEXT
            )
        """)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS paths")
        onCreate(db)
    }

    fun insertPath(pathId: String, segmentIndex: Int, points: List<LatLng>, type: String) {
        val db = writableDatabase
        points.forEach { point ->
            val values = ContentValues().apply {
                put("path_id", pathId)
                put("segment_index", segmentIndex)
                put("latitude", point.latitude)
                put("longitude", point.longitude)
                put("type", type)
            }
            db.insert("paths", null, values)
        }
    }

    fun getPath(pathId: String): List<List<LatLng>> {
        val paths = mutableListOf<List<LatLng>>()
        val db = readableDatabase
        val cursor = db.query(
            "paths",
            arrayOf("latitude", "longitude", "segment_index"),
            "path_id = ?",
            arrayOf(pathId),
            null,
            null,
            "segment_index"
        )

        var currentSegment = mutableListOf<LatLng>()
        var lastIndex = -1

        while (cursor.moveToNext()) {
            val segmentIndex = cursor.getInt(2)
            if (segmentIndex != lastIndex && currentSegment.isNotEmpty()) {
                paths.add(currentSegment)
                currentSegment = mutableListOf()
            }
            currentSegment.add(
                LatLng(cursor.getDouble(0), cursor.getDouble(1))
            )
            lastIndex = segmentIndex
        }
        if (currentSegment.isNotEmpty()) {
            paths.add(currentSegment)
        }
        cursor.close()
        return paths
    }
}