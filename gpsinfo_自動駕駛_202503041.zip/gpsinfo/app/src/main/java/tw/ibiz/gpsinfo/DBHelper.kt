package tw.ibiz.gpsinfo

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) : SQLiteOpenHelper(context, "gpsinfo", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE Surveying (" +
                    "ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "coordinates TEXT, " +
                    "description TEXT, " +
                    "created_at TEXT, " +
                    "zoom REAL, " +
                    "center_lat REAL, " +
                    "center_lng REAL, " +
                    "bearing REAL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS Surveying")
        onCreate(db)
    }

    fun insertSurveyingData(
        coordinates: String,
        description: String,
        createdAt: String,
        zoom: Float,
        centerLat: Double,
        centerLng: Double,
        bearing: Float
    ): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put("coordinates", coordinates)
            put("description", description)
            put("created_at", createdAt)
            put("zoom", zoom)
            put("center_lat", centerLat)
            put("center_lng", centerLng)
            put("bearing", bearing)
        }
        return db.insert("Surveying", null, values)
    }
}