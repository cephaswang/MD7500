package tw.ibiz.gpsinfo

import com.google.android.gms.maps.model.LatLng
import java.util.Random

private fun generateTestData(): List<LatLng> {
    val random = Random()
    val testData = mutableListOf<LatLng>()
    for (i in 0 until 10) {
        val lat = 37.7749 + random.nextDouble() * 0.01
        val lng = -122.4194 + random.nextDouble() * 0.01
        testData.add(LatLng(lat, lng))
    }
    return testData
}