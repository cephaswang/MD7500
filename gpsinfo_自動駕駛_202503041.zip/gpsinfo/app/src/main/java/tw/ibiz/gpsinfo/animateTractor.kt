package tw.ibiz.gpsinfo

import android.animation.ValueAnimator
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import com.google.android.gms.maps.model.LatLng

/*
private fun animateTractor(path: List<LatLng>) {
    val tractorView = findViewById<ImageView>(R.id.tractorView)
    val animator = ValueAnimator.ofInt(0, path.size - 1)
    animator.duration = 5000 // 5秒
    animator.interpolator = LinearInterpolator()
    animator.addUpdateListener { animation ->
        val index = animation.animatedValue as Int
        val position = path[index]
        // 更新曳引機的位置
        // 這裡需要將 LatLng 轉換為屏幕坐標
    }
    animator.start()
}
*/