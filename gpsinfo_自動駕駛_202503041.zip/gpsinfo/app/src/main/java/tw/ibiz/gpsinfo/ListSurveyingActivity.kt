package tw.ibiz.gpsinfo

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class ListSurveyingActivity : AppCompatActivity() {

    private lateinit var dbHelper: SurveyingDBHelper
    private lateinit var db: SQLiteDatabase
    private lateinit var linearLayout: LinearLayout
    private lateinit var editTextOwner: EditText
    private var selectedRecordView: View? = null // 當前選中的記錄視圖

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_surveying)

        // 初始化視圖
        linearLayout = findViewById(R.id.linearLayout)
        editTextOwner = findViewById(R.id.editTextOwner)

        // 初始化數據庫
        dbHelper = SurveyingDBHelper(this)
        db = dbHelper.readableDatabase

        // 設置 ImageView 按鈕事件
        findViewById<ImageView>(R.id.buttonExit).setOnClickListener {
            finish() // 結束 Activity
        }

        findViewById<ImageView>(R.id.buttonQuery).setOnClickListener {
            queryData() // 查詢資料表
        }

        findViewById<ImageView>(R.id.buttonPrintNewRecord).setOnClickListener {
            // 跳轉到 SurveyingActivity
            val intent = Intent(this, SurveyingActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onStart() {
        super.onStart()
        // 刷新頁面，重新載入查詢記錄
        queryData()
    }


    private fun queryData() {
        val owner = editTextOwner.text.toString()
        val query: String
        val selectionArgs: Array<String>?

        if (owner.isNotEmpty()) {
            query = "SELECT * FROM ${SurveyingDBHelper.TABLE_NAME} WHERE ${SurveyingDBHelper.COLUMN_OWNER} LIKE ?"
            selectionArgs = arrayOf("%$owner%")
        } else {
            query = "SELECT * FROM ${SurveyingDBHelper.TABLE_NAME}"
            selectionArgs = null
        }

        val cursor = db.rawQuery(query, selectionArgs)

        // 清空之前的列表
        linearLayout.removeAllViews()
        selectedRecordView = null // 重置選中的記錄視圖

        // 顯示查詢結果
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_ID))
                val owner = cursor.getString(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_OWNER))
                val location = cursor.getString(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_LOCATION))
                val areaFen = cursor.getDouble(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_AREA_FEN))
                val coordinatesJson = cursor.getString(cursor.getColumnIndexOrThrow(SurveyingDBHelper.COLUMN_COORDINATES))

                // 格式化 area_fen 為 %.04f
                val formattedAreaFen = String.format(Locale.getDefault(), "%.04f", areaFen)

                // 解析座標陣列
             //   val coordinates = Gson().fromJson(coordinatesJson, Array<LatLng>::class.java).toList()

                // 創建並添加記錄視圖
                val recordView = createRecordView(id, owner, location, formattedAreaFen, coordinatesJson)
                linearLayout.addView(recordView)
            } while (cursor.moveToNext())
        }

        cursor.close()
    }

    private fun createRecordView(
        id: Int,
        owner: String,
        location: String,
        areaFen: String,
        coordinates: String
    ): View {
        val recordView = TextView(this).apply {
            text = "流水號: $id, 業主: $owner, 地點: $location, 面積[分地]: $areaFen"
            setPadding(32, 16, 32, 16)
            setBackgroundColor(if (id % 2 == 0) 0xFFDDDDDD.toInt() else 0xFFEEEEEE.toInt()) // 單雙列交替底色
            setOnClickListener {
                // 選取列時改變底色
                selectedRecordView?.setBackgroundColor(if ((selectedRecordView?.tag as Int) % 2 == 0) 0xFFDDDDDD.toInt() else 0xFFEEEEEE.toInt())
                setBackgroundColor(Color.CYAN) // 選中底色
                selectedRecordView = this

                // 打印欄位記錄，包括業主和座標陣列
                printRecord(id, owner, location, areaFen, coordinates)
            }
            tag = id // 設置標籤以便區分單雙列
        }

        return recordView
    }


    private fun printRecord(
        id: Int,
        owner: String,
        location: String,
        areaFen: String,
        coordinates: String
    ) {
        println("打印記錄: 流水號=$id, 業主=$owner, 地點=$location, 面積[分地]=$areaFen")
       // println("座標陣列: ${coordinates.joinToString(", ") { "(${it.latitude}, ${it.longitude})" }}")
        println(coordinates)
        // 跳轉到 SurveyingActivity
        val intent = Intent(this, RouteActivity::class.java)
        intent.putExtra("PointsJsonString", coordinates)
        startActivity(intent)
    }


    override fun onDestroy() {
        db.close()
        dbHelper.close()
        super.onDestroy()
    }
}