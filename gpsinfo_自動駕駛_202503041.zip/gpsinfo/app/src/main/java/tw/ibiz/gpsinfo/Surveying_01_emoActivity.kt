package tw.ibiz.gpsinfo

import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolygonOptions
import com.google.maps.android.SphericalUtil

class Surveying01EmoActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var googleMap: GoogleMap
    private val points = mutableListOf<LatLng>()
    private var pointCounter = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_surveying01_emo)

        // 使用 findViewById 初始化視圖
        val modeButton: Button = findViewById(R.id.modeButton)
        val drawButton: Button = findViewById(R.id.drawButton)
        val saveButton: Button = findViewById(R.id.saveButton)

        // 初始化地圖
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        // 切換地圖模式
        modeButton.setOnClickListener {
            when (googleMap.mapType) {
                GoogleMap.MAP_TYPE_NORMAL -> {
                    googleMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
                    Log.d("MapMode", "切換到衛星模式")
                }
                GoogleMap.MAP_TYPE_SATELLITE -> {
                    googleMap.mapType = GoogleMap.MAP_TYPE_NORMAL
                    Log.d("MapMode", "切換到普通模式")
                }
            }
        }

        // 添加點
        drawButton.setOnClickListener {
            googleMap.setOnMapClickListener { latLng ->
                points.add(latLng)
                googleMap.addMarker(MarkerOptions().position(latLng).title("點 $pointCounter"))
                pointCounter++
                Log.d("PointCoordinates", "添加點: $latLng")
            }
        }

        // 保存並繪製多邊形
        saveButton.setOnClickListener {
            if (points.size > 2) {
                // 繪製多邊形
                val polygonOptions = PolygonOptions()
                    .addAll(points)
                    .strokeWidth(5f)
                    .strokeColor(0xFFFF0000.toInt()) // 紅色邊框
                    .fillColor(0x22FF0000.toInt()) // 半透明紅色填充
                googleMap.addPolygon(polygonOptions)

                // 計算並顯示每一條線段的長度
                for (i in 0 until points.size) {
                    val startPoint = points[i]
                    val endPoint = points[(i + 1) % points.size] // 最後一個點連回第一個點

                    // 計算線段長度
                    val distance = SphericalUtil.computeDistanceBetween(startPoint, endPoint)
                    Log.d("Distance", "線段 ${i + 1} 的長度: $distance 公尺")

                    // 在線段中間添加標示文字
                    val midPoint = LatLng(
                        (startPoint.latitude + endPoint.latitude) / 2,
                        (startPoint.longitude + endPoint.longitude) / 2
                    )
                    googleMap.addMarker(
                        MarkerOptions()
                            .position(midPoint)
                            .title("${String.format("%.2f", distance)} 公尺")
                    )
                }
            }
        }
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        // 設置初始位置（例如台北 101）
        val initialLocation = LatLng(25.0330, 121.5654)
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(initialLocation, 15f))
    }
}