package tw.ibiz.gpsinfo


import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// 路徑數據類，放在檔案頂部以確保在整個檔案中可見
data class PathData(
    val id: Long,
    val width: Float,
    val length: Float,
    val overlap: Float,
    val pathString: String,
    val segmentString: String
)

class PathDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "field_path.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_PATHS = "paths"

        private const val KEY_ID = "id"
        private const val KEY_WIDTH = "width"
        private const val KEY_LENGTH = "length"
        private const val KEY_OVERLAP = "overlap"
        private const val KEY_PATH_STRING = "path_string"
        private const val KEY_SEGMENT_STRING = "segment_string"
        private const val KEY_CREATED_AT = "created_at"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableQuery = """
            CREATE TABLE $TABLE_PATHS (
                $KEY_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $KEY_WIDTH REAL NOT NULL,
                $KEY_LENGTH REAL NOT NULL,
                $KEY_OVERLAP REAL NOT NULL,
                $KEY_PATH_STRING TEXT NOT NULL,
                $KEY_SEGMENT_STRING TEXT NOT NULL,
                $KEY_CREATED_AT TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """.trimIndent()

        db.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_PATHS")
        onCreate(db)
    }

    // 插入新路徑
    fun insertPath(
        width: Float,
        length: Float,
        overlap: Float,
        pathString: String,
        segmentString: String
    ): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(KEY_WIDTH, width)
            put(KEY_LENGTH, length)
            put(KEY_OVERLAP, overlap)
            put(KEY_PATH_STRING, pathString)
            put(KEY_SEGMENT_STRING, segmentString)
        }

        val id = db.insert(TABLE_PATHS, null, values)
        db.close()
        return id
    }

    // 獲取路徑數據
    fun getPath(id: Long): PathData? {
        val db = this.readableDatabase
        val query = "SELECT * FROM $TABLE_PATHS WHERE $KEY_ID = ?"
        val cursor = db.rawQuery(query, arrayOf(id.toString()))

        var pathData: PathData? = null

        if (cursor.moveToFirst()) {
            val width = cursor.getFloat(cursor.getColumnIndexOrThrow(KEY_WIDTH))
            val length = cursor.getFloat(cursor.getColumnIndexOrThrow(KEY_LENGTH))
            val overlap = cursor.getFloat(cursor.getColumnIndexOrThrow(KEY_OVERLAP))
            val pathString = cursor.getString(cursor.getColumnIndexOrThrow(KEY_PATH_STRING))
            val segmentString = cursor.getString(cursor.getColumnIndexOrThrow(KEY_SEGMENT_STRING))

            pathData = PathData(id, width, length, overlap, pathString, segmentString)
        }

        cursor.close()
        db.close()
        return pathData
    }

    // 獲取所有路徑數據
    fun getAllPaths(): List<PathData> {
        val pathList = mutableListOf<PathData>()
        val db = this.readableDatabase
        val query = "SELECT * FROM $TABLE_PATHS ORDER BY $KEY_ID DESC"
        val cursor = db.rawQuery(query, null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getLong(cursor.getColumnIndexOrThrow(KEY_ID))
                val width = cursor.getFloat(cursor.getColumnIndexOrThrow(KEY_WIDTH))
                val length = cursor.getFloat(cursor.getColumnIndexOrThrow(KEY_LENGTH))
                val overlap = cursor.getFloat(cursor.getColumnIndexOrThrow(KEY_OVERLAP))
                val pathString = cursor.getString(cursor.getColumnIndexOrThrow(KEY_PATH_STRING))
                val segmentString = cursor.getString(cursor.getColumnIndexOrThrow(KEY_SEGMENT_STRING))

                pathList.add(PathData(id, width, length, overlap, pathString, segmentString))
            } while (cursor.moveToNext())
        }

        cursor.close()
        db.close()
        return pathList
    }

    // 刪除路徑
    fun deletePath(id: Long): Boolean {
        val db = this.writableDatabase
        val success = db.delete(TABLE_PATHS, "$KEY_ID = ?", arrayOf(id.toString())) > 0
        db.close()
        return success
    }

    // 更新路徑
    fun updatePath(
        id: Long,
        width: Float,
        length: Float,
        overlap: Float,
        pathString: String,
        segmentString: String
    ): Boolean {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(KEY_WIDTH, width)
            put(KEY_LENGTH, length)
            put(KEY_OVERLAP, overlap)
            put(KEY_PATH_STRING, pathString)
            put(KEY_SEGMENT_STRING, segmentString)
        }

        val success = db.update(TABLE_PATHS, values, "$KEY_ID = ?", arrayOf(id.toString())) > 0
        db.close()
        return success
    }

    // 清除所有路徑
    fun clearAllPaths(): Boolean {
        val db = this.writableDatabase
        val success = db.delete(TABLE_PATHS, null, null) > 0
        db.close()
        return success
    }
}