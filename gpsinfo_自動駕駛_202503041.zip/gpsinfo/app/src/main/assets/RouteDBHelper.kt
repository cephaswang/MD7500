import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class RouteDBHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        const val DATABASE_NAME = "gpsinfo_Route"
        const val DATABASE_VERSION = 1

        const val TABLE_ROUTE_POINTS = "route_points"
        const val COL_ID = "id"
        const val COL_LATITUDE = "latitude"
        const val COL_LONGITUDE = "longitude"

        const val TABLE_GENERATED_PATHS = "generated_paths"
        const val COL_PATH_ID = "path_id"
        const val COL_POINT_ORDER = "point_order"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Create route points table
        val createRoutePointsTable = """
            CREATE TABLE $TABLE_ROUTE_POINTS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_LATITUDE REAL NOT NULL,
                $COL_LONGITUDE REAL NOT NULL
            )
        """.trimIndent()

        // Create generated paths table
        val createGeneratedPathsTable = """
            CREATE TABLE $TABLE_GENERATED_PATHS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_PATH_ID INTEGER NOT NULL,
                $COL_POINT_ORDER INTEGER NOT NULL,
                $COL_LATITUDE REAL NOT NULL,
                $COL_LONGITUDE REAL NOT NULL
            )
        """.trimIndent()

        db.execSQL(createRoutePointsTable)
        db.execSQL(createGeneratedPathsTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Handle database version upgrades
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ROUTE_POINTS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_GENERATED_PATHS")
        onCreate(db)
    }

    // Function to save generated paths
    fun saveGeneratedPaths(paths: List<List<com.google.android.gms.maps.model.LatLng>>) {
        val db = writableDatabase

        // Clear existing paths
        db.delete(TABLE_GENERATED_PATHS, null, null)

        // Insert new paths
        for (pathIndex in paths.indices) {
            val path = paths[pathIndex]
            for (pointIndex in path.indices) {
                val point = path[pointIndex]
                val values = android.content.ContentValues().apply {
                    put(COL_PATH_ID, pathIndex)
                    put(COL_POINT_ORDER, pointIndex)
                    put(COL_LATITUDE, point.latitude)
                    put(COL_LONGITUDE, point.longitude)
                }
                db.insert(TABLE_GENERATED_PATHS, null, values)
            }
        }
        db.close()
    }

    // Function to get route points
    fun getRoutePoints(): List<com.google.android.gms.maps.model.LatLng> {
        val points = ArrayList<com.google.android.gms.maps.model.LatLng>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_ROUTE_POINTS,
            arrayOf(COL_LATITUDE, COL_LONGITUDE),
            null, null, null, null, null
        )

        with(cursor) {
            while (moveToNext()) {
                val latitude = getDouble(getColumnIndexOrThrow(COL_LATITUDE))
                val longitude = getDouble(getColumnIndexOrThrow(COL_LONGITUDE))
                points.add(com.google.android.gms.maps.model.LatLng(latitude, longitude))
            }
            close()
        }
        db.close()
        return points
    }

    // Function to get generated paths
    fun getGeneratedPaths(): List<List<com.google.android.gms.maps.model.LatLng>> {
        val paths = ArrayList<ArrayList<com.google.android.gms.maps.model.LatLng>>()
        val db = readableDatabase

        // Get all distinct path IDs
        val pathIdCursor = db.rawQuery("SELECT DISTINCT $COL_PATH_ID FROM $TABLE_GENERATED_PATHS ORDER BY $COL_PATH_ID", null)
        val pathIds = ArrayList<Int>()

        with(pathIdCursor) {
            while (moveToNext()) {
                pathIds.add(getInt(getColumnIndexOrThrow(COL_PATH_ID)))
            }
            close()
        }

        // For each path ID, get all points in order
        for (pathId in pathIds) {
            val path = ArrayList<com.google.android.gms.maps.model.LatLng>()
            val pointsCursor = db.query(
                TABLE_GENERATED_PATHS,
                arrayOf(COL_LATITUDE, COL_LONGITUDE),
                "$COL_PATH_ID = ?",
                arrayOf(pathId.toString()),
                null, null,
                "$COL_POINT_ORDER ASC"
            )

            with(pointsCursor) {
                while (moveToNext()) {
                    val latitude = getDouble(getColumnIndexOrThrow(COL_LATITUDE))
                    val longitude = getDouble(getColumnIndexOrThrow(COL_LONGITUDE))
                    path.add(com.google.android.gms.maps.model.LatLng(latitude, longitude))
                }
                close()
            }

            paths.add(path)
        }

        db.close()
        return paths
    }
}