import android.content.ContentValues
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolygonOptions
import com.google.android.gms.maps.model.PolylineOptions
import com.google.gson.Gson
import com.google.maps.android.SphericalUtil

class SurveyingActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var dbHelper: DBHelper
    private val pointList = mutableListOf<LatLng>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_surveying)

        // 取得 SupportMapFragment 並啟動地圖
        val mapFragment = supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)

        dbHelper = DBHelper(this)

        // 設定按鈕監聽器
        findViewById<Button>(R.id.btnDraw).setOnClickListener { enableDrawing() }
        findViewById<Button>(R.id.btnComplete).setOnClickListener { connectAllPoints() }
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveToDatabase() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clearMap() }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // 啟用縮放與旋轉手勢
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isRotateGesturesEnabled = true
        mMap.uiSettings.isTiltGesturesEnabled = true  // 加上此行確保 tilt 手勢可用

        // 可設定初始位置（此處以台北為例）
        val initialLocation = LatLng(25.0330, 121.5654)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(initialLocation, 15f))

        // 監聽相機位置改變，更新介面上文字
        mMap.setOnCameraMoveListener {
            val cameraPos = mMap.cameraPosition
            findViewById<TextView>(R.id.txtTilt).text = "地圖傾角: ${cameraPos.bearing}"
            findViewById<TextView>(R.id.txtCenter).text = "地圖中心點: ${cameraPos.target.latitude}, ${cameraPos.target.longitude}"
            findViewById<TextView>(R.id.txtZoom).text = "地圖縮放比: ${cameraPos.zoom}"
        }
    }

    // 啟用繪圖模式：點擊地圖後加入標記，並依序顯示數字序號
    private fun enableDrawing() {
        mMap.setOnMapClickListener { latLng ->
            pointList.add(latLng)
            mMap.addMarker(
                MarkerOptions()
                    .position(latLng)
                    .title("點 ${pointList.size}")
            )
        }
    }

    // 連線所有點形成封閉區域
    private fun connectAllPoints() {
        if (pointList.size >= 3) {
            // 使用 PolylineOptions 依序加入所有點，再加上第一個點以封閉區域

            // 繪製多邊形
            val polygonOptions = PolygonOptions()
                .addAll(points)
                .strokeWidth(5f)
                .strokeColor(0xFFFF0000.toInt()) // 紅色邊框
                .fillColor(0x22FF0000.toInt()) // 半透明紅色填充
            googleMap.addPolygon(polygonOptions)

            // 計算並顯示每一條線段的長度
            for (i in 0 until points.size) {
                val startPoint = points[i]
                val endPoint = points[(i + 1) % points.size] // 最後一個點連回第一個點

                // 計算線段長度
                val distance = SphericalUtil.computeDistanceBetween(startPoint, endPoint)
                Log.d("Distance", "線段 ${i + 1} 的長度: $distance 公尺")

                // 在線段中間添加標示文字
                val midPoint = LatLng(
                    (startPoint.latitude + endPoint.latitude) / 2,
                    (startPoint.longitude + endPoint.longitude) / 2
                )
                googleMap.addMarker(
                    MarkerOptions()
                        .position(midPoint)
                        .title("${String.format("%.2f", distance)} 公尺")
                )
            }

            /*
            val polygonOptions = PolylineOptions()
                .addAll(pointList)
                .add(pointList.first())
                .color(Color.RED)
            mMap.addPolyline(polygonOptions)
            */


        } else {
            Toast.makeText(this, "請至少標記三個點以形成封閉區域", Toast.LENGTH_SHORT).show()
        }
    }


    // 清除地圖上的標記、線條以及輸入框內容
    private fun clearMap() {
        mMap.clear()
        pointList.clear()
        findViewById<EditText>(R.id.etDescription).text.clear()
    }

    // 將繪圖點與相關資訊儲存到 SQLite 資料庫
    private fun saveToDatabase() {
        val db = dbHelper.writableDatabase
        val jsonPoints = Gson().toJson(pointList)
        val description = findViewById<EditText>(R.id.etDescription).text.toString()
        val cameraPos = mMap.cameraPosition

        val values = ContentValues().apply {
            put("coordinates", jsonPoints)
            put("description", description)
            put("created_at", System.currentTimeMillis())
            put("zoom_level", cameraPos.zoom)
            put("center_point", "${cameraPos.target.latitude},${cameraPos.target.longitude}")
            put("map_tilt", cameraPos.tilt)
        }

        val result = db.insert("Surveying", null, values)
        db.close()

        if (result != -1L) {
            Toast.makeText(this, "保存成功！", Toast.LENGTH_SHORT).show()
            finish()
            return
        } else {
            Toast.makeText(this, "保存失敗！", Toast.LENGTH_SHORT).show()
        }
    }
}
