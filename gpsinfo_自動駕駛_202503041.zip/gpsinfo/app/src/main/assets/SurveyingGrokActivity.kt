import android.Manifest
import android.content.pm.PackageManager
import android.database.sqlite.SQLiteDatabase
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolylineOptions
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SurveyingGrokActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var dbHelper: DatabaseGrokHelper
    private lateinit var db: SQLiteDatabase

    // UI 元素
    private lateinit var textMapBearing: TextView
    private lateinit var textMapCenter: TextView
    private lateinit var textMapZoom: TextView
    private lateinit var editDescription: EditText
    private lateinit var buttonDraw: Button
    private lateinit var buttonFinish: Button
    private lateinit var buttonSave: Button
    private lateinit var buttonClear: Button

    // 繪圖相關變數
    private val pointsList = mutableListOf<LatLng>()
    private var markerCount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 設置線性佈局
        val linearLayout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT
            )
        }

        // 地圖 Fragment
        val mapFragment = SupportMapFragment.newInstance()
        supportFragmentManager.beginTransaction()
            .add(android.R.id.content, mapFragment)
            .commit()
        mapFragment.getMapAsync(this)

        // ScrollView 包含文字標籤與按鈕
        val scrollView = ScrollView(this).apply {
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val scrollContent = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(16, 16, 16, 16)
        }

        // 地圖資訊顯示
        textMapBearing = TextView(this).apply {
            text = "地圖傾角: 0.0"
            setPadding(0, 8, 0, 8)
        }
        textMapCenter = TextView(this).apply {
            text = "地圖中心點: 未設置"
            setPadding(0, 8, 0, 8)
        }
        textMapZoom = TextView(this).apply {
            text = "地圖縮放比: 0.0"
            setPadding(0, 8, 0, 8)
        }

        // 說明輸入框
        editDescription = EditText(this).apply {
            hint = "請輸入說明"
            setPadding(0, 8, 0, 8)
        }

        // 按鈕
        buttonDraw = Button(this).apply {
            text = "繪圖"
            setOnClickListener { enableDrawingMode() }
        }
        buttonFinish = Button(this).apply {
            text = "完成"
            setOnClickListener { finishDrawing() }
        }
        buttonSave = Button(this).apply {
            text = "保存到資料表"
            setOnClickListener { saveToDatabase() }
        }
        buttonClear = Button(this).apply {
            text = "清除"
            setOnClickListener { clearDrawing() }
        }

        // 將 UI 元素加入佈局
        scrollContent.addView(textMapBearing)
        scrollContent.addView(textMapCenter)
        scrollContent.addView(textMapZoom)
        scrollContent.addView(editDescription)
        scrollContent.addView(buttonDraw)
        scrollContent.addView(buttonFinish)
        scrollContent.addView(buttonSave)
        scrollContent.addView(buttonClear)

        scrollView.addView(scrollContent)
        linearLayout.addView(scrollView)
        setContentView(linearLayout)

        // 初始化資料庫與定位
        dbHelper = DatabaseGrokHelper(this)
        db = dbHelper.writableDatabase
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // 請求定位權限
        requestLocationPermission()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // 啟用地圖縮放與旋轉
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isRotateGesturesEnabled = true

        // 顯示目前位置
        showCurrentLocation()

        // 地圖事件監聽
        mMap.setOnCameraIdleListener {
            textMapBearing.text = "地圖傾角: ${mMap.cameraPosition.bearing}"
            textMapCenter.text = "地圖中心點: ${mMap.cameraPosition.target.latitude}, ${mMap.cameraPosition.target.longitude}"
            textMapZoom.text = "地圖縮放比: ${mMap.cameraPosition.zoom}"
            Log.d("地圖傾角:","${mMap.cameraPosition.bearing}")
            Log.d("地圖中心點:","${mMap.cameraPosition.target.latitude}, ${mMap.cameraPosition.target.longitude}")
            Log.d("地圖縮放比:","${mMap.cameraPosition.zoom}")
        }

        // 點擊地圖添加標記（繪圖模式）
        mMap.setOnMapClickListener { latLng ->
            if (buttonDraw.isEnabled) {
                markerCount++
                pointsList.add(latLng)
                mMap.addMarker(MarkerOptions().position(latLng).title("點 $markerCount"))
            }
        }
    }

    private fun showCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return
        }
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            location?.let {
                val currentLatLng = LatLng(it.latitude, it.longitude)
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15f))
                mMap.addMarker(MarkerOptions().position(currentLatLng).title("目前位置"))
            }
        }
    }

    private fun enableDrawingMode() {
        buttonDraw.isEnabled = false
        buttonFinish.isEnabled = true
    }

    private fun finishDrawing() {
        if (pointsList.size > 2) {
            pointsList.add(pointsList[0]) // 封閉區域
            mMap.addPolyline(PolylineOptions().addAll(pointsList).color(Color.RED).width(5f))
        }
        buttonDraw.isEnabled = true
        buttonFinish.isEnabled = false
    }

    private fun saveToDatabase() {
        if (pointsList.isEmpty()) return

        val coordinatesJson = JSONArray().apply {
            pointsList.forEach { put("${it.latitude},${it.longitude}") }
        }.toString()

        val description = editDescription.text.toString()
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        val zoom = mMap.cameraPosition.zoom
        val center = "${mMap.cameraPosition.target.latitude},${mMap.cameraPosition.target.longitude}"
        val bearing = mMap.cameraPosition.bearing

        val values = android.content.ContentValues().apply {
            put("coordinates", coordinatesJson)
            put("description", description)
            put("created_at", time)
            put("zoom_level", zoom)
            put("center_point", center)
            put("bearing", bearing)
        }

        db.insert("Surveying", null, values)
        Log.d("Database", "Data saved successfully")
    }

    private fun clearDrawing() {
        mMap.clear()
        pointsList.clear()
        markerCount = 0
        editDescription.text.clear()
        buttonDraw.isEnabled = true
        buttonFinish.isEnabled = false
    }

    private fun requestLocationPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            showCurrentLocation()
        }
    }
}

// SQLite 資料庫輔助類
class DatabaseGrokHelper(context: android.content.Context) : android.database.sqlite.SQLiteOpenHelper(context, "gpsinfo", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE Surveying (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                coordinates TEXT,
                description TEXT,
                created_at TEXT,
                zoom_level REAL,
                center_point TEXT,
                bearing REAL
            )
        """)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS Surveying")
        onCreate(db)
    }
}