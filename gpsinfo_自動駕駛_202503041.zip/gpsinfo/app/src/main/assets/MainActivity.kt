import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.PolylineOptions
import java.util.*

class MainActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var map: GoogleMap
    private lateinit var dbHelper: DatabaseHelper
    private var pathList = mutableListOf<LatLng>()
    private var currentStep = 0

    // UI Elements
    private lateinit var widthInput: EditText
    private lateinit var lengthInput: EditText
    private lateinit var overlapInput: EditText
    private lateinit var clearButton: Button
    private lateinit var loadButton: Button
    private lateinit var centerButton: Button
    private lateinit var stepButton: Button

    // Field boundaries (converted from meters to degrees, 1 degree ≈ 111111 meters)
    private val baseLat = 25.0  // Example base latitude
    private val baseLng = 121.0 // Example base longitude
    private val meterToDegree = 1.0 / 111111.0
    private val field = listOf(
        LatLng(baseLat, baseLng),
        LatLng(baseLat, baseLng + 80 * meterToDegree),
        LatLng(baseLat + 70 * meterToDegree, baseLng + 80 * meterToDegree),
        LatLng(baseLat + 70 * meterToDegree, baseLng + 50 * meterToDegree),
        LatLng(baseLat + 90 * meterToDegree, baseLng)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)

        // Initialize UI elements
        widthInput = findViewById(R.id.width_input)
        lengthInput = findViewById(R.id.length_input)
        overlapInput = findViewById(R.id.overlap_input)
        clearButton = findViewById(R.id.clear_button)
        loadButton = findViewById(R.id.load_button)
        centerButton = findViewById(R.id.center_button)
        stepButton = findViewById(R.id.step_button)

        // Set default values
        widthInput.setText("2")
        lengthInput.setText("3")
        overlapInput.setText("0.3")

        // Map setup
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        setupButtons()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        drawFieldBoundary()
        generateAndDrawPath()
    }

    private fun drawFieldBoundary() {
        map.addPolyline(
            PolylineOptions()
                .addAll(field)
                .add(field[0]) // Close the polygon
                .color(android.graphics.Color.GREEN)
                .width(3f)
        )
    }

    private fun generateAndDrawPath() {
        pathList.clear()
        map.clear()
        drawFieldBoundary()

        val width = widthInput.text.toString().toDouble()
        val overlap = overlapInput.text.toString().toDouble()
        val effectiveWidth = width * (1 - overlap)

        val minX = field.minOf { it.longitude }
        val maxX = field.maxOf { it.longitude }
        val minY = field.minOf { it.latitude }
        val maxY = field.maxOf { it.latitude }

        pathList.addAll(generateContinuousPath(minX, maxX, minY, maxY, effectiveWidth))

        val pathId = UUID.randomUUID().toString()
        savePathToDatabase(pathId, listOf(pathList))

        // Draw the complete path
        map.addPolyline(
            PolylineOptions()
                .addAll(pathList)
                .color(android.graphics.Color.RED)
                .width(5f)
        )

        Log.d("PATH", "Generated path ID: $pathId with ${pathList.size} points")
        pathList.forEachIndexed { index, point ->
            Log.d("PATH", "Point $index: $point")
        }

        centerMap()
    }

    private fun generateContinuousPath(
        minX: Double,
        maxX: Double,
        minY: Double,
        maxY: Double,
        effectiveWidth: Double
    ): List<LatLng> {
        val points = mutableListOf<LatLng>()
        var offset = 0.0
        var currentX = minX
        var currentY = minY
        var direction = 1 // 1 for right/up, -1 for left/down

        while (offset < minOf((maxX - minX) / meterToDegree, (maxY - minY) / meterToDegree) / 2) {
            val offsetDegree = offset * meterToDegree

            // Current boundaries with offset
            val left = minX + offsetDegree
            val right = maxX - offsetDegree
            val bottom = minY + offsetDegree
            val top = maxY - offsetDegree

            if (right <= left || top <= bottom) break

            // Start at bottom-left corner
            if (points.isEmpty()) {
                points.add(LatLng(bottom, left))
                currentX = left
                currentY = bottom
            }

            // Move right
            while (direction == 1 && currentX < right) {
                currentX = minOf(currentX + effectiveWidth * meterToDegree, right)
                points.add(LatLng(currentY, currentX))
            }

            // Move up
            while (direction == 1 && currentY < top) {
                currentY = minOf(currentY + effectiveWidth * meterToDegree, top)
                points.add(LatLng(currentY, currentX))
            }
            direction = -1

            // Move left
            while (direction == -1 && currentX > left) {
                currentX = maxOf(currentX - effectiveWidth * meterToDegree, left)
                points.add(LatLng(currentY, currentX))
            }

            // Move down
            while (direction == -1 && currentY > bottom) {
                currentY = maxOf(currentY - effectiveWidth * meterToDegree, bottom)
                points.add(LatLng(currentY, currentX))
            }
            direction = 1

            offset += effectiveWidth
        }

        return points
    }

    private fun savePathToDatabase(pathId: String, paths: List<List<LatLng>>) {
        paths.forEachIndexed { index, path ->
            dbHelper.insertPath(pathId, index, path, "CONTINUOUS")
        }
    }

    private fun setupButtons() {
        clearButton.setOnClickListener {
            map.clear()
            pathList.clear()
            currentStep = 0
            drawFieldBoundary()
        }

        loadButton.setOnClickListener {
            val paths = dbHelper.getPath("some_path_id")
            map.clear()
            drawFieldBoundary()
            paths.forEach { path ->
                map.addPolyline(
                    PolylineOptions()
                        .addAll(path)
                        .color(android.graphics.Color.RED)
                        .width(5f)
                )
            }
            Toast.makeText(this, "Loaded path with ${paths.size} segments", Toast.LENGTH_SHORT).show()
        }

        centerButton.setOnClickListener {
            centerMap()
        }

        stepButton.setOnClickListener {
            if (currentStep == 0) {
                map.clear()
                drawFieldBoundary()
            }
            if (currentStep < pathList.size) {
                drawStep(currentStep)
                currentStep++
            } else {
                Toast.makeText(this, "Path complete", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun centerMap() {
        val bounds = LatLngBounds.Builder()
        field.forEach { bounds.include(it) }
        val center = bounds.build().center
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(center, 15f))
    }

    private fun drawStep(step: Int) {
        val point = pathList[step]
        if (step > 0) {
            map.addPolyline(
                PolylineOptions()
                    .add(pathList[step - 1], point)
                    .width(5f)
                    .color(android.graphics.Color.RED)
            )
        }

        drawTractorOutline(point)

        Log.d("STEP", "Drawing step $step at $point")
    }

    private fun drawTractorOutline(center: LatLng) {
        val width = widthInput.text.toString().toDouble() * meterToDegree
        val length = lengthInput.text.toString().toDouble() * meterToDegree

        val halfWidth = width / 2
        val halfLength = length / 2

        map.addPolyline(
            PolylineOptions()
                .add(
                    LatLng(center.latitude - halfLength, center.longitude - halfWidth),
                    LatLng(center.latitude + halfLength, center.longitude - halfWidth),
                    LatLng(center.latitude + halfLength, center.longitude + halfWidth),
                    LatLng(center.latitude - halfLength, center.longitude + halfWidth),
                    LatLng(center.latitude - halfLength, center.longitude - halfWidth)
                )
                .color(android.graphics.Color.BLUE)
                .width(2f)
        )
    }
}

// DatabaseHelper.kt (保持不變)
class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "PathDB", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE paths (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                path_id TEXT,
                segment_index INTEGER,
                latitude REAL,
                longitude REAL,
                type TEXT
            )
        """)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS paths")
        onCreate(db)
    }

    fun insertPath(pathId: String, segmentIndex: Int, points: List<LatLng>, type: String) {
        val db = writableDatabase
        points.forEach { point ->
            val values = ContentValues().apply {
                put("path_id", pathId)
                put("segment_index", segmentIndex)
                put("latitude", point.latitude)
                put("longitude", point.longitude)
                put("type", type)
            }
            db.insert("paths", null, values)
        }
    }

    fun getPath(pathId: String): List<List<LatLng>> {
        val paths = mutableListOf<List<LatLng>>()
        val db = readableDatabase
        val cursor = db.query(
            "paths",
            arrayOf("latitude", "longitude", "segment_index"),
            "path_id = ?",
            arrayOf(pathId),
            null,
            null,
            "segment_index"
        )

        var currentSegment = mutableListOf<LatLng>()
        var lastIndex = -1

        while (cursor.moveToNext()) {
            val segmentIndex = cursor.getInt(2)
            if (segmentIndex != lastIndex && currentSegment.isNotEmpty()) {
                paths.add(currentSegment)
                currentSegment = mutableListOf()
            }
            currentSegment.add(
                LatLng(cursor.getDouble(0), cursor.getDouble(1))
            )
            lastIndex = segmentIndex
        }
        if (currentSegment.isNotEmpty()) {
            paths.add(currentSegment)
        }
        cursor.close()
        return paths
    }
}

// activity_main.xml (保持不變)