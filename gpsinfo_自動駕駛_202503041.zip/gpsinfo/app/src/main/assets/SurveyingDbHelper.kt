import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.google.android.gms.maps.model.LatLng

class SurveyingDbHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "Surveying.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "Surveying"
        private const val COLUMN_ID = "id"
        private const val COLUMN_COORDINATES = "coordinates"
        private const val COLUMN_DESCRIPTION = "description"
        private const val COLUMN_TIMESTAMP = "timestamp"
        private const val COLUMN_ZOOM = "zoom"
        private const val COLUMN_CENTER = "center"
        private const val COLUMN_TILT = "tilt"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTable = """
            CREATE TABLE $TABLE_NAME (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_COORDINATES TEXT,
                $COLUMN_DESCRIPTION TEXT,
                $COLUMN_TIMESTAMP TEXT,
                $COLUMN_ZOOM REAL,
                $COLUMN_CENTER TEXT,
                $COLUMN_TILT REAL
            )
        """.trimIndent()
        db.execSQL(createTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun insertSurveyingData(
        coordinates: String,
        description: String,
        timestamp: String,
        zoom: Float,
        center: LatLng,
        tilt: Float
    ): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_COORDINATES, coordinates)
            put(COLUMN_DESCRIPTION, description)
            put(COLUMN_TIMESTAMP, timestamp)
            put(COLUMN_ZOOM, zoom)
            put(COLUMN_CENTER, "${center.latitude},${center.longitude}")
            put(COLUMN_TILT, tilt)
        }
        return db.insert(TABLE_NAME, null, values)
    }
}