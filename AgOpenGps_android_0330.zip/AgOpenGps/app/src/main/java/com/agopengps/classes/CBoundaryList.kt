package com.agopengps.classes

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2


class CBoundaryList {
    // List of coordinates of boundary line
    val fenceLine = mutableListOf<Vec3>()
    val fenceLineEar = mutableListOf<Vec2>()
    val hdLine = mutableListOf<Vec3>()
    val turnLine = mutableListOf<Vec3>()

    // Area variable
    var area: Double = 0.0

    // Boundary variables
    var isDriveThru: Boolean = false

    // Constructor
    init {
        area = 0.0
        isDriveThru = false
    }

    fun calculateFenceLineHeadings() {
        val cnt = fenceLine.size
        if (cnt == 0) return

        val arr = fenceLine.toTypedArray()
        fenceLine.clear()

        // First point needs last, first, second points
        var pt3 = arr[0]
        pt3.heading = atan2(arr[1].easting - arr[cnt - 1].easting, arr[1].northing - arr[cnt - 1].northing)
        if (pt3.heading < 0) pt3.heading += 2 * PI
        fenceLine.add(pt3)

        // Middle points
        for (i in 1 until cnt - 1) {
            pt3 = arr[i]
            pt3.heading = atan2(arr[i + 1].easting - arr[i - 1].easting, arr[i + 1].northing - arr[i - 1].northing)
            if (pt3.heading < 0) pt3.heading += 2 * PI
            fenceLine.add(pt3)
        }

        // Last point
        pt3 = arr[cnt - 1]
        pt3.heading = atan2(arr[0].easting - arr[cnt - 2].easting, arr[0].northing - arr[cnt - 2].northing)
        if (pt3.heading < 0) pt3.heading += 2 * PI
        fenceLine.add(pt3)
    }

    fun fixFenceLine(bndNum: Int) {
        val spacing = when {
            area < 200000 -> 1.1
            area < 400000 -> 2.2
            else -> 3.3
        } * if (bndNum > 0) 0.5 else 1.0

        var bndCount = fenceLine.size
        var distance: Double

        // Ensure distance isn't too big between points on boundary (first pass)
        var i = 0
        while (i < bndCount) {
            val j = if (i + 1 == bndCount) 0 else i + 1
            distance = distance(fenceLine[i], fenceLine[j])
            if (distance > spacing * 1.5) {
                val pointB = Vec3(
                    (fenceLine[i].easting + fenceLine[j].easting) / 2.0,
                    (fenceLine[i].northing + fenceLine[j].northing) / 2.0,
                    fenceLine[i].heading
                )
                fenceLine.add(j, pointB)
                bndCount = fenceLine.size
                i--
            }
            i++
        }

        // Second pass for bigger distances
        bndCount = fenceLine.size
        i = 0
        while (i < bndCount) {
            val j = if (i + 1 == bndCount) 0 else i + 1
            distance = distance(fenceLine[i], fenceLine[j])
            if (distance > spacing * 1.6) {
                val pointB = Vec3(
                    (fenceLine[i].easting + fenceLine[j].easting) / 2.0,
                    (fenceLine[i].northing + fenceLine[j].northing) / 2.0,
                    fenceLine[i].heading
                )
                fenceLine.add(j, pointB)
                bndCount = fenceLine.size
                i--
            }
            i++
        }

        // Ensure distance isn't too small
        val minSpacing = spacing * 0.9
        i = 0
        while (i < bndCount - 1) {
            distance = distance(fenceLine[i], fenceLine[i + 1])
            if (distance < minSpacing) {
                fenceLine.removeAt(i + 1)
                bndCount = fenceLine.size
                i--
            }
            i++
        }

        calculateFenceLineHeadings()

        var delta = 0.0
        fenceLineEar.clear()
        fenceLine.forEachIndexed { index, vec3 ->
            if (index == 0) {
                fenceLineEar.add(Vec2(vec3.easting, vec3.northing))
                return@forEachIndexed
            }
            delta += (fenceLine[index - 1].heading - vec3.heading)
            if (abs(delta) > 0.005) {
                fenceLineEar.add(Vec2(vec3.easting, vec3.northing))
                delta = 0.0
            }
        }
    }

    fun reverseWinding() {
        val arr = fenceLine.toTypedArray()
        fenceLine.clear()
        for (i in arr.indices.reversed()) {
            arr[i].heading = (arr[i].heading - PI).let { if (it < 0) it + 2 * PI else it }
            fenceLine.add(arr[i])
        }
    }

    fun calculateFenceArea(idx: Int): Boolean {
        val ptCount = fenceLine.size
        if (ptCount < 1) return false

        area = 0.0
        var j = ptCount - 1

        for (i in 0 until ptCount) {
            area += (fenceLine[j].easting + fenceLine[i].easting) * (fenceLine[j].northing - fenceLine[i].northing)
            j = i
        }

        val isClockwise = area >= 0
        area = abs(area / 2)

        if ((idx == 0 && isClockwise) || (idx > 0 && !isClockwise)) {
            reverseWinding()
        }

        return isClockwise
    }

    fun calculateTurnHeadings() {
        val cnt = turnLine.size
        if (cnt == 0) return

        val arr = turnLine.toTypedArray()
        turnLine.clear()

        // First point
        var pt3 = arr[0]
        pt3.heading = atan2(arr[1].easting - arr[cnt - 1].easting, arr[1].northing - arr[cnt - 1].northing)
        if (pt3.heading < 0) pt3.heading += 2 * PI
        turnLine.add(pt3)

        // Middle points
        for (i in 1 until cnt - 1) {
            pt3 = arr[i]
            pt3.heading = atan2(arr[i + 1].easting - arr[i - 1].easting, arr[i + 1].northing - arr[i - 1].northing)
            if (pt3.heading < 0) pt3.heading += 2 * PI
            turnLine.add(pt3)
        }

        // Last point and additional first/last points
        pt3 = arr[cnt - 1]
        pt3.heading = atan2(arr[0].easting - arr[cnt - 2].easting, arr[0].northing - arr[cnt - 2].northing)
        if (pt3.heading < 0) pt3.heading += 2 * PI
        turnLine.add(pt3)

        val pt2First = arr[0]
        pt2First.heading = atan2(arr[1].easting - arr[0].easting, arr[1].northing - arr[0].northing)
        if (pt2First.heading < 0) pt2First.heading += 2 * PI
        turnLine.add(0, pt2First)

        val pt2Last = arr[cnt - 1]
        pt2Last.heading = atan2(arr[cnt - 1].easting - arr[cnt - 2].easting, arr[cnt - 1].northing - arr[cnt - 2].northing)
        if (pt2Last.heading < 0) pt2Last.heading += 2 * PI
        turnLine.add(pt2Last)
    }

    fun fixTurnLine(totalHeadWidth: Double, spacing: Int) {
        val totalHeadWidthSquared = totalHeadWidth * totalHeadWidth
        val spacingSquared = spacing * spacing

        var lineCount = turnLine.size

        // Remove points too close to boundary
        i@ for (i in fenceLine.indices) {
            j@ for (j in 0 until lineCount) {
                val distance = distanceSquared(fenceLine[i], turnLine[j])
                if (distance < totalHeadWidthSquared * 0.99) {
                    turnLine.removeAt(j)
                    lineCount = turnLine.size
                    continue@j
                }
            }
        }

        // Ensure distance isn't too big between points
        var bndCount = turnLine.size
        var i = 0
        while (i < bndCount) {
            val j = if (i + 1 == bndCount) 0 else i + 1
            val distance = distanceSquared(turnLine[i], turnLine[j])
            if (distance > spacingSquared * 1.8) {
                val pointB = Vec3(
                    (turnLine[i].easting + turnLine[j].easting) / 2.0,
                    (turnLine[i].northing + turnLine[j].northing) / 2.0,
                    turnLine[i].heading
                )
                turnLine.add(j, pointB)
                bndCount = turnLine.size
                i--
            }
            i++
        }

        // Ensure distance isn't too small
        bndCount = turnLine.size
        i = 0
        while (i < bndCount - 1) {
            val distance = distanceSquared(turnLine[i], turnLine[i + 1])
            if (distance < spacingSquared) {
                turnLine.removeAt(i + 1)
                bndCount = turnLine.size
                i--
            }
            i++
        }

        if (turnLine.isNotEmpty()) {
            calculateTurnHeadings()
        }
    }

    private fun distance(pt1: Vec3, pt2: Vec3): Double {
        val dx = pt1.easting - pt2.easting
        val dy = pt1.northing - pt2.northing
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }

    private fun distanceSquared(pt1: Vec3, pt2: Vec3): Double {
        val dx = pt1.easting - pt2.easting
        val dy = pt1.northing - pt2.northing
        return dx * dx + dy * dy
    }
}