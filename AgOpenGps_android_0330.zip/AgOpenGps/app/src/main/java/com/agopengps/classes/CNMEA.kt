package com.agopengps.classes

import com.agopengps.drive.MainActivity
import java.util.*
import kotlin.math.cos

class CNMEA(private val mf: MainActivity) {
    // WGS84 Lat Long
    var latitude: Double = 0.0
    var longitude: Double = 0.0
    var prevLatitude: Double = 0.0
    var prevLongitude: Double = 0.0

    // local plane geometry
    var latStart: Double = 0.0
    var lonStart: Double = 0.0
    var mPerDegreeLat: Double = 0.0
    var mPerDegreeLon: Double = 0.0

    // our current fix
    var fix: Vec2 = Vec2(0.0, 0.0)
    var prevSpeedFix: Vec2 = Vec2(0.0, 0.0)

    // used to offset the antenna position to compensate for drift
    var fixOffset: Vec2 = Vec2(0.0, 0.0)

    // other GIS Info
    var altitude: Double = 0.0
    var speed: Double = 0.0
    var newSpeed: Double = 0.0
    var vtgSpeed: Double = Double.MAX_VALUE
    var headingTrueDual: Double = 0.0
    var headingTrue: Double = 0.0
    var hdop: Double = 0.0
    var age: Double = 0.0
    var headingTrueDualOffset: Double = 0.0
    var fixQuality: Int = 0
    var ageAlarm: Int = 0
    var satellitesTracked: Int = 0

    init {
        // Load default settings - you'll need to replace this with Android equivalent
        ageAlarm = mf.sharedPreferences.getInt("setGPS_ageAlarm", 0)
    }

    fun averageTheSpeed() {
        // average the speed
        mf.avgSpeed = (mf.avgSpeed * 0.75) + (speed * 0.25)
    }

    fun setLocalMetersPerDegree() {
        val latRad = Math.toRadians(latStart)

        mPerDegreeLat = 111132.92 - 559.82 * cos(2.0 * latRad) + 1.175 *
                cos(4.0 * latRad) - 0.0023 * cos(6.0 * latRad)

        mPerDegreeLon = 111412.84 * cos(latRad) - 93.5 *
                cos(3.0 * latRad) + 0.118 * cos(5.0 * latRad)

        convertWGS84ToLocal(latitude, longitude).let { (northing, easting) ->
            mf.worldGrid.checkZoomWorldGrid(northing, easting)
        }
    }

    fun convertWGS84ToLocal(lat: Double, lon: Double): Pair<Double, Double> {
        val latRad = Math.toRadians(lat)
        mPerDegreeLon = 111412.84 * cos(latRad) - 93.5 *
                cos(3.0 * latRad) + 0.118 * cos(5.0 * latRad)

        val northing = (lat - latStart) * mPerDegreeLat
        val easting = (lon - lonStart) * mPerDegreeLon

        return Pair(northing, easting)
    }

    fun convertLocalToWGS84(northing: Double, easting: Double): Pair<Double, Double> {
        var lat = ((northing + fixOffset.northing) / mPerDegreeLat) + latStart
        val latRad = Math.toRadians(lat)

        mPerDegreeLon = 111412.84 * cos(latRad) - 93.5 *
                cos(3.0 * latRad) + 0.118 * cos(5.0 * latRad)

        val lon = ((easting + fixOffset.easting) / mPerDegreeLon) + lonStart

        return Pair(lat, lon)
    }

    fun getLocalToWSG84_KML(easting: Double, northing: Double): String {
        var lat = (northing / mPerDegreeLat) + latStart
        val latRad = Math.toRadians(lat)

        mPerDegreeLon = 111412.84 * cos(latRad) - 93.5 *
                cos(3.0 * latRad) + 0.118 * cos(5.0 * latRad)

        val lon = (easting / mPerDegreeLon) + lonStart

        return "%.7f,%.7f,0 ".format(locale = Locale.US, lon, lat)
    }
}

