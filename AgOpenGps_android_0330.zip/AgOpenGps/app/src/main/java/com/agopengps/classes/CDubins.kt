package com.agopengps.classes

import com.agopengps.classes.*
import com.agopengps.classes.MathConstants.PI
import com.agopengps.drive.FormGPS
import kotlin.math.*

object MathConstants {
    const val PI = kotlin.math.PI
    const val PIBy2 = PI / 2.0
    const val TwoPI = 2.0 * PI
}

//To keep track of the different paths when debugging
enum class PathType { RSR, LSL, RSL, LSR, RLR, LRL }

//Display the final Dubins Paths
class CDubins(private val mf: FormGPS) {
/*
    companion object {
        //How far we are driving each update, the accuracy will improve if we lower the driveDistance
        const val driveDistance = 0.05

        //The radius the car can turn 360 degrees with
        var turningRadius: Double = mf.settings.getDouble("set_youTurnRadius", 10.0)
    }
*/
    companion object {
        const val driveDistance = 0.05
        var turningRadius: Double = 10.0 // 默认值
    }

    init {
        turningRadius = mf.settings.getDouble("set_youTurnRadius", 10.0)
    }

    //Position, Heading is in radians
    private lateinit var startPos: Vec2
    private lateinit var goalPos: Vec2
    private var startHeading = 0.0
    private var goalHeading = 0.0

    private val pathDataList = mutableListOf<OneDubinsPath>()
    private val dubinsShortestPathList = mutableListOf<Vec3>()

    //The 4 different circles we have that sits to the left/right of the start/goal
    private lateinit var startLeftCircle: Vec2
    private lateinit var startRightCircle: Vec2
    private lateinit var goalLeftCircle: Vec2
    private lateinit var goalRightCircle: Vec2

    //takes 2 points and headings to create a path - returns list of vec3 points and headings
    fun GenerateDubins(_start: Vec3, _goal: Vec3): List<Vec3> {
        //positions and heading
        startPos = Vec2(_start.easting, _start.northing)
        startHeading = _start.heading

        goalPos = Vec2(_goal.easting, _goal.northing)
        goalHeading = _goal.heading

        //Get all valid Dubins paths
        getAllDubinsPaths()

        //clear out existing path of vec3 points
        dubinsShortestPathList.clear()

        if (pathDataList.isNotEmpty()) {
            val cnt = pathDataList[0].pathCoordinates.size
            if (cnt > 1) {
                //calculate the heading for each point
                for (i in 0 until cnt - 1 step 5) {
                    val pt = Vec3(
                        pathDataList[0].pathCoordinates[i].easting,
                        pathDataList[0].pathCoordinates[i].northing,
                        0.0
                    ).apply {
                        heading = atan2(
                            pathDataList[0].pathCoordinates[i + 1].easting - pathDataList[0].pathCoordinates[i].easting,
                            pathDataList[0].pathCoordinates[i + 1].northing - pathDataList[0].pathCoordinates[i].northing
                        )
                    }
                    dubinsShortestPathList.add(pt)
                }
            }
        }
        return dubinsShortestPathList
    }

    //Get all valid Dubins paths sorted from shortest to longest
    private fun getAllDubinsPaths(): List<OneDubinsPath> {
        //Reset the list with all Dubins paths
        pathDataList.clear()

        //Position the circles that are to the left/right of the cars
        positionLeftRightCircles()

        //Find the length of each path with tangent coordinates
        calculateDubinsPathsLengths()

        //If we have paths
        if (pathDataList.isNotEmpty()) {
            //Sort the list with paths so the shortest path is first
            pathDataList.sortBy { it.totalLength }

            //Generate the final coordinates of the path from tangent points and segment lengths
            generatePathCoordinates()
        }

        return pathDataList
    }

    //Position the left and right circles that are to the left/right of the target and the car
    private fun positionLeftRightCircles() {
        //Goal pos
        goalRightCircle = DubinsMath.getRightCircleCenterPos(goalPos, goalHeading)
        goalLeftCircle = DubinsMath.getLeftCircleCenterPos(goalPos, goalHeading)

        //Start pos
        startRightCircle = DubinsMath.getRightCircleCenterPos(startPos, startHeading)
        startLeftCircle = DubinsMath.getLeftCircleCenterPos(startPos, startHeading)
    }

    //Calculate the path lengths of all Dubins paths by using tangent points
    private fun calculateDubinsPathsLengths() {
        //RSR and LSL is only working if the circles don't have the same position
        if (startRightCircle != goalRightCircle) {
            getRSRLength()
        }

        //LSL
        if (startLeftCircle != goalLeftCircle) {
            getLSLLength()
        }

        //RSL and LSR is only working of the circles don't intersect
        val comparisonSqr = turningRadius * 2 * turningRadius * 2

        //RSL
        if ((startRightCircle - goalLeftCircle).lengthSquared > comparisonSqr) {
            getRSLLength()
        }

        //LSR
        if ((startLeftCircle - goalRightCircle).lengthSquared > comparisonSqr) {
            getLSRLength()
        }

        //With the LRL and RLR paths, the distance between the circles have to be less than 4 * r
        val comparisonSqr2 = 4 * turningRadius * 4 * turningRadius

        //RLR
        if ((startRightCircle - goalRightCircle).lengthSquared < comparisonSqr2) {
            getRLRLength()
        }

        //LRL
        if ((startLeftCircle - goalLeftCircle).lengthSquared < comparisonSqr2) {
            getLRLLength()
        }
    }

    //RSR
    private fun getRSRLength() {
        //Find both tangent positions
        val (startTangent, goalTangent) = DubinsMath.lslOrRSR(
            startRightCircle,
            goalRightCircle,
            false
        )

        //Calculate lengths
        val length1 = DubinsMath.getArcLength(startRightCircle, startPos, startTangent, false)
        val length2 = (startTangent - goalTangent).length
        val length3 = DubinsMath.getArcLength(goalRightCircle, goalTangent, goalPos, false)

        //Save the data
        val pathData = OneDubinsPath(
            length1,
            length2,
            length3,
            startTangent,
            goalTangent,
            PathType.RSR
        ).apply {
            //We also need this data to simplify when generating the final path
            segment2Turning = false
            //RSR
            setIfTurningRight(true, false, true)
        }

        //Add the path to the collection of all paths
        pathDataList.add(pathData)
    }

    //LSL
    private fun getLSLLength() {
        //Find both tangent positions
        val (startTangent, goalTangent) = DubinsMath.lslOrRSR(startLeftCircle, goalLeftCircle, true)

        //Calculate lengths
        val length1 = DubinsMath.getArcLength(startLeftCircle, startPos, startTangent, true)
        val length2 = (startTangent - goalTangent).length
        val length3 = DubinsMath.getArcLength(goalLeftCircle, goalTangent, goalPos, true)

        //Save the data
        val pathData = OneDubinsPath(
            length1,
            length2,
            length3,
            startTangent,
            goalTangent,
            PathType.LSL
        ).apply {
            //We also need this data to simplify when generating the final path
            segment2Turning = false
            //LSL
            setIfTurningRight(false, false, false)
        }

        //Add the path to the collection of all paths
        pathDataList.add(pathData)
    }

    //RSL
    private fun getRSLLength() {
        //Find both tangent positions
        val (startTangent, goalTangent) = DubinsMath.rslOrLSR(
            startRightCircle,
            goalLeftCircle,
            false
        )

        //Calculate lengths
        val length1 = DubinsMath.getArcLength(startRightCircle, startPos, startTangent, false)
        val length2 = (startTangent - goalTangent).length
        val length3 = DubinsMath.getArcLength(goalLeftCircle, goalTangent, goalPos, true)

        //Save the data
        val pathData = OneDubinsPath(
            length1,
            length2,
            length3,
            startTangent,
            goalTangent,
            PathType.RSL
        ).apply {
            //We also need this data to simplify when generating the final path
            segment2Turning = false
            //RSL
            setIfTurningRight(true, false, false)
        }

        //Add the path to the collection of all paths
        pathDataList.add(pathData)
    }

    //LSR
    private fun getLSRLength() {
        //Find both tangent positions
        val (startTangent, goalTangent) = DubinsMath.rslOrLSR(
            startLeftCircle,
            goalRightCircle,
            true
        )

        //Calculate lengths
        val length1 = DubinsMath.getArcLength(startLeftCircle, startPos, startTangent, true)
        val length2 = (startTangent - goalTangent).length
        val length3 = DubinsMath.getArcLength(goalRightCircle, goalTangent, goalPos, false)

        //Save the data
        val pathData = OneDubinsPath(
            length1,
            length2,
            length3,
            startTangent,
            goalTangent,
            PathType.LSR
        ).apply {
            //We also need this data to simplify when generating the final path
            segment2Turning = false
            //LSR
            setIfTurningRight(false, false, true)
        }

        //Add the path to the collection of all paths
        pathDataList.add(pathData)
    }

    //RLR - Find both tangent positions and the position of the 3rd circle
    private fun getRLRLength() {
        val (startTangent, goalTangent, middleCircle) = DubinsMath.getRLRorLRLTangents(
            startRightCircle,
            goalRightCircle,
            false
        )

        //Calculate lengths
        val length1 = DubinsMath.getArcLength(startRightCircle, startPos, startTangent, false)
        val length2 = DubinsMath.getArcLength(middleCircle, startTangent, goalTangent, true)
        val length3 = DubinsMath.getArcLength(goalRightCircle, goalTangent, goalPos, false)

        //Save the data
        val pathData = OneDubinsPath(
            length1,
            length2,
            length3,
            startTangent,
            goalTangent,
            PathType.RLR
        ).apply {
            //We also need this data to simplify when generating the final path
            segment2Turning = true
            //RLR
            setIfTurningRight(true, false, true)
        }

        //Add the path to the collection of all paths
        pathDataList.add(pathData)
    }

    //LRL - Find both tangent positions and the position of the 3rd circle
    private fun getLRLLength() {
        val (startTangent, goalTangent, middleCircle) = DubinsMath.getRLRorLRLTangents(
            startLeftCircle,
            goalLeftCircle,
            true
        )

        //Calculate the total length of this path
        val length1 = DubinsMath.getArcLength(startLeftCircle, startPos, startTangent, true)
        val length2 = DubinsMath.getArcLength(middleCircle, startTangent, goalTangent, false)
        val length3 = DubinsMath.getArcLength(goalLeftCircle, goalTangent, goalPos, true)

        //Save the data
        val pathData = OneDubinsPath(
            length1,
            length2,
            length3,
            startTangent,
            goalTangent,
            PathType.LRL
        ).apply {
            //We also need this data to simplify when generating the final path
            segment2Turning = true
            //LRL
            setIfTurningRight(false, true, false)
        }

        //Add the path to the collection of all paths
        pathDataList.add(pathData)
    }

    //Generate the final path from the tangent points
    private fun generatePathCoordinates() {
        pathDataList.forEach { getTotalPath(it) }
    }

    //Find the coordinates of the entire path from the 2 tangents and length of each segment
    private fun getTotalPath(pathData: OneDubinsPath) {
        //Store the waypoints of the final path here
        val finalPath = mutableListOf<Vec2>()

        //Start position of the car
        var currentPos = startPos
        //Start heading of the car
        var theta = startHeading

        //We always have to add the first position manually
        finalPath.add(currentPos)

        //How many line segments can we fit into this part of the path

        //First
        var segments = floor(pathData.length1 / driveDistance).toInt()
        DubinsMath.addCoordinatesToPath(
            currentPos, theta, finalPath, segments,
            true, pathData.segment1TurningRight
        ).let {
            currentPos = it.first
            theta = it.second
        }

        //Second
        segments = floor(pathData.length2 / driveDistance).toInt()
        DubinsMath.addCoordinatesToPath(
            currentPos, theta, finalPath, segments,
            pathData.segment2Turning, pathData.segment2TurningRight
        ).let {
            currentPos = it.first
            theta = it.second
        }

        //Third
        segments = floor(pathData.length3 / driveDistance).toInt()
        DubinsMath.addCoordinatesToPath(
            currentPos, theta, finalPath, segments,
            true, pathData.segment3TurningRight
        ).let {
            currentPos = it.first
            theta = it.second
        }

        //Add the final goal coordinate
        finalPath.add(Vec2(goalPos.easting, goalPos.northing))

        //Save the final path in the path data
        pathData.pathCoordinates = finalPath
    }
}

//Takes care of all standardized methods related the generating of Dubins paths
object DubinsMath {
    //Calculate center positions of the Right circle
    fun getRightCircleCenterPos(circlePos: Vec2, heading: Double): Vec2 {
        //The circle is 90 degrees (pi/2 radians) to the right of the car's heading
        return Vec2(
            circlePos.easting + (CDubins.turningRadius * sin(heading + glm.PI_BY_2)),
            circlePos.northing + (CDubins.turningRadius * cos(heading + glm.PI_BY_2))
        )
    }

    //Calculate center positions of the Left circle
    fun getLeftCircleCenterPos(circlePos: Vec2, heading: Double): Vec2 {
        //The circle is 90 degrees (pi/2 radians) to the left of the car's heading
        return Vec2(
            circlePos.easting + (CDubins.turningRadius * sin(heading - glm.PI_BY_2)),
            circlePos.northing + (CDubins.turningRadius * cos(heading - glm.PI_BY_2))
        )
    }

    //Outer tangent (LSL and RSR)
    fun lslOrRSR(startCircle: Vec2, goalCircle: Vec2, isBottom: Boolean): Pair<Vec2, Vec2> {
        //The angle to the first tangent coordinate is always 90 degrees if the both circles have the same radius
        var theta = glm.PI_BY_2

        //Need to modify theta if the circles are not on the same height (z)
        theta += atan2(
            goalCircle.northing - startCircle.northing,
            goalCircle.easting - startCircle.easting
        )

        //Add pi to get the "bottom" coordinate which is on the opposite side (180 degrees = pi)
        if (isBottom) theta += PI

        //The coordinates of the first tangent points
        val xT1 = startCircle.easting + (CDubins.turningRadius * cos(theta))
        val zT1 = startCircle.northing + (CDubins.turningRadius * sin(theta))

        //To get the second coordinate we need a direction
        //This direction is the same as the direction between the center pos of the circles
        val dirVec = goalCircle - startCircle

        val xT2 = xT1 + dirVec.easting
        val zT2 = zT1 + dirVec.northing

        //The final coordinates of the tangent lines
        return Pair(Vec2(xT1, zT1), Vec2(xT2, zT2))
    }

    //Inner tangent (RSL and LSR)
    fun rslOrLSR(startCircle: Vec2, goalCircle: Vec2, isBottom: Boolean): Pair<Vec2, Vec2> {
        //Find the distance between the circles
        val D = (startCircle - goalCircle).length

        //If the circles have the same radius we can use cosine and not the law of cosines
        //to calculate the angle to the first tangent coordinate
        var theta = acos((2 * CDubins.turningRadius) / D)

        //If the circles is LSR, then the first tangent pos is on the other side of the center line
        if (isBottom) theta *= -1.0

        //Need to modify theta if the circles are not on the same height
        theta += atan2(
            goalCircle.northing - startCircle.northing,
            goalCircle.easting - startCircle.easting
        )

        //The coordinates of the first tangent point
        val xT1 = startCircle.easting + (CDubins.turningRadius * cos(theta))
        val zT1 = startCircle.northing + (CDubins.turningRadius * sin(theta))

        //To get the second tangent coordinate we need the direction of the tangent
        //To get the direction we move up 2 circle radius and end up at this coordinate
        val xT1_tmp = startCircle.easting + (2.0 * CDubins.turningRadius * cos(theta))
        val zT1_tmp = startCircle.northing + (2.0 * CDubins.turningRadius * sin(theta))

        //The direction is between the new coordinate and the center of the target circle
        val dirVec = goalCircle - Vec2(xT1_tmp, zT1_tmp)

        //The coordinates of the second tangent point is the
        val xT2 = xT1 + dirVec.easting
        val zT2 = zT1 + dirVec.northing

        //The final coordinates of the tangent lines
        return Pair(Vec2(xT1, zT1), Vec2(xT2, zT2))
    }

    //Get the RLR or LRL tangent points
    fun getRLRorLRLTangents(
        startCircle: Vec2,
        goalCircle: Vec2,
        isLRL: Boolean
    ): Triple<Vec2, Vec2, Vec2> {
        //The distance between the circles
        val D = (startCircle - goalCircle).length

        //The angle between the goal and the new 3rd circle we create with the law of cosines
        var theta = acos(D / (4 * CDubins.turningRadius))

        //But we need to modify the angle theta if the circles are not on the same line
        val V1 = goalCircle - startCircle

        //Different depending on if we calculate LRL or RLR
        theta = if (isLRL) {
            atan2(V1.northing, V1.easting) + theta
        } else {
            atan2(V1.northing, V1.easting) - theta
        }

        //Calculate the position of the third circle
        val x = startCircle.easting + (2 * CDubins.turningRadius * cos(theta))
        val z = startCircle.northing + (2 * CDubins.turningRadius * sin(theta))
        val middleCircle = Vec2(x, z)

        //Calculate the tangent points
        var V2 = (startCircle - middleCircle).normalize()
        var V3 = (goalCircle - middleCircle).normalize()
        V2 *= CDubins.turningRadius
        V3 *= CDubins.turningRadius

        val startTangent = middleCircle + V2
        val goalTangent = middleCircle + V3

        return Triple(startTangent, goalTangent, middleCircle)
    }

    //Calculate the length of an circle arc depending on which direction we are driving
    fun getArcLength(
        circleCenterPos: Vec2,
        startPos: Vec2,
        goalPos: Vec2,
        isLeftCircle: Boolean
    ): Double {
        val V1 = startPos - circleCenterPos
        val V2 = goalPos - circleCenterPos

        var theta = atan2(V2.northing, V2.easting) - atan2(V1.northing, V1.easting)
        if (theta < 0 && isLeftCircle) theta += 2.0 * PI
        else if (theta > 0 && !isLeftCircle) theta -= 2.0 * PI
        return abs(theta * CDubins.turningRadius)
    }

    //Loops through segments of a path and add new coordinates to the final path
    fun addCoordinatesToPath(
        currentPos: Vec2,
        theta: Double,
        finalPath: MutableList<Vec2>,
        segments: Int,
        isTurning: Boolean,
        isTurningRight: Boolean
    ): Pair<Vec2, Double> {
        var newPos = currentPos.copy()
        var newTheta = theta

        for (i in 0..segments) {
            //Update the position of the car
            newPos.easting += CDubins.driveDistance * sin(newTheta)
            newPos.northing += CDubins.driveDistance * cos(newTheta)

            //Don't update the heading if we are driving straight
            if (isTurning) {
                //Which way are we turning?
                val turnParameter = if (isTurningRight) 1.0 else -1.0

                //Update the heading
                newTheta += (CDubins.driveDistance / CDubins.turningRadius) * turnParameter
            }

            //Add the new coordinate to the path
            finalPath.add(newPos.copy())
        }

        return Pair(newPos, newTheta)
    }
}

//Will hold data related to one Dubins path so we can sort them
class OneDubinsPath(
    val length1: Double,
    val length2: Double,
    val length3: Double,
    val tangent1: Vec2,
    val tangent2: Vec2,
    val pathType: PathType
) {
    //The total length of this path
    val totalLength = length1 + length2 + length3

    //The coordinates of the final path
    var pathCoordinates = mutableListOf<Vec2>()

    //Are we turning or driving straight in segment 2?
    var segment2Turning = false

    //Are we turning right in the particular segment?
    var segment1TurningRight = false
    var segment2TurningRight = false
    var segment3TurningRight = false

    //Are we turning right in any of the segments?
    fun setIfTurningRight(
        segment1TurningRight: Boolean,
        segment2TurningRight: Boolean,
        segment3TurningRight: Boolean
    ) {
        this.segment1TurningRight = segment1TurningRight
        this.segment2TurningRight = segment2TurningRight
        this.segment3TurningRight = segment3TurningRight
    }
}