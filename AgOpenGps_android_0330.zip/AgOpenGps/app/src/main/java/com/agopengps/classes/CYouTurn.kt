package com.agopengps.classes

import com.agopengps.classes.MathConstants.PI
import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import java.util.*
import kotlin.math.abs
import kotlin.math.atan2
import com.agopengps.classes.*
import kotlin.math.*

class CYouTurn(private val mf: FormGPS) {

    // Fields
    val isYouTurnTriggered: Boolean = false
    private var isGoingStraightThrough: Boolean = false

    var isTurnLeft: Boolean = false
    private var semiCircleIndex: Int = -1

    var isYouTurnBtnOn: Boolean = false

    var youTurnRadius: Double = 0.0

    var rowSkipsWidth: Int = 1
    var uTurnSmoothing: Int = 0

    var alternateSkips: Boolean = false
    private var previousBigSkip: Boolean = true
    var rowSkipsWidth2: Int = 3
    var turnSkips: Int = 2

    var youTurnStartOffset: Int = 0

    // Guidance values
    var distanceFromCurrentLine: Double = 0.0
    var uturnDistanceFromBoundary: Double = 0.0

    var distanceFromCurrentLineSteer: Double = 0.0
    var distanceFromCurrentLinePivot: Double = 0.0
    var steerAngleGu: Double = 0.0
    var rEastSteer: Double = 0.0
    var rNorthSteer: Double = 0.0
    var rEastPivot: Double = 0.0
    var rNorthPivot: Double = 0.0

    private var A: Int = 0
    private var B: Int = 0
    var isHeadingSameWay: Boolean = true
    var isTurnCreationTooClose: Boolean = false
    var isTurnCreationNotCrossingError: Boolean = false
    var turnTooCloseTrigger: Boolean = false

    var goalPointYT: vec2 = vec2(0.0, 0.0)
    var radiusPointYT: vec2 = vec2(0.0, 0.0)
    var steerAngleYT: Double = 0.0
    var rEastYT: Double = 0.0
    var rNorthYT: Double = 0.0
    var ppRadiusYT: Double = 0.0

    //val ytList: MutableList<vec3> = mutableListOf()
    val ytList: MutableList<vec3> = ArrayList<vec3>(128)
    private val ytList2: MutableList<vec3> = mutableListOf()

    val nextCurve: MutableList<vec3> = mutableListOf()

    var isOutSameCurve: Boolean = false

    var uTurnStyle: Int = 0

    var isOutOfBounds: Boolean = false

    var youTurnPhase: Int = 0

    var iE: Double = 0.0
    var iN: Double = 0.0

    val turnClosestList: MutableList<CClose> = mutableListOf()

    var closestTurnPt: CClose = CClose()

    var inClosestTurnPt: CClose = CClose()
    var outClosestTurnPt: CClose = CClose()
    var startOfTurnPt: CClose = CClose()

    private var pointSpacing: Double = 0.0

    // Constructor
    init {
        uturnDistanceFromBoundary = mf.settings.set_youTurnDistanceFromBoundary.toDouble()
        youTurnStartOffset = mf.settings.set_youTurnExtensionLength.toInt()
        rowSkipsWidth = mf.settings.set_youSkipWidth
        Set_Alternate_skips()
      //  ytList.ensureCapacity(128)
        youTurnRadius = mf.settings.set_youTurnRadius.toDouble()
        uTurnStyle = mf.settings.set_uTurnStyle
        uTurnSmoothing = mf.settings.setAS_uTurnSmoothing
    }

    // Methods
    fun BuildCurveDubinsYouTurn(): Boolean {
        val turnOffset = (mf.tool.width - mf.tool.overlap) * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)
        pointSpacing = youTurnRadius * 0.1

        return when (uTurnStyle) {
            0 -> {
                if (turnOffset > (youTurnRadius * 2.0)) {
                    CreateCurveWideTurn()
                } else {
                    CreateCurveOmegaTurn()
                    CreateCurveOmegaTurn()
                }
            }
            1 -> KStyleTurnCurve()
            else -> false // Programming error if you got here
        }
    }

    fun BuildABLineDubinsYouTurn(): Boolean {
        val turnOffset = (mf.tool.width - mf.tool.overlap) * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)
        pointSpacing = youTurnRadius * 0.1

        return when (uTurnStyle) {
            0 -> {
                if (turnOffset > (youTurnRadius * 2.0)) {
                    CreateABWideTurn()
                } else {
                    CreateABOmegaTurn()
                }
            }
            1 -> KStyleTurnAB()
            else -> false // Programming error if you got here
        }
    }

    // Placeholder for CreateCurveOmegaTurn, CreateCurveWideTurn, etc.
    private fun CreateCurveOmegaTurn(): Boolean {
        // To be implemented in the next part
        return false
    }

    private fun CreateCurveWideTurn(): Boolean {
        // To be implemented in the next part
        return false
    }

    private fun CreateABOmegaTurn(): Boolean {
        // To be implemented in the next part
        return false
    }

    private fun CreateABWideTurn(): Boolean {
        // To be implemented in the next part
        return false
    }

    private fun KStyleTurnCurve(): Boolean {
        // To be implemented in the next part
        return false
    }

    private fun KStyleTurnAB(): Boolean {
        // To be implemented in the next part
        return false
    }

    // CClose inner class
    class CClose {
        var closePt: vec3 = vec3()
        var turnLineNum: Int = -1
        var turnLineIndex: Int = -1
        var turnLineHeading: Double = -1.0
        var curveIndex: Int = -1

        constructor() {
            closePt = vec3()
            turnLineNum = -1
            turnLineIndex = -1
            turnLineHeading = -1.0
            curveIndex = -1
        }

        constructor(_clo: CClose) {
            closePt = vec3(_clo.closePt)
            turnLineNum = _clo.turnLineNum
            turnLineIndex = _clo.turnLineIndex
            turnLineHeading = _clo.turnLineHeading
            curveIndex = _clo.curveIndex
        }
    }


    // 前一部分的字段和方法保持不變，這裡從 CreateCurveOmegaTurn 開始


    private fun CreateCurveOmegaTurn(): Boolean {
        if (mf.makeUTurnCounter < 4) {
            youTurnPhase = 0
            return true
        }

        if (mf.trk.idx < 0 || mf.trk.gArr.size < mf.trk.idx) return true
        val track = mf.trk.gArr[mf.trk.idx]

        val turnOffset = (mf.tool.width - mf.tool.overlap) * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)

        when (youTurnPhase) {
            0 -> {
                if (!FindCurveTurnPoint(mf.curve, false)) {
                    if (track.mode == TrackMode.waterPivot || track.mode == TrackMode.bndCurve) {
                        youTurnPhase = 11 // ignore
                    } else {
                        FailCreate()
                    }
                    return false
                }

                inClosestTurnPt = CClose(closestTurnPt)
                ytList.clear()

                val count = if (mf.curve.isHeadingSameWay) -1 else 1
                var curveIndex = inClosestTurnPt.curveIndex

                isOutOfBounds = true
                var stopIfWayOut = 0
                var head = 0.0

                while (isOutOfBounds) {
                    stopIfWayOut++
                    isOutOfBounds = false

                    ytList.clear()
                    curveIndex += count

                    if (curveIndex < 0 || curveIndex >= mf.curve.curList.size) {
                        FailCreate()
                        return false
                    }

                    var currentPos = vec3(mf.curve.curList[curveIndex]) // 使用 vec3 複製構造函數
                    if (!mf.curve.isHeadingSameWay) currentPos.heading += glm.twoPI / 2
                    if (currentPos.heading >= glm.twoPI) currentPos.heading -= glm.twoPI
                    head = currentPos.heading

                    val dubYouTurnPath = CDubins()
                    dubYouTurnPath.turningRadius = youTurnRadius

                    val invertHead = currentPos.heading - glm.twoPI / 2
                    val adjustedInvertHead = when {
                        invertHead <= -glm.twoPI / 2 -> invertHead + glm.twoPI
                        invertHead >= glm.twoPI / 2 -> invertHead - glm.twoPI
                        else -> invertHead
                    }

                    val goal = vec3()
                    if (isTurnLeft) {
                        goal.easting = mf.curve.curList[curveIndex - count].easting + (cos(-adjustedInvertHead) * turnOffset)
                        goal.northing = mf.curve.curList[curveIndex - count].northing + (sin(-adjustedInvertHead) * turnOffset)
                    } else {
                        goal.easting = mf.curve.curList[curveIndex - count].easting - (cos(-adjustedInvertHead) * turnOffset)
                        goal.northing = mf.curve.curList[curveIndex - count].northing - (sin(-adjustedInvertHead) * turnOffset)
                    }
                    goal.heading = adjustedInvertHead

                    ytList.addAll(dubYouTurnPath.GenerateDubins(currentPos, goal))
                    if (ytList.isEmpty()) {
                        FailCreate()
                        return false
                    }

                    if (stopIfWayOut == 300 || curveIndex < 1 || curveIndex > (mf.curve.curList.size - 2)) {
                        FailCreate()
                        return false
                    }

                    for (i in ytList.indices) {
                        if (mf.bnd.IsPointInsideTurnArea(ytList[i]) != 0) {
                            isOutOfBounds = true
                            break
                        }
                    }
                }
                inClosestTurnPt.curveIndex = curveIndex

                var cnt = ytList.size
                for (i in 1 until cnt - 2) {
                    val distance = glm.distanceSquared(ytList[i], ytList[i + 1]) // 使用 glm.distanceSquared
                    if (distance < pointSpacing) {
                        ytList.removeAt(i + 1)
                        cnt = ytList.size
                        i--
                    }
                }

                val tempList = mutableListOf<vec3>()
                tempList.addAll(ytList)
                ytList.clear()
                ytList.addAll(MoveTurnInsideTurnLine(tempList, head, false, false))
                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                youTurnPhase = 1
            }

            1 -> {
                val widthMinusOverlap = mf.tool.width - mf.tool.overlap
                val distAway = widthMinusOverlap * (mf.curve.howManyPathsAway + (if (isTurnLeft xor mf.curve.isHeadingSameWay) rowSkipsWidth else -rowSkipsWidth)) +
                        (if (mf.curve.isHeadingSameWay) -mf.tool.offset else mf.tool.offset) + track.nudgeDistance + (0.5 * widthMinusOverlap)

                nextCurve.clear()
                nextCurve.addAll(mf.curve.BuildNewOffsetList(distAway, track))

                var dis = Double.MAX_VALUE
                if (nextCurve.size > 1) {
                    for (i in 1 until nextCurve.size) {
                        val newdis = glm.distance(nextCurve[i], ytList[ytList.size - 1]) // 使用 glm.distance
                        if (newdis < dis) {
                            dis = newdis
                            outClosestTurnPt.curveIndex = if (mf.curve.isHeadingSameWay) i - 1 else i
                        }
                    }

                    if (outClosestTurnPt.curveIndex >= 0) {
                        outClosestTurnPt.closePt = vec3(nextCurve[outClosestTurnPt.curveIndex])
                        inClosestTurnPt.closePt = vec3(mf.curve.curList[inClosestTurnPt.curveIndex])
                        if (!AddCurveSequenceLines()) return false
                    }
                }

                var cnt4 = ytList.size
                for (i in 1 until cnt4 - 2) {
                    val j = i + 1
                    if (j == cnt4 - 1) continue
                    val distanc = glm.distanceSquared(ytList[i], ytList[j]) // 使用 glm.distanceSquared
                    if (distanc > 1) {
                        val pointB = vec3(
                            (ytList[i].easting + ytList[j].easting) / 2.0,
                            (ytList[i].northing + ytList[j].northing) / 2.0,
                            ytList[i].heading
                        )
                        ytList.add(j, pointB)
                        cnt4 = ytList.size
                        i--
                    }
                }

                cnt4 = ytList.size
                val arr = arrayOfNulls<vec3>(cnt4)
                cnt4 -= 2
                ytList.toArray(arr)
                ytList.clear()

                for (i in 2 until cnt4) {
                    val pt3 = vec3(arr[i]!!)
                    pt3.heading = atan2(arr[i + 1]!!.easting - arr[i - 1]!!.easting, arr[i + 1]!!.northing - arr[i - 1]!!.northing)
                    if (pt3.heading < 0) pt3.heading += glm.twoPI
                    ytList.add(pt3)
                }

                if (glm.distance(ytList[0], mf.pivotAxlePos) < 3) { // 使用 glm.distance
                    FailCreate()
                    return false
                }

                isOutOfBounds = false
                youTurnPhase = 10
                turnTooCloseTrigger = false
                isTurnCreationTooClose = false
                return true
            }
        }
        return true
    }



    private fun CreateCurveWideTurn(): Boolean {
        if (mf.makeUTurnCounter < 4) {
            youTurnPhase = 0
            return true
        }

        if (mf.trk.idx < 0 || mf.trk.gArr.size < mf.trk.idx) return true
        val track = mf.trk.gArr[mf.trk.idx]

        var head = 0.0
        val count = if (mf.curve.isHeadingSameWay) -1 else 1

        when (youTurnPhase) {
            0 -> {
                if (!FindCurveTurnPoint(mf.curve, false)) {
                    if (track.mode == TrackMode.waterPivot || track.mode == TrackMode.bndCurve) {
                        youTurnPhase = 11 // ignore
                    } else {
                        FailCreate()
                    }
                    return false
                }
                inClosestTurnPt = CClose(closestTurnPt)
                startOfTurnPt = CClose(inClosestTurnPt)

                var stopIfWayOut = 0
                isOutOfBounds = true

                while (isOutOfBounds) {
                    isOutOfBounds = false
                    stopIfWayOut++

                    var currentPos = vec3(mf.curve.curList[inClosestTurnPt.curveIndex])
                    head = currentPos.heading
                    if (!mf.curve.isHeadingSameWay) head += PI
                    if (head > glm.twoPI) head -= glm.twoPI
                    currentPos.heading = head

                    ytList.clear()
                    ytList.add(currentPos)

                    while (abs(head - currentPos.heading) < PI) {
                        currentPos.easting += pointSpacing * sin(currentPos.heading)
                        currentPos.northing += pointSpacing * cos(currentPos.heading)
                        val turnParameter = if (isTurnLeft) -1.0 else 1.0
                        currentPos.heading += (pointSpacing / youTurnRadius) * turnParameter
                        ytList.add(currentPos)
                    }

                    val cnt4 = ytList.size
                    if (cnt4 == 0) {
                        FailCreate()
                        return false
                    }

                    for (j in 0 until cnt4 step 2) {
                        if (mf.bnd.IsPointInsideTurnArea(ytList[j]) != 0) {
                            isOutOfBounds = true
                            break
                        }
                    }

                    if (!isOutOfBounds) {
                        ytList.clear()
                        ytList.addAll(MoveTurnInsideTurnLine(ytList, head, true, false))
                        if (ytList.isEmpty()) {
                            FailCreate()
                            return false
                        }
                        youTurnPhase = 1
                        return true
                    }

                    if (stopIfWayOut == 300 || inClosestTurnPt.curveIndex < 1 || inClosestTurnPt.curveIndex > (mf.curve.curList.size - 2)) {
                        FailCreate()
                        return false
                    }

                    inClosestTurnPt.curveIndex += count
                    inClosestTurnPt.closePt = vec3(mf.curve.curList[inClosestTurnPt.curveIndex])

                    if (glm.distance(ytList[0], mf.pivotAxlePos) < 3) {
                        FailCreate()
                        return false
                    }
                }
                return false
            }

            1 -> {
                val widthMinusOverlap = mf.tool.width - mf.tool.overlap
                val distAway = widthMinusOverlap * (mf.curve.howManyPathsAway + (if (isTurnLeft xor mf.curve.isHeadingSameWay) rowSkipsWidth else -rowSkipsWidth)) +
                        (if (mf.curve.isHeadingSameWay) -mf.tool.offset else mf.tool.offset) + track.nudgeDistance + (0.5 * widthMinusOverlap)

                nextCurve.clear()
                nextCurve.addAll(mf.curve.BuildNewOffsetList(distAway, track))

                val isTurnLineSameWay = abs(inClosestTurnPt.turnLineHeading - ytList[ytList.size - 1].heading).let {
                    it <= glm.piBy2 || it >= 3 * glm.piBy2
                }

                if (!FindCurveOutTurnPoint(mf.curve, nextCurve, startOfTurnPt, isTurnLineSameWay)) {
                    FailCreate()
                    return false
                }
                outClosestTurnPt = CClose(closestTurnPt)

                isOutOfBounds = true
                while (isOutOfBounds) {
                    isOutOfBounds = false
                    var currentPos = vec3(nextCurve[outClosestTurnPt.curveIndex])
                    head = currentPos.heading
                    if ((!mf.curve.isHeadingSameWay && !isOutSameCurve) || (mf.curve.isHeadingSameWay && isOutSameCurve)) head += PI
                    if (head > glm.twoPI) head -= glm.twoPI
                    currentPos.heading = head

                    ytList2.clear()
                    ytList2.add(currentPos)

                    while (abs(head - currentPos.heading) < PI) {
                        currentPos.easting += pointSpacing * sin(currentPos.heading)
                        currentPos.northing += pointSpacing * cos(currentPos.heading)
                        val turnParameter = if (isTurnLeft) 1.0 else -1.0
                        currentPos.heading += (pointSpacing / youTurnRadius) * turnParameter
                        ytList2.add(currentPos)
                    }

                    val cnt3 = ytList2.size
                    if (cnt3 == 0) {
                        FailCreate()
                        return false
                    }

                    for (j in 0 until cnt3 step 2) {
                        if (mf.bnd.IsPointInsideTurnArea(ytList2[j]) != 0) {
                            isOutOfBounds = true
                            break
                        }
                    }

                    if (!isOutOfBounds) {
                        ytList2.clear()
                        ytList2.addAll(MoveTurnInsideTurnLine(ytList2, head, true, true))
                        if (ytList2.isEmpty()) {
                            FailCreate()
                            return false
                        }
                        youTurnPhase = 2
                        return true
                    }

                    if (outClosestTurnPt.curveIndex < 1 || outClosestTurnPt.curveIndex > (nextCurve.size - 2)) {
                        FailCreate()
                        return false
                    }

                    outClosestTurnPt.curveIndex += if (!isOutSameCurve) count else -count
                    outClosestTurnPt.closePt = vec3(nextCurve[outClosestTurnPt.curveIndex])
                }
                return false
            }

            2 -> {
                val cnt1 = ytList.size
                val cnt2 = ytList2.size

                val isFirstTurnLineSameWay = abs(inClosestTurnPt.turnLineHeading - ytList[ytList.size - 1].heading).let {
                    it <= glm.piBy2 || it >= 3 * glm.piBy2
                }

                FindInnerTurnPoints(ytList[cnt1 - 1], ytList[0].heading, inClosestTurnPt, isFirstTurnLineSameWay)
                val startClosestTurnPt = CClose(closestTurnPt)

                FindInnerTurnPoints(ytList2[cnt2 - 1], ytList2[0].heading + PI, outClosestTurnPt, !isFirstTurnLineSameWay)
                val goalClosestTurnPt = CClose(closestTurnPt)

                if (startClosestTurnPt.turnLineNum != goalClosestTurnPt.turnLineNum) {
                    FailCreate()
                    return false
                }

                if (startClosestTurnPt.turnLineIndex == goalClosestTurnPt.turnLineIndex) {
                    for (a in 0 until cnt2) {
                        ytList.add(vec3(ytList2[cnt2 - 1 - a]))
                    }
                } else {
                    val turnCount = mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine.size
                    var loops = abs(startClosestTurnPt.turnLineIndex - goalClosestTurnPt.turnLineIndex)

                    if (loops > (mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine.size / 2)) {
                        loops = if (startClosestTurnPt.turnLineIndex < goalClosestTurnPt.turnLineIndex) {
                            (turnCount - goalClosestTurnPt.turnLineIndex) + startClosestTurnPt.turnLineIndex
                        } else {
                            (turnCount - startClosestTurnPt.turnLineIndex) + goalClosestTurnPt.turnLineIndex
                        }
                    }

                    val tPoint = vec3()
                    if (isFirstTurnLineSameWay) {
                        for (i in 0 until loops) {
                            if (startClosestTurnPt.turnLineIndex + 1 >= turnCount) startClosestTurnPt.turnLineIndex = -1
                            tPoint.copyFrom(mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine[startClosestTurnPt.turnLineIndex + 1])
                            startClosestTurnPt.turnLineIndex++
                            if (startClosestTurnPt.turnLineIndex >= turnCount) startClosestTurnPt.turnLineIndex = 0
                            ytList.add(tPoint)
                        }
                    } else {
                        for (i in 0 until loops) {
                            tPoint.copyFrom(mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine[startClosestTurnPt.turnLineIndex])
                            startClosestTurnPt.turnLineIndex--
                            if (startClosestTurnPt.turnLineIndex == -1) startClosestTurnPt.turnLineIndex = turnCount - 1
                            ytList.add(tPoint)
                        }
                    }

                    for (a in 0 until cnt2) {
                        ytList.add(vec3(ytList2[cnt2 - 1 - a]))
                    }
                }

                if (!AddCurveSequenceLines()) return false

                var cnt = ytList.size
                for (i in 1 until cnt - 2) {
                    val j = i + 1
                    if (j == cnt - 1) continue
                    val distance = glm.distanceSquared(ytList[i], ytList[j])
                    if (distance > 1) {
                        val pointB = vec3(
                            (ytList[i].easting + ytList[j].easting) / 2.0,
                            (ytList[i].northing + ytList[j].northing) / 2.0,
                            ytList[i].heading
                        )
                        ytList.add(j, pointB)
                        cnt = ytList.size
                        i--
                    }
                }

                cnt = ytList.size
                val arr = arrayOfNulls<vec3>(cnt)
                cnt -= 2
                ytList.toArray(arr)
                ytList.clear()

                for (i in 2 until cnt) {
                    val pt3 = vec3(arr[i]!!)
                    pt3.heading = atan2(arr[i + 1]!!.easting - arr[i - 1]!!.easting, arr[i + 1]!!.northing - arr[i - 1]!!.northing)
                    if (pt3.heading < 0) pt3.heading += glm.twoPI
                    ytList.add(pt3)
                }

                if (glm.distance(ytList[0], mf.pivotAxlePos) < 3) {
                    FailCreate()
                    return false
                }

                isGoingStraightThrough = PI - abs(abs(ytList[ytList.size - 2].heading - ytList[1].heading) - PI) < glm.piBy2
                ytList2.clear()
                isOutOfBounds = false
                youTurnPhase = 10
                turnTooCloseTrigger = false
                isTurnCreationTooClose = false
                return true
            }
        }
        return false
    }

    private fun CreateABOmegaTurn(): Boolean {
        if (mf.makeUTurnCounter < 4) {
            youTurnPhase = 0
            return true
        }

        var head = mf.ABLine.abHeading
        if (!mf.ABLine.isHeadingSameWay) head += PI
        if (head >= glm.twoPI) head -= glm.twoPI

        when (youTurnPhase) {
            0 -> {
                FindABTurnPoint(vec3(mf.ABLine.rEastAB, mf.ABLine.rNorthAB, head))

                if (closestTurnPt.turnLineIndex != -1) {
                    mf.distancePivotToTurnLine = glm.distance(mf.pivotAxlePos, closestTurnPt.closePt)
                } else {
                    FailCreate()
                    return false
                }
                inClosestTurnPt = CClose(closestTurnPt)

                val dubYouTurnPath = CDubins()
                dubYouTurnPath.turningRadius = youTurnRadius

                val turnOffset = (mf.tool.width - mf.tool.overlap) * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)

                val start = vec3(inClosestTurnPt.closePt)
                start.heading = head

                val goal = vec3(start)
                val invertedHead = head - PI
                val adjustedInvertHead = when {
                    invertedHead < 0 -> invertedHead + glm.twoPI
                    invertedHead > glm.twoPI -> invertedHead - glm.twoPI
                    else -> invertedHead
                }

                if (isTurnLeft) {
                    goal.easting += cos(-adjustedInvertHead) * turnOffset
                    goal.northing += sin(-adjustedInvertHead) * turnOffset
                } else {
                    goal.easting -= cos(-adjustedInvertHead) * turnOffset
                    goal.northing -= sin(-adjustedInvertHead) * turnOffset
                }
                goal.heading = adjustedInvertHead

                ytList.clear()
                ytList.addAll(dubYouTurnPath.GenerateDubins(start, goal))
                isOutOfBounds = true

                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                youTurnPhase = 1

                var cnt = ytList.size
                for (i in 1 until cnt - 2) {
                    val distance = glm.distanceSquared(ytList[i], ytList[i + 1])
                    if (distance < pointSpacing) {
                        ytList.removeAt(i + 1)
                        cnt = ytList.size
                        i--
                    }
                }
                return true
            }

            1 -> {
                ytList.clear()
                ytList.addAll(MoveTurnInsideTurnLine(ytList, head, false, false))

                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                isOutOfBounds = false
                youTurnPhase = 10
                turnTooCloseTrigger = false
                isTurnCreationTooClose = false

                if (!AddABSequenceLines()) return false
                return true
            }
        }
        return true
    }

    private fun CreateABWideTurn(): Boolean {
        if (mf.makeUTurnCounter < 4) {
            youTurnPhase = 0
            return true
        }

        var head = mf.ABLine.abHeading
        if (!mf.ABLine.isHeadingSameWay) head += PI
        if (head >= glm.twoPI) head -= glm.twoPI

        when (youTurnPhase) {
            0 -> {
                val onPurePoint = vec3(mf.ABLine.rEastAB, mf.ABLine.rNorthAB, 0.0)
                FindABTurnPoint(onPurePoint)

                inClosestTurnPt = CClose(closestTurnPt)
                startOfTurnPt = CClose(closestTurnPt)

                if (inClosestTurnPt.turnLineIndex == -1) {
                    FailCreate()
                    return false
                }

                ytList.clear()
                var currentPos = vec3(inClosestTurnPt.closePt.easting, inClosestTurnPt.closePt.northing, head)
                ytList.add(currentPos)

                while (abs(head - currentPos.heading) < PI) {
                    currentPos.easting += pointSpacing * sin(currentPos.heading)
                    currentPos.northing += pointSpacing * cos(currentPos.heading)
                    val turnParameter = if (isTurnLeft) -1.0 else 1.0
                    currentPos.heading += (pointSpacing / youTurnRadius) * turnParameter
                    ytList.add(currentPos)
                }

                isOutOfBounds = true
                ytList.clear()
                ytList.addAll(MoveTurnInsideTurnLine(ytList, head, true, false))

                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                mf.distancePivotToTurnLine = glm.distance(ytList[0], mf.pivotAxlePos)
                youTurnPhase = 1
                return true
            }

            1 -> {
                val widthMinusOverlap = mf.tool.width - mf.tool.overlap
                val track = mf.trk.gArr[mf.trk.idx]
                val distAway = widthMinusOverlap * (mf.ABLine.howManyPathsAway + (if (isTurnLeft xor mf.ABLine.isHeadingSameWay) rowSkipsWidth else -rowSkipsWidth)) +
                        (if (mf.ABLine.isHeadingSameWay) -mf.tool.offset else mf.tool.offset) + track.nudgeDistance + (0.5 * widthMinusOverlap)

                nextCurve.clear()
                nextCurve.addAll(mf.curve.BuildNewOffsetList(distAway, track))

                val isTurnLineSameWay = abs(startOfTurnPt.closePt.heading - ytList[ytList.size - 1].heading).let {
                    it <= glm.piBy2 || it >= 3 * glm.piBy2
                }

                if (!FindABOutTurnPoint(mf.ABLine, nextCurve, inClosestTurnPt, isTurnLineSameWay)) {
                    FailCreate()
                    return false
                }
                outClosestTurnPt = CClose(closestTurnPt)

                var pointPos = vec3(outClosestTurnPt.closePt.easting, outClosestTurnPt.closePt.northing, 0.0)
                val headie = if (!isOutSameCurve) head else {
                    var tempHead = head + PI
                    if (tempHead >= glm.twoPI) tempHead -= glm.twoPI
                    tempHead
                }
                pointPos.heading = headie

                ytList2.clear()
                ytList2.add(pointPos)

                while (abs(headie - pointPos.heading) < PI) {
                    pointPos.easting += pointSpacing * sin(pointPos.heading)
                    pointPos.northing += pointSpacing * cos(pointPos.heading)
                    val turnParameter = if (isTurnLeft) 1.0 else -1.0
                    pointPos.heading += (pointSpacing / youTurnRadius) * turnParameter
                    ytList2.add(pointPos)
                }

                isOutOfBounds = true
                ytList2.clear()
                ytList2.addAll(MoveTurnInsideTurnLine(ytList2, headie, true, true))

                if (ytList2.isEmpty()) {
                    FailCreate()
                    return false
                }

                youTurnPhase = 2
                return true
            }

            2 -> {
                val cnt1 = ytList.size
                val cnt2 = ytList2.size

                val isFirstTurnLineSameWay = abs(inClosestTurnPt.turnLineHeading - ytList[ytList.size - 1].heading).let {
                    it <= glm.piBy2 || it >= 3 * glm.piBy2
                }

                FindInnerTurnPoints(ytList[cnt1 - 1], ytList[0].heading, inClosestTurnPt, isFirstTurnLineSameWay)
                val startClosestTurnPt = CClose(closestTurnPt)

                FindInnerTurnPoints(ytList2[cnt2 - 1], ytList2[0].heading + PI, outClosestTurnPt, !isFirstTurnLineSameWay)
                val goalClosestTurnPt = CClose(closestTurnPt)

                if (startClosestTurnPt.turnLineNum != goalClosestTurnPt.turnLineNum) {
                    FailCreate()
                    return false
                }

                if (startClosestTurnPt.turnLineIndex == goalClosestTurnPt.turnLineIndex) {
                    for (a in 0 until cnt2) {
                        ytList.add(vec3(ytList2[cnt2 - 1 - a]))
                    }
                } else {
                    val turnCount = mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine.size
                    var loops = abs(startClosestTurnPt.turnLineIndex - goalClosestTurnPt.turnLineIndex)

                    if (loops > (mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine.size / 2)) {
                        loops = if (startClosestTurnPt.turnLineIndex < goalClosestTurnPt.turnLineIndex) {
                            (turnCount - goalClosestTurnPt.turnLineIndex) + startClosestTurnPt.turnLineIndex
                        } else {
                            (turnCount - startClosestTurnPt.turnLineIndex) + goalClosestTurnPt.turnLineIndex
                        }
                    }

                    val tPoint = vec3()
                    if (isFirstTurnLineSameWay) {
                        for (i in 0 until loops) {
                            if (startClosestTurnPt.turnLineIndex + 1 >= turnCount) startClosestTurnPt.turnLineIndex = -1
                            tPoint.copyFrom(mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine[startClosestTurnPt.turnLineIndex + 1])
                            startClosestTurnPt.turnLineIndex++
                            if (startClosestTurnPt.turnLineIndex >= turnCount) startClosestTurnPt.turnLineIndex = 0
                            ytList.add(tPoint)
                        }
                    } else {
                        for (i in 0 until loops) {
                            tPoint.copyFrom(mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine[startClosestTurnPt.turnLineIndex])
                            startClosestTurnPt.turnLineIndex--
                            if (startClosestTurnPt.turnLineIndex == -1) startClosestTurnPt.turnLineIndex = turnCount - 1
                            ytList.add(tPoint)
                        }
                    }

                    for (a in 0 until cnt2) {
                        ytList.add(vec3(ytList2[cnt2 - 1 - a]))
                    }
                }

                var cnt = ytList.size
                for (i in 1 until cnt - 2) {
                    val j = i + 1
                    if (j == cnt - 1) continue
                    val distance = glm.distanceSquared(ytList[i], ytList[j])
                    if (distance > 1) {
                        val pointB = vec3(
                            (ytList[i].easting + ytList[j].easting) / 2.0,
                            (ytList[i].northing + ytList[j].northing) / 2.0,
                            ytList[i].heading
                        )
                        ytList.add(j, pointB)
                        cnt = ytList.size
                        i--
                    }
                }

                cnt = ytList.size
                val arr = arrayOfNulls<vec3>(cnt)
                cnt -= 2
                ytList.toArray(arr)
                ytList.clear()

                for (i in 2 until cnt) {
                    val pt3 = vec3(arr[i]!!)
                    pt3.heading = atan2(arr[i + 1]!!.easting - arr[i - 1]!!.easting, arr[i + 1]!!.northing - arr[i - 1]!!.northing)
                    if (pt3.heading < 0) pt3.heading += glm.twoPI
                    ytList.add(pt3)
                }

                if (glm.distance(ytList[0], mf.pivotAxlePos) < 3) {
                    FailCreate()
                    return false
                }

                isGoingStraightThrough = PI - abs(abs(ytList[ytList.size - 2].heading - ytList[1].heading) - PI) < glm.piBy2
                isOutOfBounds = false
                youTurnPhase = 10
                turnTooCloseTrigger = false
                isTurnCreationTooClose = false
                ytList2.clear()

                if (!AddABSequenceLines()) return false
                return true
            }
        }
        return false
    }


    // 前一部分的字段和方法保持不變，這裡從 KStyleTurnCurve 開始

    private fun KStyleTurnCurve(): Boolean {
        if (mf.makeUTurnCounter < 4) {
            youTurnPhase = 0
            return true
        }

        if (mf.trk.idx < 0 || mf.trk.gArr.size <= mf.trk.idx) return true
        val track = mf.trk.gArr[mf.trk.idx]

        when (youTurnPhase) {
            0 -> {
                if (!FindCurveTurnPoint(mf.curve, true)) {
                    if (track.mode == TrackMode.waterPivot || track.mode == TrackMode.bndCurve) {
                        youTurnPhase = 11 // ignore
                    } else {
                        FailCreate()
                    }
                    return false
                }

                inClosestTurnPt = CClose(closestTurnPt)
                ytList.clear()

                val count = if (mf.curve.isHeadingSameWay) -1 else 1
                var curveIndex = inClosestTurnPt.cur personallyPt.curveIndex

                        isOutOfBounds = true
                var stopIfWayOut = 0

                while (isOutOfBounds) {
                    stopIfWayOut++
                    isOutOfBounds = false

                    ytList.clear()
                    curveIndex += count

                    if (curveIndex < 0 || curveIndex >= mf.curve.curList.size) {
                        FailCreate()
                        return false
                    }

                    var currentPos = vec3(mf.curve.curList[curveIndex])
                    val head = if (mf.curve.isHeadingSameWay) currentPos.heading else {
                        var tempHead = currentPos.heading + PI
                        if (tempHead >= glm.twoPI) tempHead -= glm.twoPI
                        tempHead
                    }
                    currentPos.heading = head

                    val turnOffset = (mf.tool.width - mf.tool.overlap) * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)
                    val turnRadius = youTurnRadius * uTurnSmoothing / 10.0

                    val start = vec3(currentPos)
                    val goal = vec3()
                    val invertedHead = head - PI
                    val adjustedInvertHead = when {
                        invertedHead < 0 -> invertedHead + glm.twoPI
                        invertedHead > glm.twoPI -> invertedHead - glm.twoPI
                        else -> invertedHead
                    }

                    if (isTurnLeft) {
                        goal.easting = currentPos.easting + (cos(-adjustedInvertHead) * turnOffset)
                        goal.northing = currentPos.northing + (sin(-adjustedInvertHead) * turnOffset)
                    } else {
                        goal.easting = currentPos.easting - (cos(-adjustedInvertHead) * turnOffset)
                        goal.northing = currentPos.northing - (sin(-adjustedInvertHead) * turnOffset)
                    }
                    goal.heading = adjustedInvertHead

                    val dubYouTurnPath = CDubins()
                    dubYouTurnPath.turningRadius = turnRadius
                    ytList.addAll(dubYouTurnPath.GenerateDubins(start, goal))

                    if (ytList.isEmpty()) {
                        FailCreate()
                        return false
                    }

                    if (stopIfWayOut == 300 || curveIndex < 1 || curveIndex > (mf.curve.curList.size - 2)) {
                        FailCreate()
                        return false
                    }

                    for (i in ytList.indices) {
                        if (mf.bnd.IsPointInsideTurnArea(ytList[i]) != 0) {
                            isOutOfBounds = true
                            break
                        }
                    }
                }
                inClosestTurnPt.curveIndex = curveIndex

                var cnt = ytList.size
                for (i in 1 until cnt - 2) {
                    val distance = glm.distanceSquared(ytList[i], ytList[i + 1])
                    if (distance < pointSpacing) {
                        ytList.removeAt(i + 1)
                        cnt = ytList.size
                        i--
                    }
                }

                ytList.clear()
                ytList.addAll(MoveTurnInsideTurnLine(ytList, head, false, false))
                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                youTurnPhase = 1
            }

            1 -> {
                val widthMinusOverlap = mf.tool.width - mf.tool.overlap
                val distAway = widthMinusOverlap * (mf.curve.howManyPathsAway + (if (isTurnLeft xor mf.curve.isHeadingSameWay) rowSkipsWidth else -rowSkipsWidth)) +
                        (if (mf.curve.isHeadingSameWay) -mf.tool.offset else mf.tool.offset) + track.nudgeDistance + (0.5 * widthMinusOverlap)

                nextCurve.clear()
                nextCurve.addAll(mf.curve.BuildNewOffsetList(distAway, track))

                var dis = Double.MAX_VALUE
                if (nextCurve.size > 1) {
                    for (i in 1 until nextCurve.size) {
                        val newdis = glm.distance(nextCurve[i], ytList[ytList.size - 1])
                        if (newdis < dis) {
                            dis = newdis
                            outClosestTurnPt.curveIndex = if (mf.curve.isHeadingSameWay) i - 1 else i
                        }
                    }

                    if (outClosestTurnPt.curveIndex >= 0) {
                        outClosestTurnPt.closePt = vec3(nextCurve[outClosestTurnPt.curveIndex])
                        inClosestTurnPt.closePt = vec3(mf.curve.curList[inClosestTurnPt.curveIndex])
                        if (!AddCurveSequenceLines()) return false
                    }
                }

                var cnt = ytList.size
                for (i in 1 until cnt - 2) {
                    val j = i + 1
                    if (j == cnt - 1) continue
                    val distanc = glm.distanceSquared(ytList[i], ytList[j])
                    if (distanc > 1) {
                        val pointB = vec3(
                            (ytList[i].easting + ytList[j].easting) / 2.0,
                            (ytList[i].nortning + ytList[j].northing) / 2.0,
                            ytList[i].heading
                        )
                        ytList.add(j, pointB)
                        cnt = ytList.size
                        i--
                    }
                }

                cnt = ytList.size
                val arr = arrayOfNulls<vec3>(cnt)
                cnt -= 2
                ytList.toArray(arr)
                ytList.clear()

                for (i in 2 until cnt) {
                    val pt3 = vec3(arr[i]!!)
                    pt3.heading = atan2(arr[i + 1]!!.easting - arr[i - 1]!!.easting, arr[i + 1]!!.northing - arr[i - 1]!!.northing)
                    if (pt3.heading < 0) pt3.heading += glm.twoPI
                    ytList.add(pt3)
                }

                if (glm.distance(ytList[0], mf.pivotAxlePos) < 3) {
                    FailCreate()
                    return false
                }

                isOutOfBounds = false
                youTurnPhase = 10
                turnTooCloseTrigger = false
                isTurnCreationTooClose = false
                return true
            }
        }
        return true
    }

    private fun KStyleTurnAB(): Boolean {
        if (mf.makeUTurnCounter < 4) {
            youTurnPhase = 0
            return true
        }

        var head = mf.ABLine.abHeading
        if (!mf.ABLine.isHeadingSameWay) head += PI
        if (head >= glm.twoPI) head -= glm.twoPI

        when (youTurnPhase) {
            0 -> {
                FindABTurnPoint(vec3(mf.ABLine.rEastAB, mf.ABLine.rNorthAB, head))

                if (closestTurnPt.turnLineIndex != -1) {
                    mf.distancePivotToTurnLine = glm.distance(mf.pivotAxlePos, closestTurnPt.closePt)
                } else {
                    FailCreate()
                    return false
                }
                inClosestTurnPt = CClose(closestTurnPt)

                val turnOffset = (mf.tool.width - mf.tool.overlap) * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)
                val turnRadius = youTurnRadius * uTurnSmoothing / 10.0

                val start = vec3(inClosestTurnPt.closePt)
                start.heading = head

                val goal = vec3(start)
                val invertedHead = head - PI
                val adjustedInvertHead = when {
                    invertedHead < 0 -> invertedHead + glm.twoPI
                    invertedHead > glm.twoPI -> invertedHead - glm.twoPI
                    else -> invertedHead
                }

                if (isTurnLeft) {
                    goal.easting += cos(-adjustedInvertHead) * turnOffset
                    goal.northing += sin(-adjustedInvertHead) * turnOffset
                } else {
                    goal.easting -= cos(-adjustedInvertHead) * turnOffset
                    goal.northing -= sin(-adjustedInvertHead) * turnOffset
                }
                goal.heading = adjustedInvertHead

                val dubYouTurnPath = CDubins(mf)
                dubYouTurnPath.turningRadius = turnRadius
                ytList.clear()
                ytList.addAll(dubYouTurnPath.GenerateDubins(start, goal))

                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                var cnt = ytList.size
                for (i in 1 until cnt - 2) {
                    val distance = glm.distanceSquared(ytList[i], ytList[i + 1])
                    if (distance < pointSpacing) {
                        ytList.removeAt(i + 1)
                        cnt = ytList.size
                        i--
                    }
                }

                youTurnPhase = 1
                return true
            }

            1 -> {
                ytList.clear()
                ytList.addAll(MoveABTurnInsideTurnLine(ytList, head))

                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                isOutOfBounds = false
                youTurnPhase = 10
                turnTooCloseTrigger = false
                isTurnCreationTooClose = false

                if (!AddABSequenceLines()) return false
                return true
            }
        }
        return true
    }


    // 前一部分的字段和方法保持不變，這裡從 FindCurveTurnPoint 開始

    private fun FindCurveTurnPoint(curve: CCurve, isFirstGuess: Boolean): Boolean {
        turnClosestList.clear()
        closestTurnPt = CClose()
        var closestDistance = Double.MAX_VALUE

        val step = if (isFirstGuess) 10 else 1
        val stepD2 = step * 2

        for (t in mf.bnd.bndList.indices) {
            val turnLine = mf.bnd.bndList[t].turnLine
            if (turnLine.isEmpty()) continue

            var jStart = 0
            var jEnd = turnLine.size

            if (semiCircleIndex != -1) {
                jStart = semiCircleIndex - stepD2
                jEnd = semiCircleIndex + stepD2 + 1
                if (jStart < 0) jStart = 0
                if (jEnd > turnLine.size) jEnd = turnLine.size
            }

            for (j in jStart until jEnd step step) {
                val distance = glm.distance(turnLine[j], mf.pivotAxlePos)
                if (distance < closestDistance) {
                    closestDistance = distance
                    closestTurnPt.closePt = vec3(turnLine[j])
                    closestTurnPt.turnLineNum = t
                    closestTurnPt.turnLineIndex = j
                    closestTurnPt.curveIndex = curve.FindClosestPointOnCurve(turnLine[j])
                    closestTurnPt.turnLineHeading = if (j < turnLine.size - 1) {
                        atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                    } else {
                        atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                    }
                    if (closestTurnPt.turnLineHeading < 0) closestTurnPt.turnLineHeading += glm.twoPI
                }

                if (!isFirstGuess && distance < (youTurnRadius * 2.0)) {
                    val clo = CClose()
                    clo.closePt = vec3(turnLine[j])
                    clo.turnLineNum = t
                    clo.turnLineIndex = j
                    clo.curveIndex = curve.FindClosestPointOnCurve(turnLine[j])
                    clo.turnLineHeading = if (j < turnLine.size - 1) {
                        atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                    } else {
                        atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                    }
                    if (clo.turnLineHeading < 0) clo.turnLineHeading += glm.twoPI
                    turnClosestList.add(clo)
                }
            }
        }

        if (closestTurnPt.turnLineIndex == -1) {
            isTurnCreationNotCrossingError = true
            return false
        }

        if (closestDistance < youTurnRadius) {
            isTurnCreationTooClose = true
            turnTooCloseTrigger = true
            return false
        }

        return true
    }

    private fun FindABTurnPoint(onPurePoint: vec3) {
        turnClosestList.clear()
        closestTurnPt = CClose()
        var closestDistance = Double.MAX_VALUE

        for (t in mf.bnd.bndList.indices) {
            val turnLine = mf.bnd.bndList[t].turnLine
            if (turnLine.isEmpty()) continue

            for (j in turnLine.indices) {
                val distance = glm.distance(turnLine[j], onPurePoint)
                if (distance < closestDistance) {
                    closestDistance = distance
                    closestTurnPt.closePt = vec3(turnLine[j])
                    closestTurnPt.turnLineNum = t
                    closestTurnPt.turnLineIndex = j
                    closestTurnPt.turnLineHeading = if (j < turnLine.size - 1) {
                        atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                    } else {
                        atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                    }
                    if (closestTurnPt.turnLineHeading < 0) closestTurnPt.turnLineHeading += glm.twoPI
                }

                if (distance < (youTurnRadius * 2.0)) {
                    val clo = CClose()
                    clo.closePt = vec3(turnLine[j])
                    clo.turnLineNum = t
                    clo.turnLineIndex = j
                    clo.turnLineHeading = if (j < turnLine.size - 1) {
                        atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                    } else {
                        atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                    }
                    if (clo.turnLineHeading < 0) clo.turnLineHeading += glm.twoPI
                    turnClosestList.add(clo)
                }
            }
        }

        if (closestDistance < youTurnRadius) {
            isTurnCreationTooClose = true
            turnTooCloseTrigger = true
        }
    }

    private fun FindCurveOutTurnPoint(curve: CCurve, nextCurve: MutableList<vec3>, startPt: CClose, isTurnLineSameWay: Boolean): Boolean {
        closestTurnPt = CClose()
        var closestDistance = Double.MAX_VALUE

        val stepD2 = 20
        val count = if (curve.isHeadingSameWay) -1 else 1

        for (t in mf.bnd.bndList.indices) {
            val turnLine = mf.bnd.bndList[t].turnLine
            if (turnLine.isEmpty()) continue

            var jStart = startPt.turnLineIndex - stepD2
            var jEnd = startPt.turnLineIndex + stepD2 + 1
            if (jStart < 0) jStart = 0
            if (jEnd > turnLine.size) jEnd = turnLine.size

            for (j in jStart until jEnd) {
                if (t != startPt.turnLineNum || abs(j - startPt.turnLineIndex) > 2) {
                    val distance = glm.distance(turnLine[j], nextCurve[startPt.curveIndex])
                    if (distance < closestDistance) {
                        closestDistance = distance
                        closestTurnPt.closePt = vec3(turnLine[j])
                        closestTurnPt.turnLineNum = t
                        closestTurnPt.turnLineIndex = j
                        closestTurnPt.curveIndex = startPt.curveIndex

                        val pt = vec3(nextCurve[startPt.curveIndex])
                        val dx = turnLine[j].easting - pt.easting
                        val dz = turnLine[j].northing - pt.northing
                        val turnLineHead = atan2(dx, dz)
                        val curveHead = pt.heading

                        val delta = abs(turnLineHead - curveHead)
                        isOutSameCurve = delta <= glm.piBy2 || delta >= (glm.twoPI - glm.piBy2)

                        closestTurnPt.turnLineHeading = if (j < turnLine.size - 1) {
                            atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                        } else {
                            atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                        }
                        if (closestTurnPt.turnLineHeading < 0) closestTurnPt.turnLineHeading += glm.twoPI
                    }
                }
            }
        }

        if (closestTurnPt.turnLineIndex == -1) {
            isTurnCreationNotCrossingError = true
            return false
        }

        return true
    }

    private fun FindABOutTurnPoint(abLine: CABLine, nextCurve: MutableList<vec3>, startPt: CClose, isTurnLineSameWay: Boolean): Boolean {
        closestTurnPt = CClose()
        var closestDistance = Double.MAX_VALUE

        for (t in mf.bnd.bndList.indices) {
            val turnLine = mf.bnd.bndList[t].turnLine
            if (turnLine.isEmpty()) continue

            for (j in turnLine.indices) {
                val distance = glm.distance(turnLine[j], nextCurve[startPt.curveIndex])
                if (distance < closestDistance) {
                    closestDistance = distance
                    closestTurnPt.closePt = vec3(turnLine[j])
                    closestTurnPt.turnLineNum = t
                    closestTurnPt.turnLineIndex = j

                    val pt = vec3(nextCurve[startPt.curveIndex])
                    val dx = turnLine[j].easting - pt.easting
                    val dz = turnLine[j].northing - pt.northing
                    val turnLineHead = atan2(dx, dz)
                    val curveHead = pt.heading

                    val delta = abs(turnLineHead - curveHead)
                    isOutSameCurve = delta <= glm.piBy2 || delta >= (glm.twoPI - glm.piBy2)

                    closestTurnPt.turnLineHeading = if (j < turnLine.size - 1) {
                        atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                    } else {
                        atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                    }
                    if (closestTurnPt.turnLineHeading < 0) closestTurnPt.turnLineHeading += glm.twoPI
                }
            }
        }

        if (closestTurnPt.turnLineIndex == -1) {
            isTurnCreationNotCrossingError = true
            return false
        }

        return true
    }

    private fun FindInnerTurnPoints(turnPt: vec3, head: Double, startPt: CClose, isTurnLineSameWay: Boolean) {
        closestTurnPt = CClose()
        var closestDistance = Double.MAX_VALUE

        val stepD2 = 20

        for (t in mf.bnd.bndList.indices) {
            val turnLine = mf.bnd.bndList[t].turnLine
            if (turnLine.isEmpty()) continue

            var jStart = startPt.turnLineIndex - stepD2
            var jEnd = startPt.turnLineIndex + stepD2 + 1
            if (jStart < 0) jStart = 0
            if (jEnd > turnLine.size) jEnd = turnLine.size

            for (j in jStart until jEnd) {
                val distance = glm.distance(turnLine[j], turnPt)
                if (distance < closestDistance) {
                    closestDistance = distance
                    closestTurnPt.closePt = vec3(turnLine[j])
                    closestTurnPt.turnLineNum = t
                    closestTurnPt.turnLineIndex = j
                    closestTurnPt.turnLineHeading = if (j < turnLine.size - 1) {
                        atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                    } else {
                        atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                    }
                    if (closestTurnPt.turnLineHeading < 0) closestTurnPt.turnLineHeading += glm.twoPI
                }
            }
        }
    }

    // 前一部分的字段和方法保持不變，這裡從 MoveTurnInsideTurnLine 開始
    // 示例方法調整：MoveTurnInsideTurnLine
    private fun MoveTurnInsideTurnLine(
        ytListTemp: MutableList<vec3>,
        head: Double,
        isWideTurn: Boolean,
        isSecondHalf: Boolean
    ): MutableList<vec3> {
        val res = mutableListOf<vec3>()
        res.addAll(ytListTemp)
        val cnt = res.size

        if (cnt < 2) return res

        var isAllInside = true
        for (i in 0 until cnt step 2) {
            if (mf.bnd.IsPointInsideTurnArea(res[i]) != 0) {
                isAllInside = false
                break
            }
        }

        if (isAllInside) return res

        val turnParameter = if (isTurnLeft) -1.0 else 1.0
        val shift = if (isSecondHalf) -turnParameter else turnParameter

        val dx = cos(-head + glm.piBy2) * youTurnRadius * shift
        val dz = sin(-head + glm.piBy2) * youTurnRadius * shift

        if (isWideTurn) {
            for (j in 0 until cnt) {
                res[j] = vec3(res[j].easting + dx, res[j].northing + dz, res[j].heading)
            }

            isAllInside = true
            for (i in 0 until cnt step 2) {
                if (mf.bnd.IsPointInsideTurnArea(res[i]) != 0) {
                    isAllInside = false
                    break
                }
            }

            if (!isAllInside) {
                res.clear()
            }
        } else {
            val ptOut = mutableListOf<Int>()
            for (j in 0 until cnt) {
                val whichBound = mf.bnd.IsPointInsideTurnArea(res[j])
                if (whichBound != 0) {
                    ptOut.add(j)
                }
            }

            if (ptOut.isNotEmpty()) {
                for (k in ptOut.indices) {
                    val j = ptOut[k]
                    res[j] = vec3(res[j].easting + dx, res[j].northing + dz, res[j].heading)
                }

                isAllInside = true
                for (i in 0 until cnt step 2) {
                    if (mf.bnd.IsPointInsideTurnArea(res[i]) != 0) {
                        isAllInside = false
                        break
                    }
                }

                if (!isAllInside) {
                    res.clear()
                }
            }
        }

        return res
    }

    private fun MoveABTurnInsideTurnLine(ytListTemp: MutableList<vec3>, head: Double): MutableList<vec3> {
        val res = mutableListOf<vec3>()
        res.addAll(ytListTemp)
        val cnt = res.size

        if (cnt < 2) return res

        var isAllInside = true
        for (i in 0 until cnt step 2) {
            if (mf.bnd.IsPointInsideTurnArea(res[i]) != 0) {
                isAllInside = false
                break
            }
        }

        if (isAllInside) return res

        val turnParameter = if (isTurnLeft) -1.0 else 1.0
        val dx = cos(-head + glm.piBy2) * youTurnRadius * turnParameter
        val dz = sin(-head + glm.piBy2) * youTurnRadius * turnParameter

        for (j in 0 until cnt) {
            res[j].easting += dx
            res[j].northing += dz
        }

        isAllInside = true
        for (i in 0 until cnt step 2) {
            if (mf.bnd.IsPointInsideTurnArea(res[i]) != 0) {
                isAllInside = false
                break
            }
        }

        if (!isAllInside) {
            res.clear()
        }

        return res
    }

    private fun AddCurveSequenceLines(): Boolean {
        val widthMinusOverlap = mf.tool.width - mf.tool.overlap
        val turnOffset = widthMinusOverlap * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)

        val isTurnRight = !isTurnLeft
        val shift = if (isTurnRight) 1 else -1
        val turnSide = cos(-inClosestTurnPt.turnLineHeading + glm.piBy2) * turnOffset * shift
        val turnSide2 = sin(-inClosestTurnPt.turnLineHeading + glm.piBy2) * turnOffset * shift

        iE = inClosestTurnPt.closePt.easting + turnSide
        iN = inClosestTurnPt.closePt.northing + turnSide2

        val head = inClosestTurnPt.turnLineHeading
        val dx = outClosestTurnPt.closePt.easting - inClosestTurnPt.closePt.easting
        val dz = outClosestTurnPt.closePt.northing - inClosestTurnPt.closePt.northing
        val turnHead = atan2(dx, dz)

        val isTurnLineSameWay = abs(turnHead - head).let { it <= glm.piBy2 || it >= (glm.twoPI - glm.piBy2) }

        val pt = vec3()
        if (mf.curve.isHeadingSameWay) {
            if (!isTurnLineSameWay) {
                val turnCount = mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine.size
                var turnIndex = inClosestTurnPt.turnLineIndex
                var loops = abs(inClosestTurnPt.turnLineIndex - outClosestTurnPt.turnLineIndex)

                if (loops > turnCount / 2) {
                    loops = if (inClosestTurnPt.turnLineIndex < outClosestTurnPt.turnLineIndex) {
                        (turnCount - outClosestTurnPt.turnLineIndex) + inClosestTurnPt.turnLineIndex
                    } else {
                        (turnCount - inClosestTurnPt.turnLineIndex) + outClosestTurnPt.turnLineIndex
                    }
                }

                for (i in 0 until loops) {
                    if (turnIndex >= turnCount) turnIndex = 0
                    pt.copyFrom(mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine[turnIndex])
                    turnIndex++
                    ytList.add(pt)
                }
            }
        } else {
            if (isTurnLineSameWay) {
                val turnCount = mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine.size
                var turnIndex = inClosestTurnPt.turnLineIndex
                var loops = abs(inClosestTurnPt.turnLineIndex - outClosestTurnPt.turnLineIndex)

                if (loops > turnCount / 2) {
                    loops = if (inClosestTurnPt.turnLineIndex < outClosestTurnPt.turnLineIndex) {
                        (turnCount - outClosestTurnPt.turnLineIndex) + inClosestTurnPt.turnLineIndex
                    } else {
                        (turnCount - inClosestTurnPt.turnLineIndex) + outClosestTurnPt.turnLineIndex
                    }
                }

                for (i in 0 until loops) {
                    if (turnIndex < 0) turnIndex = turnCount - 1
                    pt.copyFrom(mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine[turnIndex])
                    turnIndex--
                    ytList.add(pt)
                }
            }
        }

        val turnDist = glm.distance(inClosestTurnPt.closePt, outClosestTurnPt.closePt)
        if (turnDist < widthMinusOverlap * 0.75) {
            isTurnCreationTooClose = true
            turnTooCloseTrigger = true
            return false
        }

        return true
    }

    private fun AddABSequenceLines(): Boolean {
        val widthMinusOverlap = mf.tool.width - mf.tool.overlap
        val turnOffset = widthMinusOverlap * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)

        val isTurnRight = !isTurnLeft
        val shift = if (isTurnRight) 1 else -1
        val turnSide = cos(-inClosestTurnPt.turnLineHeading + glm.piBy2) * turnOffset * shift
        val turnSide2 = sin(-inClosestTurnPt.turnLineHeading + glm.piBy2) * turnOffset * shift

        iE = inClosestTurnPt.closePt.easting + turnSide
        iN = inClosestTurnPt.closePt.northing + turnSide2

        val head = inClosestTurnPt.turnLineHeading
        val dx = mf.ABLine.rEastAB - inClosestTurnPt.closePt.easting
        val dz = mf.ABLine.rNorthAB - inClosestTurnPt.closePt.northing
        val turnHead = atan2(dx, dz)

        val isTurnLineSameWay = abs(turnHead - head).let { it <= glm.piBy2 || it >= (glm.twoPI - glm.piBy2) }

        val pt = vec3()
        if (mf.ABLine.isHeadingSameWay) {
            if (!isTurnLineSameWay) {
                val turnCount = mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine.size
                var turnIndex = inClosestTurnPt.turnLineIndex
                val loops = abs(inClosestTurnPt.turnLineIndex - outClosestTurnPt.turnLineIndex)

                for (i in 0 until loops) {
                    if (turnIndex >= turnCount) turnIndex = 0
                    pt.copyFrom(mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine[turnIndex])
                    turnIndex++
                    ytList.add(pt)
                }
            }
        } else {
            if (isTurnLineSameWay) {
                val turnCount = mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine.size
                var turnIndex = inClosestTurnPt.turnLineIndex
                val loops = abs(inClosestTurnPt.turnLineIndex - outClosestTurnPt.turnLineIndex)

                for (i in 0 until loops) {
                    if (turnIndex < 0) turnIndex = turnCount - 1
                    pt.copyFrom(mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine[turnIndex])
                    turnIndex--
                    ytList.add(pt)
                }
            }
        }

        val turnDist = glm.distance(inClosestTurnPt.closePt, vec3(mf.ABLine.rEastAB, mf.ABLine.rNorthAB, 0.0))
        if (turnDist < widthMinusOverlap * 0.75) {
            isTurnCreationTooClose = true
            turnTooCloseTrigger = true
            return false
        }

        return true
    }


    fun DrawYouTurn(googleMap: GoogleMap) {
        if (ytList.isEmpty()) return

        val polylineOptions = PolylineOptions()
            .color(0xFFFFA500.toInt()) // 橙色
            .width(4f)
            .geodesic(false)

        val cnt = ytList.size
        val utmE = mf.pn.utmEast
        val utmN = mf.pn.utmNorth
        val zone = mf.pn.zone
        val isNorthernHemisphere = mf.pn.latitude >= 0 // 假設 mf.pn.latitude 表示當前緯度，用於判斷半球

        for (i in 0 until cnt) {
            val latLon = glm.UTM2LatLon(utmE + ytList[i].easting, utmN + ytList[i].northing, zone, isNorthernHemisphere)
            polylineOptions.add(LatLng(latLon.latitude, latLon.longitude))
        }

        googleMap.addPolyline(polylineOptions)
    }


    // 輔助方法
    private fun FailCreate() {
        ytList.clear()
        isOutOfBounds = false
        youTurnPhase = 0
        turnTooCloseTrigger = false
        isTurnCreationTooClose = false
        isTurnCreationNotCrossingError = false
    }

    fun Set_Alternate_skips() {
        if (alternateSkips) {
            rowSkipsWidth2 = if (rowSkipsWidth == 1) 3 else rowSkipsWidth + 2
            if (rowSkipsWidth2 > turnSkips) rowSkipsWidth2 = turnSkips
            previousBigSkip = rowSkipsWidth2 < rowSkipsWidth
        } else {
            rowSkipsWidth2 = rowSkipsWidth
        }
    }

    fun ResetYouTurn() {
        youTurnPhase = 0
        ytList.clear()
        nextCurve.clear()
    }

    fun SmoothYouTurn(numSmooth: Int = 3) {
        if (ytList.size < 5) return

        val oldList = mutableListOf<vec3>()
        oldList.addAll(ytList)
        ytList.clear()

        val cnt = oldList.size
        val arr = arrayOfNulls<vec3>(cnt)
        oldList.toArray(arr)

        for (smooth in 0 until numSmooth) {
            ytList.add(vec3(arr[0]!!))
            for (i in 1 until cnt - 1) {
                val pt = vec3(
                    (arr[i - 1]!!.easting + arr[i]!!.easting + arr[i + 1]!!.easting) / 3.0,
                    (arr[i - 1]!!.northing + arr[i]!!.northing + arr[i + 1]!!.northing) / 3.0,
                    arr[i]!!.heading
                )
                ytList.add(pt)
            }
            ytList.add(vec3(arr[cnt - 1]!!))

            if (smooth < numSmooth - 1) {
                oldList.clear()
                oldList.addAll(ytList)
                ytList.clear()
                oldList.toArray(arr)
            }
        }

        for (i in 1 until cnt - 1) {
            ytList[i].heading = atan2(arr[i + 1]!!.easting - arr[i - 1]!!.easting, arr[i + 1]!!.northing - arr[i - 1]!!.northing)
            if (ytList[i].heading < 0) ytList[i].heading += glm.twoPI
        }
    }


}