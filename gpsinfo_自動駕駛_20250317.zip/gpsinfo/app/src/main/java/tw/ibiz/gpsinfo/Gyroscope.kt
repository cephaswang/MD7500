package tw.ibiz.gpsinfo

import android.util.Log
import java.net.DatagramPacket
import java.net.DatagramSocket
import kotlin.concurrent.thread

/*


請編寫，讀取磁力計方法，Android kotlin 檔名 Adafruit_GPS
package tw.ibiz.gpsinfo 從 UDP 取得數據

*/
class Gyroscope {
    private val TAG = "Gyroscope"
    private val UDP_PORT = 12345 // UDP 監聽端口，可根據需要修改
    private var socket: DatagramSocket? = null
    private var isRunning = false
    private var magneticField = FloatArray(3) // 儲存 x, y, z 三軸數據

    // 回調接口，用於將磁力計數據傳遞給外部
    interface MagnetometerListener {
        fun onMagnetometerDataReceived(x: Float, y: Float, z: Float)
    }

    private var listener: MagnetometerListener? = null

    // 設置回調監聽器
    fun setMagnetometerListener(listener: MagnetometerListener) {
        this.listener = listener
    }

    // 啟動 UDP 接收
    fun startUdpListener() {
        if (isRunning) return
        isRunning = true

        thread(start = true) {
            try {
                socket = DatagramSocket(UDP_PORT)
                Log.d(TAG, "UDP 伺服器啟動，監聽端口: $UDP_PORT")

                val buffer = ByteArray(1024) // 緩衝區大小
                val packet = DatagramPacket(buffer, buffer.size)

                while (isRunning) {
                    socket?.receive(packet) // 接收 UDP 數據包
                    val receivedData = String(packet.data, 0, packet.length)
                    Log.d(TAG, "收到數據: $receivedData")

                    // 解析磁力計數據
                    parseMagnetometerData(receivedData)

                    // 重置數據包長度以接收下一個封包
                    packet.length = buffer.size
                }
            } catch (e: Exception) {
                Log.e(TAG, "UDP 接收錯誤: ${e.message}")
            } finally {
                socket?.close()
            }
        }
    }

    // 停止 UDP 接收
    fun stopUdpListener() {
        isRunning = false
        socket?.close()
        Log.d(TAG, "UDP 伺服器已停止")
    }

    // 解析磁力計數據（假設格式為 "x,y,z"）
    private fun parseMagnetometerData(data: String) {
        try {
            val values = data.split(",")
            if (values.size >= 3) {
                magneticField[0] = values[0].toFloat() // x 軸
                magneticField[1] = values[1].toFloat() // y 軸
                magneticField[2] = values[2].toFloat() // z 軸

                // 透過回調傳遞數據
                listener?.onMagnetometerDataReceived(
                    magneticField[0],
                    magneticField[1],
                    magneticField[2]
                )
                Log.d(TAG, "磁力計數據 - X: ${magneticField[0]}, Y: ${magneticField[1]}, Z: ${magneticField[2]}")
            } else {
                Log.w(TAG, "數據格式錯誤: $data")
            }
        } catch (e: NumberFormatException) {
            Log.e(TAG, "解析磁力計數據失敗: ${e.message}")
        }
    }

    // 計算航向（heading），可選功能
    fun calculateHeading(): Float {
        val x = magneticField[0]
        val y = magneticField[1]
        var heading = Math.toDegrees(Math.atan2(y.toDouble(), x.toDouble())).toFloat()

        // 規範化到 0-360 度
        if (heading < 0) {
            heading += 360f
        }
        return heading
    }
}

// 使用範例（可在 Activity 或 Fragment 中調用）
/*
class MainActivity : AppCompatActivity() {
    private lateinit var gyroscope: Gyroscope

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gyroscope = Gyroscope()
        gyroscope.setMagnetometerListener(object : Gyroscope.MagnetometerListener {
            override fun onMagnetometerDataReceived(x: Float, y: Float, z: Float) {
                runOnUiThread {
                    // 在 UI 線程中更新顯示
                    Log.d("MainActivity", "磁力計數據 - X: $x, Y: $y, Z: $z")
                    val heading = gyroscope.calculateHeading()
                    Log.d("MainActivity", "航向: $heading 度")
                }
            }
        })
        gyroscope.startUdpListener()
    }

    override fun onDestroy() {
        super.onDestroy()
        gyroscope.stopUdpListener()
    }
}
*/