package tw.ibiz.gpsinfo


/*
https://www.youtube.com/watch?v=xXuL3IwFTbA
GPS Guided Autonomous Rover
*/

import android.util.Log
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import kotlin.math.abs
import kotlin.concurrent.thread // 確保導入這個包

class DifferentialDriveSteeringWheel {
    private val TAG = "DifferentialDriveSteeringWheel"
    private val UDP_IP = "192.168.1.100" // 目標設備的 IP 地址，需根據實際情況修改
    private val UDP_PORT = 12345 // UDP 目標端口，需與接收端匹配
    private val PWM_NEUTRAL = 1500f // 停止時的 PWM 值（中立點）
    private val PWM_MAX = 2000f // 最大正轉 PWM 值
    private val PWM_MIN = 1000f // 最大反轉 PWM 值
    private val MAX_STEERING_SPEED = 500f // 最大轉速範圍（PWM 偏移量）

    // 計算並傳送方向盤控制數據
    fun correctDirection(steeringAngle: Float, driveSpeed: Float) {
        // steeringAngle 應為 -180 到 180 度
        // driveSpeed 為基本行駛速度（影響轉速強度，範圍 0-500）
        val direction: String // 方向：正轉（FORWARD）或反轉（REVERSE）
        var pwmValue: Float // PWM 值（1000-2000）

        when {
            steeringAngle < 0 -> { // 左轉，反轉電機
                direction = "REVERSE"
                pwmValue = PWM_NEUTRAL - map(abs(steeringAngle), 0f, 180f, 0f, driveSpeed)
            }
            steeringAngle > 0 -> { // 右轉，正轉電機
                direction = "FORWARD"
                pwmValue = PWM_NEUTRAL + map(abs(steeringAngle), 0f, 180f, 0f, driveSpeed)
            }
            else -> { // 不轉動
                direction = "STOP"
                pwmValue = PWM_NEUTRAL
            }
        }

        // 限制 PWM 值在 1000-2000 範圍內
        pwmValue = pwmValue.coerceIn(PWM_MIN, PWM_MAX)

        Log.d(TAG, "方向: $direction, PWM: $pwmValue")

        // 透過 UDP 傳送控制數據
        sendToUdp(direction, pwmValue)
    }

    // 停止方向盤電機
    fun stopSteering() {
        val direction = "STOP"
        val pwmValue = PWM_NEUTRAL
        Log.d(TAG, "停止方向盤 - 方向: $direction, PWM: $pwmValue")
        sendToUdp(direction, pwmValue)
    }

    // 將控制數據透過 UDP 傳送
    private fun sendToUdp(direction: String, pwmValue: Float) {
        thread(start = true) {
            try {
                val socket = DatagramSocket()
                val inetAddress = InetAddress.getByName(UDP_IP)
                val message = "STEERING,$direction,$pwmValue" // 數據格式：STEERING,方向,PWM
                val buffer = message.toByteArray()
                val packet = DatagramPacket(buffer, buffer.size, inetAddress, UDP_PORT)

                socket.send(packet)
                Log.d(TAG, "UDP 傳送: $message 到 $UDP_IP:$UDP_PORT")
                socket.close()
            } catch (e: Exception) {
                Log.e(TAG, "UDP 傳送錯誤: ${e.message}")
            }
        }
    }

    // 映射函數，類似 Arduino 的 mapf
    private fun map(value: Float, inMin: Float, inMax: Float, outMin: Float, outMax: Float): Float {
        return (value - inMin) * (outMax - outMin) / (inMax - inMin) + outMin
    }
}

// 使用範例（可在 Activity 或 Fragment 中調用）
/*
class MainActivity : AppCompatActivity() {
    private lateinit var steeringWheel: DifferentialDriveSteeringWheel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        steeringWheel = DifferentialDriveSteeringWheel()

        // 測試方向修正
        steeringWheel.correctDirection(steeringAngle = -45f, driveSpeed = 200f) // 左轉 45 度
        Handler(Looper.getMainLooper()).postDelayed({
            steeringWheel.correctDirection(steeringAngle = 60f, driveSpeed = 300f) // 右轉 60 度
        }, 2000)
        Handler(Looper.getMainLooper()).postDelayed({
            steeringWheel.stopSteering() // 停止
        }, 4000)
    }
}
*/