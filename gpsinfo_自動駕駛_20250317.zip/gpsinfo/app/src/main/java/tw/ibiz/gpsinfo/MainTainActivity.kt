package tw.ibiz.gpsinfo

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.Manifest

class MainTainActivity : AppCompatActivity() {

    private lateinit var dbHelper: SurveyingDBHelper
    private lateinit var messageTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maintain)

        dbHelper = SurveyingDBHelper(this)
        messageTextView = findViewById(R.id.messageTextView)

        val backupButton: Button = findViewById(R.id.backupButton)
        val loadButton: Button = findViewById(R.id.loadButton)

        backupButton.setOnClickListener {
            backupDatabase()
        }

        loadButton.setOnClickListener {
            openFilePicker()
        }
        checkPermissions()
    }

    private val REQUEST_CODE_PERMISSIONS = 1002

    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_CODE_PERMISSIONS)
        } else {
            // 已经有权限，可以执行备份操作
            backupDatabase()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                // 权限被授予，可以执行备份操作
                backupDatabase()
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun backupDatabase() {
        val dbFile = getDatabasePath("gpsinfo")
        val timeStamp = SimpleDateFormat("yyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val backupFileName = "gpsinfo_$timeStamp.db"
        val backupFile = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            backupFileName
        )

        try {
            FileInputStream(dbFile).channel.use { inputChannel ->
                FileOutputStream(backupFile).channel.use { outputChannel ->
                    outputChannel.transferFrom(inputChannel, 0, inputChannel.size())
                }
            }
            messageTextView.text = "Database backed up to ${backupFile.absolutePath}"
        } catch (e: IOException) {
            e.printStackTrace()
            messageTextView.text = "Backup failed: ${e.message}"
        }
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, REQUEST_CODE_PICK_FILE)
    }

    @Deprecated("This method has been deprecated in favor of using the Activity Result API\n      which brings increased type safety via an {@link ActivityResultContract} and the prebuilt\n      contracts for common intents available in\n      {@link androidx.activity.result.contract.ActivityResultContracts}, provides hooks for\n      testing, and allow receiving results in separate, testable classes independent from your\n      activity. Use\n      {@link #registerForActivityResult(ActivityResultContract, ActivityResultCallback)}\n      with the appropriate {@link ActivityResultContract} and handling the result in the\n      {@link ActivityResultCallback#onActivityResult(Object) callback}.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_PICK_FILE && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                loadDatabase(uri)
            }
        }
    }

    private fun loadDatabase(uri: Uri) {
        val dbFile = getDatabasePath("gpsinfo")
        try {
            contentResolver.openInputStream(uri)?.use { inputStream ->
                FileOutputStream(dbFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            messageTextView.text = "Database loaded successfully"
            // Optionally, perform a query to verify the data
            val db = dbHelper.readableDatabase
            val cursor =
                db.rawQuery("SELECT COUNT(*) FROM ${SurveyingDBHelper.TABLE_SURVEYING}", null)
            if (cursor.moveToFirst()) {
                val count = cursor.getInt(0)
                messageTextView.text = "Database loaded with $count records"
            }
            cursor.close()
        } catch (e: IOException) {
            e.printStackTrace()
            messageTextView.text = "Failed to load database: ${e.message}"
        }
    }

    companion object {
        private const val REQUEST_CODE_PICK_FILE = 1001
    }
}