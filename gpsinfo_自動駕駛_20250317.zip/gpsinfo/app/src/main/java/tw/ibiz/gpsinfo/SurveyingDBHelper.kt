package tw.ibiz.gpsinfo

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.google.android.gms.maps.model.LatLng
import com.google.gson.Gson

class SurveyingDBHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        // Database information
        const val DATABASE_NAME = "gpsinfo"
        const val DATABASE_VERSION = 1

        // Surveying table
        const val TABLE_SURVEYING = "Surveying"
        const val COLUMN_ID = "id"
        const val COLUMN_COORDINATES = "coordinates"
        const val COLUMN_OWNER = "owner"
        const val COLUMN_LOCATION = "location"
        const val COLUMN_CREATED_AT = "created_at"
        const val COLUMN_ZOOM = "zoom"
        const val COLUMN_CENTER = "center"
        const val COLUMN_BEARING = "bearing"
        const val COLUMN_AREA_SQM = "area_sqm" // 面積（平方公尺）
        const val COLUMN_AREA_PING = "area_ping" // 面積（坪）
        const val COLUMN_AREA_FEN = "area_fen" // 面積（分地）

        // Route points table
        const val TABLE_ROUTE_POINTS = "route_points"
        const val COL_ID = "id"
        const val COL_LATITUDE = "latitude"
        const val COL_LONGITUDE = "longitude"

        // Generated paths table
        const val TABLE_GENERATED_PATHS = "generated_paths"
        const val COL_PATH_ID = "path_id"
        const val COL_POINT_ORDER = "point_order"

        const val TABLE_CVEHICLE = "CVehicle"
        const val COL_VEHICLE_ID = "vehicle_id"
        const val COL_NAME = "name"
        const val COL_TURNING_RADIUS = "turning_radius"
        const val COL_WHEELBASE = "wheelbase"
        const val COL_WIDTH = "width"
    }

    private val gson = Gson()

    override fun onCreate(db: SQLiteDatabase) {
        // Create Surveying table
        val createSurveyingTable = """
            CREATE TABLE $TABLE_SURVEYING (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_COORDINATES TEXT,
                $COLUMN_OWNER TEXT,
                $COLUMN_LOCATION TEXT,
                $COLUMN_CREATED_AT TEXT,
                $COLUMN_ZOOM REAL,
                $COLUMN_CENTER TEXT,
                $COLUMN_BEARING REAL,
                $COLUMN_AREA_SQM REAL,
                $COLUMN_AREA_PING REAL,
                $COLUMN_AREA_FEN REAL
            )
        """.trimIndent()

        // Create route points table
        val createRoutePointsTable = """
            CREATE TABLE $TABLE_ROUTE_POINTS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_LATITUDE REAL NOT NULL,
                $COL_LONGITUDE REAL NOT NULL
            )
        """.trimIndent()

        // Create generated paths table
        val createGeneratedPathsTable = """
            CREATE TABLE $TABLE_GENERATED_PATHS (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_PATH_ID INTEGER NOT NULL,
                $COL_POINT_ORDER INTEGER NOT NULL,
                $COL_LATITUDE REAL NOT NULL,
                $COL_LONGITUDE REAL NOT NULL
            )
        """.trimIndent()

        db.execSQL(createSurveyingTable)
        db.execSQL(createRoutePointsTable)
        db.execSQL(createGeneratedPathsTable)

        val createCVehicleTable = """
            CREATE TABLE $TABLE_CVEHICLE (
                $COL_VEHICLE_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_NAME TEXT NOT NULL,
                $COL_TURNING_RADIUS REAL NOT NULL,
                $COL_WHEELBASE REAL NOT NULL,
                $COL_WIDTH REAL NOT NULL
            )
        """.trimIndent()
        db.execSQL(createCVehicleTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Handle database version upgrades
        if (oldVersion < newVersion) {
            db.execSQL("DROP TABLE IF EXISTS $TABLE_SURVEYING")
            db.execSQL("DROP TABLE IF EXISTS $TABLE_ROUTE_POINTS")
            db.execSQL("DROP TABLE IF EXISTS $TABLE_GENERATED_PATHS")
            db.execSQL("DROP TABLE IF EXISTS $TABLE_CVEHICLE")
            onCreate(db)
        }
    }


    // ===== Surveying Table Methods =====

    fun insertSurveyingData(
        coordinates: List<LatLng>,
        owner: String,
        location: String,
        zoom: Float,
        center: LatLng,
        bearing: Float,
        areaSqm: Double,
        areaPing: Double,
        areaFen: Double
    ): Long {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_COORDINATES, gson.toJson(coordinates))
            put(COLUMN_OWNER, owner)
            put(COLUMN_LOCATION, location)
            put(COLUMN_CREATED_AT, System.currentTimeMillis().toString())
            put(COLUMN_ZOOM, zoom)
            put(COLUMN_CENTER, gson.toJson(center))
            put(COLUMN_BEARING, bearing)
            put(COLUMN_AREA_SQM, areaSqm)
            put(COLUMN_AREA_PING, areaPing)
            put(COLUMN_AREA_FEN, areaFen)
        }
        return db.insert(TABLE_SURVEYING, null, values)
    }

    fun deleteSurveyingData(id: Int): Int {
        val db = this.writableDatabase
        val whereClause = "$COLUMN_ID = ?"
        val whereArgs = arrayOf(id.toString())
        return db.delete(TABLE_SURVEYING, whereClause, whereArgs)
    }

    fun updateSurveyingData(
        id: Int,
        coordinates: List<LatLng>? = null,
        owner: String? = null,
        location: String? = null,
        zoom: Float? = null,
        center: LatLng? = null,
        bearing: Float? = null,
        areaSqm: Double? = null,
        areaPing: Double? = null,
        areaFen: Double? = null
    ): Int {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            coordinates?.let { put(COLUMN_COORDINATES, gson.toJson(it)) }
            owner?.let { put(COLUMN_OWNER, it) }
            location?.let { put(COLUMN_LOCATION, it) }
            zoom?.let { put(COLUMN_ZOOM, it) }
            center?.let { put(COLUMN_CENTER, gson.toJson(it)) }
            bearing?.let { put(COLUMN_BEARING, it) }
            areaSqm?.let { put(COLUMN_AREA_SQM, it) }
            areaPing?.let { put(COLUMN_AREA_PING, it) }
            areaFen?.let { put(COLUMN_AREA_FEN, it) }
        }

        val whereClause = "$COLUMN_ID = ?"
        val whereArgs = arrayOf(id.toString())
        return db.update(TABLE_SURVEYING, values, whereClause, whereArgs)
    }

    // ===== Route Points and Generated Paths Methods =====

    fun saveGeneratedPaths(paths: List<List<LatLng>>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            // Clear existing paths
            db.delete(TABLE_GENERATED_PATHS, null, null)

            // Insert new paths
            for (pathIndex in paths.indices) {
                val path = paths[pathIndex]
                for (pointIndex in path.indices) {
                    val point = path[pointIndex]
                    val values = ContentValues().apply {
                        put(COL_PATH_ID, pathIndex)
                        put(COL_POINT_ORDER, pointIndex)
                        put(COL_LATITUDE, point.latitude)
                        put(COL_LONGITUDE, point.longitude)
                    }
                    db.insert(TABLE_GENERATED_PATHS, null, values)
                }
            }
            db.setTransactionSuccessful()
        } catch (e: Exception) {
            Log.e("SurveyingDBHelper", "Error saving generated paths", e)
        } finally {
            db.endTransaction()
        }
    }

    fun getRoutePoints(): List<LatLng> {
        val points = ArrayList<LatLng>()
        val db = readableDatabase
        val cursor = db.query(
            TABLE_ROUTE_POINTS,
            arrayOf(COL_LATITUDE, COL_LONGITUDE),
            null, null, null, null, null
        )

        with(cursor) {
            while (moveToNext()) {
                val latitude = getDouble(getColumnIndexOrThrow(COL_LATITUDE))
                val longitude = getDouble(getColumnIndexOrThrow(COL_LONGITUDE))
                points.add(LatLng(latitude, longitude))
            }
            close()
        }
        return points
    }

    fun saveRoutePoint(point: LatLng): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_LATITUDE, point.latitude)
            put(COL_LONGITUDE, point.longitude)
        }
        return db.insert(TABLE_ROUTE_POINTS, null, values)
    }

    fun saveRoutePoints(points: List<LatLng>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (point in points) {
                val values = ContentValues().apply {
                    put(COL_LATITUDE, point.latitude)
                    put(COL_LONGITUDE, point.longitude)
                }
                db.insert(TABLE_ROUTE_POINTS, null, values)
            }
            db.setTransactionSuccessful()
        } catch (e: Exception) {
            Log.e("SurveyingDBHelper", "Error saving route points", e)
        } finally {
            db.endTransaction()
        }
    }

    fun clearRoutePoints(): Int {
        val db = writableDatabase
        return db.delete(TABLE_ROUTE_POINTS, null, null)
    }

    fun getGeneratedPaths(): List<List<LatLng>> {
        val paths = ArrayList<ArrayList<LatLng>>()
        val db = readableDatabase

        // Get all distinct path IDs
        val pathIdCursor = db.rawQuery("SELECT DISTINCT $COL_PATH_ID FROM $TABLE_GENERATED_PATHS ORDER BY $COL_PATH_ID", null)
        val pathIds = ArrayList<Int>()

        with(pathIdCursor) {
            while (moveToNext()) {
                pathIds.add(getInt(getColumnIndexOrThrow(COL_PATH_ID)))
            }
            close()
        }

        // For each path ID, get all points in order
        for (pathId in pathIds) {
            val path = ArrayList<LatLng>()
            val pointsCursor = db.query(
                TABLE_GENERATED_PATHS,
                arrayOf(COL_LATITUDE, COL_LONGITUDE),
                "$COL_PATH_ID = ?",
                arrayOf(pathId.toString()),
                null, null,
                "$COL_POINT_ORDER ASC"
            )

            with(pointsCursor) {
                while (moveToNext()) {
                    val latitude = getDouble(getColumnIndexOrThrow(COL_LATITUDE))
                    val longitude = getDouble(getColumnIndexOrThrow(COL_LONGITUDE))
                    path.add(LatLng(latitude, longitude))
                }
                close()
            }

            paths.add(path)
        }
        return paths
    }

    private fun saveRoutePointsToDB(points: List<LatLng>) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            // Clear existing points
            db.delete(TABLE_ROUTE_POINTS, null, null)

            // Insert new points
            for (point in points) {
                val values = ContentValues().apply {
                    put(COL_LATITUDE, point.latitude)
                    put(COL_LONGITUDE, point.longitude)
                }
                db.insert(TABLE_ROUTE_POINTS, null, values)
            }
            db.setTransactionSuccessful()
        } catch (e: Exception) {
            Log.e("SurveyingDBHelper", "Error saving route points", e)
        } finally {
            db.endTransaction()
        }
    }


    // CVehicle 方法調整為 Float
    fun insertVehicle(name: String, turningRadius: Float, wheelbase: Float, width: Float): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_NAME, name)
            put(COL_TURNING_RADIUS, turningRadius)
            put(COL_WHEELBASE, wheelbase)
            put(COL_WIDTH, width)
        }
        return db.insert(TABLE_CVEHICLE, null, values)
    }

    fun updateVehicle(id: Int, name: String, turningRadius: Float, wheelbase: Float, width: Float): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_NAME, name)
            put(COL_TURNING_RADIUS, turningRadius)
            put(COL_WHEELBASE, wheelbase)
            put(COL_WIDTH, width)
        }
        return db.update(TABLE_CVEHICLE, values, "$COL_VEHICLE_ID = ?", arrayOf(id.toString()))
    }

    fun deleteVehicle(id: Int): Int {
        val db = writableDatabase
        return db.delete(TABLE_CVEHICLE, "$COL_VEHICLE_ID = ?", arrayOf(id.toString()))
    }

    fun getAllVehicles(): List<Vehicle> {
        val vehicles = ArrayList<Vehicle>()
        val db = readableDatabase
        val cursor = db.query(TABLE_CVEHICLE, null, null, null, null, null, null)

        with(cursor) {
            while (moveToNext()) {
                val vehicle = Vehicle(
                    getInt(getColumnIndexOrThrow(COL_VEHICLE_ID)),
                    getString(getColumnIndexOrThrow(COL_NAME)),
                    getFloat(getColumnIndexOrThrow(COL_TURNING_RADIUS)), // 改用 getFloat
                    getFloat(getColumnIndexOrThrow(COL_WHEELBASE)),      // 改用 getFloat
                    getFloat(getColumnIndexOrThrow(COL_WIDTH))           // 改用 getFloat
                )
                vehicles.add(vehicle)
            }
            close()
        }
        return vehicles
    }


}

// 更新 Vehicle data class，使用 Float
data class Vehicle(
    val id: Int,
    val name: String,
    val turningRadius: Float,  // 改為 Float
    val wheelbase: Float,      // 改為 Float
    val width: Float           // 改為 Float
)