package tw.ibiz.gpsinfo

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    // 定義一個點類
    data class Point(val x: Double, val y: Double)

    // 定義一個線段類
    data class Line(val p1: Point, val p2: Point)

    private lateinit var mMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val locationPermissionCode = 100
    private var fieldCoordinates = ArrayList<LatLng>()
    private var polygon: Polygon? = null
    private var generatedPaths = ArrayList<ArrayList<LatLng>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        val clearButton: Button = findViewById(R.id.clearButton)
        val completeButton: Button = findViewById(R.id.completeButton)
        val generateLinesButton: Button = findViewById(R.id.generateLinesButton)

        clearButton.setOnClickListener {
            clearMap()
        }

        completeButton.setOnClickListener {
            completePolygon()
        }

        generateLinesButton.setOnClickListener {
            generatedPaths = generateParallelPath(fieldCoordinates, 2.0f, 0.3f, 1)
            drawGeneratedPaths()
        }
    }

    private fun drawFieldBoundary() {
        if (fieldCoordinates.isEmpty() || !::mMap.isInitialized) return

        // 清除之前的邊界
        mMap.clear()

        // 創建多邊形選項
        val polygonOptions = PolygonOptions()
            .addAll(fieldCoordinates)
            .strokeColor(Color.RED)
            .strokeWidth(5f)
            .fillColor(Color.argb(30, 255, 0, 0))

        // 添加多邊形到地圖
        mMap.addPolygon(polygonOptions)

        /*
        if (actSerial < 1) {
            mMap.animateCamera(CameraUpdateFactory.zoomTo(zoom.toFloat()))
            val currentPosition = mMap.cameraPosition
            val newPosition = CameraPosition.Builder(currentPosition)
                .bearing(bearing.toFloat()) // 更新方向
                .build()
            mMap.moveCamera(CameraUpdateFactory.newCameraPosition(newPosition))
            // 將地圖中心對準邊界
            centerMapOnField()
        }
        actSerial++
        */
    }


    private fun drawGeneratedPaths() {
        // 清除之前的路徑（保留邊界）
        mMap.clear()
        drawFieldBoundary()

        // 繪製每條生成的路徑
        for (i in generatedPaths.indices) {
            val path = generatedPaths[i]

            Log.d("路徑 $i", path.toString())

            // 創建折線選項
            val polylineOptions = PolylineOptions()
                .addAll(path)
                .width(5f)
                .color(Color.HSVToColor(floatArrayOf(i * 120f / generatedPaths.size, 1f, 1f)))
                .geodesic(true)

            // 添加折線到地圖
            mMap.addPolyline(polylineOptions)

            // 連接最後一個點到第一個點以閉合路徑
            if (path.size > 0) {
                val closingLine = PolylineOptions()
                    .add(path.last())
                    .add(path.first())
                    .width(5f)
                    .color(Color.HSVToColor(floatArrayOf(i * 120f / generatedPaths.size, 1f, 1f)))
                    .geodesic(true)

                mMap.addPolyline(closingLine)
            }
        }
    }


    // 計算兩條線段的交點
    fun findIntersection(line1: Line, line2: Line): Point? {
        val a1 = line1.p2.y - line1.p1.y
        val b1 = line1.p1.x - line1.p2.x
        val c1 = a1 * line1.p1.x + b1 * line1.p1.y

        val a2 = line2.p2.y - line2.p1.y
        val b2 = line2.p1.x - line2.p2.x
        val c2 = a2 * line2.p1.x + b2 * line2.p1.y

        val determinant = a1 * b2 - a2 * b1

        if (determinant == 0.0) {
            return null // 平行或重合，沒有交點
        } else {
            val x = (b2 * c1 - b1 * c2) / determinant
            val y = (a1 * c2 - a2 * c1) / determinant
            return Point(x, y)
        }
    }

    // 檢查點是否在線段上
    fun isPointOnSegment(line: Line, point: Point): Boolean {
        val minX = min(line.p1.x, line.p2.x)
        val maxX = max(line.p1.x, line.p2.x)
        val minY = min(line.p1.y, line.p2.y)
        val maxY = max(line.p1.y, line.p2.y)

        return (point.x in minX..maxX) && (point.y in minY..maxY)
    }

    // 找到直線與多邊形的交點
    fun findPolygonIntersections(
        fieldCoordinates: ArrayList<LatLng>,
        parallelPath: ArrayList<LatLng>
    ): Pair<LatLng, LatLng> {
        val intersections = ArrayList<LatLng>()

        // 將平行路徑轉換為線段
        val parallelLine = Line(
            Point(parallelPath[0].latitude, parallelPath[0].longitude),
            Point(parallelPath[1].latitude, parallelPath[1].longitude)
        )

        // 遍歷多邊形的每一條邊
        for (i in 0 until fieldCoordinates.size) {
            val j = (i + 1) % fieldCoordinates.size
            val polygonLine = Line(
                Point(fieldCoordinates[i].latitude, fieldCoordinates[i].longitude),
                Point(fieldCoordinates[j].latitude, fieldCoordinates[j].longitude)
            )

            // 計算交點
            val intersection = findIntersection(parallelLine, polygonLine)
            if (intersection != null && isPointOnSegment(polygonLine, intersection)) {
                intersections.add(LatLng(intersection.x, intersection.y))
            }
        }

        // 如果找到兩個交點，返回它們
        if (intersections.size == 2) {
            return Pair(intersections[0], intersections[1])
        }

        // 否則返回 (0, 0)
        return Pair(LatLng(0.0, 0.0), LatLng(0.0, 0.0))
    }


    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
        mMap.uiSettings.isZoomControlsEnabled = true

        if (checkLocationPermission()) {
            mMap.isMyLocationEnabled = true
            getUserLocation()
        } else {
            requestLocationPermission()
        }

        mMap.setOnMapClickListener { latLng ->
            fieldCoordinates.add(latLng)
            mMap.addMarker(MarkerOptions().position(latLng))
        }
    }

    private fun checkLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestLocationPermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            locationPermissionCode
        )
    }

    @SuppressLint("MissingPermission")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationPermissionCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mMap.isMyLocationEnabled = true
                getUserLocation()
            }
        }
    }

    private fun getUserLocation() {
        if (checkLocationPermission()) {
            fusedLocationClient.lastLocation
                .addOnSuccessListener { location: Location? ->
                    location?.let {
                        val userLatLng = LatLng(it.latitude, it.longitude)
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 18f))
                    }
                }
        }
    }

    private fun clearMap() {
        mMap.clear()
        fieldCoordinates.clear()
        polygon?.remove()
        polygon = null
    }

    private fun completePolygon() {
        if (fieldCoordinates.size >= 3) {
            polygon?.remove()
            polygon = mMap.addPolygon(
                PolygonOptions()
                    .addAll(fieldCoordinates)
                    .strokeColor(0xFF0000FF.toInt())
                    .fillColor(0x330000FF.toInt())
            )
            printPolygonCenter()
        }
    }

    private fun printPolygonCenter() {
        if (fieldCoordinates.size >= 3) {
            val center = calculatePolygonCenter(fieldCoordinates)
            Log.d("PolygonCenter", "Center: ${center.latitude}, ${center.longitude}")
        }
    }

    private fun calculatePolygonCenter(points: List<LatLng>): LatLng {
        var x = 0.0
        var y = 0.0
        for (point in points) {
            x += point.latitude
            y += point.longitude
        }
        return LatLng(x / points.size, y / points.size)
    }


    private fun generateParallelPath(
        boundaryPoints: ArrayList<LatLng>,
        vehicleWidth: Float,
        pathOverlap: Float,
        stepNum: Int // 只用於識別，並打印
    ): ArrayList<ArrayList<LatLng>> {
        val parallelPaths = ArrayList<ArrayList<LatLng>>()
        val metersToDegreesLat = 1.0 / 111111.0
        if (boundaryPoints.size < 2) {
            return parallelPaths
        }

        // 計算封閉區域的寬度（最大偏移量）
        val maxOffset = calculateMaxOffset(boundaryPoints)
        val numLines = ((maxOffset / vehicleWidth) + 1).toInt() + 100 // 計算需要的平行線數量

        val p1 = boundaryPoints[stepNum % boundaryPoints.size]
        val p2 = boundaryPoints[(stepNum + 1) % boundaryPoints.size]
        val direction = Math.atan2(p2.longitude - p1.longitude, p2.latitude - p1.latitude)

        for (i in 0 until numLines) {
            val offset = i * vehicleWidth * metersToDegreesLat
            val overlap = pathOverlap * metersToDegreesLat
            val perpendicularDirection = direction + Math.PI / 2
            val offsetX = offset * Math.cos(perpendicularDirection)
            val offsetY = offset * Math.sin(perpendicularDirection)

            val overlapX = overlap * Math.cos(direction)
            val overlapY = overlap * Math.sin(direction)

            val startPoint =
                LatLng(p1.latitude + offsetX - overlapX, p1.longitude + offsetY - overlapY)
            val endPoint =
                LatLng(p2.latitude + offsetX + overlapX, p2.longitude + offsetY + overlapY)

            var parallelPath = ArrayList<LatLng>()
            parallelPath.add(startPoint)
            parallelPath.add(endPoint)

            val intersections: Pair<LatLng, LatLng> =
                findPolygonIntersections(fieldCoordinates, parallelPath)

            if (intersections.first.latitude > 0.0) {
                parallelPath = ArrayList<LatLng>()
                parallelPath.add(intersections.first)
                parallelPath.add(intersections.second)
                parallelPaths.add(parallelPath)
            }
        }

        return parallelPaths
    }

    /**
     * 計算封閉區域的最大偏移量（平行線的最大寬度）
     */
    private fun calculateMaxOffset(boundaryPoints: ArrayList<LatLng>): Float {
        val center = calculatePolygonCenter(boundaryPoints)
        var maxDistance = 0f

        for (point in boundaryPoints) {
            val distance = calculateDistance(center, point)
            if (distance > maxDistance) {
                maxDistance = distance
            }
        }

        return maxDistance
    }

    /**
     * 計算兩個點之間的距離
     */
    private fun calculateDistance(p1: LatLng, p2: LatLng): Float {
        val lat1 = p1.latitude
        val lon1 = p1.longitude
        val lat2 = p2.latitude
        val lon2 = p2.longitude

        val radius = 6371000 // 地球半徑（單位：米）
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)

        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)

        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return (radius * c).toFloat()
    }


    /*
        private fun generateParallelLines() {
            if (points.size >= 2) {

                val center = calculatePolygonCenter(points)
                val p1 = points[0]
                val p2 = points[1]
                val direction = Math.atan2(p2.longitude - p1.longitude, p2.latitude - p1.latitude)

                for (i in 1..5) { // 生成11條平行線
                    val offset = i * 0.00002 // 調整間隔
                    val overlap = 0.000003 // 調整重疊
                    val perpendicularDirection = direction + Math.PI / 2
                    val offsetX = offset * Math.cos(perpendicularDirection)
                    val offsetY = offset * Math.sin(perpendicularDirection)

                    val overlapX = overlap * Math.cos(direction)
                    val overlapY = overlap * Math.sin(direction)

                    val startPoint = LatLng(p1.latitude + offsetX - overlapX, p1.longitude + offsetY - overlapY)
                    val endPoint = LatLng(p2.latitude + offsetX + overlapX, p2.longitude + offsetY + overlapY)

                    mMap.addPolyline(PolylineOptions().add(startPoint, endPoint).color(0xFFFF0000.toInt()))
                }
            }
        }
    */

}