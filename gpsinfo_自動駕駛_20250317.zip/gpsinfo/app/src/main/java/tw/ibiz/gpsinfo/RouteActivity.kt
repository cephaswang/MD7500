package tw.ibiz.gpsinfo

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.media.MediaPlayer
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.PowerManager
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolygonOptions
import com.google.android.gms.maps.model.PolylineOptions
import com.google.gson.Gson
import com.google.maps.android.PolyUtil
import com.google.maps.android.SphericalUtil
import fi.iki.elonen.NanoHTTPD
import okio.IOException
import org.json.JSONArray
import org.json.JSONObject
import java.lang.Math.abs


class RouteActivity : AppCompatActivity(), OnMapReadyCallback, GoogleMap.OnCameraMoveListener,
    GoogleMap.OnMarkerClickListener, IotServer.ServerEventCallback {

    private val TAG = "RouteActivity"

    // 下方視圖相關
    private lateinit var bottomView: CardView
    private lateinit var tvLatitude: TextView
    private lateinit var tvLongitude: TextView
    private lateinit var btnIncrease: Button
    private lateinit var btnDecrease: Button
    private lateinit var btnSavePoint: Button

    // 當前編輯的點
    private var currentEditingMarker: Marker? = null
    private var selectedTextView: TextView? = null // 當前選取的文字（經度或緯度）

    private lateinit var iotServer: IotServer

    private lateinit var tvPathLabel: TextView
    private lateinit var btnPathOrder: Button
    private lateinit var btnPathNext: Button

    private var currentPathIndex = 0
    private var actSerial = 0

    private var isPathOrderAscending = true
    private var vehicleMarker: Marker? = null

    private lateinit var mMap: GoogleMap
    private lateinit var edtVehicleWidth: EditText
    private lateinit var edtVehicleLength: EditText
    private lateinit var edtPathOverlap: EditText
    private lateinit var btnGeneratePath: Button
    private lateinit var btnTurbinePath: Button
    private lateinit var btnClear: Button

    // 其他變量聲明
    private lateinit var btnRemove: Button
    private lateinit var btnSave: Button
    private lateinit var btnUpdate: Button
    private lateinit var btnDelete: Button


    private lateinit var btnToggleMapType: Button
    private lateinit var tvSerial: TextView
    private lateinit var tvAreaInfo: TextView
    private lateinit var etOwner: EditText
    private lateinit var etLocation: EditText

    private lateinit var SurveyingDbHelper: SurveyingDBHelper

    private var fieldCoordinates = ArrayList<LatLng>()
    private var generatedPaths = ArrayList<ArrayList<LatLng>>()

    private lateinit var pointsJsonString: String
    private var bearing: Double = 0.0
    private var zoom: Double = 0.0
    private lateinit var center: String
    private var stepNum: Int = 0

    private var owner: String = ""
    private var location: String = ""
    private var RecordId: String = ""


    // 地圖模式狀態
    private var isSatelliteMode = false

    private val markers = mutableListOf<Marker>() // 用於保存地圖上的標示點

    private var isSimulating = false // 標誌變量，用於追蹤模擬狀態
    private val handler = Handler() // 用於執行模擬任務的 Handler

    private var act_offset = false // 初始狀態為 false

    // 當前經緯度和補正量
    private var currentLatitude = 0.0
    private var currentLongitude = 0.0
    private var latitudeOffset = 0.0
    private var longitudeOffset = 0.0
    private lateinit var tvLongitudeOff: TextView
    private lateinit var tvLatitudeOff: TextView

    private lateinit var wakeLock: PowerManager.WakeLock

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_route)

        // 初始化 WakeLock
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RouteActivity::WakeLock")
        wakeLock.acquire(1000*60*1000L /*10 minutes*/) // 獲取 WakeLock，禁止進入休眠

        val btnExpandCollapse: ImageButton = findViewById(R.id.btnExpandCollapse)
        val expandableContent: LinearLayout = findViewById(R.id.expandableContent)
        btnExpandCollapse.setOnClickListener {
            if (expandableContent.getVisibility() === View.VISIBLE) {
                expandableContent.setVisibility(View.GONE)
                btnExpandCollapse.setImageResource(R.drawable.arrow_down_24)
            } else {
                expandableContent.setVisibility(View.VISIBLE)
                btnExpandCollapse.setImageResource(R.drawable.arrow_up_24)
            }
        }
        val fabToggleBottom: ImageButton = findViewById(R.id.fabToggleBottom)
        fabToggleBottom.setOnClickListener {
            if (bottomView.visibility == View.VISIBLE) {
                bottomView.visibility = View.GONE
            } else {
                bottomView.visibility = View.VISIBLE
            }
        }

        // 獲取傳遞過來的參數
        pointsJsonString = intent.getStringExtra("PointsJsonString").toString()
        bearing = intent.getDoubleExtra("bearing", 0.0)
        center = intent.getStringExtra("center").toString()
        zoom = intent.getDoubleExtra("zoom", 0.0)

        owner = intent.getStringExtra("owner").toString()
        location = intent.getStringExtra("location").toString()
        RecordId = intent.getStringExtra("RecordId").toString()

        // 初始化下方視圖
        bottomView = findViewById(R.id.bottomView)
        tvLatitude = findViewById(R.id.tvLatitude)
        tvLongitude = findViewById(R.id.tvLongitude)
        btnIncrease = findViewById(R.id.btnIncrease)
        btnDecrease = findViewById(R.id.btnDecrease)
        btnSavePoint = findViewById(R.id.btnSavePoint)

        tvLongitudeOff = findViewById(R.id.tvLongitude_off)
        tvLatitudeOff = findViewById(R.id.tvLatitude_off)

        // 增加按鍵
        btnIncrease.setOnClickListener {
            adjustPoint(0.0000002) // 增加 0.5 公分（約 0.000005 度）
            Log.d("btnIncrease", "btnIncrease")
        }

        // 減少按鍵
        btnDecrease.setOnClickListener {
            adjustPoint(-0.0000002) // 減少 0.5 公分（約 -0.000005 度）
            Log.d("btnDecrease", "btnDecrease")
        }

        // 保存按鍵
        btnSavePoint.setOnClickListener {
            savePoint()
        }

        // 緯度文字點擊事件
        tvLatitude.setOnClickListener {
            selectTextView(tvLatitude)
        }

        // 經度文字點擊事件
        tvLongitude.setOnClickListener {
            selectTextView(tvLongitude)
        }


        val valueSerial: String = intent.getStringExtra("valueSerial").toString()

        // 從暫存讀取補正量
        val sharedPreferences = getSharedPreferences("Offsets", MODE_PRIVATE)
        latitudeOffset = sharedPreferences.getFloat("latitudeOffset", 0.0f).toDouble()
        longitudeOffset = sharedPreferences.getFloat("longitudeOffset", 0.0f).toDouble()

        // 初始化 UI 組件
        edtVehicleWidth = findViewById(R.id.edt_vehicle_width)
        edtVehicleLength = findViewById(R.id.edt_vehicle_length)
        edtPathOverlap = findViewById(R.id.edt_path_overlap)
        btnGeneratePath = findViewById(R.id.btn_generate_path)
        btnTurbinePath = findViewById(R.id.btn_turbine_path)
        btnClear = findViewById(R.id.btn_clear)
        btnToggleMapType = findViewById(R.id.btn_toggle_map_type)
        tvSerial = findViewById(R.id.tvSerial)
        // 其他初始化代碼
        btnRemove = findViewById(R.id.btn_remove)
        tvAreaInfo = findViewById(R.id.areaInfo)
        btnSave = findViewById(R.id.btn_save)
        etOwner = findViewById(R.id.etowner)
        etLocation = findViewById(R.id.etlocation)
        btnUpdate = findViewById(R.id.btn_update)
        btnDelete = findViewById(R.id.btn_delete)

        tvPathLabel = findViewById(R.id.tv_path_label)
        btnPathOrder = findViewById(R.id.btn_path_order)
        btnPathNext = findViewById(R.id.btn_path_next)

        etOwner.setText(owner)
        etLocation.setText(location)

        tvSerial.text = valueSerial

        // 設置默認值
        edtVehicleWidth.setText("2.0")
        edtVehicleLength.setText("2.0")
        edtPathOverlap.setText("0.3")

        // 初始化數據庫助手
        //dbHelper = RouteDBHelper(this)

        val btnPathOffset: Button = findViewById(R.id.btn_path_offset)
        btnPathOffset.setOnClickListener {
            // 切換 act_offset 的狀態
            act_offset = !act_offset

            currentEditingMarker = vehicleMarker

            // 根據 act_offset 的狀態更新按鈕的底色和文字顏色
            if (act_offset) {
                btnPathOffset.setBackgroundColor(Color.parseColor("#FF6200EE")) // 激活狀態背景色
                btnPathOffset.setTextColor(Color.parseColor("#FFFFFF")) // 激活狀態文字顏色
                btnPathOffset.text = "補正ON"
                // 顯示下方視圖
                bottomView.visibility = View.VISIBLE
                // 檢查 vehicleMarker 是否已經初始化
                if (vehicleMarker != null) {
                    // 獲取 vehicleMarker 的座標值
                    val latLng = vehicleMarker?.position
                    val latitude = latLng?.latitude
                    val longitude = latLng?.longitude

                    tvLatitude.text = "緯度: $latitude"
                    tvLongitude.text = "經度: $longitude"
                    // 預設選取經度文字
                    selectTextView(tvLongitude)
                    updateUI()
                }
            } else {
                btnPathOffset.setBackgroundColor(Color.parseColor("#CCCCCC")) // 默認背景色
                btnPathOffset.setTextColor(Color.parseColor("#000000")) // 默認文字顏色
                btnPathOffset.text = "補正OFF"
                // 顯示下方視圖
                bottomView.visibility = View.GONE
            }
        }

        // 初始化地圖
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        btnPathOrder.setOnClickListener {
            togglePathOrder()
        }

        btnPathNext.setOnClickListener {
            showNextPath()
        }

        // 設置按鈕點擊事件
        btnGeneratePath.setOnClickListener {
            generateRoutePath()
            saveVehicleData()
            currentPathIndex = 0
            // 更新路徑標籤
            updatePathLabel()
        }

        btnDelete.setOnClickListener {
            tapBtnDelete()
        }

        btnSave.setOnClickListener {
            tapBtnSave()
        }

        btnUpdate.setOnClickListener {
            tapBtnUpdate()
        }

        // 設置「刪除」按鈕的點擊事件
        btnRemove.setOnClickListener {
            showDeleteConfirmationDialog()
        }

        btnTurbinePath.setOnClickListener {
            generateTurbinePath()
            saveVehicleData()
            currentPathIndex = 0
            // 更新路徑標籤
            updatePathLabel()
        }

        btnClear.setOnClickListener {
            clearGeneratedPaths()
        }

        btnToggleMapType.setOnClickListener {
            toggleMapMode()
        }

        // 加載路徑點
        loadRoutePoints()

        // 加載保存的數據
        loadSavedData()

        // Initialize the server
        iotServer = IotServer(this)
        iotServer.setEventCallback(this)
        iotServer.startServer()

    }


    // 選取文字
    private fun selectTextView(textView: TextView) {
        // 清除之前選取的文字底色
        selectedTextView?.setBackgroundColor(Color.TRANSPARENT)
        // 設置當前選取的文字
        selectedTextView = textView
        // 設置選取文字的底色
        textView.setBackgroundColor(Color.GREEN)
    }

    // 保存點的座標
    private fun savePoint() {
        // 關閉下方視圖
        bottomView.visibility = View.GONE
    }

    // 更新 UI 顯示
    private fun updateUI() {
        // 更新補正量顯示
        tvLatitudeOff.text = "$latitudeOffset"
        tvLongitudeOff.text = "$longitudeOffset"
    }

    // 調整點的座標
    @SuppressLint("SetTextI18n")
    private fun adjustPoint(delta: Double) {
        saveOffsetToTemporaryStorage()
        currentEditingMarker?.let { marker ->
            val latLng = marker.position
            val newLatLng = when (selectedTextView) {
                tvLatitude -> {
                    latitudeOffset += delta // 調整緯度補正量
                    tvLatitudeOff.text = "$latitudeOffset" // 更新 UI
                    LatLng(latLng.latitude + delta, latLng.longitude) // 返回新的緯度
                }

                tvLongitude -> {
                    longitudeOffset += delta // 調整經度補正量
                    tvLongitudeOff.text = "$longitudeOffset" // 更新 UI
                    LatLng(latLng.latitude, latLng.longitude + delta) // 返回新的經度
                }

                else -> return // 如果沒有選取任何 TextView，則不執行任何操作
            }
            marker.position = newLatLng // 更新 Marker 的位置

            // 更新經緯度顯示
            tvLatitude.text = "緯度: ${newLatLng.latitude}"
            tvLongitude.text = "經度: ${newLatLng.longitude}"
        }
    }


    // 保存補正量到暫存
    private fun saveOffsetToTemporaryStorage() {
        val sharedPreferences = getSharedPreferences("Offsets", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putFloat("latitudeOffset", latitudeOffset.toFloat())
        editor.putFloat("longitudeOffset", longitudeOffset.toFloat())
        editor.apply()
    }


    private fun togglePathOrder() {
        isPathOrderAscending = !isPathOrderAscending
        updatePathLabel()

        if (isPathOrderAscending) {
            btnPathOrder.setText("+")
        } else {
            btnPathOrder.setText("-")
        }
    }

    private fun showNextPath() {
        if (generatedPaths.isEmpty()) return

        // 移除先前路徑的高亮顯示
        //  mMap.clear()
        //  drawFieldBoundary()

        // 更新當前路徑索引
        if (isPathOrderAscending) {
            currentPathIndex = (currentPathIndex + 1) % generatedPaths.size
        } else {
            currentPathIndex = (currentPathIndex - 1 + generatedPaths.size) % generatedPaths.size
        }

        // 繪製所有路徑
        //   drawGeneratedPaths()

        // 獲取當前路徑
        val currentPath = generatedPaths[currentPathIndex]

        // 高亮顯示當前路徑（藍色）
        val polylineOptions = PolylineOptions()
            .addAll(currentPath)
            .width(10f)
            .color(Color.BLUE)
            .geodesic(true)

        // 如果路徑是環形的，封閉路徑
        if (currentPath.size > 1) {
            polylineOptions.add(currentPath.first()) // 將最後一個點連接到第一個點
        }

        // 添加高亮路徑到地圖
        mMap.addPolyline(polylineOptions)

        // 更新路徑標籤
        updatePathLabel()

        // 啟動車輛位置模擬
        startSimulatingVehicleMovement()
    }


    @SuppressLint("SetTextI18n")
    private fun updatePathLabel() {
        tvPathLabel.text = "${currentPathIndex + 1}/${generatedPaths.size}"
    }

    @SuppressLint("PotentialBehaviorOverride")
    private fun updateVehiclePosition(latLng: LatLng) {
        // 應用補正量到座標
        val correctedLatLng = LatLng(
            latLng.latitude + latitudeOffset, // 緯度加上補正量
            latLng.longitude + longitudeOffset // 經度加上補正量
        )
        Log.d("實時位置", "原始座標: $latLng, 補正後座標: $correctedLatLng")

        Log.d("實時位置", latLng.toString())
        if (vehicleMarker == null) {
            // 如果標記不存在，創建新的標記
            vehicleMarker = mMap.addMarker(
                MarkerOptions()
                    .position(correctedLatLng) // 使用補正後的座標
                    .title("車輛")  // 設置標題
                    .snippet("實時位置") // 設置副標題
            )
        } else {
            // 如果標記已存在，使用 setPosition 更新位置
            vehicleMarker?.remove() // 移除舊標記
            vehicleMarker = mMap.addMarker( // 重新創建標記
                MarkerOptions()
                    .position(correctedLatLng) // 使用補正後的座標
                    .title("車輛")
                    .snippet("實時位置")
            )
        }

        // 確保標記資訊視窗顯示
        vehicleMarker?.showInfoWindow()
    }


    private fun startSimulatingVehicleMovement() {

        if (fieldCoordinates.size < 3) {
            Toast.makeText(this, "需要至少三個點來定義封閉區域", Toast.LENGTH_SHORT).show()
            return
        }

        // 如果正在模擬，先停止
        if (isSimulating) {
            stopSimulatingVehicleMovement()
        }

        // 開始模擬
        isSimulating = true
        handler.post(simulateVehicleTask)

        // 初始化車輛標記
        val initialPosition = generateRandomPointInsidePolygon(fieldCoordinates)
        if (initialPosition != null) {
            updateVehiclePosition(initialPosition)
        }
    }


    private val simulateVehicleTask = object : Runnable {
        override fun run() {

            // 你可以根據 act_offset 的狀態執行其他操作
            if (act_offset) {
                // act_offset 為 true 時的邏輯
                return
            }

            if (!isSimulating) return

            if (fieldCoordinates.size < 3) {
                return
            }

            Log.d("simulateVehicleTask", "simulateVehicleTask")
            // 生成一個位於封閉區域內的隨機點
            val latLng = generateRandomPointInsidePolygon(fieldCoordinates)
            if (latLng != null) {
                updateVehiclePosition(latLng)
            }

            // 每秒更新一次
            handler.postDelayed(this, 1000)
        }
    }


    private fun stopSimulatingVehicleMovement() {
        isSimulating = false
        handler.removeCallbacks(simulateVehicleTask) // 移除未執行的任務
    }


    /**
     * 生成一個位於多邊形區域內的隨機點
     */
    private fun generateRandomPointInsidePolygon(polygon: List<LatLng>): LatLng? {
        var randomPoint: LatLng? = null

        if (polygon.isEmpty()) {
            return randomPoint
        }

        val bounds = LatLngBounds.Builder()
        for (point in polygon) {
            bounds.include(point)
        }
        val boundsArea = bounds.build()


        var isInside = false

        // 重試直到找到一個位於多邊形內的點
        while (!isInside) {
            // 在邊界範圍內生成隨機點
            val randomLat =
                boundsArea.southwest.latitude + Math.random() * (boundsArea.northeast.latitude - boundsArea.southwest.latitude)
            val randomLng =
                boundsArea.southwest.longitude + Math.random() * (boundsArea.northeast.longitude - boundsArea.southwest.longitude)
            randomPoint = LatLng(randomLat, randomLng)

            // 檢查點是否位於多邊形內
            isInside = PolyUtil.containsLocation(randomPoint, polygon, true)
        }

        return randomPoint
    }

    private fun isValidPolygon(points: List<LatLng>): Boolean {
        if (points.size < 3) return false

        // 計算多邊形的面積
        var area = 0.0
        val n = points.size

        for (i in 0 until n) {
            val j = (i + 1) % n
            area += points[i].latitude * points[j].longitude
            area -= points[j].latitude * points[i].longitude
        }

        area = abs(area) / 2.0

        // 如果面積大於一個很小的閾值，則認為多邊形有效
        val minArea = 1e-10 // 更寬鬆的閾值
        return area > minArea
    }

    private fun tapBtnDelete() {
        AlertDialog.Builder(this)
            .setTitle("移除記錄確認")
            .setMessage("是否要移除記錄？")
            .setPositiveButton("是") { dialog, which ->

                val dbHelper = SurveyingDBHelper(this)
                val deletedRows = dbHelper.deleteSurveyingData(id = RecordId.toInt())
                if (deletedRows > 0) {
                    println("刪除成功")
                } else {
                    println("刪除失敗，可能找不到對應的 ID")
                }
                dbHelper.close()
            }
            .setNegativeButton("否") { dialog, which ->
                // 取消刪除，不做任何操作
            }
            .show()
    }

    private fun tapBtnUpdate() {

        AlertDialog.Builder(this)
            .setTitle("更新確認")
            .setMessage("是否要更新？")
            .setPositiveButton("是") { dialog, which ->

                // 計算封閉區域面積（平方公尺）
                val areaSqm = SphericalUtil.computeArea(fieldCoordinates)
                // 換算為坪
                val areaPing = areaSqm * 0.3025
                // 換算為分地
                val areaFen = areaPing / 293.4

                // 初始化數據庫助手
                SurveyingDbHelper = SurveyingDBHelper(this)
                SurveyingDbHelper.updateSurveyingData(
                    id = RecordId.toInt(),
                    owner = etOwner.text.toString(),
                    location = etLocation.text.toString(),
                    coordinates = fieldCoordinates,
                    zoom = mMap.cameraPosition.zoom,
                    center = mMap.cameraPosition.target,
                    bearing = mMap.cameraPosition.bearing,
                    areaSqm = areaSqm,
                    areaPing = areaPing,
                    areaFen = areaFen
                )
                SurveyingDbHelper.close()

            }
            .setNegativeButton("否") { dialog, which ->
                // 取消刪除，不做任何操作
            }
            .show()
    }

    private fun tapBtnSave() {
        // 檢查輸入框是否為空
        if (etOwner.text.toString().isEmpty() || etLocation.text.toString().isEmpty()) {
            // 如果任一輸入框為空，顯示警告並返回
            Toast.makeText(this, "請填寫所有欄位", Toast.LENGTH_SHORT).show()
            return
        }


        AlertDialog.Builder(this)
            .setTitle("另存確認")
            .setMessage("是否要另存？")
            .setPositiveButton("是") { dialog, which ->


                owner = etOwner.text.toString()
                location = etLocation.text.toString()

                // 計算封閉區域面積（平方公尺）
                val areaSqm = SphericalUtil.computeArea(fieldCoordinates)
                // 換算為坪
                val areaPing = areaSqm * 0.3025
                // 換算為分地
                val areaFen = areaPing / 293.4

                val zoom = mMap.cameraPosition.zoom
                val center = mMap.cameraPosition.target
                val bearing = mMap.cameraPosition.bearing

                // 初始化數據庫助手
                SurveyingDbHelper = SurveyingDBHelper(this)

                val id = SurveyingDbHelper.insertSurveyingData(
                    fieldCoordinates,
                    owner,
                    location,
                    zoom,
                    center,
                    bearing,
                    areaSqm,
                    areaPing,
                    areaFen
                )
                if (id != -1L) {
                    Toast.makeText(this, "資料保存成功", Toast.LENGTH_SHORT).show()
                    Log.d(
                        "SaveData", """
                        SQL 指令：
                        INSERT INTO Surveying (coordinates, owner, location, created_at, zoom, center, bearing, area_sqm, area_ping, area_fen)
                        VALUES (
                            '${Gson().toJson(fieldCoordinates)}',
                            '$owner',
                            '$location',
                            '${System.currentTimeMillis()}',
                            $zoom,
                            '${Gson().toJson(center)}',
                            $bearing,
                            $areaSqm,
                            $areaPing,
                            $areaFen
                        )
                    """.trimIndent()
                    )
                } else {
                    Toast.makeText(this, "資料保存失敗", Toast.LENGTH_SHORT).show()
                }

                SurveyingDbHelper.close()

            }
            .setNegativeButton("否") { dialog, which ->
                // 取消刪除，不做任何操作
            }
            .show()

    }

    override fun onStart() {
        super.onStart()
        // 檢查網路連接
        if (!isNetworkAvailable(this)) {
            Toast.makeText(this, "無網路連接，請檢查網路設定", Toast.LENGTH_LONG).show()
            return
        }
    }

    @SuppressLint("Wakelock")
    override fun onDestroy() {
        super.onDestroy()

        if (wakeLock.isHeld) {
            wakeLock.release() // 釋放 WakeLock
        }

        stopSimulatingVehicleMovement()
        // Stop the server when activity is destroyed
        iotServer.stopServer()
    }

    // 顯示刪除確認對話框
    @SuppressLint("PotentialBehaviorOverride")
    private fun showDeleteConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("刪除確認")
            .setMessage("是否要刪除所有點？")
            .setPositiveButton("是") { dialog, which ->
                // 清空 fieldCoordinates
                fieldCoordinates.clear()
                // 清除地圖上的所有繪製內容
                mMap.clear()

                mMap.setOnMarkerClickListener(this) // 設置標示點點擊事件
                // 啟用地圖點擊事件
                mMap.setOnMapClickListener { latLng ->
                    addPoint(latLng)
                }

                // 進入繪制模式
                btnRemove.text = "完成"
                // 設置「完成」按鈕的點擊事件
                btnRemove.setOnClickListener {
                    mMap.setOnMapClickListener(null)
                    mMap.setOnMarkerClickListener(null)
                    completeDrawing()
                }
            }
            .setNegativeButton("否") { dialog, which ->
                // 取消刪除，不做任何操作
            }
            .show()
    }

    // 新增點
    private fun addPoint(latLng: LatLng) {
        // 在地圖上放置標示圖
        val marker =
            mMap.addMarker(MarkerOptions().position(latLng).title("N${fieldCoordinates.size + 1}"))
        marker?.let {
            fieldCoordinates.add(latLng)
            markers.add(it)
        }
    }

    // 完成繪制，將各點連線成封閉區
    private fun completeDrawing() {
        if (fieldCoordinates.size < 3) {
            Toast.makeText(this, "需要至少三個座標點來生成封閉區", Toast.LENGTH_SHORT).show()
            return
        }

        Log.d("completeDrawing", fieldCoordinates.toString())

        // 將各點連線成封閉區
        drawFieldBoundary()
        getAreaInfo()
        showDistance()

        // 恢復「刪除」按鈕的初始狀態
        btnRemove.text = "刪除"
        btnRemove.setOnClickListener {
            showDeleteConfirmationDialog()
        }
    }

    @SuppressLint("DefaultLocale")
    private fun showDistance() {
        var vehicleMarker: Marker? = null
        // 計算並顯示每一條線段的長度
        for (i in 0 until fieldCoordinates.size) {
            val startPoint = fieldCoordinates[i]
            val endPoint = fieldCoordinates[(i + 1) % fieldCoordinates.size] // 最後一個點連回第一個點

            // 計算線段長度
            val distance = SphericalUtil.computeDistanceBetween(startPoint, endPoint)
            Log.d("Distance", "線段 ${i + 1} 的長度: $distance 公尺")

            // 在線段中間添加標示文字
            val midPoint = LatLng(
                (startPoint.latitude + endPoint.latitude) / 2,
                (startPoint.longitude + endPoint.longitude) / 2
            )
            vehicleMarker = mMap.addMarker(
                MarkerOptions()
                    .position(midPoint)
                    .title("${String.format("%.2f", distance)} 公尺")
            )!!
            // 確保標記資訊視窗顯示
            vehicleMarker.showInfoWindow()
        }

    }


    // 檢查是否有網路連接
    private fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        // 針對 Android 10 及以上版本
        val network = connectivityManager.activeNetwork ?: return false
        val networkCapabilities =
            connectivityManager.getNetworkCapabilities(network) ?: return false

        return networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun loadSavedData() {
        // 從 SharedPreferences 載入數據
        val sharedPreferences = getSharedPreferences("VehicleData", MODE_PRIVATE)
        val vehicleWidth = sharedPreferences.getString("vehicleWidth", "2.0")
        val vehicleLength = sharedPreferences.getString("vehicleLength", "3.0")
        val pathOverlap = sharedPreferences.getString("pathOverlap", "0.3")

        // 設置輸入框的值
        edtVehicleWidth.setText(vehicleWidth)
        edtVehicleLength.setText(vehicleLength)
        edtPathOverlap.setText(pathOverlap)
    }

    private fun saveVehicleData() {
        // 獲取輸入框的值
        val vehicleWidth = edtVehicleWidth.text.toString()
        val vehicleLength = edtVehicleLength.text.toString()
        val pathOverlap = edtPathOverlap.text.toString()

        // 使用 SharedPreferences 保存數據
        val sharedPreferences = getSharedPreferences("VehicleData", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("vehicleWidth", vehicleWidth)
        editor.putString("vehicleLength", vehicleLength)
        editor.putString("pathOverlap", pathOverlap)
        editor.apply()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // 啟用縮放控件和指南針
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isCompassEnabled = true
        mMap.uiSettings.isRotateGesturesEnabled = true
        mMap.uiSettings.isZoomGesturesEnabled = true

        mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE

        // 繪製初始邊界
        drawFieldBoundary()
        getAreaInfo()
        showDistance()
    }

    @SuppressLint("DefaultLocale", "SetTextI18n")
    private fun getAreaInfo() {
        // 計算封閉區域面積（平方公尺）
        val areaSqm = SphericalUtil.computeArea(fieldCoordinates)
        // 換算為坪
        val areaPing = areaSqm * 0.3025
        // 換算為分地
        val areaFen = areaPing / 293.4
        tvAreaInfo.text = String.format("%.02f 平方公尺，", areaSqm) +
                String.format("%.04f 坪，", areaPing) + String.format("%.04f 分地", areaFen)

    }

    private fun loadRoutePoints() {
        try {
            val jsonArray = JSONArray(pointsJsonString)
            fieldCoordinates.clear()

            for (i in 0 until jsonArray.length()) {
                val point = jsonArray.getJSONObject(i)
                val latitude = point.getDouble("latitude")
                val longitude = point.getDouble("longitude")
                fieldCoordinates.add(LatLng(latitude, longitude))
            }

            // 保存到數據庫
            saveRoutePointsToDB()

        } catch (e: Exception) {
            Toast.makeText(this, "Error parsing route data: ${e.message}", Toast.LENGTH_SHORT)
                .show()
        }
    }

    private fun saveRoutePointsToDB() {

        SurveyingDbHelper = SurveyingDBHelper(this)
        val db = SurveyingDbHelper.writableDatabase

        // 清除現有點
        db.delete("route_points", null, null)

        // 插入新點
        for (point in fieldCoordinates) {
            val values = android.content.ContentValues().apply {
                put("latitude", point.latitude)
                put("longitude", point.longitude)
            }
            db.insert("route_points", null, values)
        }
        db.close()
    }

    private fun drawFieldBoundary() {
        if (fieldCoordinates.isEmpty() || !::mMap.isInitialized) return

        // 清除之前的邊界
        mMap.clear()

        // 創建多邊形選項
        val polygonOptions = PolygonOptions()
            .addAll(fieldCoordinates)
            .strokeColor(Color.RED)
            .strokeWidth(5f)
            .fillColor(Color.argb(30, 255, 0, 0))

        // 添加多邊形到地圖
        mMap.addPolygon(polygonOptions)

        if (actSerial < 1) {
            mMap.animateCamera(CameraUpdateFactory.zoomTo(zoom.toFloat()))
            val currentPosition = mMap.cameraPosition
            val newPosition = CameraPosition.Builder(currentPosition)
                .bearing(bearing.toFloat()) // 更新方向
                .build()
            mMap.moveCamera(CameraUpdateFactory.newCameraPosition(newPosition))
            // 將地圖中心對準邊界
            centerMapOnField()
        }
        actSerial++
    }

    private fun toggleMapMode() {
        if (isSatelliteMode) {
            // 切換到普通模式
            mMap.mapType = GoogleMap.MAP_TYPE_NORMAL
            isSatelliteMode = false
            Log.d("MapMode", "當前模式：普通模式")
        } else {
            // 切換到衛星模式
            mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
            isSatelliteMode = true
            Log.d("MapMode", "當前模式：衛星模式")
        }
    }

    private fun centerMapOnField() {
        if (fieldCoordinates.isEmpty()) return

        val boundsBuilder = LatLngBounds.Builder()
        for (point in fieldCoordinates) {
            boundsBuilder.include(point)
        }

        val bounds = boundsBuilder.build()
        val padding = 100 // 地圖邊緣的偏移量

        val cameraUpdate = CameraUpdateFactory.newLatLngBounds(bounds, padding)
        mMap.animateCamera(cameraUpdate)
    }

    private fun generateRoutePath() {
        if (fieldCoordinates.size < 3) {
            Toast.makeText(this, "需要至少三個座標點來生成路徑", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val vehicleWidth = edtVehicleWidth.text.toString().toFloat()
            val vehicleLength = edtVehicleLength.text.toString().toFloat()
            val pathOverlap = edtPathOverlap.text.toString().toFloat()

            // 使用平行路徑生成方法
            generatedPaths = PathParallel.generateParallelPath(
                fieldCoordinates,
                vehicleWidth,
                pathOverlap,
                stepNum++
            )

            // 繪製路徑
            drawGeneratedPaths()

        } catch (e: Exception) {
            Toast.makeText(this, "生成路徑時發生錯誤: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun generateTurbinePath() {
        if (fieldCoordinates.size < 3) {
            Toast.makeText(this, "需要至少三個座標點來生成路徑", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val vehicleWidth = edtVehicleWidth.text.toString().toFloat()
            val vehicleLength = edtVehicleLength.text.toString().toFloat()
            val pathOverlap = edtPathOverlap.text.toString().toFloat()

            // 使用渦輪路徑生成方法
            generatedPaths =
                PathTurbine.generateSpiralPath(fieldCoordinates, vehicleWidth, pathOverlap)

            // 繪製路徑
            drawGeneratedPaths()

        } catch (e: Exception) {
            Toast.makeText(this, "生成路徑時發生錯誤: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun drawGeneratedPaths() {
        // 清除之前的路徑（保留邊界）
        mMap.clear()
        drawFieldBoundary()

        // 繪製每條生成的路徑
        for (i in generatedPaths.indices) {
            val path = generatedPaths[i]

            Log.d("路徑 $i", path.toString())

            // 創建折線選項
            val polylineOptions = PolylineOptions()
                .addAll(path)
                .width(5f)
                .color(Color.HSVToColor(floatArrayOf(i * 120f / generatedPaths.size, 1f, 1f)))
                .geodesic(true)

            // 添加折線到地圖
            mMap.addPolyline(polylineOptions)

            // 連接最後一個點到第一個點以閉合路徑
            if (path.size > 0) {
                val closingLine = PolylineOptions()
                    .add(path.last())
                    .add(path.first())
                    .width(5f)
                    .color(Color.HSVToColor(floatArrayOf(i * 120f / generatedPaths.size, 1f, 1f)))
                    .geodesic(true)

                mMap.addPolyline(closingLine)
            }
        }
    }

    private fun clearGeneratedPaths() {
        generatedPaths.clear()
        // 重新繪製邊界
        mMap.clear()
        drawFieldBoundary()
        Toast.makeText(this, "已清除生成的路徑", Toast.LENGTH_SHORT).show()
    }

    override fun onCameraMove() {
        TODO("Not yet implemented")
    }

    override fun onMarkerClick(p0: Marker): Boolean {
        TODO("Not yet implemented")
    }

    override fun onServerStarted() {
        Log.d(TAG, "Server started successfully")
        val ipAddress = getLocalIpAddress()
        val port = 8080
        val serverUrl = "http://$ipAddress:$port"
        Log.d(TAG, "Server started successfully")
        Log.d(TAG, "Server accessible at: $serverUrl")
        Toast.makeText(this, serverUrl, Toast.LENGTH_LONG).show()
    }

    override fun onServerStopped() {
        Log.d(TAG, "Server stopped successfully")
    }

    private fun playBeepSound() {
        var mediaPlayer: MediaPlayer? = null
        mediaPlayer = MediaPlayer().apply {
            try {
                // Open the audio file from the assets folder
                val assetFileDescriptor = assets.openFd("beep.mp3")
                setDataSource(assetFileDescriptor.fileDescriptor, assetFileDescriptor.startOffset, assetFileDescriptor.length)
                assetFileDescriptor.close()

                // Prepare and start playing
                prepare()
                start()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    override fun onRequestReceived(
        endpoint: String,
        params: Map<String, List<String>>
    ): NanoHTTPD.Response? {
        Log.d(TAG, "Request received: $endpoint with params $params")

        playBeepSound()

        // 模擬 IOT 地址數據
        val iotAddress = JSONObject().apply {
            put("t", JSONArray().apply {
                put(37.42366251669061)
                put(-122.08376781182147)
            })
        }

        // 返回 IOT 地址
        return NanoHTTPD.newFixedLengthResponse(
            NanoHTTPD.Response.Status.OK,
            "application/json",
            iotAddress.toString()
        )
    }

    override fun onPathRequested(pathNumber: Int?): NanoHTTPD.Response? {
        Log.d(TAG, "Path requested: $pathNumber")

        playBeepSound()

        // 隨機決定返回單一路徑、渦輪路徑還是路徑空了
        val pathType = when ((0..2).random()) { // 0: 單一路徑, 1: 渦輪路徑, 2: 路徑空了
            0 -> "single"
            1 -> "turbo"
            else -> "empty"
        }

        return when (pathType) {
            "single" -> {
                // 單一路徑：返回 1 組地圖座標
                val singlePath = listOf(
                    Pair(37.423425211967405, -122.08333255235378),
                    Pair(37.42411736263989, -122.08337593406257)
                )
                val correctedSinglePath = applyOffsetToPath(singlePath) // 應用補正量
                Log.d(TAG, "Sending single path: $correctedSinglePath")
                createPathResponse(correctedSinglePath)
            }

            "turbo" -> {
                // 渦輪路徑：返回 N 組地圖座標（N < 20）
                val turboPath = listOf(
                    Pair(37.423926889366534, -122.08403328799443),
                    Pair(37.42387767528559, -122.08382060787993),
                    Pair(37.42375582233595, -122.0836907757062),
                    Pair(37.423816404387075, -122.0839660559987)
                )
                val correctedTurboPath = applyOffsetToPath(turboPath) // 應用補正量
                Log.d(TAG, "Sending turbo path: $correctedTurboPath")
                createPathResponse(correctedTurboPath)
            }

            else -> {
                // 路徑空了：返回 json-finish
                Log.d(TAG, "No more paths")
                NanoHTTPD.newFixedLengthResponse(
                    NanoHTTPD.Response.Status.OK,
                    "application/json",
                    JSONObject().apply {
                        put("s", JSONArray().apply {
                            put(0)
                            put(0)
                        })
                    }.toString()
                )
            }
        }
    }

    // 將補正量應用到路徑集合
    private fun applyOffsetToPath(path: List<Pair<Double, Double>>): List<Pair<Double, Double>> {
        return path.map { (latitude, longitude) ->
            Pair(latitude - latitudeOffset, longitude - longitudeOffset)
        }
    }

    // 創建路徑回應
    private fun createPathResponse(coordinates: List<Pair<Double, Double>>): NanoHTTPD.Response {
        val jsonArray = JSONArray().apply {
            for ((lat, lng) in coordinates) {
                put(JSONArray().apply {
                    put(lat)
                    put(lng)
                })
            }
        }

        val responseJson = JSONObject().apply {
            put("s", jsonArray)
        }

        return NanoHTTPD.newFixedLengthResponse(
            NanoHTTPD.Response.Status.OK,
            "application/json",
            responseJson.toString()
        )
    }

    // Add this helper method to get the device's local IP address
    private fun getLocalIpAddress(): String? {
        try {
            val networkInterfaces = java.net.NetworkInterface.getNetworkInterfaces()
            while (networkInterfaces.hasMoreElements()) {
                val networkInterface = networkInterfaces.nextElement()
                val inetAddresses = networkInterface.inetAddresses
                while (inetAddresses.hasMoreElements()) {
                    val address = inetAddresses.nextElement()
                    // Filter IPv4 addresses that are not loopback
                    if (!address.isLoopbackAddress && address is java.net.Inet4Address) {
                        return address.hostAddress
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting IP address: ${e.message}")
        }
        return "127.0.0.1" // Default to localhost if unable to determine IP
    }
}