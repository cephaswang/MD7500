package tw.ibiz.gpsinfo

import com.google.android.gms.maps.model.LatLng
import kotlin.math.max
import kotlin.math.min

object PathParallel {

    // 定義一個點類
    data class Point(val x: Double, val y: Double)

    // 定義一個線段類
    data class Line(val p1: Point, val p2: Point)

    /**
     * 生成平行路徑
     *
     * @param boundaryPoints 多邊形邊界點
     * @param vehicleWidth 車輛寬度（單位：米）
     * @param pathOverlap 路徑重疊比例（0.0 ~ 1.0）
     * @param stepNum 當前步驟（用於選擇邊界線）
     * @return 生成的平行路徑列表
     */
    fun generateParallelPath(
        boundaryPoints: ArrayList<LatLng>,
        vehicleWidth: Float,
        pathOverlap: Float,
        stepNum: Int
    ): ArrayList<ArrayList<LatLng>> {
        val parallelPaths = ArrayList<ArrayList<LatLng>>()
        val metersToDegreesLat = 1.0 / 111111.0
        if (boundaryPoints.size < 2) {
            return parallelPaths
        }

        // 計算封閉區域的寬度（最大偏移量）
        val maxOffset = calculateMaxOffset(boundaryPoints)
        val numLines = ((maxOffset / vehicleWidth) + 1).toInt() * 100 // 計算需要的平行線數量

        val p1 = boundaryPoints[stepNum % boundaryPoints.size]
        val p2 = boundaryPoints[(stepNum + 1) % boundaryPoints.size]
        val direction = Math.atan2(p2.longitude - p1.longitude, p2.latitude - p1.latitude)

        for (i in 0 until numLines) {
            val offset = i * vehicleWidth * metersToDegreesLat
            val overlap = pathOverlap * metersToDegreesLat
            val perpendicularDirection = direction + Math.PI / 2
            val offsetX = offset * Math.cos(perpendicularDirection)
            val offsetY = offset * Math.sin(perpendicularDirection)

            val overlapX = overlap * Math.cos(direction)
            val overlapY = overlap * Math.sin(direction)

            val startPoint =
                LatLng(p1.latitude + offsetX - overlapX, p1.longitude + offsetY - overlapY)
            val endPoint =
                LatLng(p2.latitude + offsetX + overlapX, p2.longitude + offsetY + overlapY)

            var parallelPath = ArrayList<LatLng>()
            parallelPath.add(startPoint)
            parallelPath.add(endPoint)

            val intersections: Pair<LatLng, LatLng> =
                findPolygonIntersections(boundaryPoints, parallelPath)

            if (intersections.first.latitude > 0.0) {
                parallelPath = ArrayList<LatLng>()
                parallelPath.add(intersections.first)
                parallelPath.add(intersections.second)
                parallelPaths.add(parallelPath)
            }
        }

        return parallelPaths
    }

    /**
     * 計算封閉區域的最大偏移量（平行線的最大寬度）
     */
    private fun calculateMaxOffset(boundaryPoints: ArrayList<LatLng>): Float {
        val center = calculatePolygonCenter(boundaryPoints)
        var maxDistance = 0f

        for (point in boundaryPoints) {
            val distance = calculateDistance(center, point)
            if (distance > maxDistance) {
                maxDistance = distance
            }
        }

        return maxDistance
    }

    /**
     * 計算兩個點之間的距離
     */
    private fun calculateDistance(p1: LatLng, p2: LatLng): Float {
        val lat1 = p1.latitude
        val lon1 = p1.longitude
        val lat2 = p2.latitude
        val lon2 = p2.longitude

        val radius = 6371000 // 地球半徑（單位：米）
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)

        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)

        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        return (radius * c).toFloat()
    }

    /**
     * 計算多邊形的中心點
     */
    private fun calculatePolygonCenter(points: List<LatLng>): LatLng {
        var x = 0.0
        var y = 0.0
        for (point in points) {
            x += point.latitude
            y += point.longitude
        }
        return LatLng(x / points.size, y / points.size)
    }

    /**
     * 找到直線與多邊形的交點
     */
    private fun findPolygonIntersections(
        fieldCoordinates: ArrayList<LatLng>,
        parallelPath: ArrayList<LatLng>
    ): Pair<LatLng, LatLng> {
        val intersections = ArrayList<LatLng>()

        // 將平行路徑轉換為線段
        val parallelLine = Line(
            Point(parallelPath[0].latitude, parallelPath[0].longitude),
            Point(parallelPath[1].latitude, parallelPath[1].longitude)
        )

        // 遍歷多邊形的每一條邊
        for (i in 0 until fieldCoordinates.size) {
            val j = (i + 1) % fieldCoordinates.size
            val polygonLine = Line(
                Point(fieldCoordinates[i].latitude, fieldCoordinates[i].longitude),
                Point(fieldCoordinates[j].latitude, fieldCoordinates[j].longitude)
            )

            // 計算交點
            val intersection = findIntersection(parallelLine, polygonLine)
            if (intersection != null && isPointOnSegment(polygonLine, intersection)) {
                intersections.add(LatLng(intersection.x, intersection.y))
            }
        }

        // 如果找到兩個交點，返回它們
        if (intersections.size == 2) {
            return Pair(intersections[0], intersections[1])
        }

        // 否則返回 (0, 0)
        return Pair(LatLng(0.0, 0.0), LatLng(0.0, 0.0))
    }

    /**
     * 計算兩條線段的交點
     */
    private fun findIntersection(line1: Line, line2: Line): Point? {
        val a1 = line1.p2.y - line1.p1.y
        val b1 = line1.p1.x - line1.p2.x
        val c1 = a1 * line1.p1.x + b1 * line1.p1.y

        val a2 = line2.p2.y - line2.p1.y
        val b2 = line2.p1.x - line2.p2.x
        val c2 = a2 * line2.p1.x + b2 * line2.p1.y

        val determinant = a1 * b2 - a2 * b1

        if (determinant == 0.0) {
            return null // 平行或重合，沒有交點
        } else {
            val x = (b2 * c1 - b1 * c2) / determinant
            val y = (a1 * c2 - a2 * c1) / determinant
            return Point(x, y)
        }
    }

    /**
     * 檢查點是否在線段上
     */
    private fun isPointOnSegment(line: Line, point: Point): Boolean {
        val minX = min(line.p1.x, line.p2.x)
        val maxX = max(line.p1.x, line.p2.x)
        val minY = min(line.p1.y, line.p2.y)
        val maxY = max(line.p1.y, line.p2.y)

        return (point.x in minX..maxX) && (point.y in minY..maxY)
    }
}