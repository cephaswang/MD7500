package tw.ibiz.gpsinfo

import android.content.Context
import android.util.Log
import fi.iki.elonen.NanoHTTPD
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/*
使用端口轉發（最常用）：
Android模擬器提供了端口轉發功能，將主機端口映射到模擬器端口：

adb forward tcp:8080 tcp:8080

執行這個命令後，您就可以在電腦瀏覽器中通過 http://localhost:8080 訪問模擬器中的伺服器。
*/

class IotServer(private val context: Context) : NanoHTTPD("0.0.0.0", 8080) {
    private val TAG = "IotServer"

    // Define JSON response templates
    private val jsonOk = JSONObject().apply {
        put("s", "ok")
    }

    private val jsonNext = JSONObject().apply {
        put("s", JSONArray().apply {
            put(157.12)
            put(201)
        })
    }

    private val jsonFinish = JSONObject().apply {
        put("s", JSONArray().apply {
            put(0)
            put(0)
        })
    }

    private val jsonError = JSONObject().apply {
        put("s", "error")
    }

    // Callback interface for server events
    interface ServerEventCallback {
        fun onServerStarted()
        fun onServerStopped()
        fun onRequestReceived(endpoint: String, params: Map<String, List<String>>): Response?
        fun onPathRequested(pathNumber: Int?): Response?
    }

    private var callback: ServerEventCallback? = null

    fun setEventCallback(callback: ServerEventCallback) {
        this.callback = callback
    }

    fun startServer() {
        try {
            start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
            Log.d(TAG, "Server started on port 8080")
            callback?.onServerStarted()
        } catch (e: IOException) {
            Log.e(TAG, "Failed to start server: ${e.message}")
        }
    }

    fun stopServer() {
        stop()
        Log.d(TAG, "Server stopped")
        callback?.onServerStopped()
    }

    override fun serve(session: IHTTPSession): Response {
        try {
            val uri = session.uri
            val method = session.method
            val params = session.parameters

            Log.d(TAG, "Received request: $method $uri")

            if (method == Method.GET) {
                when {
                    uri.contains("info") -> {
                        // 接收物聯網 GET ?info
                        return callback?.onRequestReceived(uri, params)
                            ?: newFixedLengthResponse(Response.Status.OK, "application/json", jsonOk.toString())
                    }
                    uri.contains("path") -> {
                        // 接收物聯網 GET ?path
                        val pathNumber = params["p"]?.firstOrNull()?.toIntOrNull() // 獲取路徑編號
                        Log.d(TAG, "Requested path number: $pathNumber")

                        return callback?.onPathRequested(pathNumber)
                            ?: newFixedLengthResponse(Response.Status.OK, "application/json", jsonFinish.toString())
                    }
                    else -> {
                        // 接收失敗
                        Log.e(TAG, "Request failed: Unknown URI")
                        return newFixedLengthResponse(Response.Status.BAD_REQUEST, "application/json", jsonError.toString())
                    }
                }
            }

            // 接收失敗 - 不支援的方法
            Log.e(TAG, "Request failed: Unsupported method")
            return newFixedLengthResponse(Response.Status.METHOD_NOT_ALLOWED, "application/json", jsonError.toString())

        } catch (e: Exception) {
            // 接收失敗 - 發生異常
            Log.e(TAG, "Request failed: ${e.message}")
            return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "application/json", jsonError.toString())
        }
    }
}