package tw.ibiz.gpsinfo

/*
https://www.youtube.com/watch?v=xXuL3IwFTbA
GPS Guided Autonomous Rover
*/


import android.util.Log
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import kotlin.math.abs
import kotlin.concurrent.thread // 確保導入這個包

/*
請編寫，修正方向，Android kotlin 檔名 differentialDrive_steeringWheel
package tw.ibiz.gpsinfo 寫到 UDP 輸出為控制方向盤電機，正轉，反轉，轉速 PWM

https://www.youtube.com/watch?v=xXuL3IwFTbA
GPS Guided Autonomous Rover

*/

class DifferentialDrive {
    private val TAG = "DifferentialDrive"
    private val UDP_IP = "192.168.1.100" // 目標設備的 IP 地址，需根據實際情況修改
    private val UDP_PORT = 12345 // UDP 目標端口，需與接收端匹配
    private val REST_SPEED = 1500f // 停止時的 PWM 值（中立點）
    private val MAX_SPEED_RANGE = 200f // 最大速度範圍（類似 Arduino 的 driveSpeed）

    // 計算並傳送差速驅動數據
    fun correctDirection(steeringAngle: Float, driveSpeed: Float) {
        // steeringAngle 應為 -180 到 180 度
        // driveSpeed 為基本行駛速度（類似 Arduino 的 0-200 範圍）
        var leftSpeed = REST_SPEED + driveSpeed // 預設前進速度
        var rightSpeed = REST_SPEED - driveSpeed // 預設前進速度（右輪反向）

        when {
            steeringAngle < 0 -> { // 左轉
                leftSpeed -= map(abs(steeringAngle), 0f, 180f, 0f, MAX_SPEED_RANGE)
            }
            steeringAngle > 0 -> { // 右轉
                rightSpeed += map(abs(steeringAngle), 0f, 180f, 0f, MAX_SPEED_RANGE)
            }
        }

        // 限制速度範圍（模擬 PWM 1000-2000）
        leftSpeed = leftSpeed.coerceIn(1000f, 2000f)
        rightSpeed = rightSpeed.coerceIn(1000f, 2000f)

        Log.d(TAG, "左輪速度: $leftSpeed, 右輪速度: $rightSpeed")

        // 透過 UDP 傳送速度數據
        sendToUdp(leftSpeed, rightSpeed)
    }

    // 停止驅動
    fun stopDrive() {
        val leftSpeed = REST_SPEED
        val rightSpeed = REST_SPEED
        Log.d(TAG, "停止驅動 - 左輪: $leftSpeed, 右輪: $rightSpeed")
        sendToUdp(leftSpeed, rightSpeed)
    }

    // 將速度數據透過 UDP 傳送
    private fun sendToUdp(leftSpeed: Float, rightSpeed: Float) {
        thread(start = true) {
            try {
                val socket = DatagramSocket()
                val inetAddress = InetAddress.getByName(UDP_IP)
                val message = "DRIVE,$leftSpeed,$rightSpeed" // 定義簡單的數據格式
                val buffer = message.toByteArray()
                val packet = DatagramPacket(buffer, buffer.size, inetAddress, UDP_PORT)

                socket.send(packet)
                Log.d(TAG, "UDP 傳送: $message 到 $UDP_IP:$UDP_PORT")
                socket.close()
            } catch (e: Exception) {
                Log.e(TAG, "UDP 傳送錯誤: ${e.message}")
            }
        }
    }

    // 映射函數，類似 Arduino 的 mapf
    private fun map(value: Float, inMin: Float, inMax: Float, outMin: Float, outMax: Float): Float {
        return (value - inMin) * (outMax - outMin) / (inMax - inMin) + outMin
    }
}

// 使用範例（可在 Activity 或 Fragment 中調用）
/*
class MainActivity : AppCompatActivity() {
    private lateinit var differentialDrive: DifferentialDrive

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        differentialDrive = DifferentialDrive()

        // 測試方向修正
        differentialDrive.correctDirection(steeringAngle = -30f, driveSpeed = 200f) // 左轉 30 度
        Handler(Looper.getMainLooper()).postDelayed({
            differentialDrive.correctDirection(steeringAngle = 45f, driveSpeed = 200f) // 右轉 45 度
        }, 2000)
        Handler(Looper.getMainLooper()).postDelayed({
            differentialDrive.stopDrive() // 停止
        }, 4000)
    }
}
*/