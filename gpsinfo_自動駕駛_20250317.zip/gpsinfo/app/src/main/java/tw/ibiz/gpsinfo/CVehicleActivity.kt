package tw.ibiz.gpsinfo

/*
package tw.ibiz.gpsinfo


android kotlin
sqlite SurveyingDBHelper
const val DATABASE_NAME = "gpsinfo"
const val TABLE_CVEHICLE = "CVehicle"

Grok 生成源碼

數據庫 DATABASE_NAME
資料表 TABLE_CVEHICLE
欄位
流水號
名稱
轉彎半徑(米)
軸距(米)
寬度


CVehicleActivity
生成程式碼
線性佈局，文件 xml
findViewById
標題∶車輛管理，美美標題列

車輛列表，單雙列，加強識別的，不同底色，點選的列，呈現選取底色
列表欄位名稱
列表
有五個欄位
流水號
名稱 text
轉彎半徑(米) float
軸距(米) float
寬度 float

列表下方，帶入點選的車輛各欄位，在編輯框中(美美底色)，編輯框左邊是欄位名稱，美美欄位UI
名稱
轉彎半徑(米)
軸距(米)
寬度

按鍵，保存，事件，保存記錄，並刷新列表。
按鍵，刪除，事件，警告，是否要刪除記錄，若是，則刪除該筆記錄，並清空編輯框的值，並刷新列表。
按鍵，另存，事件，警告，是否要另存記錄，若是，新增一筆記錄，並刷新列表。
*/

import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class CVehicleActivity : AppCompatActivity() {
    private lateinit var dbHelper: SurveyingDBHelper
    private lateinit var adapter: VehicleAdapter
    private var selectedVehicle: Vehicle? = null

    private lateinit var vehicleList: ListView
    private lateinit var editName: EditText
    private lateinit var editTurningRadius: EditText
    private lateinit var editWheelbase: EditText
    private lateinit var editWidth: EditText
    private lateinit var btnSave: Button
    private lateinit var btnDelete: Button
    private lateinit var btnSaveAs: Button
    private lateinit var titleText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cvehicle)

        // 使用 findViewById 初始化視圖
        titleText = findViewById(R.id.titleText)
        vehicleList = findViewById(R.id.vehicleList)
        editName = findViewById(R.id.editName)
        editTurningRadius = findViewById(R.id.editTurningRadius)
        editWheelbase = findViewById(R.id.editWheelbase)
        editWidth = findViewById(R.id.editWidth)
        btnSave = findViewById(R.id.btnSave)
        btnDelete = findViewById(R.id.btnDelete)
        btnSaveAs = findViewById(R.id.btnSaveAs)

        dbHelper = SurveyingDBHelper(this)
        val updatedVehicles = dbHelper.getAllVehicles()
        btnSaveAs.text = "新增"

        adapter = VehicleAdapter(updatedVehicles)
        vehicleList.adapter = adapter

        vehicleList.setOnItemClickListener { _, _, position, _ ->
            selectedVehicle = adapter.getItem(position)
            selectedVehicle?.let { vehicle ->
                btnSave.visibility = View.VISIBLE
                btnDelete.visibility = View.VISIBLE
                btnSaveAs.text = "另存"

                editName.setText(vehicle.name)
                editTurningRadius.setText(vehicle.turningRadius.toString())
                editWheelbase.setText(vehicle.wheelbase.toString())
                editWidth.setText(vehicle.width.toString())
                adapter.notifyDataSetChanged() // 刷新列表以更新選取底色
            }
        }

        btnSave.setOnClickListener { saveVehicle() }
        btnDelete.setOnClickListener { deleteVehicle() }
        btnSaveAs.setOnClickListener { saveAsVehicle() }

        btnSave.visibility = View.INVISIBLE
        btnDelete.visibility = View.INVISIBLE
    }

    private fun saveVehicle() {
        selectedVehicle?.let { vehicle ->
            val name = editName.text.toString()
            val turningRadius = editTurningRadius.text.toString().toFloatOrNull() ?: return
            val wheelbase = editWheelbase.text.toString().toFloatOrNull() ?: return
            val width = editWidth.text.toString().toFloatOrNull() ?: return

            val rowsAffected =
                dbHelper.updateVehicle(vehicle.id, name, turningRadius, wheelbase, width)
            Log.d("CVehicleActivity", "保存: 影響的行數 = $rowsAffected")
            refreshList()
        } ?: run {
            Log.w("CVehicleActivity", "未選擇車輛進行保存")
        }
    }

    private fun deleteVehicle() {
        selectedVehicle?.let { vehicle ->
            AlertDialog.Builder(this)
                .setMessage("是否要刪除此記錄？")
                .setPositiveButton("是") { _, _ ->
                    val rowsDeleted = dbHelper.deleteVehicle(vehicle.id)
                    Log.d("CVehicleActivity", "刪除: 刪除的行數 = $rowsDeleted")
                    clearFields()
                    refreshList()
                }
                .setNegativeButton("否", null)
                .show()
        } ?: run {
            Log.w("CVehicleActivity", "未選擇車輛進行刪除")
        }
    }

    private fun saveAsVehicle() {
        AlertDialog.Builder(this)
            .setMessage("是否要另存此記錄？")
            .setPositiveButton("是") { _, _ ->
                val name = editName.text.toString()
                val turningRadius =
                    editTurningRadius.text.toString().toFloatOrNull() ?: return@setPositiveButton
                val wheelbase =
                    editWheelbase.text.toString().toFloatOrNull() ?: return@setPositiveButton
                val width = editWidth.text.toString().toFloatOrNull() ?: return@setPositiveButton

                val newId = dbHelper.insertVehicle(name, turningRadius, wheelbase, width)
                Log.d("CVehicleActivity", "另存: 新增的ID = $newId")
                refreshList()
            }
            .setNegativeButton("否", null)
            .show()
    }

    private fun refreshList() {
        val updatedVehicles = dbHelper.getAllVehicles()
        Log.d("CVehicleActivity", "刷新列表，車輛數量: ${updatedVehicles.size}")
        adapter.clear()
        adapter.addAll(updatedVehicles)
        adapter.notifyDataSetChanged()
        vehicleList.invalidate()

        // btnSaveAs.text = if (updatedVehicles.isEmpty()) "新增" else "另存"
    }

    private fun clearFields() {
        editName.text.clear()
        editTurningRadius.text.clear()
        editWheelbase.text.clear()
        editWidth.text.clear()
        selectedVehicle = null
    }

    inner class VehicleAdapter(vehicles: List<Vehicle>) :
        ArrayAdapter<Vehicle>(this, R.layout.vehicle_list_item, vehicles) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val view =
                convertView ?: layoutInflater.inflate(R.layout.vehicle_list_item, parent, false)
            val vehicle = getItem(position)!!

            view.findViewById<TextView>(R.id.txtId).text = vehicle.id.toString()
            view.findViewById<TextView>(R.id.txtName).text = vehicle.name
            view.findViewById<TextView>(R.id.txtTurningRadius).text =
                vehicle.turningRadius.toString()
            view.findViewById<TextView>(R.id.txtWheelbase).text = vehicle.wheelbase.toString()
            view.findViewById<TextView>(R.id.txtWidth).text = vehicle.width.toString()

            // 加強單雙列識別度的底色
            val backgroundColor = when {
                selectedVehicle?.id == vehicle.id -> 0xFFB2EBF2.toInt() // 選取底色：青色 (Cyan 100)
                position % 2 == 0 -> 0xFFE0E0E0.toInt() // 單數列：較深的灰色
                else -> 0xFFFFFFFF.toInt() // 雙數列：白色
            }
            view.setBackgroundColor(backgroundColor)

            return view
        }
    }
}