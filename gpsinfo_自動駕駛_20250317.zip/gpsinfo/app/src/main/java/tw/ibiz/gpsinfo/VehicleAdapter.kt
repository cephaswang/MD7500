package tw.ibiz.gpsinfo

class VehicleAdapter {
}