// PathParallel.kt
package `0309`

import com.google.android.gms.maps.model.LatLng
import java.lang.Math.toDegrees
import kotlin.math.*

object PathParallel {

    private fun toRadians(degrees: Double): Double {
        return degrees * Math.PI / 180.0
    }

    fun generateParallelPath(
        boundaryPoints: ArrayList<LatLng>,
        vehicleWidth: Float,
        pathOverlap: Float,
        stepNum: Int
    ): ArrayList<ArrayList<LatLng>> {
        val paths = ArrayList<ArrayList<LatLng>>()
        val effectiveWidth = vehicleWidth - pathOverlap
        val metersToDegreesLat = 1.0 / 111111.0 // 每米對應的緯度度數
        val effectiveWidthDegrees = effectiveWidth * metersToDegreesLat

        // 計算第 1 點和第 2 點的方向（基準方向）
        val p1 = boundaryPoints[stepNum % boundaryPoints.size]
        val p2 = boundaryPoints[(stepNum + 1) % boundaryPoints.size]
        val bearing = calculateBearing(p1, p2)

        // 將所有點旋轉，使基準邊線與水平方向對齊（bearing 變為 0）
        val rotatedPoints = rotatePoints(boundaryPoints, -bearing, p1)

        // 計算旋轉後的邊界範圍
        val bounds = calculateBounds(rotatedPoints)
        val minLat = bounds.first.latitude
        val maxLat = bounds.second.latitude
        val minLng = bounds.first.longitude
        val maxLng = bounds.second.longitude

        // 從上到下生成水平掃描線
        var currentLat = maxLat
        while (currentLat >= minLat) {
            val path = ArrayList<LatLng>()
            val intersections = getIntersectionsWithLatitude(rotatedPoints, currentLat)

            if (intersections.size >= 2) {
                // 按經度排序交點
                intersections.sortBy { it.longitude }
                // 每兩個交點形成一段路徑
                for (i in 0 until intersections.size - 1 step 2) {
                    path.add(intersections[i])
                    path.add(intersections[i + 1])
                }
            }

            if (path.isNotEmpty()) {
                // 將旋轉後的路徑點反向旋轉回原始坐標系
                val originalPath = rotatePoints(path, bearing, p1)
                paths.add(originalPath)
            }

            currentLat -= effectiveWidthDegrees
        }

        return paths
    }

    private fun calculateBearing(p1: LatLng, p2: LatLng): Double {
        val deltaLng = toRadians(p2.longitude - p1.longitude)
        val lat1 = toRadians(p1.latitude)
        val lat2 = toRadians(p2.latitude)

        val y = sin(deltaLng) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(deltaLng)
        val bearingRad = atan2(y, x)

        return (toDegrees(bearingRad) + 360) % 360 // 轉換為度數並規範化到 0-360
    }

    private fun rotatePoints(
        points: ArrayList<LatLng>,
        angle: Double,
        pivot: LatLng
    ): ArrayList<LatLng> {
        val rotatedPoints = ArrayList<LatLng>()
        val angleRad = toRadians(angle)
        val cosTheta = cos(angleRad)
        val sinTheta = sin(angleRad)

        for (point in points) {
            // 將點移到以 pivot 為原點的坐標系
            val dx = (point.longitude - pivot.longitude) * cos(toRadians(pivot.latitude)) * 111111.0
            val dy = (point.latitude - pivot.latitude) * 111111.0

            // 旋轉
            val newDx = dx * cosTheta - dy * sinTheta
            val newDy = dx * sinTheta + dy * cosTheta

            // 轉換回經緯度並移回原始坐標系
            val newLng = pivot.longitude + (newDx / (111111.0 * cos(toRadians(pivot.latitude))))
            val newLat = pivot.latitude + (newDy / 111111.0)

            rotatedPoints.add(LatLng(newLat, newLng))
        }

        return rotatedPoints
    }

    private fun calculateBounds(points: ArrayList<LatLng>): Pair<LatLng, LatLng> {
        var minLat = points[0].latitude
        var maxLat = points[0].latitude
        var minLng = points[0].longitude
        var maxLng = points[0].longitude

        for (point in points) {
            minLat = minOf(minLat, point.latitude)
            maxLat = maxOf(maxLat, point.latitude)
            minLng = minOf(minLng, point.longitude)
            maxLng = maxOf(maxLng, point.longitude)
        }

        return Pair(LatLng(minLat, minLng), LatLng(maxLat, maxLng))
    }

    private fun getIntersectionsWithLatitude(
        points: ArrayList<LatLng>,
        latitude: Double
    ): ArrayList<LatLng> {
        val intersections = ArrayList<LatLng>()
        val n = points.size

        for (i in 0 until n) {
            val p1 = points[i]
            val p2 = points[(i + 1) % n]

            // 檢查線段是否跨越給定緯度
            val minLat = minOf(p1.latitude, p2.latitude)
            val maxLat = maxOf(p1.latitude, p2.latitude)

            if (latitude in minLat..maxLat && minLat != maxLat) {
                // 計算交點的經度（線性插值）
                val t = (latitude - p1.latitude) / (p2.latitude - p1.latitude)
                val intersectLng = p1.longitude + t * (p2.longitude - p1.longitude)
                intersections.add(LatLng(latitude, intersectLng))
            }
        }

        return intersections
    }
}