#include <HardwareSerial.h>

// 以下是 ESP32-C6 作為移動站的程式碼，接收基站的 RTCM 數據並進行高精度定位。

HardwareSerial gnssSerial(1); // 使用 UART1

void setup() {
    // 初始化串口
    Serial.begin(115200);
    gnssSerial.begin(9600, SERIAL_8N1, 8, 9); // 設置 UART1 (GPIO8=TX, GPIO9=RX)

    // 配置 LC29H (BA) 為移動站模式
    configureRoverStation();
}

void loop() {
    // 讀取 LC29H (BA) 的定位數據並輸出
    while (gnssSerial.available()) {
        char data = gnssSerial.read();
        Serial.write(data); // 將定位數據輸出到串口監視器
    }
}

void configureRoverStation() {
    // 發送 UBX 指令配置 LC29H (BA) 為移動站模式
    const uint8_t ubxConfig[] = {
            0xB5, 0x62, 0x06, 0x01, 0x08, 0x00, 0xF0, 0x05, 0x01, 0x00, 0x00, 0x00, 0x00, 0x01, 0x06, 0x48
    };
    gnssSerial.write(ubxConfig, sizeof(ubxConfig));
    Serial.println("LC29H configured as Rover Station.");
}