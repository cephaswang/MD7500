#include "rover.h"
#include "esp_wifi.h"
#include "esp_websocket_client.h"
#include "lwip/sockets.h"
#include "driver/uart.h"

static void ws_event_handler(void *handler_args, esp_event_base_t base, int32_t event_id, void *event_data) {
    esp_websocket_event_data_t *data = (esp_websocket_event_data_t *)event_data;
    if (event_id == WEBSOCKET_EVENT_DATA) {
        uart_write_bytes(UART_NUM_1, (char *)data->data_ptr, data->data_len);
    }
}

void rover_mode(const Config *config) {
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    esp_wifi_init(&cfg);
    esp_wifi_set_mode(WIFI_MODE_STA);
    wifi_config_t wifi_config = { .sta = { .ssid = "", .password = "" } };
    strcpy((char *)wifi_config.sta.ssid, config->ssid);
    strcpy((char *)wifi_config.sta.password, config->password);
    esp_wifi_set_config(WIFI_IF_STA, &wifi_config);
    esp_wifi_start();
    esp_wifi_connect();

    if (strcmp(config->rover_mode, "single") == 0) {
        // WebSocket客戶端（單基站模式）
        char uri[128];
        snprintf(uri, sizeof(uri), "ws://%s:%d/ws", config->rover_base_ip, config->rover_base_port);
        esp_websocket_client_config_t ws_cfg = {
                .uri = uri,
                .username = config->rover_user,
                .password = config->rover_pass
        };
        esp_websocket_client_handle_t client = esp_websocket_client_init(&ws_cfg);
        esp_websocket_register_events(client, WEBSOCKET_EVENT_ANY, ws_event_handler, NULL);
        esp_websocket_client_start(client);
        vTaskLoopDelay();
    } else {
        // UDP（區域改正模式）
        int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
        struct sockaddr_in local_addr = { .sin_port = htons(config->rover_udp_port), .sin_addr.s_addr = INADDR_ANY };
        bind(sock, (struct sockaddr *)&local_addr, sizeof(local_addr));
        while (1) {
            char rtcm_buffer[512];
            recvfrom(sock, rtcm_buffer, sizeof(rtcm_buffer), 0, NULL, NULL);
            uart_write_bytes(UART_NUM_1, rtcm_buffer, strlen(rtcm_buffer));
            vTaskDelay(10 / portTICK_RATE_MS);
        }
    }
}