#ifndef SETUP_H
#define SETUP_H

#include "config_page.h"

typedef enum { BASE, ROVER, SETUP } DeviceMode;

typedef struct {
    char ssid[32];
    char password[64];
    char base_ip[16];
    uint16_t base_port;
    char base_user[32];
    char base_pass[64];
    char udp_ip[16];
    uint16_t udp_port;
    char rover_base_ip[16];
    uint16_t rover_base_port;
    char rover_user[32];
    char rover_pass[64];
    char rover_mode[8];
    uint16_t rover_udp_port;
} Config;

void setup_mode(DeviceMode *mode, Config *config);

#endif