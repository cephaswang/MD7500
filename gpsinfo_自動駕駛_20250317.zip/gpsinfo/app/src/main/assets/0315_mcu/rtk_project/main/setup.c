#include "setup.h"
#include "esp_wifi.h"
#include "esp_http_server.h"
#include "nvs_flash.h"

static esp_err_t config_handler(httpd_req_t *req) {
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    httpd_resp_send(req, html_page, strlen(html_page));
    return ESP_OK;
}

static esp_err_t save_handler(httpd_req_t *req) {
    char buf[512];
    httpd_req_recv(req, buf, req->content_len);
    Config *config = (Config *)req->user_ctx;
    DeviceMode *mode = (DeviceMode *)req->user_ctx + sizeof(Config);

    if (strstr(buf, "mode=base")) *mode = BASE;
    else *mode = ROVER;
    // 簡單解析POST數據（實際需更嚴謹）
    sscanf(buf, "ssid=%31s&password=%63s", config->ssid, config->password);
    if (*mode == BASE) {
        sscanf(buf, "base_ip=%15s&base_port=%hu&base_user=%31s&base_pass=%63s&udp_ip=%15s&udp_port=%hu",
               config->base_ip, &config->base_port, config->base_user, config->base_pass, config->udp_ip, &config->udp_port);
    } else {
        sscanf(buf, "rover_base_ip=%15s&rover_base_port=%hu&rover_user=%31s&rover_pass=%63s&rover_mode=%7s&rover_udp_port=%hu",
               config->rover_base_ip, &config->rover_base_port, config->rover_user, config->rover_pass, config->rover_mode, &config->rover_udp_port);
    }

    nvs_handle_t nvs;
    nvs_open("storage", NVS_READWRITE, &nvs);
    nvs_set_blob(nvs, "config", config, sizeof(Config));
    nvs_set_u8(nvs, "mode", *mode);
    nvs_commit(nvs);
    nvs_close(nvs);
    esp_restart();
    return ESP_OK;
}

void setup_mode(DeviceMode *mode, Config *config) {
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    esp_wifi_init(&cfg);
    esp_wifi_set_mode(WIFI_MODE_AP);
    wifi_config_t wifi_config = { .ap = { .ssid = "RTK-Setup", .password = "", .max_connection = 4 } };
    esp_wifi_set_config(WIFI_IF_AP, &wifi_config);
    esp_wifi_start();

    httpd_handle_t server = NULL;
    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    httpd_start(&server, &config);
    httpd_uri_t config_uri = { .uri = "/", .method = HTTP_GET, .handler = config_handler, .user_ctx = config };
    httpd_uri_t save_uri = { .uri = "/", .method = HTTP_POST, .handler = save_handler, .user_ctx = config };
    httpd_register_uri_handler(server, &config_uri);
    httpd_register_uri_handler(server, &save_uri);
}
