#include "base_station.h"
#include "rover.h"
#include "setup.h"
#include "nvs_flash.h"
#include "driver/uart.h"
#include "driver/gpio.h"

#define BUTTON_PIN GPIO_NUM_9

static void button_task(void *pvParameters) {
    DeviceMode *mode = (DeviceMode *)pvParameters;
    while (1) {
        if (gpio_get_level(BUTTON_PIN) == 0) {
            vTaskDelay(3000 / portTICK_PERIOD_MS);
            if (gpio_get_level(BUTTON_PIN) == 0) {
                *mode = SETUP;
                nvs_handle_t nvs;
                nvs_open("storage", NVS_READWRITE, &nvs);
                nvs_set_u8(nvs, "mode", SETUP);
                nvs_commit(nvs);
                nvs_close(nvs);
                esp_restart();
            }
        }
        vTaskDelay(100 / portTICK_PERIOD_MS);
    }
}

void app_main(void) {
    nvs_flash_init();
    uart_config_t uart_config = { .baud_rate = 115200, .data_bits = UART_DATA_8_BITS, .parity = UART_PARITY_DISABLE, .stop_bits = UART_STOP_BITS_1, .flow_ctrl = UART_HW_FLOWCTRL_DISABLE };
    uart_param_config(UART_NUM_1, &uart_config);
    uart_set_pin(UART_NUM_1, GPIO_NUM_17, GPIO_NUM_16, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    uart_driver_install(UART_NUM_1, 1024, 0, 0, NULL, 0);
    gpio_set_pull_mode(BUTTON_PIN, GPIO_PULLUP_ONLY);

    DeviceMode mode = SETUP;
    Config config = {0};
    nvs_handle_t nvs;
    nvs_open("storage", NVS_READWRITE, &nvs);
    size_t len = sizeof(config);
    if (nvs_get_blob(nvs, "config", &config, &len) != ESP_OK) {
        strcpy(config.ssid, "default_ssid");
        strcpy(config.password, "default_password");
    }
    nvs_get_u8(nvs, "mode", (uint8_t *)&mode);
    nvs_close(nvs);

    xTaskCreate(button_task, "button_task", 2048, &mode, 5, NULL);

    if (mode == BASE) base_mode(&config);
    else if (mode == ROVER) rover_mode(&config);
    else setup_mode(&mode, &config);
}