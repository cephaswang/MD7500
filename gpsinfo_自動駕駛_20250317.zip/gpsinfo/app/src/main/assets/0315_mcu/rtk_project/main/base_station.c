#include "base_station.h"
#include "esp_wifi.h"
#include "lwip/sockets.h"
#include "driver/uart.h"

static esp_err_t ws_handler(httpd_req_t *req) {
    char auth[100];
    httpd_req_get_hdr_value_str(req, "Authorization", auth, sizeof(auth));
    if (strcmp(auth, "Basic YWRtaW46cGFzc3dvcmQ=") != 0) { // "admin:password" Base64
        httpd_resp_set_status(req, "401 Unauthorized");
        httpd_resp_send(req, NULL, 0);
        return ESP_FAIL;
    }
    if (req->method == HTTP_GET) return httpd_ws_handshake(req);
    while (1) {
        char rtcm_data[512];
        uart_read_bytes(UART_NUM_1, rtcm_data, sizeof(rtcm_data), 100 / portTICK_RATE_MS);
        httpd_ws_frame_t ws_pkt = { .payload = (uint8_t *)rtcm_data, .len = strlen(rtcm_data), .type = HTTPD_WS_TYPE_BINARY };
        httpd_ws_send_frame(req, &ws_pkt);
        vTaskDelay(1000 / portTICK_RATE_MS);
    }
    return ESP_OK;
}

void base_mode(const Config *config) {
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    esp_wifi_init(&cfg);
    esp_wifi_set_mode(WIFI_MODE_STA);
    wifi_config_t wifi_config = { .sta = { .ssid = "", .password = "" } };
    strcpy((char *)wifi_config.sta.ssid, config->ssid);
    strcpy((char *)wifi_config.sta.password, config->password);
    esp_wifi_set_config(WIFI_IF_STA, &wifi_config);
    esp_wifi_start();
    esp_wifi_connect();

    // WebSocket服務器（單基站模式）
    httpd_handle_t server = NULL;
    httpd_config_t http_config = HTTPD_DEFAULT_CONFIG();
    httpd_start(&server, &http_config);
    httpd_uri_t ws = { .uri = "/ws", .method = HTTP_GET, .handler = ws_handler, .is_websocket = true };
    httpd_register_uri_handler(server, &ws);

    // UDP（區域改正模式）
    int sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_IP);
    struct sockaddr_in dest_addr = { .sin_addr.s_addr = inet_addr(config->udp_ip), .sin_port = htons(config->udp_port) };
    while (1) {
        char rtcm_data[512];
        uart_read_bytes(UART_NUM_1, rtcm_data, sizeof(rtcm_data), 100 / portTICK_RATE_MS);
        sendto(sock, rtcm_data, strlen(rtcm_data), 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr));
        vTaskDelay(1000 / portTICK_RATE_MS);
    }
}