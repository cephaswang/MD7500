#ifndef BASE_STATION_H
#define BASE_STATION_H

#include "esp_http_server.h"

typedef struct {
    char ssid[32];
    char password[64];
    char base_ip[16];
    uint16_t base_port;
    char base_user[32];
    char base_pass[64];
    char udp_ip[16];
    uint16_t udp_port;
} Config;

void base_mode(const Config *config);

#endif