#ifndef ROVER_H
#define ROVER_H

typedef struct {
    char ssid[32];
    char password[64];
    char rover_base_ip[16];
    uint16_t rover_base_port;
    char rover_user[32];
    char rover_pass[64];
    char rover_mode[8]; // "single" 或 "fkp"
    uint16_t rover_udp_port;
} Config;

void rover_mode(const Config *config);

#endif