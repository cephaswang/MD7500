#include <HardwareSerial.h>
// 以下是 ESP32-C6 作為基站的程式碼，配置 LC29H (BA) 輸出 RTCM 數據。

HardwareSerial gnssSerial(1); // 使用 UART1

void setup() {
    // 初始化串口
    Serial.begin(115200);
    gnssSerial.begin(9600, SERIAL_8N1, 8, 9); // 設置 UART1 (GPIO8=TX, GPIO9=RX)

    // 配置 LC29H (BA) 為基站模式
    configureBaseStation();
}

void loop() {
    // 讀取 LC29H (BA) 的 RTCM 數據並通過串口輸出
    while (gnssSerial.available()) {
        char data = gnssSerial.read();
        Serial.write(data); // 將 RTCM 數據輸出到串口監視器
    }
}

void configureBaseStation() {
    // 發送 UBX 指令配置 LC29H (BA) 為基站模式
    const uint8_t ubxConfig[] = {
            0xB5, 0x62, 0x06, 0x01, 0x08, 0x00, 0xF0, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x05, 0x47
    };
    gnssSerial.write(ubxConfig, sizeof(ubxConfig));
    Serial.println("LC29H configured as Base Station.");
}