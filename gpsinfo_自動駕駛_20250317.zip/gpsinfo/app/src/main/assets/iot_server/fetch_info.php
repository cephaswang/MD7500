<?php
// fetch_info.php

// 車輛資訊數據
$vehicleInfo = json_encode(array(
    "t" => array(37.42366251669061, -122.08376781182147), // 車輛位置
    "s" => 5.2 // 車輛速度
));

// 將車輛資訊作為參數附加到 URL
$serverUrl = "http://localhost:8080/info?data=" . urlencode($vehicleInfo);

// 打印生成的 URL（用於調試）
echo "生成的 URL: " . $serverUrl . "\n";

// 初始化 cURL
$ch = curl_init();

// 設置 cURL 選項
curl_setopt($ch, CURLOPT_URL, $serverUrl); // 設置 URL
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // 返回結果而不是直接輸出
curl_setopt($ch, CURLOPT_HTTPGET, true); // 使用 GET 請求

// 發送請求並獲取回應
$response = curl_exec($ch);

// 檢查是否有錯誤
if (curl_errno($ch)) {
    echo "cURL 錯誤: " . curl_error($ch);
} else {
    // 打印伺服器回應
    echo "伺服器回應: " . $response . "\n";

    // 解析伺服器回應
    $responseData = json_decode($response, true);

    if ($responseData) {
        // 提取並打印路徑資訊
        $currentPath = $responseData['p'];
        $totalPaths = $responseData['total_paths'];
        echo "目前路徑: " . $currentPath . "\n";
        echo "總路徑數: " . $totalPaths . "\n";

        // 提取並打印車輛尺寸資訊
        $carWidth = $responseData['car']['w'];
        $carLength = $responseData['car']['len'];
        echo "車輛寬度: " . $carWidth . "\n";
        echo "車輛長度: " . $carLength . "\n";
    } else {
        echo "無法解析伺服器回應。\n";
    }
}

// 關閉 cURL
curl_close($ch);

?>