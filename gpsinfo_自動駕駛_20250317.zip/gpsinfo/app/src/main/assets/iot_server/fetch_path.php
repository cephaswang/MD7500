<?php
// fetch_path.php

// 路徑編號
$pathNumber = 10; // 這裡可以根據需求動態設置

// 構建 URL
$serverUrl = "http://localhost:8080/path?p=" . urlencode($pathNumber);

// 打印生成的 URL（用於調試）
echo "生成的 URL: " . $serverUrl . "\n";

// 初始化 cURL
$ch = curl_init();

// 設置 cURL 選項
curl_setopt($ch, CURLOPT_URL, $serverUrl); // 設置 URL
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // 返回結果而不是直接輸出
curl_setopt($ch, CURLOPT_HTTPGET, true); // 使用 GET 請求

// 發送請求並獲取回應
$response = curl_exec($ch);

// 檢查是否有錯誤
if (curl_errno($ch)) {
    echo "cURL 錯誤: " . curl_error($ch);
} else {
    // 打印伺服器回應
    echo "伺服器回應: " . $response . "\n";

    // 解析 JSON 回應
    $data = json_decode($response, true);

    if (isset($data['s'])) {
        if (is_array($data['s'])) {
            if ($data['s'] == [0, 0]) {
                echo "沒有更多路徑，任務完成。\n";
            } else {
                echo "下一個路徑: " . json_encode($data['s']) . "\n";
            }
        } else {
            echo "伺服器回應: " . $data['s'] . "\n";
        }
    } else {
        echo "未找到路徑數據\n";
    }
}

// 關閉 cURL
curl_close($ch);

/*
生成的 URL: http://localhost:8080/path?p=10
伺服器回應: {"s":[157.12,201],"p":20}
總路徑數 20

下一個路徑: [157.12,201]
admin@admins-Mac-mini iot_server % php fetch_path.php
生成的 URL: http://localhost:8080/path?p=10
伺服器回應: {"s":[0,0]}
沒有更多路徑，任務完成。
*/

?>