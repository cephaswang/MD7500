// PathTurbine.kt
package tw.ibiz.gpsinfo

import com.google.android.gms.maps.model.LatLng
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object PathTurbine {

    private var stepNum: Int = 0

    private fun toRadians(degrees: Double): Double {
        return degrees * Math.PI / 180.0
    }

    fun generateSpiralPath(
        boundaryPoints: ArrayList<LatLng>,
        vehicleWidth: Float,
        pathOverlap: Float
    ): ArrayList<ArrayList<LatLng>> {
        val paths = ArrayList<ArrayList<LatLng>>()
        val effectiveWidth = vehicleWidth - pathOverlap
        val metersToDegreesLat = 1.0 / 111111.0 // 每米對應的緯度度數
        val effectiveWidthDegrees = effectiveWidth * metersToDegreesLat

        // 初始邊界
        var currentBoundary = ArrayList(boundaryPoints)
        paths.add(ArrayList(currentBoundary)) // 添加外圍邊界作為起點

        val maxIterations = 5000
        var iteration = 0

        // 計算多邊形中心點作為螺旋的目標
        val center = calculateCentroid(currentBoundary)

        while (iteration < maxIterations) {
            val nextPath = ArrayList<LatLng>()
            val distanceToCenterThreshold = effectiveWidthDegrees  // 停止條件：接近中心

            // 檢查當前邊界的邊數
            if (currentBoundary.size == 3) {
                // 如果是三角形，檢查邊長是否小於車身寬度
                if (isTriangleSmallerThanVehicleWidth(currentBoundary, vehicleWidth)) {
                    break
                }
            }

            for (i in currentBoundary.indices) {
                val currentPoint = currentBoundary[i]
                // 計算從當前點到中心的向量
                val deltaLat = center.latitude - currentPoint.latitude
                val deltaLng =
                    (center.longitude - currentPoint.longitude) * cos(toRadians(currentPoint.latitude))
                val distanceToCenter = sqrt(deltaLat * deltaLat + deltaLng * deltaLng)

                if (distanceToCenter < distanceToCenterThreshold) {
                    // 如果接近中心，結束螺旋
                    if (nextPath.isNotEmpty()) paths.add(nextPath)
                    return paths
                }

                // 沿著指向中心的向量內縮
                val directionLat = deltaLat / distanceToCenter
                val directionLng = deltaLng / distanceToCenter
                val newLat = currentPoint.latitude + directionLat * effectiveWidthDegrees
                val newLng = currentPoint.longitude + directionLng * effectiveWidthDegrees

                nextPath.add(LatLng(newLat, newLng))
            }

            // 檢查新路徑的有效性
            if (nextPath.size < 3 || !isValidPolygon(nextPath)) {
                // 如果無法生成有效路徑，切換到平行路徑生成
                val parallelPaths = PathParallel.generateParallelPath(
                    currentBoundary,
                    vehicleWidth,
                    pathOverlap,
                    stepNum++
                )
                paths.addAll(parallelPaths)
                break
            }

            paths.add(nextPath)
            currentBoundary = nextPath
            iteration++
        }

        return paths
    }

    private fun calculateCentroid(points: ArrayList<LatLng>): LatLng {
        var centroidLat = 0.0
        var centroidLng = 0.0
        val n = points.size

        for (point in points) {
            centroidLat += point.latitude
            centroidLng += point.longitude
        }

        return LatLng(centroidLat / n, centroidLng / n)
    }

    private fun isValidPolygon(points: ArrayList<LatLng>): Boolean {
        if (points.size < 3) return false

        // Calculate the area of the polygon to check if it's valid
        var area = 0.0
        val n = points.size

        for (i in 0 until n) {
            val j = (i + 1) % n
            area += points[i].latitude * points[j].longitude
            area -= points[j].latitude * points[i].longitude
        }

        area = abs(area) / 2.0

        // If area is too small, consider it invalid
        val minArea = 1e-8 // Arbitrary small threshold
        return area > minArea
    }

    private fun isTriangleSmallerThanVehicleWidth(
        triangle: ArrayList<LatLng>,
        vehicleWidth: Float
    ): Boolean {
        // 計算三角形的邊長
        val side1 = calculateDistance(triangle[0], triangle[1])
        val side2 = calculateDistance(triangle[1], triangle[2])
        val side3 = calculateDistance(triangle[2], triangle[0])

        // 如果任意一邊的長度小於車身寬度，返回 true
        return side1 < vehicleWidth || side2 < vehicleWidth || side3 < vehicleWidth
    }

    private fun calculateDistance(p1: LatLng, p2: LatLng): Double {
        val lat1 = toRadians(p1.latitude)
        val lng1 = toRadians(p1.longitude)
        val lat2 = toRadians(p2.latitude)
        val lng2 = toRadians(p2.longitude)

        val dLat = lat2 - lat1
        val dLng = lng2 - lng1

        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(lat1) * cos(lat2) *
                sin(dLng / 2) * sin(dLng / 2)

        val c = 2 * atan2(sqrt(a), sqrt(1 - a))

        return 6371000 * c // 地球半徑（米）乘以弧度
    }
}