package com.agopengps.classes

import com.agopengps.drive.FormGPS
import com.agopengps.drive.MainActivity

class CHeadLine(private val mf: FormGPS) {
    val tracksArr = mutableListOf<CHeadPath>()
    var idx: Int = 0
    val desList = mutableListOf<vec3>()

    // For calculating the averaged new line for display
    // Add your calculation methods here as needed
}

class CHeadPath {
    val trackPts = mutableListOf<vec3>()
    var name: String = ""
    var moveDistance: Double = 0.0
    var mode: Int = 0
    var a_point: Int = 0
}

