package com.agopengps.classes

import com.agopengps.drive.BtnStates


class CSection {
    // Section control states
    var isSectionOn: Boolean = false
    var isSectionRequiredOn: Boolean = false
    var sectionOnRequest: Boolean = false
    var sectionOffRequest: Boolean = false
    var sectionOnOffCycle: Boolean = false

    // Timers
    var sectionOnTimer: Int = 0
    var sectionOffTimer: Int = 0

    // Mapping control
    var isMappingOn: Boolean = false
    var mappingOnTimer: Int = 0
    var mappingOffTimer: Int = 0
    var speedPixels: Double = 0.0

    // Section position and dimensions (in meters)
    // Left side is negative, right side is positive
    // e.g., left side only: -8 to -4
    //       center: -4 to 4
    //       right side only: 4 to 8
    var positionLeft: Double = -4.0
    var positionRight: Double = 4.0
    var sectionWidth: Double
        get() = positionRight - positionLeft
        set(value) {
            val center = (positionLeft + positionRight) / 2
            positionLeft = center - value / 2
            positionRight = center + value / 2
        }

    var foreDistance: Double = 0.0

    // Pixel array properties for rendering
    var rpSectionWidth: Int = 0
    var rpSectionPosition: Int = 0

    // World space points
    var leftPoint: vec2 = vec2(0.0, 0.0)
    var rightPoint: vec2 = vec2(0.0, 0.0)
    var lastLeftPoint: vec2 = vec2(0.0, 0.0)
    var lastRightPoint: vec2 = vec2(0.0, 0.0)

    // Boundary and headland states
    var isInBoundary: Boolean = true
    var isHydLiftInWorkArea: Boolean = true
    var isInHeadlandArea: Boolean = true
    var isLookOnInHeadland: Boolean = true
    var numTriangles: Int = 0

    // Section button state
    var sectionBtnState: BtnStates = BtnStates.Off

    // Custom getter for section width
    fun getSectionWidthMeters(): Double {
        return positionRight - positionLeft
    }

    fun setSectionWidthMeters(width: Double) {
        val center = (positionLeft + positionRight) / 2
        positionLeft = center - width / 2
        positionRight = center + width / 2
    }
}

