package com.agopengps.classes

import com.agopengps.drive.FormGPS
import com.agopengps.drive.btnStates
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.Dot
import kotlin.math.*

data class CRecPathPt(
    var easting: Double,
    var northing: Double,
    var heading: Double,
    var speed: Double,
    var autoBtnState: Boolean
) {
    constructor(
        _easting: Double,
        _northing: Double,
        _heading: Double,
        _speed: Double,
        _autoBtnState: Boolean
    ) : this(_easting, _northing, _heading, _speed, _autoBtnState)
}

class CRecordedPath(private val mf: FormGPS) {
    val recList = mutableListOf<CRecPathPt>()
    val shuttleDubinsList = mutableListOf<CRecPathPt>()
    var shuttleListCount: Int = 0
    val shortestDubinsList = mutableListOf<vec3>()

    var refPoint1 = vec2(1.0, 1.0)
    var refPoint2 = vec2(2.0, 2.0)
    var distanceFromRefLine: Double = 0.0
    var distanceFromCurrentLinePivot: Double = 0.0
    private var A: Int = 0
    private var B: Int = 0
    private var C: Int = 0
    var currentPositonIndex: Int = 0

    var pivotAxlePosRP = vec3(0.0, 0.0, 0.0)
    var homePos = vec3()
    var goalPointRP = vec2(0.0, 0.0)
    var steerAngleRP: Double = 0.0
    var rEastRP: Double = 0.0
    var rNorthRP: Double = 0.0
    var ppRadiusRP: Double = 0.0
    var radiusPointRP = vec2(0.0, 0.0)

    var isBtnFollowOn: Boolean = false
    var isEndOfTheRecLine: Boolean = false
    var isRecordOn: Boolean = false
    var isDrivingRecordedPath: Boolean = false
    var isFollowingDubinsToPath: Boolean = false
    var isFollowingRecPath: Boolean = false
    var isFollowingDubinsHome: Boolean = false

    var pivotDistanceError: Double = 0.0
    var pivotDistanceErrorLast: Double = 0.0
    var pivotDerivative: Double = 0.0
    var pivotDerivativeSmoothed: Double = 0.0
    private var counter2: Int = 0

    var inty: Double = 0.0
    var steerAngleSmoothed: Double = 0.0
    var pivotErrorTotal: Double = 0.0
    var distSteerError: Double = 0.0
    var lastDistSteerError: Double = 0.0
    var derivativeDistError: Double = 0.0

    var resumeState: Int = 0
    private var starPathIndx: Int = 0
    var trig: Boolean = false
    var north: Double = 0.0
    var pathCount: Int = 0

    fun StartDrivingRecordedPath(): Boolean {
        A = 0
        B = 0
        C = 0

        if (recList.size < 5) return false

        homePos = mf.pivotAxlePos

        var distance = Double.MAX_VALUE
        var idx = 0
        var i = 0

        when (resumeState) {
            0 -> {
                currentPositonIndex = 0
                idx = 0
                starPathIndx = 0
            }
            1 -> {
                if (currentPositonIndex + 5 > recList.size) {
                    currentPositonIndex = 0
                    idx = 0
                    starPathIndx = 0
                } else {
                    idx = currentPositonIndex
                    starPathIndx = currentPositonIndex
                }
            }
            else -> {
                recList.forEachIndexed { index, pt ->
                    val temp = ((pt.easting - homePos.easting) * (pt.easting - homePos.easting)) +
                            ((pt.northing - homePos.northing) * (pt.northing - homePos.northing))
                    if (temp < distance) {
                        distance = temp
                        idx = index
                    }
                    i++
                }

                idx = if (idx + 5 < recList.size) idx + 5 else recList.size - 1
                starPathIndx = idx
                currentPositonIndex = idx
            }
        }

        val goal = vec3(recList[idx].easting, recList[idx].northing, recList[idx].heading)
        GetDubinsPath(goal)
        shuttleListCount = shuttleDubinsList.size

        if (shuttleListCount == 0) return false

        isFollowingDubinsHome = false
        isFollowingRecPath = false
        isFollowingDubinsToPath = true
        isEndOfTheRecLine = false
        isDrivingRecordedPath = true
        return true
    }

    fun UpdatePosition() {
        when {
            isFollowingDubinsToPath -> {
                mf.sim.stepDistance = shuttleDubinsList[C].speed / 50
                pivotAxlePosRP = mf.pivotAxlePos
                PurePursuitDubins(shuttleListCount)

                val cnt = shuttleDubinsList.size
                pathCount = cnt - B
                if (pathCount < 8) {
                    val distSqr = glm.distanceSquared(pivotAxlePosRP.northing, pivotAxlePosRP.easting, recList[starPathIndx].northing, recList[starPathIndx].easting)
                    if (distSqr < 2) {
                        isFollowingRecPath = true
                        isFollowingDubinsToPath = false
                        shuttleDubinsList.clear()
                        shortestDubinsList.clear()
                        C = starPathIndx
                        A = C + 3
                        B = A + 1
                    }
                }
            }
            isFollowingRecPath -> {
                pivotAxlePosRP = mf.pivotAxlePos
                PurePursuitRecPath(recList.size)

                if (!isEndOfTheRecLine) {
                    mf.sim.stepDistance = recList[C].speed / 34.86
                    north = recList[C].northing
                    pathCount = recList.size - C

                    val autoBtn = (mf.autoBtnState == btnStates.Auto)
                    trig = autoBtn
                    if (autoBtn != recList[C].autoBtnState) mf.btnSectionMasterAuto.PerformClick()
                } else {
                    StopDrivingRecordedPath()
                    return
                }
            }
            isFollowingDubinsHome -> {
                val cnt = shuttleDubinsList.size
                pathCount = cnt - B
                if (pathCount < 3) {
                    StopDrivingRecordedPath()
                    return
                }

                mf.sim.stepDistance = shuttleDubinsList[C].speed / 35
                pivotAxlePosRP = mf.pivotAxlePos
                PurePursuitDubins(shuttleListCount)
            }
        }
    }

    fun StopDrivingRecordedPath() {
        isFollowingDubinsHome = false
        isFollowingRecPath = false
        isFollowingDubinsToPath = false
        shuttleDubinsList.clear()
        shortestDubinsList.clear()
        mf.sim.stepDistance = 0.0
        isDrivingRecordedPath = false
        mf.btnPathGoStop.Image = Properties.Resources.boundaryPlay
        mf.btnPathRecordStop.Enabled = true
        mf.btnPickPath.Enabled = true
        mf.btnResumePath.Enabled = true
    }

    private fun GetDubinsPath(goal: vec3) {
        CDubins.turningRadius = mf.yt.youTurnRadius * 1.2
        val dubPath = CDubins(mf)
        pivotAxlePosRP = mf.pivotAxlePos

        val pt2 = vec3(
            easting = pivotAxlePosRP.easting + (sin(pivotAxlePosRP.heading) * 3),
            northing = pivotAxlePosRP.northing + (cos(pivotAxlePosRP.heading) * 3),
            heading = pivotAxlePosRP.heading
        )

        shortestDubinsList.clear()
        shuttleDubinsList.clear()

        shortestDubinsList.addAll(dubPath.GenerateDubins(pt2, goal))

        if (shortestDubinsList.isNotEmpty()) {
            shortestDubinsList.add(0, mf.pivotAxlePos)

            for (i in shortestDubinsList.indices) {
                val pt = CRecPathPt(shortestDubinsList[i].easting, shortestDubinsList[i].northing, shortestDubinsList[i].heading, 9.0, false)
                shuttleDubinsList.add(pt)
            }
        }
    }

    private fun PurePursuitRecPath(ptCount: Int) {
        var minDistA = Double.MAX_VALUE
        var dist: Double
        var dx: Double
        var dz: Double

        val top = minOf(currentPositonIndex + 5, ptCount)
        for (t in currentPositonIndex until top) {
            dist = ((pivotAxlePosRP.easting - recList[t].easting) * (pivotAxlePosRP.easting - recList[t].easting)) +
                    ((pivotAxlePosRP.northing - recList[t].northing) * (pivotAxlePosRP.northing - recList[t].northing))
            if (dist < minDistA) {
                minDistA = dist
                A = t
            }
        }

        C = A
        B = A + 1
        if (B == ptCount) {
            A--
            B--
            isEndOfTheRecLine = true
        }

        currentPositonIndex = A

        dx = recList[B].easting - recList[A].easting
        dz = recList[B].northing - recList[A].northing

        if (abs(dx) < Double.MIN_VALUE && abs(dz) < Double.MIN_VALUE) return

        distanceFromCurrentLinePivot = ((dz * pivotAxlePosRP.easting) - (dx * pivotAxlePosRP.northing) +
                (recList[B].easting * recList[A].northing) - (recList[B].northing * recList[A].easting)) /
                sqrt((dz * dz) + (dx * dx))

        if (mf.vehicle.purePursuitIntegralGain != 0.0) {
            pivotDistanceError = distanceFromCurrentLinePivot * 0.2 + pivotDistanceError * 0.8

            if (counter2++ > 4) {
                pivotDerivative = pivotDistanceError - pivotDistanceErrorLast
                pivotDistanceErrorLast = pivotDistanceError
                counter2 = 0
                pivotDerivative *= 2
            }

            if (isFollowingRecPath && abs(pivotDerivative) < 0.1 && mf.avgSpeed > 2.5) {
                if ((inty < 0 && distanceFromCurrentLinePivot < 0) || (inty > 0 && distanceFromCurrentLinePivot > 0)) {
                    inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.04
                } else {
                    if (abs(distanceFromCurrentLinePivot) > 0.02) {
                        inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.02
                        inty = inty.coerceIn(-0.2, 0.2)
                    }
                }
            } else inty *= 0.95
        } else inty = 0.0

        if (mf.isReverse) inty = 0.0

        val U = (((pivotAxlePosRP.easting - recList[A].easting) * dx) +
                ((pivotAxlePosRP.northing - recList[A].northing) * dz)) /
                ((dx * dx) + (dz * dz))

        rEastRP = recList[A].easting + (U * dx)
        rNorthRP = recList[A].northing + (U * dz)

        val goalPointDistance = mf.vehicle.UpdateGoalPointDistance()
        val reverseHeading = !mf.isReverse
        val count = if (reverseHeading) 1 else -1
        val start = CRecPathPt(rEastRP, rNorthRP, 0.0, 0.0, false)
        var distSoFar = 0.0

        val range = if (reverseHeading) B until ptCount else A downTo 0
        for (i in range step count) {
            val tempDist = sqrt((start.easting - recList[i].easting) * (start.easting - recList[i].easting) +
                    (start.northing - recList[i].northing) * (start.northing - recList[i].northing))

            if ((tempDist + distSoFar) > goalPointDistance) {
                val j = (goalPointDistance - distSoFar) / tempDist
                goalPointRP.easting = (((1 - j) * start.easting) + (j * recList[i].easting))
                goalPointRP.northing = (((1 - j) * start.northing) + (j * recList[i].northing))
                break
            } else {
                distSoFar += tempDist
                start.easting = recList[i].easting
                start.northing = recList[i].northing
            }
        }

        val goalPointDistanceSquared = glm.distanceSquared(goalPointRP.northing, goalPointRP.easting, pivotAxlePosRP.northing, pivotAxlePosRP.easting)
        val localHeading = glm.twoPI - mf.fixHeading + inty

        ppRadiusRP = goalPointDistanceSquared / (2 * (((goalPointRP.easting - pivotAxlePosRP.easting) * cos(localHeading)) +
                ((goalPointRP.northing - pivotAxlePosRP.northing) * sin(localHeading))))

        steerAngleRP = glm.toDegrees(atan(2 * (((goalPointRP.easting - pivotAxlePosRP.easting) * cos(localHeading)) +
                ((goalPointRP.northing - pivotAxlePosRP.northing) * sin(localHeading))) * mf.vehicle.wheelbase / goalPointDistanceSquared))

        steerAngleRP = steerAngleRP.coerceIn(-mf.vehicle.maxSteerAngle, mf.vehicle.maxSteerAngle)

        mf.vehicle.modeActualXTE = distanceFromCurrentLinePivot
        mf.guidanceLineDistanceOff = round(distanceFromCurrentLinePivot * 1000.0).toShort()
        mf.guidanceLineSteerAngle = (steerAngleRP * 100).toShort()
    }

    private fun PurePursuitDubins(ptCount: Int) {
        var minDistA = 1000000.0
        var minDistB = 1000000.0
        var dist: Double
        var dx: Double
        var dz: Double

        for (t in 0 until ptCount) {
            dist = ((pivotAxlePosRP.easting - shuttleDubinsList[t].easting) * (pivotAxlePosRP.easting - shuttleDubinsList[t].easting)) +
                    ((pivotAxlePosRP.northing - shuttleDubinsList[t].northing) * (pivotAxlePosRP.northing - shuttleDubinsList[t].northing))
            when {
                dist < minDistA -> {
                    minDistB = minDistA
                    B = A
                    minDistA = dist
                    A = t
                }
                dist < minDistB -> {
                    minDistB = dist
                    B = t
                }
            }
        }

        if (A > B) {
            C = A
            A = B
            B = C
        }

        dx = shuttleDubinsList[B].easting - shuttleDubinsList[A].easting
        dz = shuttleDubinsList[B].northing - shuttleDubinsList[A].northing

        if (abs(dx) < Double.MIN_VALUE && abs(dz) < Double.MIN_VALUE) return

        distanceFromCurrentLinePivot = ((dz * pivotAxlePosRP.easting) - (dx * pivotAxlePosRP.northing) +
                (shuttleDubinsList[B].easting * shuttleDubinsList[A].northing) - (shuttleDubinsList[B].northing * shuttleDubinsList[A].easting)) /
                sqrt((dz * dz) + (dx * dx))

        if (mf.vehicle.purePursuitIntegralGain != 0.0) {
            pivotDistanceError = distanceFromCurrentLinePivot * 0.2 + pivotDistanceError * 0.8

            if (counter2++ > 4) {
                pivotDerivative = pivotDistanceError - pivotDistanceErrorLast
                pivotDistanceErrorLast = pivotDistanceError
                counter2 = 0
                pivotDerivative *= 2
            }

            if (mf.isBtnAutoSteerOn && abs(pivotDerivative) < 0.1 && mf.avgSpeed > 2.5 && !mf.yt.isYouTurnTriggered) {
                if ((inty < 0 && distanceFromCurrentLinePivot < 0) || (inty > 0 && distanceFromCurrentLinePivot > 0)) {
                    inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.04
                } else {
                    if (abs(distanceFromCurrentLinePivot) > 0.02) {
                        inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.02
                        inty = inty.coerceIn(-0.2, 0.2)
                    }
                }
            } else inty *= 0.95
        } else inty = 0.0

        if (mf.isReverse) inty = 0.0

        val U = (((pivotAxlePosRP.easting - shuttleDubinsList[A].easting) * dx) +
                ((pivotAxlePosRP.northing - shuttleDubinsList[A].northing) * dz)) /
                ((dx * dx) + (dz * dz))

        rEastRP = shuttleDubinsList[A].easting + (U * dx)
        rNorthRP = shuttleDubinsList[A].northing + (U * dz)

        val goalPointDistance = mf.vehicle.UpdateGoalPointDistance()
        val reverseHeading = !mf.isReverse
        val count = if (reverseHeading) 1 else -1
        val start = CRecPathPt(rEastRP, rNorthRP, 0.0, 0.0, false)
        var distSoFar = 0.0

        val range = if (reverseHeading) B until ptCount else A downTo 0
        for (i in range step count) {
            val tempDist = sqrt((start.easting - shuttleDubinsList[i].easting) * (start.easting - shuttleDubinsList[i].easting) +
                    (start.northing - shuttleDubinsList[i].northing) * (start.northing - shuttleDubinsList[i].northing))

            if ((tempDist + distSoFar) > goalPointDistance) {
                val j = (goalPointDistance - distSoFar) / tempDist
                goalPointRP.easting = (((1 - j) * start.easting) + (j * shuttleDubinsList[i].easting))
                goalPointRP.northing = (((1 - j) * start.northing) + (j * shuttleDubinsList[i].northing))
                break
            } else {
                distSoFar += tempDist
                start.easting = shuttleDubinsList[i].easting
                start.northing = shuttleDubinsList[i].northing
            }
        }

        val goalPointDistanceSquared = glm.distanceSquared(goalPointRP.northing, goalPointRP.easting, pivotAxlePosRP.northing, pivotAxlePosRP.easting)
        val localHeading = glm.twoPI - mf.fixHeading + inty

        ppRadiusRP = goalPointDistanceSquared / (2 * (((goalPointRP.easting - pivotAxlePosRP.easting) * cos(localHeading)) +
                ((goalPointRP.northing - pivotAxlePosRP.northing) * sin(localHeading))))

        steerAngleRP = glm.toDegrees(atan(2 * (((goalPointRP.easting - pivotAxlePosRP.easting) * cos(localHeading)) +
                ((goalPointRP.northing - pivotAxlePosRP.northing) * sin(localHeading))) * mf.vehicle.wheelbase / goalPointDistanceSquared))

        steerAngleRP = steerAngleRP.coerceIn(-mf.vehicle.maxSteerAngle, mf.vehicle.maxSteerAngle)
        ppRadiusRP = ppRadiusRP.coerceIn(-500.0, 500.0)

        radiusPointRP.easting = pivotAxlePosRP.easting + (ppRadiusRP * cos(localHeading))
        radiusPointRP.northing = pivotAxlePosRP.northing + (ppRadiusRP * sin(localHeading))

        mf.guidanceLineDistanceOff = round(distanceFromCurrentLinePivot * 1000.0).toShort()
        mf.guidanceLineSteerAngle = (steerAngleRP * 100).toShort()
    }

    fun DrawRecordedLine(map: GoogleMap) {
        val ptCount = recList.size
        if (ptCount < 1) return

        val polylineOptions = PolylineOptions()
            .width(2f)
            .color(android.graphics.Color.argb(255, 250, 235, 117)) // Approx RGB(0.98, 0.92, 0.46)
            .addAll(recList.map { LatLng(it.northing, it.easting) })

        map.addPolyline(polylineOptions)

        if (!isRecordOn) {
            map.addCircle(
                CircleOptions()
                    .center(LatLng(recList[currentPositonIndex].northing, recList[currentPositonIndex].easting))
                    .radius(8.0) // Half of 16.0f point size
                    .fillColor(android.graphics.Color.argb(255, 255, 128, 242)) // Approx RGB(1.0, 0.5, 0.95)
                    .strokeWidth(0f)
            )
        }
    }

    fun DrawDubins(map: GoogleMap) {
        if (shuttleDubinsList.size > 1) {
            val polylineOptions = PolylineOptions()
                .width(2f)
                .color(android.graphics.Color.argb(255, 76, 245, 75)) // Approx RGB(0.298, 0.96, 0.296)
                .pattern(listOf(Dot()))
                .addAll(shuttleDubinsList.map { LatLng(it.northing, it.easting) })

            map.addPolyline(polylineOptions)
        }
    }
}