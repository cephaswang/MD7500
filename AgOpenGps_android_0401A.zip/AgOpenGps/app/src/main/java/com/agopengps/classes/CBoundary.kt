package com.agopengps.classes

import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import java.util.*
import kotlin.math.*
import com.agopengps.drive.BtnStates

class CBoundary(private val mf: FormGPS) {

    // Lists
    val bndList = mutableListOf<CBoundaryList>()
    private val bndBeingMadePts = mutableListOf<vec3>()

    // Properties
    var createBndOffset: Double = 0.0
    var isBndBeingMade: Boolean = false
    var isDrawRightSide: Boolean = true
    var isDrawAtPivot: Boolean = true
    var isOkToAddPoints: Boolean = false
    var isRecBoundaryWhenSectionOn: Boolean = false
    var closestFenceNum: Int = 0
    var closestFencePt = vec3(-10000.0, -10000.0, 9.0)
    var isHeadlandOn: Boolean = false
    private var isToolInHeadland: Boolean = false
    private var isToolOuterPointsInHeadland: Boolean = false
    var isSectionControlledByHeadland: Boolean =
        mf.settings.setHeadland_isSectionControlled
    private var turnSelected: Int = 0
    var closestTurnNum: Int = 0
    var iE: Double = 0.0
    var iN: Double = 0.0


    init {
        turnSelected = 0
        isHeadlandOn = false
    }



    fun isPointInsideFenceArea(testPoint: vec3): Boolean = with(glm) {
        // 将 vec3 转换为 vec2，因为 fenceLineEar 是 MutableList<vec2>
        val testPoint2D = vec2(testPoint.easting, testPoint.northing)
        if (bndList[0].fenceLineEar.IsPointInPolygon(testPoint2D)) {
            for (i in 1 until bndList.size) {
                if (bndList[i].fenceLineEar.IsPointInPolygon(testPoint2D)) {
                    return false
                }
            }
            return true
        }
        return false
    }

    fun isPointInsideFenceArea(testPoint: vec2): Boolean = with(glm) {
        // 直接使用 vec2 版本
        if (bndList[0].fenceLineEar.IsPointInPolygon(testPoint)) {
            for (i in 1 until bndList.size) {
                if (bndList[i].fenceLineEar.IsPointInPolygon(testPoint)) {
                    return false
                }
            }
            return true
        }
        return false
    }


    // 修改為使用 Google Maps 繪製圍欄線
    fun drawFenceLines(googleMap: GoogleMap) {
        if (bndBeingMadePts.isEmpty()) return

        // 將 vec3 點轉換為 LatLng（假設 easting 是經度，northing 是緯度）
        val points = bndBeingMadePts.map { LatLng(it.northing, it.easting) }

        // 使用 PolylineOptions 繪製線條
        val polylineOptions = PolylineOptions()
            .addAll(points)
            .color(android.graphics.Color.MAGENTA) // 設置線條顏色（對應原來的 0.825f, 0.22f, 0.90f）
            .width(mf.ABLine.lineWidth.toFloat()) // 使用原始線寬

        // 在 Google Maps 上添加折線
        googleMap.addPolyline(polylineOptions)
    }

    fun setHydPosition() {
        if (mf.vehicle.isHydLiftOn || mf.avgSpeed > 0.2 ||
            mf.autoBtnState == BtnStates.Auto || !mf.isReverse
        ) {
            if (isToolInHeadland) {
                mf.p_239.pgn[mf.p_239.hydLift] = 2
                if (mf.sounds.isHydLiftChange != isToolInHeadland) {
                    if (mf.sounds.isHydLiftSoundOn) mf.sounds.playHydLiftUp()
                    mf.sounds.isHydLiftChange = isToolInHeadland
                    isToolInHeadland
                }
            } else {
                mf.p_239.pgn[mf.p_239.hydLift] = 1
                if (mf.sounds.isHydLiftChange != isToolInHeadland) {
                    if (mf.sounds.isHydLiftSoundOn) mf.sounds.playHydLiftDown()
                    mf.sounds.isHydLiftChange = isToolInHeadland
                }
            }
        }
    }

    fun whereAreToolCorners() {
        if (bndList.isNotEmpty() && bndList[0].hdLine.isNotEmpty()) {
            var isLeftInWk: Boolean
            var isRightInWk = true

            for (j in 0 until mf.tool.numOfSections) {
                isLeftInWk =
                    if (j == 0) isPointInsideHeadArea(mf.section[j].leftPoint) else isRightInWk
                isRightInWk = isPointInsideHeadArea(mf.section[j].rightPoint)

                if (j == 0) mf.tool.isLeftSideInHeadland = !isLeftInWk
                mf.section[j].isInHeadlandArea = !isLeftInWk && !isRightInWk
            }

            mf.tool.isRightSideInHeadland = !isRightInWk
            isToolOuterPointsInHeadland =
                mf.tool.isLeftSideInHeadland && mf.tool.isRightSideInHeadland
        }
    }

    fun whereAreToolLookOnPoints() {
        if (bndList.isNotEmpty() && bndList[0].hdLine.isNotEmpty()) {
            var isLookRightIn = false
            val toolFix = mf.toolPivotPos
            val sinAB = sin(toolFix.heading)
            val cosAB = cos(toolFix.heading)
            var pos = 0.0
            val mOn = (mf.tool.lookAheadDistanceOnPixelsRight -
                    mf.tool.lookAheadDistanceOnPixelsLeft) / mf.tool.rpWidth

            for (j in 0 until mf.tool.numOfSections) {
                val isLookLeftIn = if (j == 0) isPointInsideHeadArea(
                    vec2(
                        mf.section[j].leftPoint.easting + (sinAB * mf.tool.lookAheadDistanceOnPixelsLeft * 0.1),
                        mf.section[j].leftPoint.northing + (cosAB * mf.tool.lookAheadDistanceOnPixelsLeft * 0.1)
                    )
                ) else isLookRightIn

                pos += mf.section[j].rpSectionWidth
                val endHeight = (mf.tool.lookAheadDistanceOnPixelsLeft + (mOn * pos)) * 0.1

                isLookRightIn = isPointInsideHeadArea(
                    vec2(
                        mf.section[j].rightPoint.easting + (sinAB * endHeight),
                        mf.section[j].rightPoint.northing + (cosAB * endHeight)
                    )
                )

                mf.section[j].isLookOnInHeadland = !isLookLeftIn && !isLookRightIn
            }
        }
    }

    // 使用 glm.isPointInPolygon 檢查點是否在頭地區域內
    private fun isPointInsideHeadArea(pt: vec2): Boolean = with(glm) {
        if (bndList[0].hdLine.IsPointInPolygon(pt)) {
            for (i in 1 until bndList.size) {
                if (bndList[i].hdLine.IsPointInPolygon(pt)) {
                    return@with false
                }
            }
            return@with true
        }
        return@with false
    }

    fun isPointInsideTurnArea(pt: vec3): Int = with(glm) {
        if (bndList.isNotEmpty() && bndList[0].turnLine.IsPointInPolygon(pt)) {
            for (i in 1 until bndList.size) {
                if (bndList[i].isDriveThru) continue
                if (bndList[i].turnLine.IsPointInPolygon(pt)) {
                    return@with i
                }
            }
            return@with 0
        }
        return@with -1
    }

    fun buildTurnLines() {
        if (bndList.isEmpty()) {
            return
        }

        mf.fd.updateFieldBoundaryGUIAreas()
        val totalHeadWidth = mf.yt.uturnDistanceFromBoundary

        for (j in bndList.indices) {
            bndList[j].turnLine.clear()
            if (bndList[j].isDriveThru) continue

            val ptCount = bndList[j].fenceLine.size
            for (i in ptCount - 1 downTo 0) {
                val point = vec3(
                    easting = bndList[j].fenceLine[i].easting + (-sin(PI / 2 + bndList[j].fenceLine[i].heading) * totalHeadWidth),
                    northing = bndList[j].fenceLine[i].northing + (-cos(PI / 2 + bndList[j].fenceLine[i].heading) * totalHeadWidth),
                    heading = bndList[j].fenceLine[i].heading
                ).apply {
                    if (heading < -2 * PI) heading += 2 * PI
                }

                if (j == 0 == with(glm) { bndList[j].fenceLineEar.IsPointInPolygon(point) }) {
                    bndList[j].turnLine.add(vec3(point.easting, point.northing, point.heading))
                }
            }
            bndList[j].fixTurnLine(totalHeadWidth, 2)

            val cnt = bndList[j].turnLine.size
            val arr = Array(cnt) { bndList[j].turnLine[it] }
            var delta = 0.0
            bndList[j].turnLine.clear()

            for (i in arr.indices) {
                if (i == 0) {
                    bndList[j].turnLine.add(arr[i])
                    continue
                }
                delta += (arr[i - 1].heading - arr[i].heading)
                if (abs(delta) > 0.005) {
                    bndList[j].turnLine.add(arr[i])
                    delta = 0.0
                }
            }

            if (bndList[j].turnLine.isNotEmpty()) {
                bndList[j].turnLine.add(
                    vec3(
                        bndList[j].turnLine[0].easting,
                        bndList[j].turnLine[0].northing,
                        bndList[j].turnLine[0].heading
                    )
                )
            }
        }
    }
}

