package com.agopengps.classes


import com.agopengps.drive.FormGPS
import com.agopengps.drive.MainActivity

class CModuleComm(private val mf: FormGPS) {
    //Critical Safety Properties
    var isOutOfBounds = true

    // ---- Section control switches to AOG  ---------------------------------------------------------
    //PGN - 32736 - 127.249 0x7FF9
    val ss = ByteArray(9)
    val ssP = ByteArray(9)

    val swHeader = 0
    val swMain = 1
    val swReserve = 2
    val swReserve2 = 3
    val swNumSections = 4
    val swOnGr0 = 5
    val swOffGr0 = 6
    val swOnGr1 = 7
    val swOffGr1 = 8

    var pwmDisplay = 0
    var actualSteerAngleDegrees = 0.0
    var actualSteerAngleChart = 0
    var sensorData = -1

    //for the workswitch
    var isWorkSwitchActiveLow = true
    var isRemoteWorkSystemOn = false
    var isWorkSwitchEnabled = false
    var isWorkSwitchManualSections = false
    var isSteerWorkSwitchManualSections = false
    var isSteerWorkSwitchEnabled = false

    var workSwitchHigh = false
    var oldWorkSwitchHigh = false
    var steerSwitchHigh = false
    var oldSteerSwitchHigh = false
    var oldSteerSwitchRemote = false

    init {
        //WorkSwitch logic
        isRemoteWorkSystemOn = false
        //does a low, grounded out, mean on
        isWorkSwitchActiveLow = true
    }

    //Called from "OpenGL.Designer.cs" when required
    fun checkWorkAndSteerSwitch() {
        //AutoSteerAuto button enable - Ray Bear inspired code - Thx Ray!
        if (mf.ahrs.isAutoSteerAuto && steerSwitchHigh != oldSteerSwitchRemote) {
            oldSteerSwitchRemote = steerSwitchHigh
            //steerSwitch is active low
            if (steerSwitchHigh == mf.isBtnAutoSteerOn) {
                mf.btnAutoSteer.performClick()
            }
        }

        if (isRemoteWorkSystemOn) {
            if (isWorkSwitchEnabled && (oldWorkSwitchHigh != workSwitchHigh)) {
                oldWorkSwitchHigh = workSwitchHigh

                if (workSwitchHigh != isWorkSwitchActiveLow) {
                    if (isWorkSwitchManualSections) {
                        if (mf.manualBtnState != BtnStates.ON)
                            mf.btnSectionMasterManual.performClick()
                    } else {
                        if (mf.autoBtnState != BtnStates.AUTO)
                            mf.btnSectionMasterAuto.performClick()
                    }
                } else {
                    //Checks both on-screen buttons, performs click if button is not off
                    if (mf.autoBtnState != BtnStates.OFF)
                        mf.btnSectionMasterAuto.performClick()
                    if (mf.manualBtnState != BtnStates.OFF)
                        mf.btnSectionMasterManual.performClick()
                }
            }

            if (isSteerWorkSwitchEnabled && (oldSteerSwitchHigh != steerSwitchHigh)) {
                oldSteerSwitchHigh = steerSwitchHigh

                if ((mf.isBtnAutoSteerOn && mf.ahrs.isAutoSteerAuto)
                    || !mf.ahrs.isAutoSteerAuto && !steerSwitchHigh) {
                    if (isSteerWorkSwitchManualSections) {
                        if (mf.manualBtnState != BtnStates.ON)
                            mf.btnSectionMasterManual.performClick()
                    } else {
                        if (mf.autoBtnState != BtnStates.AUTO)
                            mf.btnSectionMasterAuto.performClick()
                    }
                } else {
                    //Checks both on-screen buttons, performs click if button is not off
                    if (mf.autoBtnState != BtnStates.OFF)
                        mf.btnSectionMasterAuto.performClick()
                    if (mf.manualBtnState != BtnStates.OFF)
                        mf.btnSectionMasterManual.performClick()
                }
            }
        }
    }
}

/*
// Assuming this enum exists in your Kotlin project
enum class BtnStates {
    OFF,
    ON,
    AUTO
}*/