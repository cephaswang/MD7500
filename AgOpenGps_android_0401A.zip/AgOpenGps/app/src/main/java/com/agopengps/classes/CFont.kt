package com.agopengps.classes

import com.agopengps.drive.FormGPS
import javax.microedition.khronos.opengles.GL10
import com.agopengps.drive.MainActivity
import kotlin.math.*

class CFont(private val mf: FormGPS) {
    companion object {
        const val GLYPHS_PER_LINE = 16
        const val GLYPH_LINE_COUNT = 16
        const val GLYPH_WIDTH = 16
        const val GLYPH_HEIGHT = 32
        const val CHAR_X_SPACING = 16
        const val TEXTURE_WIDTH = 256
        const val TEXTURE_HEIGHT = 256
    }

    var isFontOn: Boolean = true

    fun drawTextVehicle(x: Double, y: Double, text: String, size: Double = 1.0) {
        mf.gl.glPushMatrix()

        var adjustedSize = size * -mf.camera.camSetDistance
        adjustedSize = adjustedSize.pow(0.8) / 800

        // 2D
        if (mf.camera.camPitch > -58) {
            if (!mf.camera.camFollowing) {
                mf.gl.glRotatef(mf.camHeading.toFloat(), 0f, 0f, 1f)
                val adjustedY = y * 1.2
                drawTextInternal(x, adjustedY, text, adjustedSize, true)
            } else {
                val adjustedY = y * 1.2
                mf.gl.glTranslatef(x.toFloat(), adjustedY.toFloat(), 0f)
                drawTextInternal(0.0, 0.0, text, adjustedSize, true)
            }
        }
        // 3D
        else {
            if (!mf.camera.camFollowing) {
                mf.gl.glRotatef(90f, 1f, 0f, 0f)
                mf.gl.glRotatef(mf.camHeading.toFloat(), 0f, 1f, 0f)
                val adjustedY = y * 0.3
                drawTextInternal(x, adjustedY, text, adjustedSize, true)
            } else {
                mf.gl.glRotatef(-mf.camera.camPitch.toFloat(), 1f, 0f, 0f)
                val adjustedY = y * 0.3
                drawTextInternal(x, adjustedY, text, adjustedSize, true)
            }
        }

        mf.gl.glPopMatrix()
    }

    fun drawText3D(x1: Double, y1: Double, text: String, size: Double = 1.0) {
        mf.gl.glPushMatrix()
        mf.gl.glTranslatef(x1.toFloat(), y1.toFloat(), 0f)

        var adjustedSize = if (mf.camera.camPitch < -45) {
            mf.gl.glRotatef(90f, 1f, 0f, 0f)
            if (mf.camera.camFollowing) {
                mf.gl.glRotatef(-mf.camHeading.toFloat(), 0f, 1f, 0f)
            }
            val tempSize = -mf.camera.camSetDistance
            tempSize.pow(0.8) / 800
        } else {
            if (mf.camera.camFollowing) {
                mf.gl.glRotatef(-mf.camHeading.toFloat(), 0f, 0f, 1f)
            }
            val tempSize = -mf.camera.camSetDistance
            tempSize.pow(0.85) / 1000
        }

        drawTextInternal(0.0, 0.0, text, adjustedSize, false)
        mf.gl.glPopMatrix()
    }

    fun drawText3DNoGPS(x1: Double, y1: Double, text: String, size: Double = 1.0) {
        mf.gl.glPushMatrix()
        mf.gl.glTranslatef(x1.toFloat(), y1.toFloat(), 0f)
        mf.gl.glRotatef(90f, 1f, 0f, 0f)

        val adjustedSize = 40.0.pow(0.8) / 800
        drawTextInternal(0.0, 0.0, text, adjustedSize, false)
        mf.gl.glPopMatrix()
    }

    fun drawText(x: Double, y: Double, text: String, size: Double = 1.0) {
        drawTextInternal(x, y, text, size, false)
    }

    private fun drawTextInternal(x: Double, y: Double, text: String, size: Double, flipTexture: Boolean) {
        mf.gl.glBindTexture(GL10.GL_TEXTURE_2D, mf.textures[MainActivity.Textures.FONT.ordinal])
        mf.gl.glEnable(GL10.GL_TEXTURE_2D)
        mf.gl.glBegin(GL10.GL_QUADS)

        val uStep = GLYPH_WIDTH.toDouble() / TEXTURE_WIDTH
        val vStep = GLYPH_HEIGHT.toDouble() / TEXTURE_HEIGHT

        var currentX = x
        for (char in text) {
            val u = (char.code % GLYPHS_PER_LINE) * uStep
            val v = (char.code / GLYPHS_PER_LINE) * vStep

            if (flipTexture) {
                mf.gl.glTexCoord2f(u.toFloat(), (v + vStep).toFloat())
                mf.gl.glVertex2f(currentX.toFloat(), y.toFloat())

                mf.gl.glTexCoord2f((u + uStep).toFloat(), (v + vStep).toFloat())
                mf.gl.glVertex2f((currentX + GLYPH_WIDTH * size).toFloat(), y.toFloat())

                mf.gl.glTexCoord2f((u + uStep).toFloat(), v.toFloat())
                mf.gl.glVertex2f((currentX + GLYPH_WIDTH * size).toFloat(), (y + GLYPH_HEIGHT * size).toFloat())

                mf.gl.glTexCoord2f(u.toFloat(), v.toFloat())
                mf.gl.glVertex2f(currentX.toFloat(), (y + GLYPH_HEIGHT * size).toFloat())
            } else {
                mf.gl.glTexCoord2f(u.toFloat(), v.toFloat())
                mf.gl.glVertex2f(currentX.toFloat(), y.toFloat())

                mf.gl.glTexCoord2f((u + uStep).toFloat(), v.toFloat())
                mf.gl.glVertex2f((currentX + GLYPH_WIDTH * size).toFloat(), y.toFloat())

                mf.gl.glTexCoord2f((u + uStep).toFloat(), (v + vStep).toFloat())
                mf.gl.glVertex2f((currentX + GLYPH_WIDTH * size).toFloat(), (y + GLYPH_HEIGHT * size).toFloat())

                mf.gl.glTexCoord2f(u.toFloat(), (v + vStep).toFloat())
                mf.gl.glVertex2f(currentX.toFloat(), (y + GLYPH_HEIGHT * size).toFloat())
            }

            currentX += CHAR_X_SPACING * size
        }

        mf.gl.glEnd()
        mf.gl.glDisable(GL10.GL_TEXTURE_2D)
    }
}