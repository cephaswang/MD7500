package com.agopengps.classes


import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng

class CCamera(private val mf: FormGPS) {

    private var camPosX: Double = 0.0
    private var camPosY: Double = 0.0
    private val camPosZ: Double = 0.0

    private var camYaw: Double = 0.0

    var camPitch: Double
    var panX = 0.0
    var panY = 0.0
    var camSetDistance = -75.0

    var gridZoom: Double = 0.0

    var zoomValue = 15.0
    var previousZoom = 25.0

    var camFollowing: Boolean
    var camMode = 0
    var camSmoothFactor: Double

    init {
        camPitch = mf.settings.setDisplay_camPitch
        zoomValue = mf.settings.setDisplay_camZoom
        camSmoothFactor = mf.settings.setDisplay_camSmooth
        // 從設置中獲取攝影機俯仰角和縮放值
        camFollowing = true
    }

    fun SetWorldCam(_fixPosX: Double, _fixPosY: Double, _fixHeading: Double, googleMap: GoogleMap?) {
        camPosX = _fixPosX
        camPosY = _fixPosY
        camYaw = _fixHeading

        googleMap?.let { map ->
            // 將 camPosX 和 camPosY 視為經緯度坐標
            val targetPosition = LatLng(camPosY, camPosX)

            // 計算攝影機距離和縮放級別
            val adjustedZoom = (zoomValue + (camSetDistance * 0.5 / 75.0)).toFloat()

            // 構建 Google Maps 的 CameraPosition
            val cameraPosition = CameraPosition.Builder()
                .target(targetPosition)           // 目標位置
                .zoom(adjustedZoom)              // 縮放級別
                .tilt(camPitch.toFloat())        // 俯仰角
                .bearing(camYaw.toFloat())       // 航向角 (偏航)
                .build()

            // 根據 camFollowing 模式決定是否應用航向
            if (camFollowing) {
                // 追蹤模式：使用目標的航向
                map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition))
            } else {
                // 固定模式：不應用航向
                val fixedCamera = CameraPosition.Builder()
                    .target(targetPosition)
                    .zoom(adjustedZoom)
                    .tilt(camPitch.toFloat())
                    .build()
                map.animateCamera(CameraUpdateFactory.newCameraPosition(fixedCamera))
            }

            // 平移效果 (模擬 panX, panY)
            if (panX != 0.0 || panY != 0.0) {
                map.moveCamera(CameraUpdateFactory.scrollBy(panX.toFloat(), panY.toFloat()))
            }
        }
    }
}