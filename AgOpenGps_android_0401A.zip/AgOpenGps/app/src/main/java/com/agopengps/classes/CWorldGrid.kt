package com.agopengps.classes

import android.opengl.GLES20
import com.agopengps.drive.FormGPS
import com.agopengps.drive.MainActivity
import kotlin.math.round

class CWorldGrid(private val mf: FormGPS) {
    //Y
    var northingMax: Double = 0.0
    var northingMin: Double = 0.0

    //X
    var eastingMax: Double = 0.0
    var eastingMin: Double = 0.0

    //Y
    var northingMaxGeo: Double = 300.0
    var northingMinGeo: Double = -300.0

    //X
    var eastingMaxGeo: Double = 300.0
    var eastingMinGeo: Double = -300.0

    //Y
    var northingMaxRate: Double = 300.0
    var northingMinRate: Double = -300.0

    //X
    var eastingMaxRate: Double = 300.0
    var eastingMinRate: Double = -300.0

    var gridSize: Double = 6000.0
    var count: Double = 40.0
    var isGeoMap: Boolean = false
    var gridRotation: Double = 0.0

    init {
        // Initialization values are set as property initializers above
    }

    fun drawFieldSurface() {
        val field = if (mf.isDay) mf.fieldColorDay else mf.fieldColorNight

        //adjust bitmap zoom based on cam zoom
        count = when {
            mf.camera.zoomValue > 100 -> 4.0
            mf.camera.zoomValue > 80 -> 8.0
            mf.camera.zoomValue > 50 -> 16.0
            mf.camera.zoomValue > 20 -> 32.0
            mf.camera.zoomValue > 10 -> 64.0
            else -> 80.0
        }

        GLES20.glColor3f(field.red / 255f, field.green / 255f, field.blue / 255f)
        if (mf.isTextureOn) {
            GLES20.glEnable(GLES20.GL_TEXTURE_2D)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mf.texture[MainActivity.Textures.FLOOR.ordinal])
        }

        GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP)
        GLES20.glTexCoord2f(0f, 0f)
        GLES20.glVertex3f(eastingMin.toFloat(), northingMax.toFloat(), -0.10f)
        GLES20.glTexCoord2f(count.toFloat(), 0f)
        GLES20.glVertex3f(eastingMax.toFloat(), northingMax.toFloat(), -0.10f)
        GLES20.glTexCoord2f(0f, count.toFloat())
        GLES20.glVertex3f(eastingMin.toFloat(), northingMin.toFloat(), -0.10f)
        GLES20.glTexCoord2f(count.toFloat(), count.toFloat())
        GLES20.glVertex3f(eastingMax.toFloat(), northingMin.toFloat(), -0.10f)
        GLES20.glEnd()

        if (isGeoMap) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mf.texture[MainActivity.Textures.BING_GRID.ordinal])
            GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP)
            GLES20.glColor4f(0.6f, 0.6f, 0.6f, 0.5f)
            GLES20.glTexCoord2f(0f, 0f)
            GLES20.glVertex3f(eastingMinGeo.toFloat(), northingMaxGeo.toFloat(), -0.05f)
            GLES20.glTexCoord2f(1f, 0f)
            GLES20.glVertex3f(eastingMaxGeo.toFloat(), northingMaxGeo.toFloat(), -0.05f)
            GLES20.glTexCoord2f(0f, 1f)
            GLES20.glVertex3f(eastingMinGeo.toFloat(), northingMinGeo.toFloat(), -0.05f)
            GLES20.glTexCoord2f(1f, 1f)
            GLES20.glVertex3f(eastingMaxGeo.toFloat(), northingMinGeo.toFloat(), -0.05f)
            GLES20.glEnd()
        }
        GLES20.glDisable(GLES20.GL_TEXTURE_2D)
    }

    fun drawWorldGrid(gridZoom: Double) {
        GLES20.glRotatef(-gridRotation.toFloat(), 0f, 0f, 1.0f)

        if (mf.isDay) {
            GLES20.glColor3f(0.25f, 0.25f, 0.25f)
        } else {
            GLES20.glColor3f(0.12f, 0.12f, 0.12f)
        }
        GLES20.glLineWidth(1f)
        GLES20.glBegin(GLES20.GL_LINES)

        var num = round(eastingMin / gridZoom) * gridZoom
        while (num < eastingMax) {
            if (num >= eastingMin) {
                GLES20.glVertex3f(num.toFloat(), northingMax.toFloat(), 0.1f)
                GLES20.glVertex3f(num.toFloat(), northingMin.toFloat(), 0.1f)
            }
            num += gridZoom
        }

        var num2 = round(northingMin / gridZoom) * gridZoom
        while (num2 < northingMax) {
            if (num2 >= northingMin) {
                GLES20.glVertex3f(eastingMax.toFloat(), num2.toFloat(), 0.1f)
                GLES20.glVertex3f(eastingMin.toFloat(), num2.toFloat(), 0.1f)
            }
            num2 += gridZoom
        }

        GLES20.glEnd()
        GLES20.glRotatef(gridRotation.toFloat(), 0f, 0f, 1.0f)
    }

    fun checkZoomWorldGrid(northing: Double, easting: Double) {
        val n = round(northing / (gridSize / count * 2)) * (gridSize / count * 2)
        val e = round(easting / (gridSize / count * 2)) * (gridSize / count * 2)

        northingMax = n + gridSize
        northingMin = n - gridSize
        eastingMax = e + gridSize
        eastingMin = e - gridSize
    }
}