package com.agopengps.classes

import android.graphics.Color
import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import kotlin.math.*


class CTool(private val mf: FormGPS) {
    var width: Double = 0.0
    var halfWidth: Double = 0.0
    var contourWidth: Double = 0.0
    var farLeftPosition: Double = 0.0
    var farLeftSpeed: Double = 0.0
    var farRightPosition: Double = 0.0
    var farRightSpeed: Double = 0.0

    var overlap: Double = 0.0
    var trailingHitchLength: Double = 0.0
    var tankTrailingHitchLength: Double = 0.0
    var trailingToolToPivotLength: Double = 0.0
    var offset: Double = 0.0

    var lookAheadOffSetting: Double = 0.0
    var lookAheadOnSetting: Double = 0.0
    var turnOffDelay: Double = 0.0

    var lookAheadDistanceOnPixelsLeft: Double = 0.0
    var lookAheadDistanceOnPixelsRight: Double = 0.0
    var lookAheadDistanceOffPixelsLeft: Double = 0.0
    var lookAheadDistanceOffPixelsRight: Double = 0.0

    var isToolTrailing: Boolean = false
    var isToolTBT: Boolean = false
    var isToolRearFixed: Boolean = false
    var isToolFrontFixed: Boolean = false

    var isMultiColoredSections: Boolean = false
    var isSectionOffWhenOut: Boolean = false
    var toolAttachType: String = ""

    var hitchLength: Double = 0.0

    var numOfSections: Int = 0
    var minCoverage: Int = 0

    var areAllSectionBtnsOn: Boolean = true
    var isLeftSideInHeadland: Boolean = true
    var isRightSideInHeadland: Boolean = true
    var isSectionsNotZones: Boolean = true

    var rpXPosition: Int = 0
    var rpWidth: Int = 0

    private var textRotate: Double = 0.0

    var secColors: Array<Int> = Array(16) { Color.BLACK } // 使用 Android Color

    var zones: Int = 0
    var zoneRanges: IntArray = IntArray(9)

    var isDisplayTramControl: Boolean = false

    init {
        // 從設置中獲取車輛特定參數
        trailingToolToPivotLength = Properties.Settings.Default.setTool_trailingToolToPivotLength
        width = Properties.Settings.Default.setVehicle_toolWidth
        overlap = Properties.Settings.Default.setVehicle_toolOverlap
        offset = Properties.Settings.Default.setVehicle_toolOffset

        trailingHitchLength = Properties.Settings.Default.setTool_toolTrailingHitchLength
        tankTrailingHitchLength = Properties.Settings.Default.setVehicle_tankTrailingHitchLength
        hitchLength = Properties.Settings.Default.setVehicle_hitchLength

        isToolRearFixed = Properties.Settings.Default.setTool_isToolRearFixed
        isToolTrailing = Properties.Settings.Default.setTool_isToolTrailing
        isToolTBT = Properties.Settings.Default.setTool_isToolTBT
        isToolFrontFixed = Properties.Settings.Default.setTool_isToolFront

        lookAheadOnSetting = Properties.Settings.Default.setVehicle_toolLookAheadOn
        lookAheadOffSetting = Properties.Settings.Default.setVehicle_toolLookAheadOff
        turnOffDelay = Properties.Settings.Default.setVehicle_toolOffDelay

        isSectionOffWhenOut = Properties.Settings.Default.setTool_isSectionOffWhenOut
        isSectionsNotZones = Properties.Settings.Default.setTool_isSectionsNotZones

        numOfSections = if (isSectionsNotZones) {
            Properties.Settings.Default.setVehicle_numSections
        } else {
            Properties.Settings.Default.setTool_numSectionsMulti
        }

        minCoverage = Properties.Settings.Default.setVehicle_minCoverage
        isMultiColoredSections = Properties.Settings.Default.setColor_isMultiColorSections

        // 初始化 secColors，使用 Android Color
        secColors[0] = Properties.Settings.Default.setColor_sec01.checkColorFor255()
        secColors[1] = Properties.Settings.Default.setColor_sec02.checkColorFor255()
        secColors[2] = Properties.Settings.Default.setColor_sec03.checkColorFor255()
        secColors[3] = Properties.Settings.Default.setColor_sec04.checkColorFor255()
        secColors[4] = Properties.Settings.Default.setColor_sec05.checkColorFor255()
        secColors[5] = Properties.Settings.Default.setColor_sec06.checkColorFor255()
        secColors[6] = Properties.Settings.Default.setColor_sec07.checkColorFor255()
        secColors[7] = Properties.Settings.Default.setColor_sec08.checkColorFor255()
        secColors[8] = Properties.Settings.Default.setColor_sec09.checkColorFor255()
        secColors[9] = Properties.Settings.Default.setColor_sec10.checkColorFor255()
        secColors[10] = Properties.Settings.Default.setColor_sec11.checkColorFor255()
        secColors[11] = Properties.Settings.Default.setColor_sec12.checkColorFor255()
        secColors[12] = Properties.Settings.Default.setColor_sec13.checkColorFor255()
        secColors[13] = Properties.Settings.Default.setColor_sec14.checkColorFor255()
        secColors[14] = Properties.Settings.Default.setColor_sec15.checkColorFor255()
        secColors[15] = Properties.Settings.Default.setColor_sec16.checkColorFor255()

        val words = Properties.Settings.Default.setTool_zones.split(",")
        zones = words[0].toInt()

        for (i in words.indices) {
            zoneRanges[i] = words[i].toInt()
        }

        isDisplayTramControl = Properties.Settings.Default.setTool_isDisplayTramControl
    }

    fun DrawTool() {
        val mMap: GoogleMap? = mf.mMap // 假設 FormGPS 中有 mMap 屬性
        mMap?.clear() // 清除地圖上的舊繪圖

        // 計算車輛中心位置（假設以 pivotAxlePos 為基準）
        val pivotLatLng = LatLng(mf.pivotAxlePos.northing, mf.pivotAxlePos.easting)
        val headingRad = mf.fixHeading // 車輛朝向（弧度）

        // 計算 hitch 的位置
        val hitchOffsetX = sin(headingRad) * hitchLength
        val hitchOffsetY = cos(headingRad) * hitchLength
        val hitchLatLng = offsetLatLng(pivotLatLng, hitchOffsetY, hitchOffsetX)

        // 處理 trailing 和 TBT 邏輯
        val trailingTank: Double
        val trailingTool: Double
        if (isToolTrailing) {
            trailingTank = tankTrailingHitchLength
            trailingTool = trailingHitchLength
        } else {
            trailingTank = 0.0
            trailingTool = 0.0
        }

        var toolLatLng = hitchLatLng
        var toolHeadingRad = headingRad

        // 如果有 tow between hitch (TBT)
        if (isToolTBT && isToolTrailing) {
            // 計算 tank 的位置和朝向
            val tankHeadingRad = mf.tankPos.heading
            val tankOffsetY = trailingTank * cos(tankHeadingRad)
            val tankOffsetX = trailingTank * sin(tankHeadingRad)
            val tankLatLng = offsetLatLng(hitchLatLng, tankOffsetY, tankOffsetX)

            // 繪製 tank hitch（用 Polyline 表示）
            mMap?.addPolyline(
                PolylineOptions()
                    .add(hitchLatLng, tankLatLng)
                    .width(6f)
                    .color(Color.BLACK)
            )
            mMap?.addPolyline(
                PolylineOptions()
                    .add(hitchLatLng, tankLatLng)
                    .width(1f)
                    .color(Color.rgb(195, 194, 82)) // 0.765, 0.76, 0.32
            )

            // 更新 tool 的位置和朝向
            toolHeadingRad = mf.toolPivotPos.heading
            toolLatLng = tankLatLng
        } else {
            toolHeadingRad = mf.toolPivotPos.heading
        }

        // 如果是 trailing，繪製 hitch
        if (isToolTrailing) {
            val toolOffsetY = trailingTool * cos(toolHeadingRad)
            val toolOffsetX = trailingTool * sin(toolHeadingRad)
            val trailingToolLatLng = offsetLatLng(toolLatLng, toolOffsetY, toolOffsetX)

            // 繪製 hitch（用 Polyline）
            mMap?.addPolyline(
                PolylineOptions()
                    .add(toolLatLng, trailingToolLatLng)
                    .width(6f)
                    .color(Color.BLACK)
            )
            mMap?.addPolyline(
                PolylineOptions()
                    .add(toolLatLng, trailingToolLatLng)
                    .width(1f)
                    .color(Color.rgb(179, 102, 51)) // 0.7, 0.4, 0.2
            )

            // 更新 tool 的最終位置
            toolLatLng = offsetLatLng(trailingToolLatLng, -trailingToolToPivotLength * cos(toolHeadingRad), -trailingToolToPivotLength * sin(toolHeadingRad))
        }

        // 如果任務已開始，繪製 lookahead 線條和區段
        if (mf.isJobStarted) {
            // Lookahead 線條
            val leftOnLatLng = offsetLatLng(toolLatLng, lookAheadDistanceOnPixelsLeft * 0.1 * cos(toolHeadingRad), farLeftPosition + lookAheadDistanceOnPixelsLeft * 0.1 * sin(toolHeadingRad))
            val rightOnLatLng = offsetLatLng(toolLatLng, lookAheadDistanceOnPixelsRight * 0.1 * cos(toolHeadingRad), farRightPosition + lookAheadDistanceOnPixelsRight * 0.1 * sin(toolHeadingRad))
            val leftOffLatLng = offsetLatLng(toolLatLng, lookAheadDistanceOffPixelsLeft * 0.1 * cos(toolHeadingRad), farLeftPosition + lookAheadDistanceOffPixelsLeft * 0.1 * sin(toolHeadingRad))
            val rightOffLatLng = offsetLatLng(toolLatLng, lookAheadDistanceOffPixelsRight * 0.1 * cos(toolHeadingRad), farRightPosition + lookAheadDistanceOffPixelsRight * 0.1 * sin(toolHeadingRad))

            mMap?.addPolyline(
                PolylineOptions()
                    .add(leftOnLatLng, rightOnLatLng)
                    .width(3f)
                    .color(Color.rgb(51, 179, 51)) // 0.20, 0.7, 0.2
            )
            mMap?.addPolyline(
                PolylineOptions()
                    .add(leftOffLatLng, rightOffLatLng)
                    .width(3f)
                    .color(Color.rgb(179, 51, 51)) // 0.70, 0.2, 0.2
            )

            if (mf.vehicle.isHydLiftOn) {
                val hydLeftLatLng = offsetLatLng(toolLatLng, mf.vehicle.hydLiftLookAheadDistanceLeft * 0.1 * cos(toolHeadingRad), mf.section[0].positionLeft)
                val hydRightLatLng = offsetLatLng(toolLatLng, mf.vehicle.hydLiftLookAheadDistanceRight * 0.1 * cos(toolHeadingRad), mf.section[numOfSections - 1].positionRight)
                mMap?.addPolyline(
                    PolylineOptions()
                        .add(hydLeftLatLng, hydRightLatLng)
                        .width(3f)
                        .color(Color.rgb(179, 51, 183)) // 0.70, 0.2, 0.72
                )
            }

            // 繪製區段
            val hite = min(max(mf.camera.camSetDistance / -150, 1.0), 8.0) // 高度調整
            for (j in 0 until numOfSections) {
                val section = mf.section[j]
                val leftLatLng = offsetLatLng(toolLatLng, -hite * cos(toolHeadingRad), section.positionLeft)
                val rightLatLng = offsetLatLng(toolLatLng, -hite * cos(toolHeadingRad), section.positionRight)
                val midLatLng = offsetLatLng(toolLatLng, -hite * 1.5 * cos(toolHeadingRad), (section.positionRight + section.positionLeft) / 2)

                val color = if (section.isSectionOn) {
                    if (section.sectionBtnState == btnStates.Auto) {
                        if (section.isMappingOn) Color.rgb(0, 242, 0) // 0.0, 0.95, 0.0
                        else Color.rgb(247, 77, 247) // 0.970, 0.30, 0.970
                    } else Color.rgb(247, 247, 0) // 0.97, 0.97, 0
                } else {
                    if (!section.isMappingOn) Color.rgb(242, 51, 51) // 0.950, 0.2, 0.2
                    else Color.rgb(0, 64, 247) // 0.00, 0.250, 0.97
                }

                // 使用 Polyline 繪製區段（簡化為線條）
                mMap?.addPolyline(
                    PolylineOptions()
                        .add(leftLatLng, midLatLng, rightLatLng)
                        .width(2f)
                        .color(color)
                )
            }

            // 繪製 zones
            if (!isSectionsNotZones && zones > 0 && mf.camera.camSetDistance > -150) {
                for (i in 1 until zones) {
                    val zoneLeftLatLng = offsetLatLng(toolLatLng, -0.4 * cos(toolHeadingRad), mf.section[zoneRanges[i]].positionLeft)
                    val zoneRightLatLng = offsetLatLng(toolLatLng, 0.2 * cos(toolHeadingRad), mf.section[zoneRanges[i]].positionLeft)
                    mMap?.addPolyline(
                        PolylineOptions()
                            .add(zoneLeftLatLng, zoneRightLatLng)
                            .width(2f)
                            .color(Color.rgb(128, 204, 242)) // 0.5, 0.80, 0.950
                    )
                }
            }

            // 繪製 tram dots
            if (isDisplayTramControl && mf.tram.displayMode != 0 && mf.camera.camSetDistance > -300) {
                val pointSize = if (mf.camera.camSetDistance > -100) 12.0 else 8.0
                if (mf.tram.isOuter) {
                    val rightLatLng = offsetLatLng(toolLatLng, 0.0, farRightPosition - mf.tram.halfWheelTrack)
                    val leftLatLng = offsetLatLng(toolLatLng, 0.0, farLeftPosition + mf.tram.halfWheelTrack)

                    mMap?.addCircle(
                        CircleOptions()
                            .center(rightLatLng)
                            .radius(pointSize)
                            .fillColor(if (mf.tram.controlByte and 1 == 1) Color.rgb(0, 229, 101) else Color.BLACK)
                            .strokeWidth(0f)
                    )
                    mMap?.addCircle(
                        CircleOptions()
                            .center(leftLatLng)
                            .radius(pointSize)
                            .fillColor(if (mf.tram.controlByte and 2 == 2) Color.rgb(0, 229, 100) else Color.BLACK)
                            .strokeWidth(0f)
                    )
                } else {
                    val rightLatLng = offsetLatLng(toolLatLng, 0.0, mf.tram.halfWheelTrack)
                    val leftLatLng = offsetLatLng(toolLatLng, 0.0, -mf.tram.halfWheelTrack)

                    mMap?.addCircle(
                        CircleOptions()
                            .center(rightLatLng)
                            .radius(pointSize)
                            .fillColor(if (mf.tram.controlByte and 1 == 1) Color.rgb(0, 229, 101) else Color.BLACK)
                            .strokeWidth(0f)
                    )
                    mMap?.addCircle(
                        CircleOptions()
                            .center(leftLatLng)
                            .radius(pointSize)
                            .fillColor(if (mf.tram.controlByte and 2 == 2) Color.rgb(0, 229, 100) else Color.BLACK)
                            .strokeWidth(0f)
                    )
                }
            }
        }
    }

    // 輔助方法：計算偏移後的 LatLng
    private fun offsetLatLng(base: LatLng, northOffset: Double, eastOffset: Double): LatLng {
        val earthRadius = 6378137.0 // 地球半徑（公尺）
        val newLat = base.latitude + (northOffset / earthRadius) * (180.0 / PI)
        val newLon = base.longitude + (eastOffset / (earthRadius * cos(PI * base.latitude / 180.0))) * (180.0 / PI)
        return LatLng(newLat, newLon)
    }
}

// 假設的外部類（僅用於編譯，不實現）
object Properties {
    object Settings {
        object Default {
            val setTool_trailingToolToPivotLength: Double get() = 0.0
            val setVehicle_toolWidth: Double get() = 0.0
            val setVehicle_toolOverlap: Double get() = 0.0
            val setVehicle_toolOffset: Double get() = 0.0
            val setTool_toolTrailingHitchLength: Double get() = 0.0
            val setVehicle_tankTrailingHitchLength: Double get() = 0.0
            val setVehicle_hitchLength: Double get() = 0.0
            val setTool_isToolRearFixed: Boolean get() = false
            val setTool_isToolTrailing: Boolean get() = false
            val setTool_isToolTBT: Boolean get() = false
            val setTool_isToolFront: Boolean get() = false
            val setVehicle_toolLookAheadOn: Double get() = 0.0
            val setVehicle_toolLookAheadOff: Double get() = 0.0
            val setVehicle_toolOffDelay: Double get() = 0.0
            val setTool_isSectionOffWhenOut: Boolean get() = false
            val setTool_isSectionsNotZones: Boolean get() = true
            val setVehicle_numSections: Int get() = 0
            val setTool_numSectionsMulti: Int get() = 0
            val setVehicle_minCoverage: Int get() = 0
            val setColor_isMultiColorSections: Boolean get() = false
            val setColor_sec01: Int get() = Color.BLACK
            val setColor_sec02: Int get() = Color.BLACK
            val setColor_sec03: Int get() = Color.BLACK
            val setColor_sec04: Int get() = Color.BLACK
            val setColor_sec05: Int get() = Color.BLACK
            val setColor_sec06: Int get() = Color.BLACK
            val setColor_sec07: Int get() = Color.BLACK
            val setColor_sec08: Int get() = Color.BLACK
            val setColor_sec09: Int get() = Color.BLACK
            val setColor_sec10: Int get() = Color.BLACK
            val setColor_sec11: Int get() = Color.BLACK
            val setColor_sec12: Int get() = Color.BLACK
            val setColor_sec13: Int get() = Color.BLACK
            val setColor_sec14: Int get() = Color.BLACK
            val setColor_sec15: Int get() = Color.BLACK
            val setColor_sec16: Int get() = Color.BLACK
            val setTool_zones: String get() = "0"
            val setTool_isDisplayTramControl: Boolean get() = false
        }
    }
}

fun Int.checkColorFor255(): Int = this // 假設的擴展方法，Android Color 不需要此檢查
enum class btnStates { Auto } // 假設的列舉