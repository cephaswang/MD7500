package com.agopengps.drive

import android.graphics.Color
import android.location.Location
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.common.base.Stopwatch
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import kotlin.math.max


class UDPComm(private val mf: FormGPS) {
    // App Sockets
    private lateinit var loopBackSocket: DatagramSocket

    // Endpoints of modules
    private val epAgIO = InetAddress.getByName("127.255.255.255") to 17777
    private val endPointLoopBack = InetAddress.getByName("127.0.0.1") to 0

    // Data stream
    private val loopBuffer = ByteArray(1024)

    // Status
    private var missedSentenceCount = 0
    private var udpWatchLimit = 70
    private val udpWatch = Stopwatch.createUnstarted()

    // Google Maps Marker
    private var vehicleMarker: Marker? = null

    private fun receiveFromAgIO(data: ByteArray) {
        if (data.size > 4 && data[0] == 0x80.toByte() && data[1] == 0x81.toByte()) {
            val length = max((data[4].toInt() and 0xFF) + 5, 5)

            if (data.size > length) {
                var ckA: Byte = 0
                for (j in 2 until length) {
                    ckA = (ckA + data[j]).toByte()
                }

                if (data[length] != ckA) {
                    return
                }
            } else {
                return
            }

            when (data[3].toInt() and 0xFF) {
                0xD6 -> {
                    if (udpWatch.elapsedMillis() < udpWatchLimit) {
                        missedSentenceCount++
                        return
                    }
                    udpWatch.reset()
                    udpWatch.start()

                    val lon = ByteBuffer.wrap(data, 5, 8).order(ByteOrder.LITTLE_ENDIAN).double
                    val lat = ByteBuffer.wrap(data, 13, 8).order(ByteOrder.LITTLE_ENDIAN).double

                    if (lon != Double.MAX_VALUE && lat != Double.MAX_VALUE) {
                        if (mf.timerSim.isEnabled) {
                            disableSim()
                        }

                        mf.pn.longitude = lon
                        mf.pn.latitude = lat

                        mf.pn.convertWGS84ToLocal(lat, lon)

                        // From dual antenna heading sentences
                        var temp = ByteBuffer.wrap(data, 21, 4).order(ByteOrder.LITTLE_ENDIAN).float
                        if (temp != Float.MAX_VALUE) {
                            mf.pn.headingTrueDual = temp + mf.pn.headingTrueDualOffset
                            mf.pn.headingTrueDual = when {
                                mf.pn.headingTrueDual >= 360 -> mf.pn.headingTrueDual - 360
                                mf.pn.headingTrueDual < 0 -> mf.pn.headingTrueDual + 360
                                else -> mf.pn.headingTrueDual
                            }
                        }

                        // From single antenna sentences (VTG, RMC)
                        mf.pn.headingTrue =
                            ByteBuffer.wrap(data, 25, 4).order(ByteOrder.LITTLE_ENDIAN).float.toDouble()

                        // Always save the speed
                        temp = ByteBuffer.wrap(data, 29, 4).order(ByteOrder.LITTLE_ENDIAN).float
                        if (temp != Float.MAX_VALUE) {
                            mf.pn.vtgSpeed = temp.toDouble()
                        }

                        // Roll in degrees
                        temp = ByteBuffer.wrap(data, 33, 4).order(ByteOrder.LITTLE_ENDIAN).float
                        if (temp != Float.MAX_VALUE) {
                            if (mf.ahrs.isRollInvert) temp *= -1f
                            mf.ahrs.imuRoll = temp - mf.ahrs.rollZero
                        }
                        if (temp == Float.MIN_VALUE) {
                            mf.ahrs.imuRoll = 0.0
                        }

                        // Altitude in meters
                        temp = ByteBuffer.wrap(data, 37, 4).order(ByteOrder.LITTLE_ENDIAN).float
                        if (temp != Float.MAX_VALUE) {
                            mf.pn.altitude = temp.toDouble()
                        }

                        val sats = ByteBuffer.wrap(data, 41, 2)
                            .order(ByteOrder.LITTLE_ENDIAN).short.toInt() and 0xFFFF
                        if (sats != 0xFFFF) {
                            mf.pn.satellitesTracked = sats
                        }

                        val fix = data[43].toInt() and 0xFF
                        if (fix != 0xFF) {
                            mf.pn.fixQuality = fix
                        }

                        val hdop = ByteBuffer.wrap(data, 44, 2)
                            .order(ByteOrder.LITTLE_ENDIAN).short.toInt() and 0xFFFF
                        if (hdop != 0xFFFF) {
                            mf.pn.hdop = hdop * 0.01
                        }

                        val age = ByteBuffer.wrap(data, 46, 2)
                            .order(ByteOrder.LITTLE_ENDIAN).short.toInt() and 0xFFFF
                        if (age != 0xFFFF) {
                            mf.pn.age = age * 0.01
                        }

                        val imuHead = ByteBuffer.wrap(data, 48, 2)
                            .order(ByteOrder.LITTLE_ENDIAN).short.toInt() and 0xFFFF
                        if (imuHead != 0xFFFF) {
                            mf.ahrs.imuHeading = imuHead * 0.1
                        }

                        val imuRol = ByteBuffer.wrap(data, 50, 2)
                            .order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        if (imuRol != Short.MAX_VALUE.toInt()) {
                            var rollK = imuRol.toDouble()
                            if (mf.ahrs.isRollInvert) rollK *= -0.1
                            else rollK *= 0.1
                            rollK -= mf.ahrs.rollZero
                            mf.ahrs.imuRoll =
                                (mf.ahrs.imuRoll * mf.ahrs.rollFilter + rollK * (1 - mf.ahrs.rollFilter)).toFloat()
                                    .toDouble()
                        }

                        val imuPich = ByteBuffer.wrap(data, 52, 2)
                            .order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        if (imuPich != Short.MAX_VALUE.toInt()) {
                            mf.ahrs.imuPitch = imuPich.toDouble()
                        }

                        val imuYaw = ByteBuffer.wrap(data, 54, 2)
                            .order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                        if (imuYaw != Short.MAX_VALUE.toInt()) {
                            mf.ahrs.imuYawRate = imuYaw.toDouble()
                        }

                        mf.sentenceCounter = 0

                        // 創建 Location 物件並傳入車輛位置
                        val location = Location("gps").apply {
                            latitude = mf.pn.latitude
                            longitude = mf.pn.longitude
                            speed = speed.toFloat() // 速度（米/秒）
                            time = System.currentTimeMillis() // 當前時間
                            altitude = mf.pn.altitude // 海拔（若有）
                        }
                        mf.updateFixPosition(location)

                        // 更新 Google Maps 標記
                        updateVehicleMarkerOnMap()
                    }
                }

                0xD3 -> { // External IMU
                    if (data.size != 14) return
                    if (mf.ahrs.imuRoll > 25 || mf.ahrs.imuRoll < -25) mf.ahrs.imuRoll = 0.0

                    // Heading
                    mf.ahrs.imuHeading = (((data[6].toInt() shl 8) + data[5].toInt()).toShort() * 0.1f).toDouble()

                    // Roll
                    var rollK = ((data[8].toInt() shl 8) + data[7].toInt()).toShort().toDouble()
                    rollK *= if (mf.ahrs.isRollInvert) -0.1
                    else 0.1
                    rollK -= mf.ahrs.rollZero
                    mf.ahrs.imuRoll =
                        (mf.ahrs.imuRoll * mf.ahrs.rollFilter + rollK * (1 - mf.ahrs.rollFilter)).toDouble()

                    // Angular velocity
                    mf.ahrs.angVel =
                        (((data[10].toInt() shl 8) + data[9].toInt()).toShort() / -2f).toInt().toShort()

                    
                }

                0xD4 -> { // IMU disconnect PGN
                    if (data[5].toInt() and 0xFF == 1) {
                        mf.ahrs.imuHeading = 99999.0
                        mf.ahrs.imuRoll = 88888.0
                        mf.ahrs.angVel = 0
                    }
                    
                }

                253 -> { // Return from autosteer module
                    if (data.size != 14) return

                    // Steer angle actual
                    mf.mc.actualSteerAngleChart =
                        ((data[6].toInt() shl 8) + data[5].toInt()).toInt()
                    mf.mc.actualSteerAngleDegrees = mf.mc.actualSteerAngleChart * 0.01

                    // Heading
                    val head253 = ((data[8].toInt() shl 8) + data[7].toInt()).toShort()
                    if (head253 != 9999.toShort()) {
                        mf.ahrs.imuHeading = (head253 * 0.1f).toDouble()
                    }

                    // Roll
                    var rollK = ((data[10].toInt() shl 8) + data[9].toInt()).toShort().toDouble()
                    if (rollK != 8888.0) {
                        rollK *= if (mf.ahrs.isRollInvert) -0.1
                        else 0.1
                        rollK -= mf.ahrs.rollZero
                        mf.ahrs.imuRoll =
                            (mf.ahrs.imuRoll * mf.ahrs.rollFilter + rollK * (1 - mf.ahrs.rollFilter)).toDouble()
                    }

                    // Switch status
                    mf.mc.workSwitchHigh = (data[11].toInt() and 0x1) == 1
                    mf.mc.steerSwitchHigh = (data[11].toInt() and 0x2) == 2

                    // The pink steer dot reset
                    mf.steerModuleConnectedCounter = 0

                    // Actual PWM
                    mf.mc.pwmDisplay = data[12].toInt() and 0xFF


                }

                250 -> {
                    if (data.size != 14) return
                    mf.mc.sensorData = data[5].toInt() and 0xFF

                }

                221 -> { // DD
                    if (data.size < 9) return

                    if (isHardwareMessages) {
                        lblHardwareMessage.text =
                            String(data, 7, data[4].toInt() and 0xFF - 2, Charsets.UTF_8)
                        lblHardwareMessage.isVisible = true
                        hardwareLineCounter = (data[5].toInt() and 0xFF) * 10

                        Log.eventWriter(lblHardwareMessage.text)

                        // Color based on byte 6
                        if (data[6].toInt() and 0xFF == 0) {
                            lblHardwareMessage.setBackgroundColor(Color.SALMON)
                            lblHardwareMessage.setTextColor(Color.BLACK)
                        } else {
                            lblHardwareMessage.setBackgroundColor(Color.BISQUE)
                            lblHardwareMessage.setTextColor(Color.BLACK)
                        }
                    } else {
                        lblHardwareMessage.isVisible = false
                        hardwareLineCounter = 0
                    }

                }

                234 -> { // MTZ8302 Feb 2020 - Remote Switches
                    if (data.size != 14) return

                    System.arraycopy(data, 5, mf.mc.ss, 1, 8)
                    doRemoteSwitches()

                }
            }
        }
    }

    // 更新地圖上的車輛標記
    private fun updateVehicleMarkerOnMap() {
        mf.mMap?.let { map ->
            val vehiclePosition = LatLng(mf.pn.latitude, mf.pn.longitude)
            val heading = if (mf.pn.headingTrueDual != 0.0) {
                mf.pn.headingTrueDual.toFloat() // 優先使用雙天線朝向
            } else {
                mf.pn.headingTrue.toFloat() // 否則使用單天線朝向
            }

            if (vehicleMarker == null) {
                // 如果標記尚未創建，添加一個新標記
                vehicleMarker = map.addMarker(
                    MarkerOptions()
                        .position(vehiclePosition)
                        .title("Vehicle")
                        .rotation(heading)
                )
            } else {
                // 更新現有標記的位置和方向
                vehicleMarker?.position = vehiclePosition
                vehicleMarker?.rotation = heading
            }

            // 可選：調整地圖視野以跟隨車輛
            // map.moveCamera(CameraUpdateFactory.newLatLngZoom(vehiclePosition, 15f))
        }
    }


    // Start the UDP server
    fun startLoopbackServer() {
        try {
            // Initialize the socket
            loopBackSocket = DatagramSocket(15555, InetAddress.getByName("127.0.0.1"))
            loopBackSocket.broadcast = true
            logEvent("UDP Loopback network started: 127.0.0.1:15555")

            // Start receiving data in a separate thread
            Thread {
                while (!loopBackSocket.isClosed) {
                    receiveAppData()
                }
            }.start()
        } catch (ex: SocketException) {
            showErrorDialog("Load Error: ${ex.message}", "UDP Server")
            logEvent("Catch -> Load UDP Loopback Error: ${ex.stackTraceToString()}")
        }
    }

    private fun disableSim() {
        isFirstFixPositionSet = false
        isGPSPositionInitialized = false
        isFirstHeadingSet = false
        startCounter = 0
        panelSim.isVisible = false
        timerSim.isEnabled = false
        simulatorOnToolStripMenuItem.isChecked = false
        mf.settings.setMenu_isSimulatorOn = simulatorOnToolStripMenuItem.isChecked
        mf.settings.save()
    }

    private fun receiveAppData() {
        try {
            val packet = DatagramPacket(loopBuffer, loopBuffer.size)
            loopBackSocket.receive(packet)

            val localMsg = packet.data.copyOf(packet.length)

            // Process the received data on the Swing thread
            SwingUtilities.invokeLater {
                receiveFromAgIO(localMsg)
            }
        } catch (ex: Exception) {
            // Handle receive error silently or log it
            // showErrorDialog("ReceiveData Error: ${ex.message}", "UDP Server")
        }
    }

    // Helper functions
    private fun showErrorDialog(message: String, title: String) {
        SwingUtilities.invokeLater {
            JOptionPane.showMessageDialog(
                null,
                message,
                title,
                JOptionPane.ERROR_MESSAGE
            )
        }
    }

    private fun logEvent(message: String) {
        // Implement your logging functionality
    }

    // UDP sending functions
    fun sendPgnToLoop(byteData: ByteArray) {
        if (::loopBackSocket.isInitialized && byteData.size > 2) {
            try {
                var crc = 0
                for (i in 2 until byteData.size - 1) {
                    crc += byteData[i].toInt()
                }
                byteData[byteData.size - 1] = crc.toByte()

                val packet = DatagramPacket(byteData, byteData.size, epAgIO.first, epAgIO.second)
                loopBackSocket.send(packet)
            } catch (e: Exception) {
                // Log error silently
            }
        }
    }

    // Window handling
    companion object {
        private const val RESIZE_HANDLE_SIZE = 7
    }

    // For moving and sizing borderless window
    // Note: In Kotlin/Java, window handling is different from C# WinForms
    // You would typically use JFrame's built-in methods or custom mouse listeners

    // Key handling
    init {
        addKeyListener(this)
    }

    fun keyPressed(e: KeyEvent) {
        when (e.keyCode) {
            // Autosteer button on/off
            hotkeys[0].toInt() -> {
                btnAutoSteer.doClick()
                if (!isBtnAutoSteerOn) timedMessageBox(
                    2000,
                    gStr.gsGuidanceStopped,
                    "Hotkey Triggered"
                )
            }

            // Open the steer chart
            hotkeys[1].toInt() -> btnCycleLines.doClick()

            hotkeys[2].toInt() -> fileSaveEverythingBeforeClosingField()

            // Flag click
            hotkeys[3].toInt() -> btnFlag.doClick()

            // Auto section on/off
            hotkeys[4].toInt() -> btnSectionMasterManual.doClick()
            hotkeys[5].toInt() -> btnSectionMasterAuto.doClick()

            // Snap/Priority click
            hotkeys[6].toInt() -> trk.snapToPivot()

            // Nudge track
            hotkeys[7].toInt() -> if (trk.idx > -1) trk.nudgeTrack(mf.settings.setAS_snapDistance * -0.01)
            hotkeys[8].toInt() -> if (trk.idx > -1) trk.nudgeTrack(mf.settings.setAS_snapDistance * 0.01)

            // Open vehicle settings
            hotkeys[9].toInt() -> toolStripConfig.doClick()

            // Wizard
            hotkeys[10].toInt() -> {
                val fcs = applicationOpenForms["FormSteer"]
                fcs?.let {
                    it.requestFocus()
                    it.dispose()
                }

                val fc = applicationOpenForms["FormSteerWiz"]
                if (fc != null) {
                    fc.requestFocus()
                } else {
                    FormSteerWiz(this).apply {
                        isVisible = true
                    }
                }
            }

            // Section or zone buttons
            hotkeys[11].toInt() -> if (tool.isSectionsNotZones) btnSection1Man.doClick() else btnZone1.doClick()
            hotkeys[12].toInt() -> if (tool.isSectionsNotZones) btnSection2Man.doClick() else btnZone2.doClick()
            hotkeys[13].toInt() -> if (tool.isSectionsNotZones) btnSection3Man.doClick() else btnZone3.doClick()
            hotkeys[14].toInt() -> if (tool.isSectionsNotZones) btnSection4Man.doClick() else btnZone4.doClick()
            hotkeys[15].toInt() -> if (tool.isSectionsNotZones) btnSection5Man.doClick() else btnZone5.doClick()
            hotkeys[16].toInt() -> if (tool.isSectionsNotZones) btnSection6Man.doClick() else btnZone6.doClick()
            hotkeys[17].toInt() -> if (tool.isSectionsNotZones) btnSection7Man.doClick() else btnZone7.doClick()
            hotkeys[18].toInt() -> if (tool.isSectionsNotZones) btnSection8Man.doClick() else btnZone8.doClick()

            // Numpad keys
            KeyEvent.VK_NUMPAD1 -> btnSectionMasterAuto.doClick()
            KeyEvent.VK_NUMPAD0 -> btnSectionMasterManual.doClick()
            KeyEvent.VK_F11 -> btnMaximizeMainForm.doClick()

            // Reset Sim
            KeyEvent.VK_R -> btnResetSim.doClick()

            // UTurn
            KeyEvent.VK_U -> {
                mf.sim.headingTrue += Math.PI
                mf.ABLine.isABValid = false
                mf.curve.isCurveValid = false
                if (isBtnAutoSteerOn) {
                    btnAutoYouTurn.doClick()
                }
            }

            // Speed control
            KeyEvent.VK_UP -> {
                mf.sim.stepDistance = when {
                    mf.sim.stepDistance < 0.4 && mf.sim.stepDistance > -0.36 -> mf.sim.stepDistance + 0.01
                    else -> mf.sim.stepDistance + 0.04
                }.coerceAtMost(4.0)
            }

            KeyEvent.VK_DOWN -> {
                mf.sim.stepDistance = when {
                    mf.sim.stepDistance < 0.2 && mf.sim.stepDistance > -0.04 -> mf.sim.stepDistance - 0.01
                    else -> mf.sim.stepDistance - 0.04
                }.coerceAtLeast(-0.35)
            }

            KeyEvent.VK_PERIOD -> mf.sim.stepDistance = 0.0

            // Steering control
            KeyEvent.VK_RIGHT -> {
                mf.sim.steerAngle = (mf.sim.steerAngle + 1.0).coerceIn(-40.0, 40.0)
                updateSteeringUI()
            }

            KeyEvent.VK_LEFT -> {
                mf.sim.steerAngle = (mf.sim.steerAngle - 1.0).coerceIn(-40.0, 40.0)
                updateSteeringUI()
            }

            KeyEvent.VK_SLASH -> {
                mf.sim.steerAngle = 0.0
                updateSteeringUI()
            }

            KeyEvent.VK_OPEN_BRACKET -> {
                mf.sim.stepDistance = 0.0
                mf.sim.isAccelBack = true
            }

            KeyEvent.VK_CLOSE_BRACKET -> {
                mf.sim.stepDistance = 0.0
                mf.sim.isAccelForward = true
            }

            KeyEvent.VK_QUOTE -> mf.sim.stepDistance = 0.0

            KeyEvent.VK_F6 -> {
                if (timerSim.isEnabled) {
                    timerSim.delay = if (timerSim.delay < 20) 93 else 15
                }
            }
        }
    }

    private fun updateSteeringUI() {
        mf.sim.steerAngleScrollBar = mf.sim.steerAngle
        btnResetSteerAngle.text = mf.sim.steerAngle.toString()
        hsbarSteerAngle.value = (10 * mf.sim.steerAngle).toInt() + 400
    }

    fun keyReleased(e: KeyEvent) {}
    fun keyTyped(e: KeyEvent) {}

    // Helper functions
    private fun timedMessageBox(duration: Int, message: String, title: String) {
        // Implement timed message box functionality
    }

    private val applicationOpenForms: Map<String, JFrame>
        get() {
            // Implement getting open forms
            return emptyMap()
        }
}

// Helper extension for Stopwatch
fun Stopwatch.elapsedMillis() = this.elapsed(TimeUnit.MILLISECONDS)
