package com.agopengps.classes

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolygonOptions
import com.google.android.gms.maps.model.PolylineOptions
import kotlin.math.atan2
import kotlin.math.pow
import kotlin.math.sqrt

object glm {


    const val fileRegex = "^(?!.{256,})(?!(aux|clock\\$|con|nul|prn|com[1-9]|lpt[1-9])(?:$|\\.)[^ ][ \\.\\w-$()+=[\\];#@~,&']+[^\\. ]$/i"

    const val in2m = 0.0254
    const val m2in = 39.3701
    const val m2ft = 3.28084
    const val ft2m = 0.3048
    const val ha2ac = 2.47105
    const val ac2ha = 0.404686
    const val m2ac = 0.000247105
    const val m2ha = 0.0001
    const val galAc2Lha = 9.35396
    const val LHa2galAc = 0.106907
    const val L2Gal = 0.264172
    const val Gal2L = 3.785412534258
    const val twoPI = 6.28318530717958647692
    const val PIBy2 = 1.57079632679489661923


    fun vec2.GetClosestSegmentLooping(
        curList: List<vec3>,
        AA: Int,
        BB: Int,
        minDistA: Double,
        Start: Int = 0,
        End: Int = Int.MAX_VALUE
    ) {
        val isLoop = true
        var AA = -1
        var BB = -1
        var minDistA = Double.MAX_VALUE
        var A = if (Start > 0) Start - 1 else curList.size - 1
        val looping = isLoop && Start > End
        var B = if (Start > 0) Start else 0
        while (B < End || looping) {
            if (B == curList.size) {
                if (looping) {
                    B = -1
                    continue
                } else break
            }
            if (B == 0 && !isLoop) continue
            else if (B == 0) A = curList.size - 1

            val dist2 = DistanceSquared(curList[A], curList[B])
            if (dist2 < minDistA) {
                minDistA = dist2
                AA = A
                BB = B
            }
            A = B++
        }
    }

    fun InRangeBetweenAB(
        start_x: Double, start_y: Double, end_x: Double, end_y: Double,
        point_x: Double, point_y: Double
    ): Boolean {
        val dx = end_x - start_x
        val dy = end_y - start_y
        val innerProduct = (point_x - start_x) * dx + (point_y - start_y) * dy
        return innerProduct in 0.0..(dx * dx + dy * dy)
    }

    fun List<vec3>.IsPointInPolygon(testPoint: vec3): Boolean {
        var result = false
        var j = this.size - 1
        for (i in 0 until this.size) {
            if ((this[i].easting < testPoint.easting && this[j].easting >= testPoint.easting) ||
                (this[j].easting < testPoint.easting && this[i].easting >= testPoint.easting)
            ) {
                if (this[i].northing + (testPoint.easting - this[i].easting) /
                    (this[j].easting - this[i].easting) * (this[j].northing - this[i].northing) < testPoint.northing
                ) {
                    result = !result
                }
            }
            j = i
        }
        return result
    }

    fun List<vec3>.IsPointInPolygon(testPoint: vec2): Boolean {
        var result = false
        var j = this.size - 1
        for (i in 0 until this.size) {
            if ((this[i].easting < testPoint.easting && this[j].easting >= testPoint.easting) ||
                (this[j].easting < testPoint.easting && this[i].easting >= testPoint.easting)
            ) {
                if (this[i].northing + (testPoint.easting - this[i].easting) /
                    (this[j].easting - this[i].easting) * (this[j].northing - this[i].northing) < testPoint.northing
                ) {
                    result = !result
                }
            }
            j = i
        }
        return result
    }

    fun List<vec2>.IsPointInPolygon(testPoint: vec2): Boolean {
        var result = false
        var j = this.size - 1
        for (i in 0 until this.size) {
            if ((this[i].easting < testPoint.easting && this[j].easting >= testPoint.easting) ||
                (this[j].easting < testPoint.easting && this[i].easting >= testPoint.easting)
            ) {
                if (this[i].northing + (testPoint.easting - this[i].easting) /
                    (this[j].easting - this[i].easting) * (this[j].northing - this[i].northing) < testPoint.northing
                ) {
                    result = !result
                }
            }
            j = i
        }
        return result
    }

    fun List<vec2>.IsPointInPolygon(testPoint: vec3): Boolean {
        var result = false
        var j = this.size - 1
        for (i in 0 until this.size) {
            if ((this[i].easting < testPoint.easting && this[j].easting >= testPoint.easting) ||
                (this[j].easting < testPoint.easting && this[i].easting >= testPoint.easting)
            ) {
                if (this[i].northing + (testPoint.easting - this[i].easting) /
                    (this[j].easting - this[i].easting) * (this[j].northing - this[i].northing) < testPoint.northing
                ) {
                    result = !result
                }
            }
            j = i
        }
        return result
    }

    fun List<vec3>.DrawPolygon(googleMap: GoogleMap) {
        if (this.size > 2) {
            val polylineOptions = PolylineOptions()
                .width(5f)
                .color(Color.BLUE)
            for (i in this.indices) {
                polylineOptions.add(LatLng(this[i].northing, this[i].easting))
            }
            googleMap.addPolyline(polylineOptions)
        }
    }

    fun List<vec2>.DrawPolygon(googleMap: GoogleMap) {
        if (this.size > 2) {
            val polygonOptions = PolygonOptions()
                .strokeWidth(5f)  // Line width
                .strokeColor(Color.BLUE)  // Line color
                .fillColor(Color.TRANSPARENT)  // Optional fill color; use TRANSPARENT for no fill
            for (i in this.indices) {
                polygonOptions.add(LatLng(this[i].northing, this[i].easting))
            }
            googleMap.addPolygon(polygonOptions)
        }
    }


    fun Catmull(t: Double, p0: vec3, p1: vec3, p2: vec3, p3: vec3): vec3 {
        val tt = t * t
        val ttt = tt * t

        val q1 = -ttt + 2.0 * tt - t
        val q2 = 3.0 * ttt - 5.0 * tt + 2.0
        val q3 = -3.0 * ttt + 4.0 * tt + t
        val q4 = ttt - tt

        val tx = 0.5 * (p0.easting * q1 + p1.easting * q2 + p2.easting * q3 + p3.easting * q4)
        val ty = 0.5 * (p0.northing * q1 + p1.northing * q2 + p2.northing * q3 + p3.northing * q4)

        return vec3(tx, ty, 0.0)
    }

    fun CatmullGradient(t: Double, p0: vec3, p1: vec3, p2: vec3, p3: vec3): Double {
        val tt = t * t

        val q1 = -3.0 * tt + 4.0 * t - 1
        val q2 = 9.0 * tt - 10.0 * t
        val q3 = -9.0 * tt + 8.0 * t + 1.0
        val q4 = 3.0 * tt - 2.0 * t

        val tx = 0.5 * (p0.easting * q1 + p1.easting * q2 + p2.easting * q3 + p3.easting * q4)
        val ty = 0.5 * (p0.northing * q1 + p1.northing * q2 + p2.northing * q3 + p3.northing * q4)

        return atan2(tx, ty)
    }


    fun toDegrees(radians: Double): Double = radians * 57.295779513082325225835265587528

    fun toRadians(degrees: Double): Double = degrees * 0.01745329251994329576923690768489

    fun Distance(east1: Double, north1: Double, east2: Double, north2: Double): Double =
        sqrt((east1 - east2).pow(2) + (north1 - north2).pow(2))

    fun Distance(first: vec2, second: vec2): Double =
        sqrt((first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2))

    fun Distance(first: vec2, second: vec3): Double =
        sqrt((first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2))

    fun Distance(first: vec3, second: vec2): Double =
        sqrt((first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2))

    fun Distance(first: vec3, second: vec3): Double =
        sqrt((first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2))

    fun Distance(first: vec2, east: Double, north: Double): Double =
        sqrt((first.easting - east).pow(2) + (first.northing - north).pow(2))

    fun Distance(first: vec3, east: Double, north: Double): Double =
        sqrt((first.easting - east).pow(2) + (first.northing - north).pow(2))

    fun Distance(first: vecFix2Fix, second: vec2): Double =
        sqrt((first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2))

    fun Distance(first: vecFix2Fix, second: vecFix2Fix): Double =
        sqrt((first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2))

    fun DistanceSquared(northing1: Double, easting1: Double, northing2: Double, easting2: Double): Double =
        (easting1 - easting2).pow(2) + (northing1 - northing2).pow(2)

    fun DistanceSquared(first: vec3, second: vec2): Double =
        (first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2)

    fun DistanceSquared(first: vec2, second: vec3): Double =
        (first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2)

    fun DistanceSquared(first: vec3, second: vec3): Double =
        (first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2)

    fun DistanceSquared(first: vec2, second: vec2): Double =
        (first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2)

    fun DistanceSquared(first: vecFix2Fix, second: vec2): Double =
        (first.easting - second.easting).pow(2) + (first.northing - second.northing).pow(2)

    fun MakeGrayscale3(original: Bitmap): Bitmap {
        val newBitmap = Bitmap.createBitmap(original.width, original.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(newBitmap)
        val paint = Paint()
        val colorMatrix = ColorMatrix(
            floatArrayOf(
                0.3f, 0.3f, 0.3f, 0f, 0f,
                0.59f, 0.59f, 0.59f, 0f, 0f,
                0.11f, 0.11f, 0.11f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
                0f, 0f, 0f, 0f, 1f
            )
        )
        val filter = ColorMatrixColorFilter(colorMatrix)
        paint.colorFilter = filter
        canvas.drawBitmap(original, 0f, 0f, paint)
        return newBitmap
    }
}