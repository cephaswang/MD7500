package com.example.agopengps

import android.location.Location
import com.agopengps.classes.glm
import com.google.android.gms.maps.model.LatLng
import kotlin.math.*
import com.agopengps.drive.FormGPS

class CSim(private val mf: FormGPS) {
    // Properties
    var altitude: Double = 300.0
    var latitude: Double = mf.settings.setGPS_SimLatitude
    var longitude: Double = mf.settings.setGPS_SimLongitude

    var headingTrue: Double = 0.0
    var stepDistance: Double = 0.0
    var steerAngle: Double = 0.0
    var steerAngleAve: Double = 0.0
    var steerAngleScrollBar: Double = 0.0

    var isAccelForward: Boolean = false
    var isAccelBack: Boolean = false

    fun doSimTick(_st: Double) {
        steerAngle = _st

        val diff = abs(steerAngle - steerAngleAve)

        when {
            diff > 11 -> {
                steerAngleAve += if (steerAngleAve >= steerAngle) -6.0 else 6.0
            }
            diff > 5 -> {
                steerAngleAve += if (steerAngleAve >= steerAngle) -2.0 else 2.0
            }
            diff > 1 -> {
                steerAngleAve += if (steerAngleAve >= steerAngle) -0.5 else 0.5
            }
            else -> {
                steerAngleAve = steerAngle
            }
        }

        mf.mc.actualSteerAngleDegrees = steerAngleAve

        val temp = stepDistance * tan(steerAngleAve * 0.0165329252) / 2
        headingTrue += temp
        headingTrue = when {
            headingTrue > TWO_PI -> headingTrue - TWO_PI
            headingTrue < 0 -> headingTrue + TWO_PI
            else -> headingTrue
        }

        mf.pn.vtgSpeed = abs(round(4 * stepDistance * 10 * 100) / 100.0)
        mf.pn.averageTheSpeed()

        // Calculate new position
        val newPosition = calculateNewPositionFromBearingDistance(
            LatLng(latitude, longitude),
            headingTrue,
            stepDistance / 1000.0
        )
        latitude = newPosition.latitude
        longitude = newPosition.longitude

        // Convert to local coordinates
        val (northing, easting) = mf.pn.convertWGS84ToLocal(latitude, longitude)
        mf.pn.fix.northing = northing
        mf.pn.fix.easting = easting

        val headingDegrees = glm.toDegrees(headingTrue)
        mf.pn.headingTrue = headingDegrees
        mf.pn.headingTrueDual = headingDegrees
        mf.ahrs.imuHeading = headingDegrees
        if (mf.ahrs.imuHeading >= 360) mf.ahrs.imuHeading -= 360

        mf.pn.latitude = latitude
        mf.pn.longitude = longitude
        mf.pn.hdop = 0.7

        // Calculate altitude
        var tempAlt = abs(mf.pn.latitude * 100)
        tempAlt -= floor(tempAlt).toInt()
        tempAlt *= 100
        altitude = tempAlt + 200

        tempAlt = abs(mf.pn.longitude * 100)
        tempAlt -= floor(tempAlt).toInt()
        tempAlt *= 100
        altitude += tempAlt

        mf.pn.satellitesTracked = 12
        mf.sentenceCounter = 0
        var lastLocation: Location? = null
        lastLocation = Location("arbitrary").apply {
            latitude = 35.6895    // 緯度
            longitude = 139.6917  // 經度
            altitude = 10.0       // 海拔（任意值，單位：公尺）
            time = System.currentTimeMillis()  // 當前時間
        }
       // lastLocation =Location(0.0,0.0)
        mf.updateFixPosition(lastLocation)

        // Handle acceleration
        when {
            isAccelForward -> {
                isAccelBack = false
                stepDistance += 0.02
                if (stepDistance > 0.12) isAccelForward = false
            }
            isAccelBack -> {
                isAccelForward = false
                stepDistance -= 0.01
                if (stepDistance < -0.06) isAccelBack = false
            }
        }
    }

    private fun calculateNewPositionFromBearingDistance(
        startPosition: LatLng,
        bearing: Double,
        distance: Double
    ): LatLng {
        val earthRadius = 6371.0 // Earth's radius in kilometers
        val distRatio = distance / earthRadius

        val lat1 = glm.toRadians(startPosition.latitude)
        val lon1 = glm.toRadians(startPosition.longitude)

        val lat2 = asin(
            sin(lat1) * cos(distRatio) +
                    cos(lat1) * sin(distRatio) * cos(bearing)
        )

        val lon2 = lon1 + atan2(
            sin(bearing) * sin(distRatio) * cos(lat1),
            cos(distRatio) - (sin(lat1) * sin(lat2))
        )

        return LatLng(glm.toDegrees(lat2), glm.toDegrees(lon2))
    }

    companion object {
        const val TWO_PI = 2 * PI
    }
}

// Placeholder for the original FormGPS class structure
class FormGPS {
    val mc = MachineControl()
    val pn = PositionNavigation()
    val ahrs = AHRS()

    fun updateFixPosition() {
        // Implementation needed
    }
}

class MachineControl {
    var actualSteerAngleDegrees: Double = 0.0
}

class PositionNavigation {
    var vtgSpeed: Double = 0.0
    var headingTrue: Double = 0.0
    var headingTrueDual: Double = 0.0
    var latitude: Double = 0.0
    var longitude: Double = 0.0
    var hdop: Double = 0.0
    var altitude: Double = 0.0
    var satellitesTracked: Int = 0
    val fix = Fix()

    fun averageTheSpeed() {
        // Implementation needed
    }

    fun convertWGS84ToLocal(lat: Double, lon: Double): Pair<Double, Double> {
        // Implementation needed
        return Pair(0.0, 0.0)
    }
}

class Fix {
    var northing: Double = 0.0
    var easting: Double = 0.0
}

class AHRS {
    var imuHeading: Double = 0.0
}