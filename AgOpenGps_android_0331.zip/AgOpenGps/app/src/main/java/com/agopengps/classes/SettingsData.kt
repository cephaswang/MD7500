package com.agopengps.classes

import android.content.SharedPreferences
import android.graphics.Color

class SettingsData {
    //region 工具设置
    var setTool_trailingToolToPivotLength: Double = 0.0
    var setTool_toolTrailingHitchLength: Double = 0.0
    var setTool_isToolRearFixed: Boolean = false
    var setTool_isToolTrailing: Boolean = false
    var setTool_isToolTBT: Boolean = false
    var setTool_isToolFront: Boolean = false
    var setTool_isSectionOffWhenOut: Boolean = false
    var setTool_isSectionsNotZones: Boolean = false
    var setTool_numSectionsMulti: Int = 0
    var setTool_zones: String = "0"
    var setTool_isDisplayTramControl: Boolean = false
    //endregion

    //region 显示设置
    var displayLineWidth: Int = 2  // 默认值
    var numGuideLines: Int = 5     // 默认值
    var setDisplay_isBrightnessOn: Boolean = false
    var setDisplay_brightness: Int = 100
    var setDisplay_brightnessSystem: Int = 100
    var setDisplay_isAutoStartAgIO: Boolean = false
    var setDisplay_isAutoOffAgIO: Boolean = false
    var setDisplay_isShutdownWhenNoPower: Boolean = false
    var setDisplay_isTermsAccepted: Boolean = false
    var setDisplay_lineWidth: Int = 2  // 显示线宽
    //endregion

    //region 车辆设置
    var setVehicle_toolWidth: Double = 0.0
    var setVehicle_toolOverlap: Double = 0.0
    var setVehicle_toolOffset: Double = 0.0
    var setVehicle_tankTrailingHitchLength: Double = 0.0
    var setVehicle_hitchLength: Double = 0.0
    var setVehicle_toolLookAheadOn: Double = 0.0
    var setVehicle_toolLookAheadOff: Double = 0.0
    var setVehicle_toolOffDelay: Double = 0.0
    var setVehicle_numSections: Int = 0
    var setVehicle_minCoverage: Int = 0
    //endregion

    //region 颜色设置
    var setColor_isMultiColorSections: Boolean = false
    var setColor_sec01: Int = Color.BLACK
    var setColor_sec02: Int = Color.BLACK
    var setColor_sec03: Int = Color.BLACK
    var setColor_sec04: Int = Color.BLACK
    var setColor_sec05: Int = Color.BLACK
    var setColor_sec06: Int = Color.BLACK
    var setColor_sec07: Int = Color.BLACK
    var setColor_sec08: Int = Color.BLACK
    var setColor_sec09: Int = Color.BLACK
    var setColor_sec10: Int = Color.BLACK
    var setColor_sec11: Int = Color.BLACK
    var setColor_sec12: Int = Color.BLACK
    var setColor_sec13: Int = Color.BLACK
    var setColor_sec14: Int = Color.BLACK
    var setColor_sec15: Int = Color.BLACK
    var setColor_sec16: Int = Color.BLACK
    //endregion

    //region 自动转向设置
    var setAS_sideHillComp: Double = 0.0
    var setAS_maxSteerAngle: Double = 30.0
    var setAS_steerAngleOffset: Double = 0.0
    var setAS_countsPerDegree: Int = 10
    var setAS_isSteerInReverse: Boolean = true
    var setAS_isStanleyUsed: Boolean = true
    var setAS_numGuideLines: Int = 5
    var setAS_uTurnSmoothing: Int = 10 // 新增：U-Turn 平滑度，默认值 10
    //endregion

    //region U-Turn 设置
    var set_youTurnDistanceFromBoundary: Int = 5 // 新增：U-Turn 距离边界，默认值 5
    var set_youTurnExtensionLength: Double = 0.0 // 新增：U-Turn 扩展长度，默认值 0.0
    var set_youSkipWidth: Int = 1 // 新增：跳过的行宽，默认值 1
    var set_youTurnRadius: Int = 10 // 新增：U-Turn 半径，默认值 10
    var set_uTurnStyle: Int = 0 // 新增：U-Turn 样式，默认值 0
    //endregion

    //region 声音设置
    var setSound_isAutoSteerOn: Boolean = true
    var setSound_isHydLiftOn: Boolean = true
    var setSound_isUturnOn: Boolean = true
    var setSound_isSectionsOn: Boolean = true
    var setSound_isBoundaryAlarmOn: Boolean = true
    var setSound_volume: Int = 80
    //endregion

    //region 字段设置
    var setF_CurrentDir: String = ""
    var setF_DefaultDir: String = ""
    var setF_isMetric: Boolean = true
    //endregion

    // 从 SharedPreferences 加载设置
    fun loadFromPreferences(prefs: SharedPreferences) {
        displayLineWidth = prefs.getInt("displayLineWidth", 2)
        numGuideLines = prefs.getInt("numGuideLines", 5)

        // 工具设置
        setTool_trailingToolToPivotLength = prefs.getDouble("setTool_trailingToolToPivotLength", 0.0)
        setTool_toolTrailingHitchLength = prefs.getDouble("setTool_toolTrailingHitchLength", 0.0)
        setTool_isToolRearFixed = prefs.getBoolean("setTool_isToolRearFixed", false)
        setTool_isToolTrailing = prefs.getBoolean("setTool_isToolTrailing", false)
        setTool_isToolTBT = prefs.getBoolean("setTool_isToolTBT", false)
        setTool_isToolFront = prefs.getBoolean("setTool_isToolFront", false)
        setTool_isSectionOffWhenOut = prefs.getBoolean("setTool_isSectionOffWhenOut", false)
        setTool_isSectionsNotZones = prefs.getBoolean("setTool_isSectionsNotZones", false)
        setTool_numSectionsMulti = prefs.getInt("setTool_numSectionsMulti", 0)
        setTool_zones = prefs.getString("setTool_zones", "0") ?: "0"
        setTool_isDisplayTramControl = prefs.getBoolean("setTool_isDisplayTramControl", false)

        // 车辆设置
        setVehicle_toolWidth = prefs.getDouble("setVehicle_toolWidth", 0.0)
        setVehicle_toolOverlap = prefs.getDouble("setVehicle_toolOverlap", 0.0)
        setVehicle_toolOffset = prefs.getDouble("setVehicle_toolOffset", 0.0)
        setVehicle_tankTrailingHitchLength = prefs.getDouble("setVehicle_tankTrailingHitchLength", 0.0)
        setVehicle_hitchLength = prefs.getDouble("setVehicle_hitchLength", 0.0)
        setVehicle_toolLookAheadOn = prefs.getDouble("setVehicle_toolLookAheadOn", 0.0)
        setVehicle_toolLookAheadOff = prefs.getDouble("setVehicle_toolLookAheadOff", 0.0)
        setVehicle_toolOffDelay = prefs.getDouble("setVehicle_toolOffDelay", 0.0)
        setVehicle_numSections = prefs.getInt("setVehicle_numSections", 0)
        setVehicle_minCoverage = prefs.getInt("setVehicle_minCoverage", 0)

        // 颜色设置
        setColor_isMultiColorSections = prefs.getBoolean("setColor_isMultiColorSections", false)
        setColor_sec01 = prefs.getInt("setColor_sec01", Color.BLACK)
        setColor_sec02 = prefs.getInt("setColor_sec02", Color.BLACK)
        setColor_sec03 = prefs.getInt("setColor_sec03", Color.BLACK)
        setColor_sec04 = prefs.getInt("setColor_sec04", Color.BLACK)
        setColor_sec05 = prefs.getInt("setColor_sec05", Color.BLACK)
        setColor_sec06 = prefs.getInt("setColor_sec06", Color.BLACK)
        setColor_sec07 = prefs.getInt("setColor_sec07", Color.BLACK)
        setColor_sec08 = prefs.getInt("setColor_sec08", Color.BLACK)
        setColor_sec09 = prefs.getInt("setColor_sec09", Color.BLACK)
        setColor_sec10 = prefs.getInt("setColor_sec10", Color.BLACK)
        setColor_sec11 = prefs.getInt("setColor_sec11", Color.BLACK)
        setColor_sec12 = prefs.getInt("setColor_sec12", Color.BLACK)
        setColor_sec13 = prefs.getInt("setColor_sec13", Color.BLACK)
        setColor_sec14 = prefs.getInt("setColor_sec14", Color.BLACK)
        setColor_sec15 = prefs.getInt("setColor_sec15", Color.BLACK)
        setColor_sec16 = prefs.getInt("setColor_sec16", Color.BLACK)

        // 自动转向设置
        setAS_sideHillComp = prefs.getDouble("setAS_sideHillComp", 0.0)
        setAS_maxSteerAngle = prefs.getDouble("setAS_maxSteerAngle", 30.0)
        setAS_steerAngleOffset = prefs.getDouble("setAS_steerAngleOffset", 0.0)
        setAS_countsPerDegree = prefs.getInt("setAS_countsPerDegree", 10)
        setAS_isSteerInReverse = prefs.getBoolean("setAS_isSteerInReverse", true)
        setAS_isStanleyUsed = prefs.getBoolean("setAS_isStanleyUsed", true)
        setAS_numGuideLines = prefs.getInt("setAS_numGuideLines", 5)
        setAS_uTurnSmoothing = prefs.getInt("setAS_uTurnSmoothing", 10) // 新增

        // U-Turn 设置
        set_youTurnDistanceFromBoundary = prefs.getInt("set_youTurnDistanceFromBoundary", 5) // 新增
        set_youTurnExtensionLength = prefs.getDouble("set_youTurnExtensionLength", 0.0) // 新增
        set_youSkipWidth = prefs.getInt("set_youSkipWidth", 1) // 新增
        set_youTurnRadius = prefs.getInt("set_youTurnRadius", 10) // 新增
        set_uTurnStyle = prefs.getInt("set_uTurnStyle", 0) // 新增

        // 显示设置
        setDisplay_isBrightnessOn = prefs.getBoolean("setDisplay_isBrightnessOn", false)
        setDisplay_brightness = prefs.getInt("setDisplay_brightness", 100)
        setDisplay_brightnessSystem = prefs.getInt("setDisplay_brightnessSystem", 100)
        setDisplay_isAutoStartAgIO = prefs.getBoolean("setDisplay_isAutoStartAgIO", false)
        setDisplay_isAutoOffAgIO = prefs.getBoolean("setDisplay_isAutoOffAgIO", false)
        setDisplay_isShutdownWhenNoPower = prefs.getBoolean("setDisplay_isShutdownWhenNoPower", false)
        setDisplay_isTermsAccepted = prefs.getBoolean("setDisplay_isTermsAccepted", false)
        setDisplay_lineWidth = prefs.getInt("setDisplay_lineWidth", 2)

        // 声音设置
        setSound_isAutoSteerOn = prefs.getBoolean("setSound_isAutoSteerOn", true)
        setSound_isHydLiftOn = prefs.getBoolean("setSound_isHydLiftOn", true)
        setSound_isUturnOn = prefs.getBoolean("setSound_isUturnOn", true)
        setSound_isSectionsOn = prefs.getBoolean("setSound_isSectionsOn", true)
        setSound_isBoundaryAlarmOn = prefs.getBoolean("setSound_isBoundaryAlarmOn", true)
        setSound_volume = prefs.getInt("setSound_volume", 80)

        // 字段设置
        setF_CurrentDir = prefs.getString("setF_CurrentDir", "") ?: ""
        setF_DefaultDir = prefs.getString("setF_DefaultDir", "") ?: ""
        setF_isMetric = prefs.getBoolean("setF_isMetric", true)
    }

    // 保存设置到 SharedPreferences
    fun saveToPreferences(prefs: SharedPreferences) {
        prefs.edit().apply {
            putInt("displayLineWidth", displayLineWidth)
            putInt("numGuideLines", numGuideLines)

            // 工具设置
            putDouble("setTool_trailingToolToPivotLength", setTool_trailingToolToPivotLength)
            putDouble("setTool_toolTrailingHitchLength", setTool_toolTrailingHitchLength)
            putBoolean("setTool_isToolRearFixed", setTool_isToolRearFixed)
            putBoolean("setTool_isToolTrailing", setTool_isToolTrailing)
            putBoolean("setTool_isToolTBT", setTool_isToolTBT)
            putBoolean("setTool_isToolFront", setTool_isToolFront)
            putBoolean("setTool_isSectionOffWhenOut", setTool_isSectionOffWhenOut)
            putBoolean("setTool_isSectionsNotZones", setTool_isSectionsNotZones)
            putInt("setTool_numSectionsMulti", setTool_numSectionsMulti)
            putString("setTool_zones", setTool_zones)
            putBoolean("setTool_isDisplayTramControl", setTool_isDisplayTramControl)

            // 车辆设置
            putDouble("setVehicle_toolWidth", setVehicle_toolWidth)
            putDouble("setVehicle_toolOverlap", setVehicle_toolOverlap)
            putDouble("setVehicle_toolOffset", setVehicle_toolOffset)
            putDouble("setVehicle_tankTrailingHitchLength", setVehicle_tankTrailingHitchLength)
            putDouble("setVehicle_hitchLength", setVehicle_hitchLength)
            putDouble("setVehicle_toolLookAheadOn", setVehicle_toolLookAheadOn)
            putDouble("setVehicle_toolLookAheadOff", setVehicle_toolLookAheadOff)
            putDouble("setVehicle_toolOffDelay", setVehicle_toolOffDelay)
            putInt("setVehicle_numSections", setVehicle_numSections)
            putInt("setVehicle_minCoverage", setVehicle_minCoverage)

            // 颜色设置
            putBoolean("setColor_isMultiColorSections", setColor_isMultiColorSections)
            putInt("setColor_sec01", setColor_sec01)
            putInt("setColor_sec02", setColor_sec02)
            putInt("setColor_sec03", setColor_sec03)
            putInt("setColor_sec04", setColor_sec04)
            putInt("setColor_sec05", setColor_sec05)
            putInt("setColor_sec06", setColor_sec06)
            putInt("setColor_sec07", setColor_sec07)
            putInt("setColor_sec08", setColor_sec08)
            putInt("setColor_sec09", setColor_sec09)
            putInt("setColor_sec10", setColor_sec10)
            putInt("setColor_sec11", setColor_sec11)
            putInt("setColor_sec12", setColor_sec12)
            putInt("setColor_sec13", setColor_sec13)
            putInt("setColor_sec14", setColor_sec14)
            putInt("setColor_sec15", setColor_sec15)
            putInt("setColor_sec16", setColor_sec16)

            // 自动转向设置
            putDouble("setAS_sideHillComp", setAS_sideHillComp)
            putDouble("setAS_maxSteerAngle", setAS_maxSteerAngle)
            putDouble("setAS_steerAngleOffset", setAS_steerAngleOffset)
            putInt("setAS_countsPerDegree", setAS_countsPerDegree)
            putBoolean("setAS_isSteerInReverse", setAS_isSteerInReverse)
            putBoolean("setAS_isStanleyUsed", setAS_isStanleyUsed)
            putInt("setAS_numGuideLines", setAS_numGuideLines)
            putInt("setAS_uTurnSmoothing", setAS_uTurnSmoothing) // 新增

            // U-Turn 设置
            putInt("set_youTurnDistanceFromBoundary", set_youTurnDistanceFromBoundary) // 新增
            putDouble("set_youTurnExtensionLength", set_youTurnExtensionLength) // 新增
            putInt("set_youSkipWidth", set_youSkipWidth) // 新增
            putInt("set_youTurnRadius", set_youTurnRadius) // 新增
            putInt("set_uTurnStyle", set_uTurnStyle) // 新增

            // 显示设置
            putBoolean("setDisplay_isBrightnessOn", setDisplay_isBrightnessOn)
            putInt("setDisplay_brightness", setDisplay_brightness)
            putInt("setDisplay_brightnessSystem", setDisplay_brightnessSystem)
            putBoolean("setDisplay_isAutoStartAgIO", setDisplay_isAutoStartAgIO)
            putBoolean("setDisplay_isAutoOffAgIO", setDisplay_isAutoOffAgIO)
            putBoolean("setDisplay_isShutdownWhenNoPower", setDisplay_isShutdownWhenNoPower)
            putBoolean("setDisplay_isTermsAccepted", setDisplay_isTermsAccepted)
            putInt("setDisplay_lineWidth", setDisplay_lineWidth)

            // 声音设置
            putBoolean("setSound_isAutoSteerOn", setSound_isAutoSteerOn)
            putBoolean("setSound_isHydLiftOn", setSound_isHydLiftOn)
            putBoolean("setSound_isUturnOn", setSound_isUturnOn)
            putBoolean("setSound_isSectionsOn", setSound_isSectionsOn)
            putBoolean("setSound_isBoundaryAlarmOn", setSound_isBoundaryAlarmOn)
            putInt("setSound_volume", setSound_volume)

            // 字段设置
            putString("setF_CurrentDir", setF_CurrentDir)
            putString("setF_DefaultDir", setF_DefaultDir)
            putBoolean("setF_isMetric", setF_isMetric)

            apply()
        }
    }

    // 辅助方法：SharedPreferences 扩展，支持 Double 类型
    private fun SharedPreferences.Editor.putDouble(key: String, value: Double) {
        putLong(key, value.toBits())
    }

    private fun SharedPreferences.getDouble(key: String, defaultValue: Double): Double {
        return if (contains(key)) Double.fromBits(getLong(key, defaultValue.toBits()))
        else defaultValue
    }

    // 获取设置值的方法
    fun getDouble(key: String, defaultValue: Double): Double {
        return when (key) {
            // 工具设置
            "setTool_trailingToolToPivotLength" -> setTool_trailingToolToPivotLength
            "setTool_toolTrailingHitchLength" -> setTool_toolTrailingHitchLength
            // 车辆设置
            "setVehicle_toolWidth" -> setVehicle_toolWidth
            "setVehicle_toolOverlap" -> setVehicle_toolOverlap
            "setVehicle_toolOffset" -> setVehicle_toolOffset
            "setVehicle_tankTrailingHitchLength" -> setVehicle_tankTrailingHitchLength
            "setVehicle_hitchLength" -> setVehicle_hitchLength
            "setVehicle_toolLookAheadOn" -> setVehicle_toolLookAheadOn
            "setVehicle_toolLookAheadOff" -> setVehicle_toolLookAheadOff
            "setVehicle_toolOffDelay" -> setVehicle_toolOffDelay
            // 自动转向设置
            "setAS_sideHillComp" -> setAS_sideHillComp
            "setAS_maxSteerAngle" -> setAS_maxSteerAngle
            "setAS_steerAngleOffset" -> setAS_steerAngleOffset
            // U-Turn 设置
            "set_youTurnExtensionLength" -> set_youTurnExtensionLength // 新增
            else -> defaultValue
        }
    }

    fun getBoolean(key: String, defaultValue: Boolean): Boolean {
        return when (key) {
            // 工具设置
            "setTool_isToolRearFixed" -> setTool_isToolRearFixed
            "setTool_isToolTrailing" -> setTool_isToolTrailing
            "setTool_isToolTBT" -> setTool_isToolTBT
            "setTool_isToolFront" -> setTool_isToolFront
            "setTool_isSectionOffWhenOut" -> setTool_isSectionOffWhenOut
            "setTool_isSectionsNotZones" -> setTool_isSectionsNotZones
            "setTool_isDisplayTramControl" -> setTool_isDisplayTramControl
            // 颜色设置
            "setColor_isMultiColorSections" -> setColor_isMultiColorSections
            // 自动转向设置
            "setAS_isSteerInReverse" -> setAS_isSteerInReverse
            "setAS_isStanleyUsed" -> setAS_isStanleyUsed
            // 显示设置
            "setDisplay_isBrightnessOn" -> setDisplay_isBrightnessOn
            "setDisplay_isAutoStartAgIO" -> setDisplay_isAutoStartAgIO
            "setDisplay_isAutoOffAgIO" -> setDisplay_isAutoOffAgIO
            "setDisplay_isShutdownWhenNoPower" -> setDisplay_isShutdownWhenNoPower
            "setDisplay_isTermsAccepted" -> setDisplay_isTermsAccepted
            // 声音设置
            "setSound_isAutoSteerOn" -> setSound_isAutoSteerOn
            "setSound_isHydLiftOn" -> setSound_isHydLiftOn
            "setSound_isUturnOn" -> setSound_isUturnOn
            "setSound_isSectionsOn" -> setSound_isSectionsOn
            "setSound_isBoundaryAlarmOn" -> setSound_isBoundaryAlarmOn
            // 字段设置
            "setF_isMetric" -> setF_isMetric
            else -> defaultValue
        }
    }

    fun getInt(key: String, defaultValue: Int): Int {
        return when (key) {
            "displayLineWidth" -> displayLineWidth
            "numGuideLines" -> numGuideLines
            // 工具设置
            "setTool_numSectionsMulti" -> setTool_numSectionsMulti
            // 车辆设置
            "setVehicle_numSections" -> setVehicle_numSections
            "setVehicle_minCoverage" -> setVehicle_minCoverage
            // 颜色设置
            "setColor_sec01" -> setColor_sec01
            "setColor_sec02" -> setColor_sec02
            "setColor_sec03" -> setColor_sec03
            "setColor_sec04" -> setColor_sec04
            "setColor_sec05" -> setColor_sec05
            "setColor_sec06" -> setColor_sec06
            "setColor_sec07" -> setColor_sec07
            "setColor_sec08" -> setColor_sec08
            "setColor_sec09" -> setColor_sec09
            "setColor_sec10" -> setColor_sec10
            "setColor_sec11" -> setColor_sec11
            "setColor_sec12" -> setColor_sec12
            "setColor_sec13" -> setColor_sec13
            "setColor_sec14" -> setColor_sec14
            "setColor_sec15" -> setColor_sec15
            "setColor_sec16" -> setColor_sec16
            // 自动转向设置
            "setAS_countsPerDegree" -> setAS_countsPerDegree
            "setAS_numGuideLines" -> setAS_numGuideLines
            "setAS_uTurnSmoothing" -> setAS_uTurnSmoothing // 新增
            // U-Turn 设置
            "set_youTurnDistanceFromBoundary" -> set_youTurnDistanceFromBoundary // 新增
            "set_youSkipWidth" -> set_youSkipWidth // 新增
            "set_youTurnRadius" -> set_youTurnRadius // 新增
            "set_uTurnStyle" -> set_uTurnStyle // 新增
            // 显示设置
            "setDisplay_brightness" -> setDisplay_brightness
            "setDisplay_brightnessSystem" -> setDisplay_brightnessSystem
            "setDisplay_lineWidth" -> setDisplay_lineWidth
            // 声音设置
            "setSound_volume" -> setSound_volume
            else -> defaultValue
        }
    }

    fun getString(key: String, defaultValue: String): String {
        return when (key) {
            // 工具设置
            "setTool_zones" -> setTool_zones
            // 字段设置
            "setF_CurrentDir" -> setF_CurrentDir
            "setF_DefaultDir" -> setF_DefaultDir
            else -> defaultValue
        }
    }
}