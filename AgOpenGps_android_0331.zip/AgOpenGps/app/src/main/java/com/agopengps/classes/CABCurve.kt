package com.agopengps.classes

import android.graphics.Color
import android.util.Log
import com.agopengps.drive.MainActivity
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions
import kotlin.math.*
import com.agopengps.classes.*

class CABCurve(private val mf: MainActivity) {
    // Pointers to mainform controls
    var isBtnTrackOn = false
    var isMakingCurve = false
    var isRecordingCurve = false

    var distanceFromCurrentLinePivot = 0.0
    var distanceFromRefLine = 0.0

    var isHeadingSameWay = true
    private var lastIsHeadingSameWay = true

    var howManyPathsAway = 0.0
    private var lastHowManyPathsAway = 0.0

    var refPoint1 = vec2(1.0, 1.0)
    var refPoint2 = vec2(2.0, 2.0)

    private var A = 0
    private var B = 0
    private var C = 0
    private var rA = 0
    private var rB = 0

    var currentLocationIndex = 0

    // Pure pursuit values
    var goalPointCu = vec2(0.0, 0.0)
    var radiusPointCu = vec2(0.0, 0.0)
    var steerAngleCu = 0.0
    var rEastCu = 0.0
    var rNorthCu = 0.0
    var ppRadiusCu = 0.0
    var manualUturnHeading = 0.0

    var isSmoothWindowOpen = false
    var isLooping = false
    val smooList = mutableListOf<vec3>()

    // The list of points of curve to drive on
    val curList = mutableListOf<vec3>()

    private var isBusyWorking = false
    var isCurveValid = false
    private var lastSecond = 0.0

    val desList = mutableListOf<vec3>()
    var desName = "**"

    var pivotDistanceError = 0.0
    private var pivotDistanceErrorLast = 0.0
    var pivotDerivative = 0.0
    var pivotDerivativeSmoothed = 0.0
    private var lastCurveDistance = 10000.0

    // Derivative counters
    private var counter2 = 0
    var inty = 0.0

    // Should we find the global nearest curve point on the next search
    private var findGlobalNearestCurvePoint = true

    // Google Maps related properties
    private lateinit var mMap: GoogleMap
    private var curvePolyline: Polyline? = null
    private var smoothedPolyline: Polyline? = null
    private var referencePolyline: Polyline? = null

    fun initialize(map: GoogleMap) {
        this.mMap = map
    }

    suspend fun buildCurveCurrentList(pivot: vec3) {
        var minDistA = 1000000.0
        var minDistB = 0.0

        // Move the ABLine over based on the overlap amount set in vehicle
        val widthMinusOverlap = mf.tool.width - mf.tool.overlap
        val track = mf.trk.gArr[mf.trk.idx]

        if (!isCurveValid || ((mf.secondsSinceStart - lastSecond) > 0.66 && (!mf.isBtnAutoSteerOn || mf.mc.steerSwitchHigh))) {
            lastSecond = mf.secondsSinceStart
            findGlobalNearestCurvePoint = true

            if (track.mode != TrackMode.WaterPivot) {
                val refCount = track.curvePts.size
                if (refCount < 2) {
                    curList.clear()
                    return
                }

                // Close call hit
                var cc = 0
                var dd: Int

                for (j in 0 until refCount step 10) {
                    val dist = (mf.guidanceLookPos.longitude - track.curvePts[j].longitude).pow(2) +
                            (mf.guidanceLookPos.latitude - track.curvePts[j].latitude).pow(2)
                    if (dist < minDistA) {
                        minDistA = dist
                        cc = j
                    }
                }

                minDistA = 1000000.0
                minDistB = 1000000.0

                dd = cc + 7
                if (dd > refCount - 1) dd = refCount
                cc -= 7
                if (cc < 0) cc = 0

                // Find the closest 2 points to current close call
                for (j in cc until dd) {
                    val dist = (mf.guidanceLookPos.longitude - track.curvePts[j].longitude).pow(2) +
                            (mf.guidanceLookPos.latitude - track.curvePts[j].latitude).pow(2)
                    when {
                        dist < minDistA -> {
                            minDistB = minDistA
                            rB = rA
                            minDistA = dist
                            rA = j
                        }
                        dist < minDistB -> {
                            minDistB = dist
                            rB = j
                        }
                    }
                }

                if (rA > rB) {
                    C = rA
                    rA = rB
                    rB = C
                }

                // Same way as line creation or not
                isHeadingSameWay = abs(abs(pivot.heading - track.curvePts[rA].heading) - PI) < (PI / 2)

                // Calculate endpoints of reference line based on closest point
                refPoint1 = vec2(
                    track.curvePts[rA].longitude - (sin(track.curvePts[rA].heading) * 300.0,
                    track.curvePts[rA].latitude - (cos(track.curvePts[rA].heading) * 300.0)
                )

                refPoint2 = vec2(
                    track.curvePts[rA].longitude + (sin(track.curvePts[rA].heading) * 300.0),
                    track.curvePts[rA].latitude + (cos(track.curvePts[rA].heading) * 300.0)
                )

                // Calculate distance from reference line
                val dx = refPoint2.longitude - refPoint1.longitude
                val dz = refPoint2.latitude - refPoint1.latitude

                distanceFromRefLine = ((dz * mf.guidanceLookPos.longitude) - (dx * mf.guidanceLookPos.latitude) +
                        (refPoint2.longitude * refPoint1.latitude) - (refPoint2.latitude * refPoint1.longitude)) /
                        sqrt((dz * dz) + (dx * dx))
            } else {
                // Pivot guide list
                isHeadingSameWay = ((mf.pivotAxlePos.longitude - track.ptA.longitude) *
                        (mf.steerAxlePos.latitude - track.ptA.latitude) -
                        (mf.pivotAxlePos.latitude - track.ptA.latitude) *
                        (mf.steerAxlePos.longitude - track.ptA.longitude)) < 0

                // Pivot circle center
                distanceFromRefLine = -glm.Distance(mf.guidanceLookPos, track.ptA)
            }

            distanceFromRefLine -= (0.5 * widthMinusOverlap)
            val refDist = (distanceFromRefLine + (if (isHeadingSameWay) mf.tool.offset else -mf.tool.offset) -
                    track.nudgeDistance) / widthMinusOverlap

            howManyPathsAway = if (refDist < 0) floor(refDist - 0.5) else ceil(refDist + 0.5)
        }

        if (!isCurveValid || howManyPathsAway != lastHowManyPathsAway ||
            (isHeadingSameWay != lastIsHeadingSameWay && mf.tool.offset != 0.0)) {
            if (!isBusyWorking) {
                isBusyWorking = true
                isCurveValid = true
                lastHowManyPathsAway = howManyPathsAway
                lastIsHeadingSameWay = isHeadingSameWay
                val distAway = widthMinusOverlap * howManyPathsAway +
                        (if (isHeadingSameWay) -mf.tool.offset else mf.tool.offset) +
                        track.nudgeDistance

                curList.clear()
                curList.addAll(buildNewOffsetList(distAway, track))
                isBusyWorking = false
                findGlobalNearestCurvePoint = true

                // Update the map display
                updateCurveOnMap()
            }
        }
    }

    private fun updateCurveOnMap() {
        // Remove existing polyline if any
        curvePolyline?.remove()

        // Create new polyline options
        val options = PolylineOptions()
            .width(10f)  // Wider line for better visibility
            .color(Color.BLUE)
            .geodesic(true)

        // Add all points from curList
        curList.forEach { vec3 ->
            options.add(LatLng(vec3.latitude, vec3.longitude))
        }

        // Add to map
        curvePolyline = mMap.addPolyline(options)
    }

    fun buildNewOffsetList(distAway: Double, track: CTrk): List<vec3> {
        val newCurList = mutableListOf<vec3>()

        try {
            when (track.mode) {
                TrackMode.AB -> {
                    // Move the curline as well
                    val nudgePtA = vec2(track.ptA)
                    val nudgePtB = vec2(track.ptB)

                    // Depending which way you are going, the offset can be either side
                    val point1 = vec2(
                        (cos(-track.heading) * distAway) + nudgePtA.longitude,
                        (sin(-track.heading) * distAway) + nudgePtA.latitude
                    )

                    val point2 = vec2(
                        (cos(-track.heading) * distAway) + nudgePtB.longitude,
                        (sin(-track.heading) * distAway) + nudgePtB.latitude
                    )

                    // Create the new line extent points
                    val easting1 = point1.longitude - (sin(track.heading) * mf.ABLine.abLength)
                    val northing1 = point1.latitude - (cos(track.heading) * mf.ABLine.abLength)

                    newCurList.add(vec3(easting1, northing1, track.heading))

                    val easting2 = point2.longitude + (sin(track.heading) * mf.ABLine.abLength)
                    val northing2 = point2.latitude + (cos(track.heading) * mf.ABLine.abLength)
                    newCurList.add(vec3(easting2, northing2, track.heading))
                }

                TrackMode.WaterPivot -> {
                    // Max 2 cm offset from correct circle or limit to 500 points
                    val angle = TWO_PI / min(max(
                        ceil(TWO_PI / (2 * acos(1 - (0.02 / abs(distAway))))),
                        50.0), 500.0)

                    val centerPos = vec3(track.ptA.longitude, track.ptA.latitude, 0.0)
                    var rotation = 0.0

                    while (rotation < TWO_PI) {
                        rotation += angle
                        newCurList.add(vec3(
                            centerPos.longitude + distAway * sin(rotation),
                            centerPos.latitude + distAway * cos(rotation),
                            0.0
                        ))
                    }

                    if (newCurList.size > 1) {
                        val arr = newCurList.toTypedArray()
                        newCurList.clear()

                        for (i in 0 until arr.size - 1) {
                            arr[i].heading = atan2(
                                arr[i + 1].longitude - arr[i].longitude,
                                arr[i + 1].latitude - arr[i].latitude
                            )
                            if (arr[i].heading < 0) arr[i].heading += TWO_PI
                            if (arr[i].heading >= TWO_PI) arr[i].heading -= TWO_PI
                        }

                        arr[arr.size - 1].heading = atan2(
                            arr[0].longitude - arr[arr.size - 1].longitude,
                            arr[0].latitude - arr[arr.size - 1].latitude
                        )

                        newCurList.addAll(arr)
                    }
                }

                else -> {
                    var point: vec3
                    var step = (mf.tool.width - mf.tool.overlap) * 0.48
                    step = step.coerceIn(1.0, 4.0)

                    val distSqAway = (distAway * distAway) - 0.01
                    val refCount = track.curvePts.size

                    for (i in 0 until refCount) {
                        point = vec3(
                            track.curvePts[i].longitude + (sin(PI / 2 + track.curvePts[i].heading) * distAway),
                            track.curvePts[i].latitude + (cos(PI / 2 + track.curvePts[i].heading) * distAway),
                            track.curvePts[i].heading
                        )

                        var shouldAdd = true
                        for (t in 0 until refCount) {
                            val dist = (point.longitude - track.curvePts[t].longitude).pow(2) +
                                    (point.latitude - track.curvePts[t].latitude).pow(2)
                            if (dist < distSqAway) {
                                shouldAdd = false
                                break
                            }
                        }

                        if (shouldAdd) {
                            if (newCurList.isNotEmpty()) {
                                val dist = (point.longitude - newCurList.last().longitude).pow(2) +
                                        (point.latitude - newCurList.last().latitude).pow(2)
                                if (dist > step) {
                                    newCurList.add(point)
                                }
                            } else {
                                newCurList.add(point)
                            }
                        }
                    }

                    if (newCurList.size > 6) {
                        val arr = newCurList.toTypedArray()
                        newCurList.clear()

                        for (i in 0 until arr.size - 1) {
                            arr[i].heading = atan2(
                                arr[i + 1].longitude - arr[i].longitude,
                                arr[i + 1].latitude - arr[i].latitude
                            )
                            if (arr[i].heading < 0) arr[i].heading += TWO_PI
                            if (arr[i].heading >= TWO_PI) arr[i].heading -= TWO_PI
                        }

                        arr[arr.size - 1].heading = arr[arr.size - 2].heading

                        val cnt = arr.size
                        var distance: Double

                        newCurList.add(arr[0])

                        for (i in 0 until cnt - 3) {
                            newCurList.add(arr[i + 1])
                            distance = glm.Distance(arr[i + 1], arr[i + 2])

                            if (distance > step) {
                                val loopTimes = (distance / step + 1).toInt()
                                for (j in 1 until loopTimes) {
                                    val pos = glm.Catmull(
                                        j.toDouble() / loopTimes,
                                        arr[i], arr[i + 1], arr[i + 2], arr[i + 3]
                                    )
                                    newCurList.add(pos)
                                }
                            }
                        }

                        newCurList.add(arr[cnt - 2])
                        newCurList.add(arr[cnt - 1])

                        calculateHeadings(newCurList)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("CABCurve", "Exception Build new offset curve: ${e.message}")
        }

        return newCurList
    }

    fun getCurrentCurveLine(pivot: vec3, steer: vec3) {
        if (mf.trk.gArr[mf.trk.idx].curvePts.isEmpty() ||
            (mf.trk.gArr[mf.trk.idx].curvePts.size < 5 &&
                    mf.trk.gArr[mf.trk.idx].mode != TrackMode.WaterPivot)) {
            return
        }

        if (curList.isNotEmpty()) {
            // Update based on autosteer settings and distance from line
            val goalPointDistance = mf.vehicle.updateGoalPointDistance()
            val reverseHeading = if (mf.isReverse) !isHeadingSameWay else isHeadingSameWay

            if (mf.yt.isYouTurnTriggered && mf.yt.distanceFromYouTurnLine()) {
                // Use auto turn values
                steerAngleCu = mf.yt.steerAngleYT
                distanceFromCurrentLinePivot = mf.yt.distanceFromCurrentLine
                goalPointCu = mf.yt.goalPointYT
                radiusPointCu = vec2(mf.yt.radiusPointYT.longitude, mf.yt.radiusPointYT.latitude)
                ppRadiusCu = mf.yt.ppRadiusYT
                mf.vehicle.modeActualXTE = distanceFromCurrentLinePivot
            } else if (mf.isStanleyUsed) {
                mf.gyd.stanleyGuidanceCurve(pivot, steer, curList)
            } else {
                // Pure Pursuit implementation
                var minDistA: Double
                var minDistB: Double

                if (mf.trk.gArr[mf.trk.idx].mode <= TrackMode.Curve) {
                    minDistB = Double.MAX_VALUE
                    var cc: Int
                    var dd: Int

                    if (findGlobalNearestCurvePoint) {
                        cc = findNearestGlobalCurvePoint(pivot, 10)
                        findGlobalNearestCurvePoint = false
                    } else {
                        cc = findNearestLocalCurvePoint(
                            pivot,
                            currentLocationIndex,
                            goalPointDistance,
                            reverseHeading
                        )
                    }

                    minDistA = Double.MAX_VALUE
                    dd = cc + 8
                    if (dd > curList.size - 1) dd = curList.size
                    cc -= 8
                    if (cc < 0) cc = 0

                    for (j in cc until dd) {
                        val dist = glm.DistanceSquared(pivot, curList[j])
                        when {
                            dist < minDistA -> {
                                minDistB = minDistA
                                B = A
                                minDistA = dist
                                A = j
                            }
                            dist < minDistB -> {
                                minDistB = dist
                                B = j
                            }
                        }
                    }

                    if (A > B) {
                        C = A
                        A = B
                        B = C
                    }

                    currentLocationIndex = A

                    if (A > curList.size - 1 || B > curList.size - 1) return
                } else {
                    A = if (findGlobalNearestCurvePoint) {
                        findGlobalNearestCurvePoint(pivot)
                    } else {
                        findNearestLocalCurvePoint(
                            pivot,
                            currentLocationIndex,
                            goalPointDistance,
                            reverseHeading
                        )
                    }

                    findGlobalNearestCurvePoint = false
                    currentLocationIndex = A

                    if (A > curList.size - 1) return

                    B = if (A == curList.size - 1) 0 else A + 1

                    if (!glm.InRangeBetweenAB(
                            curList[A].longitude, curList[A].latitude,
                            curList[B].longitude, curList[B].latitude,
                            pivot.longitude, pivot.latitude
                        )) {
                        // Step back one
                        if (A == 0) {
                            A = curList.size - 1
                            B = 0
                        } else {
                            A--
                            B = A + 1
                        }

                        if (!glm.InRangeBetweenAB(
                                curList[A].longitude, curList[A].latitude,
                                curList[B].longitude, curList[B].latitude,
                                pivot.longitude, pivot.latitude
                            )) {
                            return
                        }
                    }
                }

                // Calculate distance from current line
                val dx = curList[B].longitude - curList[A].longitude
                val dz = curList[B].latitude - curList[A].latitude

                if (abs(dx) < Double.MIN_VALUE && abs(dz) < Double.MIN_VALUE) return

                distanceFromCurrentLinePivot = ((dz * pivot.longitude) - (dx * pivot.latitude) +
                        (curList[B].longitude * curList[A].latitude) -
                        (curList[B].latitude * curList[A].longitude)) /
                        sqrt((dz * dz) + (dx * dx))

                // Integral calculations
                if (mf.vehicle.purePursuitIntegralGain != 0.0 && !mf.isReverse) {
                    pivotDistanceError = distanceFromCurrentLinePivot * 0.2 + pivotDistanceError * 0.8

                    if (counter2++ > 4) {
                        pivotDerivative = pivotDistanceError - pivotDistanceErrorLast
                        pivotDistanceErrorLast = pivotDistanceError
                        counter2 = 0
                        pivotDerivative *= 2.0
                    }

                    if (mf.isBtnAutoSteerOn && mf.avgSpeed > 2.5 && abs(pivotDerivative) < 0.1) {
                        if ((inty < 0 && distanceFromCurrentLinePivot < 0) ||
                            (inty > 0 && distanceFromCurrentLinePivot > 0)) {
                            inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.04
                        } else {
                            if (abs(distanceFromCurrentLinePivot) > 0.02) {
                                inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.02
                                inty = inty.coerceIn(-0.2, 0.2)
                            }
                        }
                    } else {
                        inty *= 0.95
                    }
                } else {
                    inty = 0.0
                }

                // Pure pursuit point calculation
                val u = (((pivot.longitude - curList[A].longitude) * dx) +
                        ((pivot.latitude - curList[A].latitude) * dz)) /
                        ((dx * dx) + (dz * dz))

                rEastCu = curList[A].longitude + (u * dx)
                rNorthCu = curList[A].latitude + (u * dz)
                manualUturnHeading = curList[A].heading

                val count = if (reverseHeading) 1 else -1
                var start = vec3(rEastCu, rNorthCu, 0.0)
                var distSoFar = 0.0

                var i = if (reverseHeading) B else A
                while (i in curList.indices) {
                    val tempDist = glm.Distance(start, curList[i])

                    if ((tempDist + distSoFar) > goalPointDistance) {
                        val j = (goalPointDistance - distSoFar) / tempDist
                        goalPointCu = vec2(
                            ((1 - j) * start.longitude) + (j * curList[i].longitude),
                            ((1 - j) * start.latitude) + (j * curList[i].latitude)
                        )
                        break
                    } else {
                        distSoFar += tempDist
                    }
                    start = curList[i]
                    i += count
                    if (i < 0) i = curList.size - 1
                    if (i > curList.size - 1) i = 0
                }

                // Check if we're past end of curve
                if (mf.trk.gArr[mf.trk.idx].mode <= TrackMode.Curve) {
                    if (mf.isBtnAutoSteerOn && !mf.isReverse) {
                        val endPoint = if (isHeadingSameWay) curList.last() else curList.first()
                        if (glm.Distance(goalPointCu, vec2(endPoint.longitude, endPoint.latitude)) < 0.5) {
                            mf.btnAutoSteer.performClick()
                            mf.timedMessageBox(2000, "Guidance Stopped", "Past End of Curve")
                        }
                    }
                }

                // Calculate steering angle
                val goalPointDistanceSquared = glm.DistanceSquared(
                    goalPointCu.latitude, goalPointCu.longitude,
                    pivot.latitude, pivot.longitude
                )

                val localHeading = if (reverseHeading)
                    TWO_PI - mf.fixHeading + inty
                else
                    TWO_PI - mf.fixHeading - inty

                ppRadiusCu = goalPointDistanceSquared / (2 *
                        ((goalPointCu.longitude - pivot.longitude) * cos(localHeading) +
                                (goalPointCu.latitude - pivot.latitude) * sin(localHeading)))

                steerAngleCu = toDegrees(atan(
                    2 * ((goalPointCu.longitude - pivot.longitude) * cos(localHeading) +
                            (goalPointCu.latitude - pivot.latitude) * sin(localHeading)) *
                            mf.vehicle.wheelbase / goalPointDistanceSquared
                ))

                if (mf.ahrs.imuRoll != 88888.0) {
                    steerAngleCu += mf.ahrs.imuRoll * -mf.gyd.sideHillCompFactor
                }

                steerAngleCu = steerAngleCu.coerceIn(
                    -mf.vehicle.maxSteerAngle,
                    mf.vehicle.maxSteerAngle
                )

                if (!isHeadingSameWay) {
                    distanceFromCurrentLinePivot *= -1.0
                }

                mf.vehicle.modeActualXTE = distanceFromCurrentLinePivot

                var steerHeadingError = pivot.heading - curList[A].heading
                // Fix circular error
                when {
                    steerHeadingError > PI -> steerHeadingError -= PI
                    steerHeadingError < -PI -> steerHeadingError += PI
                    steerHeadingError > PI / 2 -> steerHeadingError -= PI
                    steerHeadingError < -PI / 2 -> steerHeadingError += PI
                }

                mf.vehicle.modeActualHeadingError = toDegrees(steerHeadingError)
                mf.guidanceLineDistanceOff = (distanceFromCurrentLinePivot * 1000.0).roundToInt().toShort()
                mf.guidanceLineSteerAngle = (steerAngleCu * 100).roundToInt().toShort()
            }
        } else {
            distanceFromCurrentLinePivot = 32000.0
            mf.guidanceLineDistanceOff = 32000
        }
    }
    // Drawing functions for Google Maps
    fun drawCurve() {
        if (mf.trk.idx == -1) return

        val track = mf.trk.gArr[mf.trk.idx]
        when (track.mode) {
            TrackMode.WaterPivot -> {
                // Draw pivot center point
                val centerOptions = CircleOptions()
                    .center(LatLng(track.ptA.latitude, track.ptA.longitude))
                    .radius(2.0)
                    .strokeWidth(3f)
                    .strokeColor(Color.RED)
                    .fillColor(Color.argb(100, 255, 0, 0))
                mMap.addCircle(centerOptions)
            }
            else -> {
                // Draw reference curve
                if (track.curvePts.isNotEmpty()) {
                    val refLineOptions = PolylineOptions()
                        .width(6f)
                        .color(Color.RED)
                        .geodesic(true)

                    track.curvePts.forEach { pt ->
                        refLineOptions.add(LatLng(pt.latitude, pt.longitude))
                    }

                    referencePolyline?.remove()
                    referencePolyline = mMap.addPolyline(refLineOptions)

                    // Draw points A and B if in AB mode
                    if (track.mode == TrackMode.AB && mf.font.isFontOn) {
                        mMap.addMarker(
                            MarkerOptions()
                                .position(LatLng(track.ptA.latitude, track.ptA.longitude))
                                .title("A")
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
                        )
                        mMap.addMarker(
                            MarkerOptions()
                                .position(LatLng(track.ptB.latitude, track.ptB.longitude))
                                .title("B")
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                        )
                    }
                }
            }
        }

        // Draw smoothed line if smoothing window is open
        if (isSmoothWindowOpen && smooList.isNotEmpty()) {
            val smoothOptions = PolylineOptions()
                .width(8f)
                .color(Color.YELLOW)
                .geodesic(true)

            smooList.forEach { pt ->
                smoothOptions.add(LatLng(pt.latitude, pt.longitude))
            }

            smoothedPolyline?.remove()
            smoothedPolyline = mMap.addPolyline(smoothOptions)
        }

        // Draw current guidance line
        if (curList.isNotEmpty() && !isSmoothWindowOpen) {
            val curveOptions = PolylineOptions()
                .width(12f)
                .color(Color.BLUE)
                .geodesic(true)

            // Different drawing modes based on curve type
            if (track.mode <= TrackMode.Curve) {
                // Regular curve - draw as line strip
                curList.forEach { pt ->
                    curveOptions.add(LatLng(pt.latitude, pt.longitude))
                }
            } else {
                // Closed loop - draw as polygon
                val points = curList.map { LatLng(it.latitude, it.longitude) }
                mMap.addPolygon(
                    PolygonOptions()
                        .addAll(points)
                        .strokeWidth(12f)
                        .strokeColor(Color.BLUE)
                        .fillColor(Color.argb(30, 0, 0, 255))
                )
            }

            curvePolyline?.remove()
            curvePolyline = mMap.addPolyline(curveOptions)

            // Draw goal point for pure pursuit
            if (!mf.isStanleyUsed && mf.camera.camSetDistance > -200) {
                mMap.addMarker(
                    MarkerOptions()
                        .position(LatLng(goalPointCu.latitude, goalPointCu.longitude))
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW))
                )
            }
        }
    }

    // Utility functions
    fun calculateHeadings(xList: MutableList<vec3>) {
        if (xList.size > 3) {
            val arr = xList.toTypedArray()
            xList.clear()

            // First point
            var pt3 = arr[0]
            pt3.heading = atan2(
                arr[1].longitude - arr[0].longitude,
                arr[1].latitude - arr[0].latitude
            )
            if (pt3.heading < 0) pt3.heading += TWO_PI
            xList.add(pt3)

            // Middle points
            for (i in 1 until arr.size - 1) {
                pt3 = arr[i]
                pt3.heading = atan2(
                    arr[i + 1].longitude - arr[i - 1].longitude,
                    arr[i + 1].latitude - arr[i - 1].latitude
                )
                if (pt3.heading < 0) pt3.heading += TWO_PI
                xList.add(pt3)
            }

            // Last point
            pt3 = arr[arr.size - 1]
            pt3.heading = atan2(
                arr[arr.size - 1].longitude - arr[arr.size - 2].longitude,
                arr[arr.size - 1].latitude - arr[arr.size - 2].latitude
            )
            if (pt3.heading < 0) pt3.heading += TWO_PI
            xList.add(pt3)
        }
    }

    private fun makePointMinimumSpacing(xList: MutableList<vec3>, minDistance: Double) {
        if (xList.size > 3) {
            var i = 0
            while (i < xList.size - 1) {
                val j = i + 1
                val distance = glm.Distance(xList[i], xList[j])
                if (distance > minDistance) {
                    val pointB = vec3(
                        (xList[i].longitude + xList[j].longitude) / 2.0,
                        (xList[i].latitude + xList[j].latitude) / 2.0,
                        xList[i].heading
                    )
                    xList.add(j, pointB)
                    i = -1 // Restart check after modification
                }
                i++
            }
        }
    }

    fun saveSmoothList() {
        if (smooList.isEmpty()) return

        mf.trk.gArr[mf.trk.idx].curvePts.clear()

        // Calculate new headings on smoothed line
        for (i in 0 until smooList.size - 1) {
            smooList[i].heading = atan2(
                smooList[i + 1].longitude - smooList[i].longitude,
                smooList[i + 1].latitude - smooList[i].latitude
            )
            if (smooList[i].heading < 0) smooList[i].heading += TWO_PI
            mf.trk.gArr[mf.trk.idx].curvePts.add(smooList[i])
        }

        // Update the display
        updateCurveOnMap()
    }

    fun pointOnLine(pt1: vec3, pt2: vec3, pt: vec3): Boolean {
        if (pt1.latitude == pt2.latitude && pt1.longitude == pt2.longitude) {
            return false
        }

        val u = ((pt.latitude - pt1.latitude) * (pt2.latitude - pt1.latitude) +
                (pt.longitude - pt1.longitude) * (pt2.longitude - pt1.longitude)) /
                ((pt2.latitude - pt1.latitude).pow(2) + (pt2.longitude - pt1.longitude).pow(2))

        val r = vec2(
            pt1.longitude + u * (pt2.longitude - pt1.longitude),
            pt1.latitude + u * (pt2.latitude - pt1.latitude)
        )

        val minX = min(pt1.latitude, pt2.latitude)
        val maxX = max(pt1.latitude, pt2.latitude)
        val minY = min(pt1.longitude, pt2.longitude)
        val maxY = max(pt1.longitude, pt2.longitude)

        return r.latitude in minX..maxX && r.longitude in minY..maxY
    }

    fun addFirstLastPoints(xList: MutableList<vec3>) {
        val ptCnt = xList.size - 1
        val start: vec3

        val extensionLength = if (mf.bnd.bndList.isNotEmpty()) 100 else 300

        // Add points at the end
        for (i in 1..extensionLength) {
            val pt = vec3(xList[ptCnt])
            pt.longitude += sin(pt.heading) * i
            pt.latitude += cos(pt.heading) * i
            xList.add(pt)
        }

        // Add points at the beginning
        start = vec3(xList[0])
        for (i in 1..extensionLength) {
            val pt = vec3(start)
            pt.longitude -= sin(pt.heading) * i
            pt.latitude -= cos(pt.heading) * i
            xList.add(0, pt)
        }
    }

    fun resetCurveLine() {
        curList.clear()
        mf.trk.idx = -1
        curvePolyline?.remove()
        curvePolyline = null
    }

    // Point finding functions
    private fun findNearestGlobalCurvePoint(refPoint: vec3, increment: Int = 1): Int {
        var minDist = Double.MAX_VALUE
        var minDistIndex = 0

        for (i in 0 until curList.size step increment) {
            val dist = glm.DistanceSquared(refPoint, curList[i])
            if (dist < minDist) {
                minDist = dist
                minDistIndex = i
            }
        }
        return minDistIndex
    }

    private fun findNearestLocalCurvePoint(
        refPoint: vec3,
        startIndex: Int,
        minSearchDistance: Double,
        reverseSearchDirection: Boolean
    ): Int {
        var minDist = glm.DistanceSquared(refPoint, curList[(startIndex + curList.size) % curList.size])
        var minDistIndex = startIndex

        val directionMultiplier = if (reverseSearchDirection) 1 else -1
        var distSoFar = 0.0
        var start = curList[startIndex]

        // Check points within search distance
        var offset = 1
        while (offset < curList.size) {
            val pointIndex = (startIndex + (offset * directionMultiplier) + curList.size) % curList.size
            val dist = glm.DistanceSquared(refPoint, curList[pointIndex])

            if (dist < minDist) {
                minDist = dist
                minDistIndex = pointIndex
            }

            distSoFar += glm.Distance(start, curList[pointIndex])
            start = curList[pointIndex]
            offset++

            if (distSoFar > minSearchDistance) break
        }

        // Continue until distance starts increasing
        while (offset < curList.size) {
            val pointIndex = (startIndex + (offset * directionMultiplier) + curList.size) % curList.size
            val dist = glm.DistanceSquared(refPoint, curList[pointIndex])
            if (dist < minDist) {
                minDist = dist
                minDistIndex = pointIndex
            } else {
                break
            }
            offset++
        }

        // Check in opposite direction
        for (oppositeOffset in 1 until curList.size) {
            val pointIndex = (startIndex + (oppositeOffset * -directionMultiplier) + curList.size) % curList.size
            val dist = glm.DistanceSquared(refPoint, curList[pointIndex])
            if (dist < minDist) {
                minDist = dist
                minDistIndex = pointIndex
            } else {
                break
            }
        }

        return minDistIndex
    }

    companion object {
        const val TWO_PI = 2 * PI
    }

}