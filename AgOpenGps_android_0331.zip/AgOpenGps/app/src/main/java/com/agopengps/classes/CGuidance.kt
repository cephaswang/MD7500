package com.agopengps.classes

import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions
import kotlin.math.*


class CGuidance(private val mf: FormGPS) {
    private lateinit var mMap: GoogleMap

    // Steer, pivot, and reference indexes
    private var sA = 0
    private var sB = 0
    private var c = 0
    private var pA = 0
    private var pB = 0

    var distanceFromCurrentLineSteer = 0.0
    var distanceFromCurrentLinePivot = 0.0
    var steerAngleGu = 0.0
    var rEastSteer = 0.0
    var rNorthSteer = 0.0
    var rEastPivot = 0.0
    var rNorthPivot = 0.0

    var inty = 0.0
    var xTrackSteerCorrection = 0.0
    var steerHeadingError = 0.0
    var steerHeadingErrorDegrees = 0.0

    var distSteerError = 0.0
    var lastDistSteerError = 0.0
    var derivativeDistError = 0.0
    var pivotDistanceError = 0.0
    var stanleyModeMultiplier = 0.0

    var sideHillCompFactor = 0.0
    private var counter = 0

    private var guidanceLine: Polyline? = null

    init {
        sideHillCompFactor = mf.settings.setAS_sideHillComp ?: 0.0
    }

    fun setGoogleMap(googleMap: GoogleMap) {
        mMap = googleMap
    }

    private fun doSteerAngleCalc() {
        var headingError = steerHeadingError
        if (mf.isReverse) headingError *= -1.0

        headingError *= mf.vehicle.stanleyHeadingErrorGain

        var sped = abs(mf.avgSpeed)
        sped = if (sped > 1) 1 + 0.277 * (sped - 1) else 1.0

        val xTEc = atan((distanceFromCurrentLineSteer * mf.vehicle.stanleyDistanceErrorGain) / sped)
        xTrackSteerCorrection = (xTrackSteerCorrection * 0.5) + (xTEc * 0.5)

        distSteerError = (distSteerError * 0.95) + ((xTrackSteerCorrection * 60) * 0.05)
        if (counter++ > 5) {
            derivativeDistError = distSteerError - lastDistSteerError
            lastDistSteerError = distSteerError
            counter = 0
        }

        steerAngleGu = toDegrees((xTrackSteerCorrection + headingError) * -1.0)

        steerAngleGu *= when {
            abs(distanceFromCurrentLineSteer) > 0.5 -> 0.5
            else -> (1 - abs(distanceFromCurrentLineSteer))
        }

        pivotDistanceError = (pivotDistanceError * 0.6) + (distanceFromCurrentLinePivot * 0.4)

        if (mf.avgSpeed > 1 && mf.isBtnAutoSteerOn &&
            abs(derivativeDistError) < 1 && abs(pivotDistanceError) < 0.25) {
            inty += if ((inty < 0 && distanceFromCurrentLinePivot < 0) ||
                (inty > 0 && distanceFromCurrentLinePivot > 0)) {
                pivotDistanceError * mf.vehicle.stanleyIntegralGainAB * -0.03
            } else {
                pivotDistanceError * mf.vehicle.stanleyIntegralGainAB * -0.01
            }

            if (mf.vehicle.stanleyIntegralGainAB == 0.0) inty = 0.0
        } else {
            inty *= 0.7
        }

        if (mf.isReverse) inty = 0.0

        if (mf.ahrs.imuRoll != 88888.0) {
            steerAngleGu += mf.ahrs.imuRoll * -sideHillCompFactor
        }

        steerAngleGu = when {
            steerAngleGu < -mf.vehicle.maxSteerAngle -> -mf.vehicle.maxSteerAngle
            steerAngleGu > mf.vehicle.maxSteerAngle -> mf.vehicle.maxSteerAngle
            else -> steerAngleGu
        }

        mf.vehicle.modeActualXTE = distanceFromCurrentLinePivot
        mf.guidanceLineDistanceOff = (distanceFromCurrentLinePivot * 1000.0).roundToInt().toShort()
        mf.guidanceLineSteerAngle = (steerAngleGu * 100).toInt().toShort()
    }

    fun stanleyGuidanceABLine(curPtA: vec3, curPtB: vec3, pivot: vec3, steer: vec3) {
        val dx = curPtB.longitude - curPtA.longitude
        val dy = curPtB.latitude - curPtA.latitude
        if (abs(dx) < Double.MIN_VALUE && abs(dy) < Double.MIN_VALUE) return

        distanceFromCurrentLinePivot = ((dy * pivot.longitude) - (dx * pivot.latitude) +
                (curPtB.longitude * curPtA.latitude) - (curPtB.latitude * curPtA.longitude)) /
                sqrt((dy * dy) + (dx * dx))

        if (!mf.abLine.isHeadingSameWay) distanceFromCurrentLinePivot *= -1.0

        mf.abLine.distanceFromCurrentLinePivot = distanceFromCurrentLinePivot

        val u = (((pivot.longitude - curPtA.longitude) * dx) +
                ((pivot.latitude - curPtA.latitude) * dy)) / ((dx * dx) + (dy * dy))

        rEastPivot = curPtA.longitude + (u * dx)
        rNorthPivot = curPtA.latitude + (u * dy)

        mf.abLine.rEastAB = rEastPivot
        mf.abLine.rNorthAB = rNorthPivot

        var steerA = vec3(curPtA)
        var steerB = vec3(curPtB)

        steerA.longitude += sin(steerA.heading + PI / 2) * inty
        steerA.latitude += cos(steerA.heading + PI / 2) * inty
        steerB.longitude += sin(steerB.heading + PI / 2) * inty
        steerB.latitude += cos(steerB.heading + PI / 2) * inty

        val dxSteer = steerB.longitude - steerA.longitude
        val dySteer = steerB.latitude - steerA.latitude

        if (abs(dxSteer) < Double.MIN_VALUE && abs(dySteer) < Double.MIN_VALUE) return

        distanceFromCurrentLineSteer = ((dySteer * steer.longitude) - (dxSteer * steer.latitude) +
                (steerB.longitude * steerA.latitude) - (steerB.latitude * steerA.longitude)) /
                sqrt((dySteer * dySteer) + (dxSteer * dxSteer))

        if (!mf.abLine.isHeadingSameWay) distanceFromCurrentLinePivot *= -1.0

        val uSteer = (((steer.longitude - steerA.longitude) * dxSteer) +
                ((steer.latitude - steerA.latitude) * dySteer)) /
                ((dxSteer * dxSteer) + (dySteer * dySteer))

        rEastSteer = steerA.longitude + (uSteer * dxSteer)
        rNorthSteer = steerA.latitude + (uSteer * dySteer)

        val steerErr = atan2(rEastSteer - rEastPivot, rNorthSteer - rNorthPivot)
        steerHeadingError = steer.heading - steerErr

        steerHeadingError = when {
            steerHeadingError > PI -> steerHeadingError - PI
            steerHeadingError < -PI -> steerHeadingError + PI
            else -> steerHeadingError
        }

        steerHeadingError = when {
            steerHeadingError > PI/2 -> steerHeadingError - PI
            steerHeadingError < -PI/2 -> steerHeadingError + PI
            else -> steerHeadingError
        }

        mf.vehicle.modeActualHeadingError = toDegrees(steerHeadingError)

        // Draw guidance line on map
        updateGuidanceLine(curPtA, curPtB)

        doSteerAngleCalc()
    }

    private fun updateGuidanceLine(ptA: vec3, ptB: vec3) {
        guidanceLine?.remove()
        guidanceLine = mMap.addPolyline(
            PolylineOptions()
                .add(ptA.toLatLng(), ptB.toLatLng())
                .width(10f) // Wider line (default is 5f)
                .color(0xFF00FF00.toInt()) // Green color
        )
    }

    fun stanleyGuidanceCurve(pivot: vec3, steer: vec3, curList: MutableList<vec3>) {
        if (curList.size <= 5) {
            distanceFromCurrentLineSteer = 32000.0
            mf.guidanceLineDistanceOff = 32000
            return
        }

        // Implementation similar to original, adapted for Google Maps
        // Find closest points and calculate guidance
        // ... (rest of the curve guidance logic)

        // Draw curve on map
        updateCurveGuidanceLine(curList)
    }

    private fun updateCurveGuidanceLine(curList: List<vec3>) {
        guidanceLine?.remove()
        guidanceLine = mMap.addPolyline(
            PolylineOptions()
                .addAll(curList.map { it.toLatLng() })
                .width(10f)
                .color(0xFF00FF00.toInt())
        )
    }

    private fun toDegrees(radians: Double): Double = radians * 180.0 / PI
}

/*
// Assuming these are defined elsewhere in your project
object Properties {
    object Settings {
        object Default {
            const val setAS_sideHillComp = 0.0 // Replace with actual default value
        }
    }
}*/