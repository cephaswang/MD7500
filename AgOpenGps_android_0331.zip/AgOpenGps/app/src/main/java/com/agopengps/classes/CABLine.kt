package com.agopengps.classes

import com.agopengps.classes.glm.isPointInPolygon
import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import kotlin.math.*


class CABLine(private val mf: FormGPS) {
    var abHeading: Double = 0.0
    var abLength: Double = 2000.0

    var isABValid: Boolean = false

    // The current AB guidance line
    var currentLinePtA = vec3(0.0, 0.0, 0.0)
    var currentLinePtB = vec3(0.0, 1.0, 0.0)

    var distanceFromCurrentLinePivot: Double = 0.0
    var distanceFromRefLine: Double = 0.0

    // Pure pursuit values
    var goalPointAB = vec2(0.0, 0.0)

    // List of all available ABLines
    var refLine = CTrk()

    var howManyPathsAway: Double = 0.0
    var lastHowManyPathsAway: Double = 0.0
    var isMakingABLine: Boolean = false
    var isHeadingSameWay: Boolean = true
    var lastIsHeadingSameWay: Boolean = false

    var ppRadiusAB: Double = 0.0

    var radiusPointAB = vec2(0.0, 0.0)
    var rEastAB: Double = 0.0
    var rNorthAB: Double = 0.0

    var snapDistance: Double = 0.0
    var lastSecond: Double = 0.0
    var steerAngleAB: Double = 0.0
    var lineWidth: Int = mf.settings.setDisplay_lineWidth
    var numGuideLines: Int = mf.settings.setAS_numGuideLines

    // Design
    var desPtA = vec2(0.2, 0.15)
    var desPtB = vec2(0.3, 0.3)

    var desLineEndA = vec2(0.0, 0.0)
    var desLineEndB = vec2(999997.0, 1.0)

    var desHeading: Double = 0.0
    var desName: String = ""

    // Autosteer errors
    var pivotDistanceError: Double = 0.0
    var pivotDistanceErrorLast: Double = 0.0
    var pivotDerivative: Double = 0.0
    var pivotDerivativeSmoothed: Double = 0.0

    private var counter2: Int = 0

    var inty: Double = 0.0
    var steerAngleSmoothed: Double = 0.0
    var pivotErrorTotal: Double = 0.0
    var distSteerError: Double = 0.0
    var lastDistSteerError: Double = 0.0
    var derivativeDistError: Double = 0.0

    var tramPassEvery: Int = 0

    init {
        // Constructor logic
    }

    fun buildCurrentABLineList(pivot: vec3) {
        if (mf.trk.gArr.size <= mf.trk.idx || mf.trk.idx < 0) return

        val track:CTrk = mf.trk.gArr[mf.trk.idx]

        if (!isABValid || ((mf.secondsSinceStart - lastSecond) > 0.66 && (!mf.isBtnAutoSteerOn || mf.mc.steerSwitchHigh))) {
            lastSecond = mf.secondsSinceStart

            abHeading = track.heading

            track.endPtA.easting = track.ptA.easting - (sin(abHeading) * abLength)
            track.endPtA.northing = track.ptA.northing - (cos(abHeading) * abLength)

            track.endPtB.easting = track.ptB.easting + (sin(abHeading) * abLength)
            track.endPtB.northing = track.ptB.northing + (cos(abHeading) * abLength)

            val widthMinusOverlap = mf.tool.width - mf.tool.overlap

            val dx = track.endPtB.easting - track.endPtA.easting
            val dy = track.endPtB.northing - track.endPtA.northing

            distanceFromRefLine = ((dy * mf.guidanceLookPos.easting) - (dx * mf.guidanceLookPos.northing) +
                    (track.endPtB.easting * track.endPtA.northing) - (track.endPtB.northing * track.endPtA.easting)) /
                    sqrt((dy * dy) + (dx * dx))

            distanceFromRefLine -= (0.5 * widthMinusOverlap)

            isHeadingSameWay = PI - abs(abs(pivot.heading - abHeading) - PI) < (PI / 2)

            val refDist = (distanceFromRefLine + (if (isHeadingSameWay) mf.tool.offset else -mf.tool.offset) - track.nudgeDistance) / widthMinusOverlap

            howManyPathsAway = if (refDist < 0) (refDist - 0.5).toInt().toDouble() else (refDist + 0.5).toInt().toDouble()
        }

        if (!isABValid || howManyPathsAway != lastHowManyPathsAway || (isHeadingSameWay != lastIsHeadingSameWay && mf.tool.offset != 0.0)) {
            isABValid = true
            lastHowManyPathsAway = howManyPathsAway
            lastIsHeadingSameWay = isHeadingSameWay

            val widthMinusOverlap = mf.tool.width - mf.tool.overlap
            val distAway = widthMinusOverlap * howManyPathsAway + (if (isHeadingSameWay) -mf.tool.offset else mf.tool.offset) + track.nudgeDistance

            val nudgePtA = vec2(track.ptA.easting, track.ptA.northing)
            val nudgePtB = vec2(track.ptB.easting, track.ptB.northing)

            val point1 = vec2((cos(-abHeading) * distAway) + nudgePtA.easting, (sin(-abHeading) * distAway) + nudgePtA.northing)
            val point2 = vec2((cos(-abHeading) * distAway) + nudgePtB.easting, (sin(-abHeading) * distAway) + nudgePtB.northing)

            currentLinePtA.easting = point1.easting - (sin(abHeading) * abLength)
            currentLinePtA.northing = point1.northing - (cos(abHeading) * abLength)
            currentLinePtB.easting = point2.easting + (sin(abHeading) * abLength)
            currentLinePtB.northing = point2.northing + (cos(abHeading) * abLength)

            currentLinePtA.heading = abHeading
            currentLinePtB.heading = abHeading
        }
    }

    fun getCurrentABLine(pivot: vec3, steer: vec3) {
        if (mf.yt.isYouTurnTriggered && mf.yt.distanceFromYouTurnLine()) {
            steerAngleAB = mf.yt.steerAngleYT
            distanceFromCurrentLinePivot = mf.yt.distanceFromCurrentLine
            goalPointAB = mf.yt.goalPointYT
            radiusPointAB.easting = mf.yt.radiusPointYT.easting
            radiusPointAB.northing = mf.yt.radiusPointYT.northing
            ppRadiusAB = mf.yt.ppRadiusYT
            mf.vehicle.modeTimeCounter = 0
            mf.vehicle.modeActualXTE = distanceFromCurrentLinePivot
        } else if (mf.isStanleyUsed) {
            mf.gyd.stanleyGuidanceABLine(currentLinePtA, currentLinePtB, pivot, steer)
        } else {
            val dx = currentLinePtB.easting - currentLinePtA.easting
            val dy = currentLinePtB.northing - currentLinePtA.northing

            distanceFromCurrentLinePivot = ((dy * pivot.easting) - (dx * pivot.northing) +
                    (currentLinePtB.easting * currentLinePtA.northing) - (currentLinePtB.northing * currentLinePtA.easting)) /
                    sqrt((dy * dy) + (dx * dx))

            if (mf.vehicle.purePursuitIntegralGain != 0.0 && !mf.isReverse) {
                pivotDistanceError = distanceFromCurrentLinePivot * 0.2 + pivotDistanceError * 0.8

                if (counter2++ > 4) {
                    pivotDerivative = pivotDistanceError - pivotDistanceErrorLast
                    pivotDistanceErrorLast = pivotDistanceError
                    counter2 = 0
                    pivotDerivative *= 2
                }

                if (mf.isBtnAutoSteerOn && abs(pivotDerivative) < 0.1 && mf.avgSpeed > 2.5 && !mf.yt.isYouTurnTriggered) {
                    if ((inty < 0 && distanceFromCurrentLinePivot < 0) || (inty > 0 && distanceFromCurrentLinePivot > 0)) {
                        inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.04
                    } else {
                        if (abs(distanceFromCurrentLinePivot) > 0.02) {
                            inty += pivotDistanceError * mf.vehicle.purePursuitIntegralGain * -0.02
                            if (inty > 0.2) inty = 0.2
                            else if (inty < -0.2) inty = -0.2
                        }
                    }
                } else {
                    inty *= 0.95
                }
            } else {
                inty = 0.0
            }

            val u = (((pivot.easting - currentLinePtA.easting) * dx) + ((pivot.northing - currentLinePtA.northing) * dy)) /
                    ((dx * dx) + (dy * dy))

            rEastAB = currentLinePtA.easting + (u * dx)
            rNorthAB = currentLinePtA.northing + (u * dy)

            val goalPointDistance = mf.vehicle.updateGoalPointDistance()

            if (mf.isReverse xor isHeadingSameWay) {
                goalPointAB.easting = rEastAB + (sin(abHeading) * goalPointDistance)
                goalPointAB.northing = rNorthAB + (cos(abHeading) * goalPointDistance)
            } else {
                goalPointAB.easting = rEastAB - (sin(abHeading) * goalPointDistance)
                goalPointAB.northing = rNorthAB - (cos(abHeading) * goalPointDistance)
            }

            val goalPointDistanceDSquared = distanceSquared(goalPointAB.northing, goalPointAB.easting, pivot.northing, pivot.easting)

            val localHeading = if (isHeadingSameWay) (2 * PI - mf.fixHeading + inty) else (2 * PI - mf.fixHeading - inty)

            ppRadiusAB = goalPointDistanceDSquared / (2 * (((goalPointAB.easting - pivot.easting) * cos(localHeading)) +
                    ((goalPointAB.northing - pivot.northing) * sin(localHeading))))

            steerAngleAB = toDegrees(atan(2 * (((goalPointAB.easting - pivot.easting) * cos(localHeading)) +
                    ((goalPointAB.northing - pivot.northing) * sin(localHeading))) * mf.vehicle.wheelbase / goalPointDistanceDSquared))

            if (mf.ahrs.imuRoll != 88888.0) {
                steerAngleAB += mf.ahrs.imuRoll * -mf.gyd.sideHillCompFactor
            }

            steerAngleAB = steerAngleAB.coerceIn(-mf.vehicle.maxSteerAngle, mf.vehicle.maxSteerAngle)

            ppRadiusAB = ppRadiusAB.coerceIn(-500.0, 500.0)

            radiusPointAB.easting = pivot.easting + (ppRadiusAB * cos(localHeading))
            radiusPointAB.northing = pivot.northing + (ppRadiusAB * sin(localHeading))

            if (!isHeadingSameWay) {
                distanceFromCurrentLinePivot *= -1.0
            }

            mf.vehicle.modeActualXTE = distanceFromCurrentLinePivot

            var steerHeadingError = pivot.heading - abHeading
            if (steerHeadingError > PI) steerHeadingError -= PI
            else if (steerHeadingError < -PI) steerHeadingError += PI

            if (steerHeadingError > PI / 2) steerHeadingError -= PI
            else if (steerHeadingError < -PI / 2) steerHeadingError += PI

            mf.vehicle.modeActualHeadingError = toDegrees(steerHeadingError)

            mf.guidanceLineDistanceOff = (distanceFromCurrentLinePivot * 1000.0).roundToInt().toShort()
            mf.guidanceLineSteerAngle = (steerAngleAB * 100).toInt().toShort()
        }
    }

    // Modified to use Google Maps
    fun drawABLineNew(googleMap: GoogleMap) {
        val polylineOptions = PolylineOptions()
            .add(LatLng(desLineEndA.northing, desLineEndA.easting))
            .add(LatLng(desLineEndB.northing, desLineEndB.easting))
            .color(android.graphics.Color.argb(255, 242, 178, 127)) // Equivalent to (0.95f, 0.70f, 0.50f)
            .width(lineWidth.toFloat())

        googleMap.addPolyline(polylineOptions)
        // Note: Text drawing like "&A" and "&B" requires custom markers in Google Maps
    }

    // Modified to use Google Maps
    fun drawABLines(googleMap: GoogleMap) {
        val track = mf.trk.gArr[mf.trk.idx]

        // Draw reference AB line
        val refLineOptions = PolylineOptions()
            .add(LatLng(track.endPtA.northing, track.endPtA.easting))
            .add(LatLng(track.endPtB.northing, track.endPtB.easting))
            .color(android.graphics.Color.argb(255, 237, 51, 51)) // Equivalent to (0.930f, 0.2f, 0.2f)
            .width(4f)
            .pattern(listOf(com.google.android.gms.maps.model.Dash(10f))) // Stippled line

        googleMap.addPolyline(refLineOptions)

        // Draw current AB line
        val currentLineOptions = PolylineOptions()
            .add(LatLng(currentLinePtA.northing, currentLinePtA.easting))
            .add(LatLng(currentLinePtB.northing, currentLinePtB.easting))
            .color(android.graphics.Color.argb(255, 242, 51, 242)) // Equivalent to (0.95f, 0.20f, 0.950f)
            .width(lineWidth.toFloat())

        googleMap.addPolyline(currentLineOptions)

        // Add side guide lines if enabled
        if (mf.isSideGuideLines && mf.camera.camSetDistance > mf.tool.width * -400) {
            val toolWidth = mf.tool.width - mf.tool.overlap
            val cosHeading = cos(-abHeading)
            val sinHeading = sin(-abHeading)

            for (i in 1..numGuideLines) {
                val sideLineOptions = PolylineOptions()
                    .add(LatLng((sinHeading * (toolWidth * i)) + currentLinePtA.northing, (cosHeading * (toolWidth * i)) + currentLinePtA.easting))
                    .add(LatLng((sinHeading * (toolWidth * i)) + currentLinePtB.northing, (cosHeading * (toolWidth * i)) + currentLinePtB.easting))
                    .color(android.graphics.Color.argb(153, 50, 153, 50)) // Equivalent to (0.19907f, 0.6f, 0.19750f, 0.6f)
                    .width(lineWidth.toFloat())

                googleMap.addPolyline(sideLineOptions)

                val negSideLineOptions = PolylineOptions()
                    .add(LatLng((sinHeading * (-toolWidth * i)) + currentLinePtA.northing, (cosHeading * (-toolWidth * i)) + currentLinePtA.easting))
                    .add(LatLng((sinHeading * (-toolWidth * i)) + currentLinePtB.northing, (cosHeading * (-toolWidth * i)) + currentLinePtB.easting))
                    .color(android.graphics.Color.argb(153, 50, 153, 50))
                    .width(lineWidth.toFloat())

                googleMap.addPolyline(negSideLineOptions)
            }
        }

        // Note: Shadows and text annotations are omitted here as they require more complex Google Maps implementations (e.g., polygons, markers).
    }

    fun buildTram() {
        if (mf.tram.generateMode != 1) {
            mf.tram.buildTramBnd()
        } else {
            mf.tram.tramBndOuterArr.clear()
            mf.tram.tramBndInnerArr.clear()
        }

        mf.tram.tramList.clear()
        mf.tram.tramArr?.clear()

        if (mf.tram.generateMode == 2) return

        val tramRef = mutableListOf<vec2>()
        val isBndExist = mf.bnd.bndList.isNotEmpty()

        abHeading = mf.trk.gArr[mf.trk.idx].heading

        val hsin = sin(abHeading)
        val hcos = cos(abHeading)

        val len = distance(mf.trk.gArr[mf.trk.idx].endPtA, mf.trk.gArr[mf.trk.idx].endPtB)
        for (i in 0 until len.toInt() step 4) {
            tramRef.add(vec2((hsin * i) + mf.trk.gArr[mf.trk.idx].endPtA.easting, (hcos * i) + mf.trk.gArr[mf.trk.idx].endPtA.northing))
        }

        val headingCalc = abHeading + (PI / 2)
        val hsinCalc = sin(headingCalc)
        val hcosCalc = cos(headingCalc)

        mf.tram.tramList.clear()
        mf.tram.tramArr?.clear()

        val cntr = if (isBndExist && mf.tram.generateMode != 1) 1 else 0

        for (i in cntr until mf.tram.passes) {
            mf.tram.tramArr = ArrayList<vec2>(128).apply {
                ensureCapacity(128)
            }
            mf.tram.tramList.add(mf.tram.tramArr!!)

            var widd = (mf.tram.tramWidth * 0.5) - mf.tram.halfWheelTrack + (mf.tram.tramWidth * i)
            for (j in tramRef.indices) {
                val p1 = vec2(hsinCalc * widd + tramRef[j].easting, hcosCalc * widd + tramRef[j].northing)
                if (!isBndExist || mf.bnd.bndList[0].fenceLineEar.isPointInPolygon(p1)) {
                    mf.tram.tramArr?.add(p1)
                }
            }

            widd = (mf.tram.tramWidth * 0.5) + mf.tram.halfWheelTrack + (mf.tram.tramWidth * i)
           // mf.tram.tramArr = mutableListOf<vec2>().apply { ensureCapacity(128) }
            mf.tram.tramArr = ArrayList<vec2>(128).apply {
                ensureCapacity(128)
            }
            mf.tram.tramList.add(mf.tram.tramArr!!)

            for (j in tramRef.indices) {
                val p1 = vec2(hsinCalc * widd + tramRef[j].easting, hcosCalc * widd + tramRef[j].northing)
                if (!isBndExist || mf.bnd.bndList[0].fenceLineEar.isPointInPolygon(p1)) {
                    mf.tram.tramArr?.add(p1)
                }
            }
        }

        tramRef.clear()
    }

    // Helper functions (simplified from glm)
    private fun distanceSquared(n1: Double, e1: Double, n2: Double, e2: Double): Double {
        val dx = e1 - e2
        val dy = n1 - n2
        return dx * dx + dy * dy
    }

    private fun distance(p1: vec2, p2: vec2): Double {
        return sqrt(distanceSquared(p1.northing, p1.easting, p2.northing, p2.easting))
    }

    private fun toDegrees(radians: Double): Double = radians * (180.0 / PI)
}