package com.agopengps.classes

import javax.microedition.khronos.opengles.GL10
import com.agopengps.drive.MainActivity
import com.agopengps.classes.*
import kotlin.math.cos
import kotlin.math.sin


class CTram(private val mf: MainActivity) {
    // List of constants and multiples of the boundary
    val calcList = mutableListOf<Vec2>()

    // Triangle strip of the outer tram highlight
    val tramBndOuterArr = mutableListOf<Vec2>()
    val tramBndInnerArr = mutableListOf<Vec2>()

    // Tram settings
    var tramWidth: Double = 0.0
    var halfWheelTrack: Double = 0.0
    var alpha: Double = 0.0
    var passes: Int = 0
    var isOuter: Boolean = false
    var isLeftManualOn: Boolean = false
    var isRightManualOn: Boolean = false

    // Tram lines
    var tramArr = mutableListOf<Vec2>()
    val tramList = mutableListOf<MutableList<Vec2>>()

    // Display modes: 0 off, 1 All, 2 Lines, 3 Outer
    var displayMode: Int = 0
    var generateMode: Int = 0

    internal var controlByte: Int = 0

    init {
        // Constructor
        tramWidth = mf.settings.setTram_tramWidth
        halfWheelTrack = mf.settings.setVehicle_trackWidth * 0.5
        isTramOuterOrInner()
        passes = mf.settings.setTram_passes
        displayMode = 0
        alpha = mf.settings.setTram_alpha
    }

    fun isTramOuterOrInner() {
        isOuter = ((tramWidth / mf.tool.width + 0.5).toInt() % 2 == 0)
        if (mf.settings.setTool_isTramOuterInverted) isOuter = !isOuter
    }

    fun drawTram(gl: GL10) {
        val lineWidth = if (mf.camera.camSetDistance > -500) 10f else 6f
        gl.glLineWidth(lineWidth)
        gl.glColor4f(0f, 0f, 0f, alpha.toFloat())

        if (displayMode == 1 || displayMode == 2) {
            if (tramList.isNotEmpty()) {
                for (tramLine in tramList) {
                    gl.glBegin(GL10.GL_LINE_STRIP)
                    for (point in tramLine) {
                        gl.glVertex3f(point.easting.toFloat(), point.northing.toFloat(), 0f)
                    }
                    gl.glEnd()
                }
            }
        }

        if (displayMode == 1 || displayMode == 3) {
            if (tramBndOuterArr.isNotEmpty()) {
                gl.glBegin(GL10.GL_LINE_STRIP)
                for (point in tramBndOuterArr) {
                    gl.glVertex3f(point.easting.toFloat(), point.northing.toFloat(), 0f)
                }
                gl.glEnd()

                gl.glBegin(GL10.GL_LINE_STRIP)
                for (point in tramBndInnerArr) {
                    gl.glVertex3f(point.easting.toFloat(), point.northing.toFloat(), 0f)
                }
                gl.glEnd()
            }
        }

        val thinLineWidth = if (mf.camera.camSetDistance > -500) 4f else 2f
        gl.glLineWidth(thinLineWidth)
        gl.glColor4f(0.930f, 0.72f, 0.73530f, alpha.toFloat())

        if (displayMode == 1 || displayMode == 2) {
            if (tramList.isNotEmpty()) {
                for (tramLine in tramList) {
                    gl.glBegin(GL10.GL_LINE_STRIP)
                    for (point in tramLine) {
                        gl.glVertex3f(point.easting.toFloat(), point.northing.toFloat(), 0f)
                    }
                    gl.glEnd()
                }
            }
        }

        if (displayMode == 1 || displayMode == 3) {
            if (tramBndOuterArr.isNotEmpty()) {
                gl.glBegin(GL10.GL_LINE_STRIP)
                for (point in tramBndOuterArr) {
                    gl.glVertex3f(point.easting.toFloat(), point.northing.toFloat(), 0f)
                }
                gl.glEnd()

                gl.glBegin(GL10.GL_LINE_STRIP)
                for (point in tramBndInnerArr) {
                    gl.glVertex3f(point.easting.toFloat(), point.northing.toFloat(), 0f)
                }
                gl.glEnd()
            }
        }
    }

    fun buildTramBnd() {
        val isBndExist = mf.bnd.bndList.isNotEmpty()

        if (isBndExist) {
            createBndOuterTramTrack()
            createBndInnerTramTrack()
        } else {
            tramBndOuterArr.clear()
            tramBndInnerArr.clear()
        }
    }

    private fun createBndInnerTramTrack() {
        // Count the points from the boundary
        val ptCount = mf.bnd.bndList[0].fenceLine.size
        tramBndInnerArr.clear()

        val distSq = ((tramWidth * 0.5) + halfWheelTrack).let { it * it } * 0.999

        // Make the boundary tram outer array
        for (i in 0 until ptCount) {
            val fencePoint = mf.bnd.bndList[0].fenceLine[i]
            val pt3 = Vec2(
                fencePoint.easting - (sin(glm.PIBy2 + fencePoint.heading) * (tramWidth * 0.5 + halfWheelTrack),
                fencePoint.northing - (cos(glm.PIBy2 + fencePoint.heading) * (tramWidth * 0.5 + halfWheelTrack))
            )

            val shouldAdd = (0 until ptCount).none { j ->
                glm.distanceSquared(
                    pt3.northing, pt3.easting,
                    mf.bnd.bndList[0].fenceLine[j].northing, mf.bnd.bndList[0].fenceLine[j].easting
                ) < distSq
            }

            if (shouldAdd) {
                if (tramBndInnerArr.isNotEmpty()) {
                    val lastPoint = tramBndInnerArr.last()
                    val dist = (pt3.easting - lastPoint.easting).pow(2) +
                            (pt3.northing - lastPoint.northing).pow(2)
                    if (dist > 2) {
                        tramBndInnerArr.add(pt3)
                    }
                } else {
                    tramBndInnerArr.add(pt3)
                }
            }
        }
    }

    fun createBndOuterTramTrack() {
        // Count the points from the boundary
        val ptCount = mf.bnd.bndList[0].fenceLine.size
        tramBndOuterArr.clear()

        val distSq = ((tramWidth * 0.5) - halfWheelTrack).let { it * it } * 0.999

        // Make the boundary tram outer array
        for (i in 0 until ptCount) {
            val fencePoint = mf.bnd.bndList[0].fenceLine[i]
            val pt3 = Vec2(
                fencePoint.easting - (sin(glm.PIBy2 + fencePoint.heading) * (tramWidth * 0.5 - halfWheelTrack),
                fencePoint.northing - (cos(glm.PIBy2 + fencePoint.heading) * (tramWidth * 0.5 - halfWheelTrack)
                        )

                val shouldAdd = (0 until ptCount).none { j ->
                glm.distanceSquared(
                    pt3.northing, pt3.easting,
                    mf.bnd.bndList[0].fenceLine[j].northing, mf.bnd.bndList[0].fenceLine[j].easting
                ) < distSq
            }

            if (shouldAdd) {
                if (tramBndOuterArr.isNotEmpty()) {
                    val lastPoint = tramBndOuterArr.last()
                    val dist = (pt3.easting - lastPoint.easting).pow(2) +
                            (pt3.northing - lastPoint.northing).pow(2)
                    if (dist > 2) {
                        tramBndOuterArr.add(pt3)
                    }
                } else {
                    tramBndOuterArr.add(pt3)
                }
            }
        }
    }
}