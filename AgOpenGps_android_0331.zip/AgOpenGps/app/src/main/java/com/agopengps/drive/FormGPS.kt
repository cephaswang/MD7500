package com.agopengps.drive

import android.content.Context
import android.content.res.Resources
import android.os.Bundle
import android.os.PowerManager
import android.os.SystemClock
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.agopengps.classes.*
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.*
import java.util.*
import kotlin.math.roundToInt


class FormGPS : AppCompatActivity(), OnMapReadyCallback {
    companion object {
        const val MAXSECTIONS = 64
        const val MAXBOUNDARIES = 6
        const val MAXHEADS = 6
    }

    var makeUTurnCounter: Int = 0


    var guidanceLineDistanceOff: Short = 0
    var guidanceLineSteerAngle: kotlin.Short = 0

    var fixHeading = 0.0
    var isReverse = false
    var avgSpeed: Double = 0.0
  //  var previousSpeed: kotlin.Double = 0.0 //for average speed

    var guidanceLookPos: vec2 = vec2(0.0, 0.0)
    // Properties
    lateinit var settings: SettingsData
    var currentFieldDirectory: String? = null
    var displayFieldName: String? = null
    private var leftMouseDownOnOpenGL = false
    var flagNumberPicked = 0
    var isJobStarted = false
    var isBtnAutoSteerOn = false
    var isLidarBtnOn = true
    var isSavingFile = false
    var isSideGuideLines = false

    val secondsSinceStart: Double
        get() = SystemClock.elapsedRealtime() / 1000.0
    var gridToolSpacing = 0.0

    var frameTime = 0.0
    var gpsHz = 10.0
    var isStanleyUsed = true

    var pbarSteer = 0
    var pbarMachine = 0
    var pbarUDP = 0
    var nudNumber = 0.0

    var m2InchOrCm = 0.0
    var inchOrCm2m = 0.0
    var m2FtOrM = 0.0
    var ftOrMtoM = 0.0
    var cm2CmOrIn = 0.0
    var inOrCm2Cm = 0.0
    var unitsFtM: String? = null
    var unitsInCm: String? = null
    var unitsInCmNS: String? = null

    var hotkeys: CharArray? = null
    var filePickerFileAndDirectory: String? = null

    var GPSDataWindowLeft = 80
    var GPSDataWindowTopOffset = 220
    var isInAutoDrive = true
    var isGPSSentencesOn = false
    var isKeepOffsetsOn = false


    var pivotAxlePos: vec3 = vec3(0.0, 0.0, 0.0)
    var steerAxlePos: vec3 = vec3(0.0, 0.0, 0.0)
    var toolPivotPos: vec3 = vec3(0.0, 0.0, 0.0)
    var toolPos: vec3 = vec3(0.0, 0.0, 0.0)
    var tankPos: vec3 = vec3(0.0, 0.0, 0.0)
    var hitchPos: vec2 = vec2(0.0, 0.0)

    // Class instances
    lateinit var camera: CCamera
    lateinit var worldGrid: CWorldGrid
    lateinit var pn: CNMEA
    lateinit var section: Array<CSection>
    val triStrip = mutableListOf<CPatches>()
    lateinit var ABLine: CABLine
    lateinit var tram: CTram
    lateinit var ct: CContour
    lateinit var trk: CTrack
    lateinit var curve: CABCurve
    lateinit var yt: CYouTurn
    lateinit var vehicle: CVehicle
    lateinit var tool: CTool
    lateinit var mc: CModuleComm
    lateinit var bnd: CBoundary
    lateinit var hdl: CHeadLine
    lateinit var sim: CSim
    lateinit var _rm: Resources
    lateinit var ahrs: CAHRS
    lateinit var recPath: CRecordedPath
    lateinit var fd: CFieldData
    lateinit var sounds: CSound
    lateinit var font: CFont
    lateinit var gyd: CGuidance
    lateinit var displayBrightness: CWindowsSettingsBrightnessController

    var distancePivotToTurnLine: Double = -2222.0
    var distanceToolToTurnLine: Double = -2222.0

    // Google Maps
    lateinit var mMap: GoogleMap
    private lateinit var mapFragment: SupportMapFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_form_gps)

        initializeComponents()
        // 初始化 SettingsData
        settings = SettingsData()

        // Setup Google Maps
        mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        setupPowerModeListener()
    }

    private fun initializeComponents() {
        camera = CCamera()
        worldGrid = CWorldGrid(this)
        vehicle = CVehicle(this)
        tool = CTool(this)

        section = Array(MAXSECTIONS) { CSection() }
        triStrip.add(CPatches(this))

        pn = CNMEA(this)
        ABLine = CABLine(this)
        ct = CContour(this)
        curve = CABCurve(this)
        trk = CTrack(this)
        hdl = CHeadLine(this)
        yt = CYouTurn(this)
        mc = CModuleComm(this)
        bnd = CBoundary(this)
        sim = CSim(this)
        ahrs = CAHRS()
        recPath = CRecordedPath(this)
        fd = CFieldData(this)
        tram = CTram(this)
        _rm = resources
        font = CFont(this)
        gyd = CGuidance(this)
        sounds = CSound(this)
        displayBrightness = CWindowsSettingsBrightnessController(false)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        setupMap()
        loadMapData()
    }

    private fun setupMap() {
        mMap.mapType = GoogleMap.MAP_TYPE_SATELLITE
        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isCompassEnabled = true
    }

    private fun loadMapData() {
        // Replace OpenGL texture loading with Google Maps overlays
        // Example: Add vehicle position
        val vehiclePosition = LatLng(pn.latitude, pn.longitude)
        mMap.addMarker(
            MarkerOptions()
                .position(vehiclePosition)
                .title("Vehicle")
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.tractor_icon))
        )

        // Add boundary
        if (bnd.bndList.isNotEmpty()) {
            val polygonOptions = PolygonOptions()
            bnd.bndList.forEach { boundary ->
                boundary.points.forEach { point ->
                    polygonOptions.add(LatLng(point.latitude, point.longitude))
                }
            }
            mMap.addPolygon(polygonOptions.strokeColor(android.graphics.Color.RED))
        }

        setZoom()
    }

    private fun setupPowerModeListener() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        // Android doesn't have a direct equivalent to Windows PowerModeChanged event
        // You might want to use BroadcastReceiver for power events
    }

    fun jobNew() {
        isJobStarted = true
        // Update UI elements
        findViewById<View>(R.id.btnSectionMasterManual)?.isEnabled = true
        findViewById<View>(R.id.btnSectionMasterAuto)?.isEnabled = true
        findViewById<View>(R.id.btnContour)?.isEnabled = true
        findViewById<View>(R.id.btnTrack)?.isEnabled = true
        findViewById<View>(R.id.btnABDraw)?.isEnabled = true
        findViewById<View>(R.id.btnAutoSteer)?.isEnabled = true
        findViewById<View>(R.id.btnFlag)?.isEnabled = true

        ABLine.abHeading = 0.00
        fileSaveCounter = 25

        updateMapDisplay()
    }

    fun jobClose() {
        recPath.resumeState = 0
        bnd.isHeadlandOn = false

        // Clear map overlays
        mMap.clear()

        isJobStarted = false
        triStrip.clear()
        triStrip.add(CPatches(this))
        flagPts.clear()
        tram.tramList?.clear()
        curve.resetCurveLine()
        trk.gArr?.clear()
        trk.idx = -1

        updateMapDisplay()
    }

    private fun updateMapDisplay() {
        mMap.clear()

        // Add vehicle marker
        val vehiclePosition = LatLng(pn.latitude, pn.longitude)
        mMap.addMarker(
            MarkerOptions()
                .position(vehiclePosition)
                .title("Vehicle")
                .rotation(vehicle.heading.toFloat())
        )

        // Add sections
        section.forEach { sec ->
            if (sec.isSectionOn) {
                val polygon = PolygonOptions()
                sec.points.forEach { point ->
                    polygon.add(LatLng(point.latitude, point.longitude))
                }
                mMap.addPolygon(polygon.fillColor(android.graphics.Color.argb(100, 0, 255, 0)))
            }
        }
    }

    fun setZoom() {
        val zoomLevel = when {
            camera.camSetDistance < 100 -> 18f
            camera.camSetDistance < 500 -> 15f
            camera.camSetDistance < 2000 -> 12f
            else -> 10f
        }

        gridToolSpacing = (camera.gridZoom / tool.width + 0.5).roundToInt().toDouble()
        if (gridToolSpacing < 1) gridToolSpacing = 1.0
        camera.gridZoom = gridToolSpacing * tool.width

        mMap.animateCamera(CameraUpdateFactory.zoomTo(zoomLevel))
    }

    fun timedMessageBox(timeout: Int, s1: String, s2: String) {
        // Show toast or dialog
        android.widget.Toast.makeText(this, "$s1\n$s2", android.widget.Toast.LENGTH_LONG).show()
    }

    fun yesMessageBox(s1: String) {
        android.app.AlertDialog.Builder(this)
            .setMessage(s1)
            .setPositiveButton("OK") { _, _ -> }
            .show()
    }

    fun randomNumber(min: Double, max: Double): Double {
        return min + Random().nextDouble() * (max - min)
    }

    private var fileSaveCounter = 0

    /*
    // Assuming these classes exist as simple data holders
    data class CCamera(var camSetDistance: Double = -200.0, var gridZoom: Double = 0.0)
    data class CWorldGrid(val context: FormGPS)
    data class CNMEA(val context: FormGPS) { var latitude: Double = 0.0; var longitude: Double = 0.0 }
    data class CSection(var isSectionOn: Boolean = false, val points: MutableList<Point> = mutableListOf())
    data class CPatches(val context: FormGPS)
    data class CABLine(val context: FormGPS) { var abHeading = 0.0 }
    data class CTram(val context: FormGPS) { var tramList: MutableList<Any>? = null }
    data class CContour(val context: FormGPS) { fun resetContour() {} }
    data class CTrack(val context: FormGPS) { var gArr: MutableList<Any>? = null; var idx = -1 }
    data class CABCurve(val context: FormGPS) { fun resetCurveLine() {} }
    data class CYouTurn(val context: FormGPS)
    data class CVehicle(val context: FormGPS) { var heading = 0.0 }
    data class CTool(val context: FormGPS) { var width = 0.0 }
    data class CModuleComm(val context: FormGPS)
    data class CBoundary(val context: FormGPS) {
        val bndList = mutableListOf<Boundary>();
        var isHeadlandOn = false
    }
    data class CHeadLine(val context: FormGPS)
    data class CSim(val context: FormGPS)
    data class CAHRS()
    data class CRecordedPath(val context: FormGPS) {
        var resumeState = 0;
        var recList: MutableList<Any>? = null
    }
    data class CFieldData(val context: FormGPS)
    data class CSound()
    data class CFont(val context: FormGPS)
    data class CGuidance(val context: FormGPS)
    data class CWindowsSettingsBrightnessController(val isOn: Boolean)
    data class Point(val latitude: Double, val longitude: Double)
    data class Boundary(val points: MutableList<Point>)
*/
    val flagPts = mutableListOf<Any>()
}

// layout/activity_form_gps.xml would need to be created with:
// <fragment android:id="@+id/map"
//           android:name="com.google.android.gms.maps.SupportMapFragment"
//           android:layout_width="match_parent"
//           android:layout_height="match_parent"/>