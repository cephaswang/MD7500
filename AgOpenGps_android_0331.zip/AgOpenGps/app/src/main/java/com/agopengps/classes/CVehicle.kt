package com.agopengps.classes

import android.opengl.GLES20
import com.agopengps.drive.MainActivity
import com.agopengps.classes.*

class CVehicle(private val mf: MainActivity) {
    var isSteerAxleAhead: Boolean = false
    var isPivotBehindAntenna: Boolean = false

    var antennaHeight: Double = 0.0
    var antennaPivot: Double = 0.0
    var wheelbase: Double = 0.0
    var antennaOffset: Double = 0.0
    var deadZoneHeading: Int = 0
    var deadZoneDelay: Int = 0
    var vehicleType: Int = 0
    var deadZoneDelayCounter: Int = 0
    var isInDeadZone: Boolean = false

    //min vehicle speed allowed before turning shit off
    var slowSpeedCutoff: Double = 0.0

    //autosteer values
    var goalPointLookAheadHold: Double = 0.0
    var goalPointLookAheadMult: Double = 0.0
    var goalPointAcquireFactor: Double = 0.0
    var uturnCompensation: Double = 0.0

    var stanleyDistanceErrorGain: Double = 0.0
    var stanleyHeadingErrorGain: Double = 0.0
    var minLookAheadDistance: Double = 2.0
    var maxSteerAngle: Double = 0.0
    var maxSteerSpeed: Double = 0.0
    var minSteerSpeed: Double = 0.0
    var maxAngularVelocity: Double = 0.0
    var hydLiftLookAheadTime: Double = 0.0
    var trackWidth: Double = 0.0

    var hydLiftLookAheadDistanceLeft: Double = 0.0
    var hydLiftLookAheadDistanceRight: Double = 0.0

    var isHydLiftOn: Boolean = false
    var stanleyIntegralDistanceAwayTriggerAB: Double = 0.0
    var stanleyIntegralGainAB: Double = 0.0
    var purePursuitIntegralGain: Double = 0.0

    //flag for free drive window to control autosteer
    var isInFreeDriveMode: Boolean = false

    //the trackbar angle for free drive
    var driveFreeSteerAngle: Double = 0.0

    var modeXTE: Double = 0.0
    var modeActualXTE: Double = 0.0
    var modeActualHeadingError: Double = 0.0
    var modeTime: Int = 0

    var functionSpeedLimit: Double = 0.0

    var modeTimeCounter: Int = 0
    var goalDistance: Double = 0.0

    init {
        //constructor
        isPivotBehindAntenna = mf.settings.getBoolean("setVehicle_isPivotBehindAntenna", false)
        antennaHeight = mf.settings.getDouble("setVehicle_antennaHeight", 0.0)
        antennaPivot = mf.settings.getDouble("setVehicle_antennaPivot", 0.0)
        antennaOffset = mf.settings.getDouble("setVehicle_antennaOffset", 0.0)

        wheelbase = mf.settings.getDouble("setVehicle_wheelbase", 0.0)
        isSteerAxleAhead = mf.settings.getBoolean("setVehicle_isSteerAxleAhead", false)

        slowSpeedCutoff = mf.settings.getDouble("setVehicle_slowSpeedCutoff", 0.0)

        goalPointLookAheadHold = mf.settings.getDouble("setVehicle_goalPointLookAheadHold", 0.0)
        goalPointLookAheadMult = mf.settings.getDouble("setVehicle_goalPointLookAheadMult", 0.0)
        goalPointAcquireFactor = mf.settings.getDouble("setVehicle_goalPointAcquireFactor", 0.0)

        stanleyDistanceErrorGain = mf.settings.getDouble("stanleyDistanceErrorGain", 0.0)
        stanleyHeadingErrorGain = mf.settings.getDouble("stanleyHeadingErrorGain", 0.0)

        maxAngularVelocity = mf.settings.getDouble("setVehicle_maxAngularVelocity", 0.0)
        maxSteerAngle = mf.settings.getDouble("setVehicle_maxSteerAngle", 0.0)

        isHydLiftOn = false

        trackWidth = mf.settings.getDouble("setVehicle_trackWidth", 0.0)

        stanleyIntegralGainAB = mf.settings.getDouble("stanleyIntegralGainAB", 0.0)
        stanleyIntegralDistanceAwayTriggerAB = mf.settings.getDouble("stanleyIntegralDistanceAwayTriggerAB", 0.0)

        purePursuitIntegralGain = mf.settings.getDouble("purePursuitIntegralGainAB", 0.0)
        vehicleType = mf.settings.getInt("setVehicle_vehicleType", 0)

        hydLiftLookAheadTime = mf.settings.getDouble("setVehicle_hydraulicLiftLookAhead", 0.0)

        deadZoneHeading = mf.settings.getInt("setAS_deadZoneHeading", 0)
        deadZoneDelay = mf.settings.getInt("setAS_deadZoneDelay", 0)

        isInFreeDriveMode = false

        //how far from line before it becomes Hold
        modeXTE = 0.2

        //how long before hold is activated
        modeTime = 1

        functionSpeedLimit = mf.settings.getDouble("setAS_functionSpeedLimit", 0.0)
        maxSteerSpeed = mf.settings.getDouble("setAS_maxSteerSpeed", 0.0)
        minSteerSpeed = mf.settings.getDouble("setAS_minSteerSpeed", 0.0)

        uturnCompensation = mf.settings.getDouble("setAS_uTurnCompensation", 0.0)
    }

    fun updateGoalPointDistance(): Double {
        val xTE = Math.abs(modeActualXTE)
        var goalPointDistance = mf.avgSpeed * 0.05 * goalPointLookAheadMult

        var loekiAheadHold = goalPointLookAheadHold
        var loekiAheadAcquire = goalPointLookAheadHold * goalPointAcquireFactor

        if (!mf.isBtnAutoSteerOn) {
            loekiAheadHold = 5.0
            loekiAheadAcquire = loekiAheadHold * goalPointAcquireFactor
        }

        if (xTE <= 0.1) {
            goalPointDistance *= loekiAheadHold
            goalPointDistance += loekiAheadHold
        } else if (xTE > 0.1 && xTE < 0.4) {
            val adjustedXTE = xTE - 0.1

            loekiAheadHold = (1 - (adjustedXTE / 0.3)) * (loekiAheadHold - loekiAheadAcquire)
            loekiAheadHold += loekiAheadAcquire

            goalPointDistance *= loekiAheadHold
            goalPointDistance += loekiAheadHold
        } else {
            goalPointDistance *= loekiAheadAcquire
            goalPointDistance += loekiAheadAcquire
        }

        if (goalPointDistance < 2) goalPointDistance = 2.0
        goalDistance = goalPointDistance

        return goalPointDistance
    }

    fun drawVehicle() {
        //draw vehicle
        GLES20.glRotatef((-mf.fixHeading).toDegrees(), 0.0f, 0.0f, 1.0f)

        if (mf.isFirstHeadingSet && !mf.tool.isToolFrontFixed) {
            if (!mf.tool.isToolRearFixed) {
                GLES20.glLineWidth(4.0f)
                //draw the rigid hitch
                GLES20.glColor3f(0f, 0f, 0f)
                GLES20.glBegin(GLES20.GL_LINES)
                GLES20.glVertex3f(0f, mf.tool.hitchLength.toFloat(), 0f)
                GLES20.glVertex3f(0f, 0f, 0f)
                GLES20.glEnd()

                GLES20.glLineWidth(1.0f)
                GLES20.glColor3f(1.237f, 0.037f, 0.0397f)
                GLES20.glBegin(GLES20.GL_LINES)
                GLES20.glVertex3f(0f, mf.tool.hitchLength.toFloat(), 0f)
                GLES20.glVertex3f(0f, 0f, 0f)
                GLES20.glEnd()
            } else {
                GLES20.glLineWidth(4.0f)
                //draw the rigid hitch
                GLES20.glColor3f(0f, 0f, 0f)
                GLES20.glBegin(GLES20.GL_LINES)
                GLES20.glVertex3f(-0.35f, mf.tool.hitchLength.toFloat(), 0f)
                GLES20.glVertex3f(-0.350f, 0f, 0f)
                GLES20.glVertex3f(0.35f, mf.tool.hitchLength.toFloat(), 0f)
                GLES20.glVertex3f(0.350f, 0f, 0f)
                GLES20.glEnd()

                GLES20.glLineWidth(1.0f)
                GLES20.glColor3f(1.237f, 0.037f, 0.0397f)
                GLES20.glBegin(GLES20.GL_LINES)
                GLES20.glVertex3f(-0.35f, mf.tool.hitchLength.toFloat(), 0f)
                GLES20.glVertex3f(-0.35f, 0f, 0f)
                GLES20.glVertex3f(0.35f, mf.tool.hitchLength.toFloat(), 0f)
                GLES20.glVertex3f(0.35f, 0f, 0f)
                GLES20.glEnd()
            }
        }

        if (!mf.isFirstHeadingSet && mf.headingFromSource != "Dual") {
            GLES20.glEnable(GLES20.GL_TEXTURE_2D)
            GLES20.glColor4f(1f, 1f, 1f, 0.75f)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mf.textures[MainActivity.Textures.QuestionMark.ordinal])
            GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP)
            GLES20.glTexCoord2f(1f, 0f); GLES20.glVertex2f(5f, 5f) // Top Right
            GLES20.glTexCoord2f(0f, 0f); GLES20.glVertex2f(1f, 5f) // Top Left
            GLES20.glTexCoord2f(1f, 1f); GLES20.glVertex2f(5f, 1f) // Bottom Right
            GLES20.glTexCoord2f(0f, 1f); GLES20.glVertex2f(1f, 1f) // Bottom Left
            GLES20.glEnd()
            GLES20.glDisable(GLES20.GL_TEXTURE_2D)
        }

        //3 vehicle types  tractor=0 harvestor=1 4wd=2
        if (mf.isVehicleImage) {
            when (vehicleType) {
                0 -> drawTractor()
                1 -> drawHarvester()
                2 -> draw4WD()
            }
        } else {
            drawBasicVehicle()
        }

        if (mf.camera.camSetDistance > -75 && mf.isFirstHeadingSet) {
            drawAntennaDot()
        }

        if (mf.bnd.isBndBeingMade && mf.bnd.isDrawAtPivot) {
            drawBoundaryIndicator()
        }

        if (mf.isSvennArrowOn && mf.camera.camSetDistance > -1000) {
            drawSvennArrow()
        }

        GLES20.glLineWidth(1.0f)
    }

    private fun drawTractor() {
        GLES20.glEnable(GLES20.GL_TEXTURE_2D)
        GLES20.glColor4f(
            mf.vehicleColor.red.toFloat() / 255f,
            mf.vehicleColor.green.toFloat() / 255f,
            mf.vehicleColor.blue.toFloat() / 255f,
            mf.vehicleOpacity.toFloat()
        )
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mf.textures[MainActivity.Textures.Tractor.ordinal])

        val leftAckerman: Double
        val rightAckerman: Double

        if (mf.timerSim.isEnabled) {
            if (mf.sim.steerangleAve < 0) {
                leftAckerman = 1.25 * -mf.sim.steerangleAve
                rightAckerman = -mf.sim.steerangleAve
            } else {
                leftAckerman = -mf.sim.steerangleAve
                rightAckerman = 1.25 * -mf.sim.steerangleAve
            }
        } else {
            if (mf.mc.actualSteerAngleDegrees < 0) {
                leftAckerman = 1.25 * -mf.mc.actualSteerAngleDegrees
                rightAckerman = -mf.mc.actualSteerAngleDegrees
            } else {
                leftAckerman = -mf.mc.actualSteerAngleDegrees
                rightAckerman = 1.25 * -mf.mc.actualSteerAngleDegrees
            }
        }

        GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP)
        GLES20.glTexCoord2f(1f, 0f); GLES20.glVertex2f(trackWidth.toFloat(), (wheelbase * 1.5).toFloat())
        GLES20.glTexCoord2f(0f, 0f); GLES20.glVertex2f(-trackWidth.toFloat(), (wheelbase * 1.5).toFloat())
        GLES20.glTexCoord2f(1f, 1f); GLES20.glVertex2f(trackWidth.toFloat(), (-wheelbase * 0.5).toFloat())
        GLES20.glTexCoord2f(0f, 1f); GLES20.glVertex2f(-trackWidth.toFloat(), (-wheelbase * 0.5).toFloat())
        GLES20.glEnd()

        //right wheel
        GLES20.glPushMatrix()
        GLES20.glTranslatef((trackWidth * 0.5).toFloat(), wheelbase.toFloat(), 0f)
        GLES20.glRotatef(rightAckerman.toFloat(), 0f, 0f, 1f)

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mf.textures[MainActivity.Textures.FrontWheels.ordinal])
        GLES20.glColor4f(
            mf.vehicleColor.red.toFloat() / 255f,
            mf.vehicleColor.green.toFloat() / 255f,
            mf.vehicleColor.blue.toFloat() / 255f,
            mf.vehicleOpacity.toFloat()
        )

        GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP)
        GLES20.glTexCoord2f(1f, 0f); GLES20.glVertex2f((trackWidth * 0.5).toFloat(), (wheelbase * 0.75).toFloat())
        GLES20.glTexCoord2f(0f, 0f); GLES20.glVertex2f((-trackWidth * 0.5).toFloat(), (wheelbase * 0.75).toFloat())
        GLES20.glTexCoord2f(1f, 1f); GLES20.glVertex2f((trackWidth * 0.5).toFloat(), (-wheelbase * 0.75).toFloat())
        GLES20.glTexCoord2f(0f, 1f); GLES20.glVertex2f((-trackWidth * 0.5).toFloat(), (-wheelbase * 0.75).toFloat())
        GLES20.glEnd()

        GLES20.glPopMatrix()

        //Left Wheel
        GLES20.glPushMatrix()
        GLES20.glTranslatef((-trackWidth * 0.5).toFloat(), wheelbase.toFloat(), 0f)
        GLES20.glRotatef(leftAckerman.toFloat(), 0f, 0f, 1f)

        GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP)
        GLES20.glTexCoord2f(1f, 0f); GLES20.glVertex2f((trackWidth * 0.5).toFloat(), (wheelbase * 0.75).toFloat())
        GLES20.glTexCoord2f(0f, 0f); GLES20.glVertex2f((-trackWidth * 0.5).toFloat(), (wheelbase * 0.75).toFloat())
        GLES20.glTexCoord2f(1f, 1f); GLES20.glVertex2f((trackWidth * 0.5).toFloat(), (-wheelbase * 0.75).toFloat())
        GLES20.glTexCoord2f(0f, 1f); GLES20.glVertex2f((-trackWidth * 0.5).toFloat(), (-wheelbase * 0.75).toFloat())
        GLES20.glEnd()

        GLES20.glPopMatrix()
        GLES20.glDisable(GLES20.GL_TEXTURE_2D)
    }

    private fun drawHarvester() {
        GLES20.glEnable(GLES20.GL_TEXTURE_2D)

        val leftAckerman: Double
        val rightAckerman: Double

        if (mf.timerSim.isEnabled) {
            if (mf.sim.steerAngle < 0) {
                leftAckerman = 1.25 * mf.sim.steerAngle
                rightAckerman = mf.sim.steerAngle
            } else {
                leftAckerman = mf.sim.steerAngle
                rightAckerman = 1.25 * mf.sim.steerAngle
            }
        } else {
            if (mf.mc.actualSteerAngleDegrees < 0) {
                leftAckerman = 1.25 * mf.mc.actualSteerAngleDegrees
                rightAckerman = mf.mc.actualSteerAngleDegrees
            } else {
                leftAckerman = mf.mc.actualSteerAngleDegrees
                rightAckerman = 1.25 * mf.mc.actualSteerAngleDegrees
            }
        }

        GLES20.glColor4f(20f/255f, 20f/255f, 20f/255f, mf.vehicleOpacity.toFloat())
        //right wheel
        GLES20.glPushMatrix()
        GLES20.glTranslatef((trackWidth * 0.5).toFloat(), (-wheelbase).toFloat(), 0f)
        GLES20.glRotatef(rightAckerman.toFloat(), 0f, 0f, 1f)

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mf.textures[MainActivity.Textures.FrontWheels.ordinal])

        GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP)
        GLES20.glTexCoord2f(1f, 0f); GLES20.glVertex2f((trackWidth * 0.25).toFloat(), (wheelbase * 0.5).toFloat())
        GLES20.glTexCoord2f(0f, 0f); GLES20.glVertex2f((-trackWidth * 0.25).toFloat(), (wheelbase * 0.5).toFloat())
        GLES20.glTexCoord2f(1f, 1f); GLES20.glVertex2f((trackWidth * 0.25).toFloat(), (-wheelbase * 0.5).toFloat())
        GLES20.glTexCoord2f(0f, 1f); GLES20.glVertex2f((-trackWidth * 0.25).toFloat(), (-wheelbase * 0.5).toFloat())
        GLES20.glEnd()

        GLES20.glPopMatrix()

        //Left Wheel
        GLES20.glPushMatrix()
        GLES20.glTranslatef((-trackWidth * 0.5).toFloat(), (-wheelbase).toFloat(), 0f)
        GLES20.glRotatef(leftAckerman.toFloat(), 0f, 0f, 1f)

        GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP)
        GLES20.glTexCoord2f(1f, 0f); GLES20.glVertex2f((trackWidth * 0.25).toFloat(), (wheelbase * 0.5).toFloat())
        GLES20.glTexCoord2f(0f, 0f); GLES20.glVertex2f((-trackWidth * 0.25).toFloat(), (wheelbase * 0.5).toFloat())
        GLES20.glTexCoord2f(1f, 1f); GLES20.glVertex2f((trackWidth * 0.25).toFloat(), (-wheelbase * 0.5).toFloat())
        GLES20.glTexCoord2f(0f, 1f); GLES20.glVertex2f((-trackWidth * 0.25).toFloat(), (-wheelbase * 0.5).toFloat())
        GLES20.glEnd()

        GLES20.glPopMatrix()

        GLES20.glColor4f(
            mf.vehicleColor.red.toFloat() / 255f,
            mf.vehicleColor.green.toFloat() / 255f,
            mf.vehicleColor.blue.toFloat() / 255f,
            mf.vehicleOpacity.toFloat()
        )
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mf.textures[MainActivity.Textures.Harvester.ordinal])
        GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP)
        GLES20.glTexCoord2f(1f, 0f); GLES20.glVertex2f(trackWidth.toFloat(), (wheelbase * 1.5).toFloat())
        GLES20.glTexCoord2f(0f, 0f); GLES20.glVertex2f(-trackWidth.toFloat(), (wheelbase * 1.5).toFloat())
        GLES20.glTexCoord2f(1f, 1f); GLES20.glVertex2f(trackWidth.toFloat(), (-wheelbase * 1.5).toFloat())
        GLES20.glTexCoord2f(0f, 1f); GLES20.glVertex2f(-trackWidth.toFloat(), (-wheelbase * 1.5).toFloat())
        GLES20.glEnd()

        GLES20.glDisable(GLES20.GL_TEXTURE_2D)
    }

    private fun draw4WD() {
        val modelSteerAngle = if (mf.timerSim.isEnabled) {
            0.5 * mf.sim.steerAngle
        } else {
            0.5 * mf.mc.actualSteerAngleDegrees
        }

        GLES20.glEnable(GLES20.GL_TEXTURE_2D)
        GLES20.glColor4f(
            mf.vehicleColor.red.toFloat() / 255f,
            mf.vehicleColor.green.toFloat() / 255f,
            mf.vehicleColor.blue.toFloat() / 255f,
            mf.vehicleOpacity.toFloat()
        )

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mf.textures[MainActivity.Textures.FourWDRear.ordinal])

        GLES20.glPushMatrix()
        GLES20.glTranslatef(0f, (-wheelbase * 0.5).toFloat(), 0f)
        GLES20.glRotatef(modelSteerAngle.toFloat(), 0f, 0f, 1f)

        GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP)
        GLES20.glTexCoord2f(1f, 0f); GLES20.glVertex2f(trackWidth.toFloat(), (wheelbase * 0.65).toFloat())
        GLES20.glTexCoord2f(0f, 0f); GLES20.glVertex2f(-trackWidth.toFloat(), (wheelbase * 0.65).toFloat())
        GLES20.glTexCoord2f(1f, 1f); GLES20.glVertex2f(trackWidth.toFloat(), (-wheelbase * 0.65).toFloat())
        GLES20.glTexCoord2f(0f, 1f); GLES20.glVertex2f(-trackWidth.toFloat(), (-wheelbase * 0.65).toFloat())
        GLES20.glEnd()

        GLES20.glPopMatrix()

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, mf.textures[MainActivity.Textures.FourWDFront.ordinal])

        GLES20.glPushMatrix()
        GLES20.glTranslatef(0f, (wheelbase * 0.5).toFloat(), 0f)
        GLES20.glRotatef((-modelSteerAngle).toFloat(), 0f, 0f, 1f)

        GLES20.glBegin(GLES20.GL_TRIANGLE_STRIP)
        GLES20.glTexCoord2f(1f, 0f); GLES20.glVertex2f(trackWidth.toFloat(), (wheelbase * 0.65).toFloat())
        GLES20.glTexCoord2f(0f, 0f); GLES20.glVertex2f(-trackWidth.toFloat(), (wheelbase * 0.65).toFloat())
        GLES20.glTexCoord2f(1f, 1f); GLES20.glVertex2f(trackWidth.toFloat(), (-wheelbase * 0.65).toFloat())
        GLES20.glTexCoord2f(0f, 1f); GLES20.glVertex2f(-trackWidth.toFloat(), (-wheelbase * 0.65).toFloat())
        GLES20.glEnd()

        GLES20.glPopMatrix()
        GLES20.glDisable(GLES20.GL_TEXTURE_2D)
    }

    private fun drawBasicVehicle() {
        GLES20.glColor4f(1.2f, 1.20f, 0.0f, mf.vehicleOpacity.toFloat())
        GLES20.glBegin(GLES20.GL_TRIANGLE_FAN)
        GLES20.glVertex3f(0f, antennaPivot.toFloat(), -0.0f)
        GLES20.glVertex3f(1.0f, 0f, 0.0f)
        GLES20.glColor4f(0.0f, 1.20f, 1.22f, mf.vehicleOpacity.toFloat())
        GLES20.glVertex3f(0f, wheelbase.toFloat(), 0.0f)
        GLES20.glColor4f(1.220f, 0.0f, 1.2f, mf.vehicleOpacity.toFloat())
        GLES20.glVertex3f(-1.0f, 0f, 0.0f)
        GLES20.glVertex3f(1.0f, 0f, 0.0f)
        GLES20.glEnd()

        GLES20.glLineWidth(3.0f)
        GLES20.glColor3f(0.12f, 0.12f, 0.12f)
        GLES20.glBegin(GLES20.GL_LINE_LOOP)
        GLES20.glVertex3f(-1.0f, 0f, 0f)
        GLES20.glVertex3f(1.0f, 0f, 0f)
        GLES20.glVertex3f(0f, wheelbase.toFloat(), 0f)
        GLES20.glEnd()
    }

    private fun drawAntennaDot() {
        //draw the bright antenna dot
        GLES20.glPointSize(16.0f)
        GLES20.glBegin(GLES20.GL_POINTS)
        GLES20.glColor3f(0f, 0f, 0f)
        GLES20.glVertex3f(-antennaOffset.toFloat(), antennaPivot.toFloat(), 0.1f)
        GLES20.glEnd()

        GLES20.glPointSize(10.0f)
        GLES20.glBegin(GLES20.GL_POINTS)
        GLES20.glColor3f(0.20f, 0.98f, 0.98f)
        GLES20.glVertex3f(-antennaOffset.toFloat(), antennaPivot.toFloat(), 0.1f)
        GLES20.glEnd()
    }

    private fun drawBoundaryIndicator() {
        if (mf.bnd.isDrawRightSide) {
            GLES20.glLineWidth(2.0f)
            GLES20.glBegin(GLES20.GL_LINE_STRIP)
            GLES20.glColor3f(0.0f, 1.270f, 0.0f)
            GLES20.glVertex3f(0.0f, 0f, 0f)
            GLES20.glColor3f(1.270f, 1.220f, 0.20f)
            GLES20.glVertex3f(mf.bnd.createBndOffset.toFloat(), 0f, 0f)
            GLES20.glVertex3f((mf.bnd.createBndOffset * 0.75).toFloat(), 0.25f, 0f)
            GLES20.glEnd()
        } else {
            //draw on left side
            GLES20.glLineWidth(2.0f)
            GLES20.glBegin(GLES20.GL_LINE_STRIP)
            GLES20.glColor3f(0.0f, 1.270f, 0.0f)
            GLES20.glVertex3f(0.0f, 0f, 0f)
            GLES20.glColor3f(1.270f, 1.220f, 0.20f)
            GLES20.glVertex3f(-mf.bnd.createBndOffset.toFloat(), 0f, 0f)
            GLES20.glVertex3f((-mf.bnd.createBndOffset * 0.75).toFloat(), 0.25f, 0f)
            GLES20.glEnd()
        }
    }

    private fun drawSvennArrow() {
        val svennDist = mf.camera.camSetDistance * -0.07
        val svennWidth = svennDist * 0.22
        GLES20.glLineWidth(mf.ABLine.lineWidth.toFloat())
        GLES20.glColor3f(0.95f, 0.95f, 0.10f)
        GLES20.glBegin(GLES20.GL_LINE_STRIP)
        GLES20.glVertex3f(svennWidth.toFloat(), (wheelbase + svennDist).toFloat(), 0.0f)
        GLES20.glVertex3f(0f, (wheelbase + svennWidth + 0.5 + svennDist).toFloat(), 0.0f)
        GLES20.glVertex3f(-svennWidth.toFloat(), (wheelbase + svennDist).toFloat(), 0.0f)
        GLES20.glEnd()
    }

    private fun Double.toDegrees(): Float {
        return Math.toDegrees(this).toFloat()
    }
}