plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.agopengps"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.agopengps"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.navigation.fragment.ktx)
    implementation(libs.androidx.navigation.ui.ktx)
    implementation(libs.androidx.benchmark.baseline.profile.gradle.plugin)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    // Google Maps
    implementation ("com.google.android.gms:play-services-maps:19.1.0")
    implementation ("com.google.android.gms:play-services-location:21.3.0")

    // 生命周期管理
    implementation ("androidx.lifecycle:lifecycle-livedata-ktx:2.8.7")
    implementation ("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.1")

    // 工具库
    implementation ("com.jakewharton.timber:timber:5.0.1")
    implementation ("org.apache.commons:commons-math3:3.6.1")


    // 测试
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    // 可选：Multik（如果实际需要）
    implementation ("org.jetbrains.kotlinx:multik-core:0.2.0")
    implementation ("org.jetbrains.kotlinx:multik-default:0.2.0")

    implementation ("com.google.android.gms:play-services-maps:19.1.0")
    implementation ("com.google.maps.android:android-maps-utils:3.8.0")

    implementation("com.google.guava:guava:31.1-android") // Stopwatch
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3") // 協程（可選）

 //   implementation ("androidx.opengl:opengl:1.0.0")
//implementation ("androidx.opengl:opengl-api:1.0.0")
//implementation ("androidx.opengl:opengl:1.0.0")
//implementation ("androidx.opengl:opengl-extension-pack:1.0.0")
  //  implementation ("androidx.appcompat:appcompat:1.6.1")

 //   implementation ("com.android.support:appcompat-v7:28.0.0")

}