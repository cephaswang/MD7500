package com.agopengps.classes

import com.google.android.gms.maps.model.LatLng
import java.lang.Math.toDegrees
import kotlin.math.*

data class vecRGB(
    var red: Byte,
    var grn: Byte,
    var blu: Byte,
    var alpha: Byte
)

/**
 * Represents a three dimensional vector.
 */
data class vec3(
    var easting: Double = 0.0,  // Default value
    var northing: Double = 0.0, // Default value
    var heading: Double = 0.0   // Default value
) {
    constructor(v: vec3) : this(v.easting, v.northing, v.heading)

    fun copyFrom(other: vec3) {
        easting = other.easting
        northing = other.northing
        heading = other.heading
    }

    fun headingXZ(): Double = atan2(easting, northing)

    fun normalize() {
        val length = getLength()
        if (abs(length) < 0.0000000000001) {
            throw ArithmeticException("Trying to normalize a vector with length of zero.")
        }
        easting /= length
        northing /= length
        heading /= length
    }

    fun getLength(): Double =
        sqrt((easting * easting) + (heading * heading) + (northing * northing))

    fun getLengthSquared(): Double =
        (easting * easting) + (heading * heading) + (northing * northing)

    operator fun minus(rhs: vec3) = vec3(
        easting - rhs.easting,
        northing - rhs.northing,
        heading - rhs.heading
    )

    // 將 UTM 座標轉換為 LatLng 的方法
    fun toLatLng(zone: Int, isNorthernHemisphere: Boolean): LatLng {
        return utmToLatLng(easting, northing, zone, isNorthernHemisphere)
    }

    companion object {
        fun utmToLatLng(
            easting: Double,
            northing: Double,
            zone: Int,
            isNorthernHemisphere: Boolean
        ): LatLng {
            val a = 6378137.0 // WGS84 赤道半徑
            val f = 1 / 298.257223563 // 扁平率
            val k0 = 0.9996 // 比例因子
            val e = sqrt(2 * f - f * f) // 偏心率

            val x = easting - 500000.0 // 移除假東距
            val y = if (isNorthernHemisphere) northing else northing - 10000000.0

            val lon0 = (zone * 6 - 183).toDouble() // 中央經線
            val M = y / k0
            val mu =
                M / (a * (1 - e * e / 4 - 3 * e * e * e * e / 64 - 5 * e * e * e * e * e * e / 256))

            val e1 = (1 - sqrt(1 - e * e)) / (1 + sqrt(1 - e * e))
            val J1 = (3 * e1 / 2 - 27 * e1 * e1 * e1 / 32)
            val J2 = (21 * e1 * e1 / 16 - 55 * e1 * e1 * e1 * e1 / 32)
            val J3 = (151 * e1 * e1 * e1 / 96)
            val J4 = (1097 * e1 * e1 * e1 * e1 / 512)

            val fp = mu + J1 * sin(2 * mu) + J2 * sin(4 * mu) + J3 * sin(6 * mu) + J4 * sin(8 * mu)
            val C1 = e * e * cos(fp) * cos(fp)
            val T1 = tan(fp) * tan(fp)
            val R1 = a * (1 - e * e) / (1 - e * e * sin(fp) * sin(fp)).pow(1.5)
            val N1 = a / sqrt(1 - e * e * sin(fp) * sin(fp))
            val D = x / (N1 * k0)

            val Q1 = N1 * tan(fp) / R1
            val Q2 = (D * D / 2)
            val Q3 = (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * e * e) * D * D * D * D / 24
            val Q4 =
                (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * e * e - 3 * C1 * C1) * D * D * D * D * D * D / 720

            val latitude = fp - Q1 * (Q2 - Q3 + Q4)
            val longitude =
                lon0 + (D - (1 + 2 * T1 + C1) * D * D * D / 6 + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * e * e + 24 * T1 * T1) * D * D * D * D * D / 120) / cos(
                    fp
                )

            return LatLng(toDegrees(latitude), toDegrees(longitude))
        }

        // WGS84 經緯度到 UTM 的轉換 (新增)
        fun latLngToUtm(latitude: Double, longitude: Double): vec3 {
            val a = 6378137.0 // WGS84 赤道半徑
            val f = 1 / 298.257223563 // 扁平率
            val k0 = 0.9996 // 比例因子
            val e = sqrt(2 * f - f * f) // 偏心率

            // 自定義 toRadians 函數
            fun toRadians(degrees: Double) = degrees * (Math.PI / 180.0)

            val latRad = toRadians(latitude)
            val lonRad = toRadians(longitude)

            // 計算 UTM 區域
            val zone = ((longitude + 180) / 6).toInt() + 1
            val isNorthernHemisphere = latitude >= 0
            val lon0 = (zone * 6 - 183).toDouble() // 中央經線 (度)
            val lon0Rad = toRadians(lon0)

            val N = a / sqrt(1 - e * e * sin(latRad) * sin(latRad))
            val T = tan(latRad) * tan(latRad)
            val C = e * e * cos(latRad) * cos(latRad) / (1 - e * e)
            val A = (lonRad - lon0Rad) * cos(latRad)
            val M = a * (
                    (1 - e * e / 4 - 3 * e * e * e * e / 64 - 5 * e * e * e * e * e * e / 256) * latRad -
                            (3 * e * e / 8 + 3 * e * e * e * e / 32 + 45 * e * e * e * e * e * e / 1024) * sin(2 * latRad) +
                            (15 * e * e * e * e / 256 + 45 * e * e * e * e * e * e / 1024) * sin(4 * latRad) -
                            (35 * e * e * e * e * e * e / 3072) * sin(6 * latRad)
                    )

            val easting = k0 * N * (A + (1 - T + C) * A * A * A / 6 + (5 - 18 * T + T * T + 72 * C - 58 * e * e) * A * A * A * A * A / 120) + 500000.0
            var northing = k0 * (M + N * tan(latRad) * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A * A * A * A / 24 + (61 - 58 * T + T * T + 600 * C - 330 * e * e) * A * A * A * A * A * A / 720))
            if (!isNorthernHemisphere) northing += 10000000.0

            return vec3(easting, northing, 0.0) // heading 設為 0，因為 LatLng 不包含方向信息
        }

        // 輔助方法：計算 UTM 區域
        fun getUtmZone(longitude: Double): Int {
            return ((longitude + 180) / 6).toInt() + 1
        }

        // 輔助方法：判斷是否為北半球
        fun isNorthernHemisphere(latitude: Double): Boolean {
            return latitude >= 0
        }
    }
}

data class vecFix2Fix(
    var easting: Double,  // easting
    var distance: Double, // distance since last point
    var northing: Double, // northing
    var isSet: Int       // altitude
)

/**
 * easting, northing, heading, boundary#
 */
class vec4(
    var easting: Double,  // easting
    var heading: Double,  // heading etc
    var northing: Double, // northing
    var index: Int       // altitude
)

data class vec2(
    var easting: Double = 0.0,  // Default value
    var northing: Double = 0.0  // Default value
) {
    constructor(v: vec2) : this(v.easting, v.northing)

    operator fun minus(rhs: vec2) = vec2(
        easting - rhs.easting,
        northing - rhs.northing
    )

    fun headingXZ(): Double = atan2(easting, northing)

    fun normalize(): vec2 {
        val length = getLength()
        if (abs(length) < 0.000000000001) {
            throw ArithmeticException("Trying to normalize a vector with length of zero.")
        }
        return vec2(easting / length, northing / length)
    }

    fun getLength(): Double = sqrt((easting * easting) + (northing * northing))

    fun getLengthSquared(): Double = (easting * easting) + (northing * northing)

    operator fun times(s: Double) = vec2(easting * s, northing * s)

    operator fun plus(rhs: vec2) = vec2(
        easting + rhs.easting,
        northing + rhs.northing
    )
}

// structure for contour guidance
data class cvec(
    var x: Double,
    var z: Double,
    var h: Double,
    var strip: Int,
    var pt: Int
) {
    constructor(v: vec3) : this(v.easting, v.northing, v.heading, 99999, 99999)
}