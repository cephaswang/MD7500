package com.agopengps.classes

import android.content.Context
import android.media.MediaPlayer
import com.agopengps.R

class CSound(private val context: Context) {
    // Sound resources - initialized lazily
    private val sndBoundaryAlarm by lazy { loadSound(R.raw.alarm10) }
    private val sndUTurnTooClose by lazy { loadSound(R.raw.tf012) }
    private val sndAutoSteerOn by lazy { loadSound(R.raw.steeron) }
    private val sndAutoSteerOff by lazy { loadSound(R.raw.steeroff) }
    val sndHydLiftUp by lazy { loadSound(R.raw.hydup) }
    val sndHydLiftDn by lazy { loadSound(R.raw.hyddown) }
    private val sndRTKAlarm by lazy { loadSound(R.raw.rtk_lost) }
    private val sndSectionOn by lazy { loadSound(R.raw.sectionon) }
    private val sndSectionOff by lazy { loadSound(R.raw.sectionoff) }

    // Sound states
    var isBoundAlarming = false
    private var isRTKAlarming = false
    var isSteerSoundOn = true
    var isTurnSoundOn = true
    var isHydLiftSoundOn = true
    var isSectionsSoundOn = true
    var isHydLiftChange = false

    init {
        // Load sound preferences from SharedPreferences
        val prefs = context.getSharedPreferences("Settings", Context.MODE_PRIVATE)
        isSteerSoundOn = prefs.getBoolean("setSound_isAutoSteerOn", true)
        isHydLiftSoundOn = prefs.getBoolean("setSound_isHydLiftOn", true)
        isTurnSoundOn = prefs.getBoolean("setSound_isUturnOn", true)
        isSectionsSoundOn = prefs.getBoolean("setSound_isSectionsOn", true)
    }

    private fun loadSound(resourceId: Int): MediaPlayer {
        return MediaPlayer.create(context, resourceId).apply {
            setOnCompletionListener { mp ->
                mp.release()
            }
        }
    }

    fun playBoundaryAlarm() {
        if (isBoundAlarming && isTurnSoundOn) {
            sndBoundaryAlarm.start()
        }
    }

    fun playUTurnTooClose() {
        if (isTurnSoundOn) {
            sndUTurnTooClose.start()
        }
    }

    fun playAutoSteerOn() {
        if (isSteerSoundOn) {
            sndAutoSteerOn.start()
        }
    }

    fun playAutoSteerOff() {
        if (isSteerSoundOn) {
            sndAutoSteerOff.start()
        }
    }

    fun playHydLiftUp() {
        if (isHydLiftSoundOn && isHydLiftChange) {
            sndHydLiftUp.start()
        }
    }

    fun playHydLiftDown() {
        if (isHydLiftSoundOn && isHydLiftChange) {
            sndHydLiftDn.start()
        }
    }

    fun playRTKAlarm() {
        if (isRTKAlarming) {
            sndRTKAlarm.start()
        }
    }

    fun playSectionOn() {
        if (isSectionsSoundOn) {
            sndSectionOn.start()
        }
    }

    fun playSectionOff() {
        if (isSectionsSoundOn) {
            sndSectionOff.start()
        }
    }

    fun releaseAll() {
        listOf(
            sndBoundaryAlarm,
            sndUTurnTooClose,
            sndAutoSteerOn,
            sndAutoSteerOff,
            sndHydLiftUp,
            sndHydLiftDn,
            sndRTKAlarm,
            sndSectionOn,
            sndSectionOff
        ).forEach { it.release() }
    }
}