package com.agopengps.classes

import android.graphics.Color
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Polygon
import com.google.android.gms.maps.model.PolygonOptions
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions
import com.agopengps.drive.FormGPS

class CWorldGrid(private val mf: FormGPS) {
    //Y
    var northingMax = 0.0

    var northingMin = 0.0

    //X
    var eastingMax = 0.0

    var eastingMin = 0.0

    //Y
    var northingMaxGeo = 300.0

    var northingMinGeo = -300.0

    //X
    var eastingMaxGeo = 300.0

    var eastingMinGeo = -300.0

    //Y
    var northingMaxRate = 300.0

    var northingMinRate = -300.0

    //X
    var eastingMaxRate = 300.0

    var eastingMinRate = -300.0

    var GridSize = 6000.0
    var Count = 40.0
    var isGeoMap = false

    var gridRotation = 0.0

    private var fieldPolygon: Polygon? = null
    private var geoMapPolygon: Polygon? = null
    private val gridLines = mutableListOf<Polyline>()

    fun DrawFieldSurface(googleMap: GoogleMap) {
        val fieldColor = if (!mf.isDay) mf.fieldColorNight else mf.fieldColorDay

        //adjust bitmap zoom based on cam zoom
        when {
            mf.camera.zoomValue > 100 -> Count = 4.0
            mf.camera.zoomValue > 80 -> Count = 8.0
            mf.camera.zoomValue > 50 -> Count = 16.0
            mf.camera.zoomValue > 20 -> Count = 32.0
            mf.camera.zoomValue > 10 -> Count = 64.0
            else -> Count = 80.0
        }

        // Draw field surface
        val fieldOptions = PolygonOptions()
            .add(
                LatLng(northingMax, eastingMin),
                LatLng(northingMax, eastingMax),
                LatLng(northingMin, eastingMax),
                LatLng(northingMin, eastingMin)
            )
            .fillColor(fieldColor)
            .strokeColor(Color.TRANSPARENT)
            .zIndex(-0.10f)

        fieldPolygon?.remove()
        fieldPolygon = googleMap.addPolygon(fieldOptions)

        if (isGeoMap) {
            val geoMapOptions = PolygonOptions()
                .add(
                    LatLng(northingMaxGeo, eastingMinGeo),
                    LatLng(northingMaxGeo, eastingMaxGeo),
                    LatLng(northingMinGeo, eastingMaxGeo),
                    LatLng(northingMinGeo, eastingMinGeo)
                )
                .fillColor(Color.argb(128, 153, 153, 153)) // 0.6f, 0.6f, 0.6f, 0.5f
                .strokeColor(Color.TRANSPARENT)
                .zIndex(-0.05f)

            geoMapPolygon?.remove()
            geoMapPolygon = googleMap.addPolygon(geoMapOptions)
        }
    }

    fun DrawWorldGrid(googleMap: GoogleMap, _gridZoom: Double) {
        // Clear previous grid lines
        gridLines.forEach { it.remove() }
        gridLines.clear()

        val gridColor = if (mf.isDay) Color.rgb(64, 64, 64) else Color.rgb(31, 31, 31) // 0.25 -> ~64, 0.12 -> ~31

        // Draw vertical grid lines
        var num = Math.round(eastingMin / _gridZoom) * _gridZoom
        while (num < eastingMax) {
            if (num >= eastingMin) {
                val lineOptions = PolylineOptions()
                    .add(LatLng(northingMax, num), LatLng(northingMin, num))
                    .color(gridColor)
                    .width(1f)
                    .zIndex(0.1f)

                gridLines.add(googleMap.addPolyline(lineOptions))
            }
            num += _gridZoom
        }

        // Draw horizontal grid lines
        var num2 = Math.round(northingMin / _gridZoom) * _gridZoom
        while (num2 < northingMax) {
            if (num2 >= northingMin) {
                val lineOptions = PolylineOptions()
                    .add(LatLng(num2, eastingMax), LatLng(num2, eastingMin))
                    .color(gridColor)
                    .width(1f)
                    .zIndex(0.1f)

                gridLines.add(googleMap.addPolyline(lineOptions))
            }
            num2 += _gridZoom
        }
    }

    fun checkZoomWorldGrid(northing: Double, easting: Double) {
        val n = Math.round(northing / (GridSize / Count * 2)) * (GridSize / Count * 2)
        val e = Math.round(easting / (GridSize / Count * 2)) * (GridSize / Count * 2)

        northingMax = n + GridSize
        northingMin = n - GridSize
        eastingMax = e + GridSize
        eastingMin = e - GridSize
    }
}