package com.agopengps.classes

import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.PolylineOptions
import kotlin.math.*

// To keep track of the different paths when debugging
enum class PathType {
    RSR, LSL, RSL, LSR, RLR, LRL
}

// Display the final Dubins Paths
class CDubins(private val mf: FormGPS) {

    private val googleMap: GoogleMap = mf.mMap


    companion object {
        // 靜態 driveDistance（不變）
        const val driveDistance = 0.05

        // 靜態 turningRadius（預設值）
        var turningRadius: Double = 5.0
    }

    // 實例的 turningRadius（getter/setter 連結到靜態變數）
    var turningRadius: Double
        get() = Companion.turningRadius
        set(value) { Companion.turningRadius = value }

    init {
        // 初始化時設定 turningRadius
        turningRadius = mf.settings.set_youTurnRadius.toDouble()
    }


    // Position, Heading is in radians
    private lateinit var startPos: vec2
    private lateinit var goalPos: vec2

    private var startHeading: Double = 0.0
    private var goalHeading: Double = 0.0

    private val pathDataList = mutableListOf<OneDubinsPath>()
    private val dubinsShortestPathList = mutableListOf<vec3>()

    // Takes 2 points and headings to create a path - returns list of vec3 points and headings
    fun GenerateDubins(_start: vec3, _goal: vec3): List<vec3> {
        // Positions and heading
        startPos = vec2(_start.easting, _start.northing)
        startHeading = _start.heading

        goalPos = vec2(_goal.easting, _goal.northing)
        goalHeading = _goal.heading

        // Get all valid Dubins paths
        pathDataList.clear()
        pathDataList.addAll(GetAllDubinsPaths())

        // Clear out existing path of vec3 points
        dubinsShortestPathList.clear()

        if (pathDataList.isNotEmpty()) {
            val cnt = pathDataList[0].pathCoordinates.size
            if (cnt > 1) {
                // Calculate the heading for each point and draw on Google Maps
                val polylineOptions = PolylineOptions().width(5f).color(0xFF0000FF.toInt())
                for (i in 0 until cnt - 1 step 5) {
                    val pt = vec3(
                        pathDataList[0].pathCoordinates[i].easting,
                        pathDataList[0].pathCoordinates[i].northing,
                        0.0
                    ).apply {
                        heading = atan2(
                            pathDataList[0].pathCoordinates[i + 1].easting - pathDataList[0].pathCoordinates[i].easting,
                            pathDataList[0].pathCoordinates[i + 1].northing - pathDataList[0].pathCoordinates[i].northing
                        )
                    }
                    dubinsShortestPathList.add(pt)
                    polylineOptions.add(
                        com.google.android.gms.maps.model.LatLng(pt.northing, pt.easting)
                    )
                }
                googleMap.addPolyline(polylineOptions)
            }
        }
        return dubinsShortestPathList
    }

    // The 4 different circles we have that sits to the left/right of the start/goal
    private lateinit var startLeftCircle: vec2
    private lateinit var startRightCircle: vec2
    private lateinit var goalLeftCircle: vec2
    private lateinit var goalRightCircle: vec2

    // Get all valid Dubins paths sorted from shortest to longest
    private fun GetAllDubinsPaths(): List<OneDubinsPath> {
        // Reset the list with all Dubins paths
        pathDataList.clear()

        // Position the circles that are to the left/right of the cars
        PositionLeftRightCircles()

        // Find the length of each path with tangent coordinates
        CalculateDubinsPathsLengths()

        // If we have paths
        if (pathDataList.isNotEmpty()) {
            // Sort the list with paths so the shortest path is first
            pathDataList.sortBy { it.totalLength }

            // Generate the final coordinates of the path from tangent points and segment lengths
            GeneratePathCoordinates()
        } else {
            pathDataList.clear()
        }

        // Return either empty or the actual list
        return pathDataList
    }

    // Position the left and right circles that are to the left/right of the target and the car
    private fun PositionLeftRightCircles() {
        // Goal pos
        goalRightCircle = DubinsMath.GetRightCircleCenterPos(goalPos, goalHeading)
        goalLeftCircle = DubinsMath.GetLeftCircleCenterPos(goalPos, goalHeading)

        // Start pos
        startRightCircle = DubinsMath.GetRightCircleCenterPos(startPos, startHeading)
        startLeftCircle = DubinsMath.GetLeftCircleCenterPos(startPos, startHeading)
    }


    // Calculate the path lengths of all Dubins paths by using tangent points
    private fun CalculateDubinsPathsLengths() {
        // RSR and LSL is only working if the circles don't have the same position
        if (startRightCircle.easting != goalRightCircle.easting && startRightCircle.northing != goalRightCircle.northing) {
            Get_RSR_Length()
        }

        // LSL
        if (startLeftCircle.easting != goalLeftCircle.easting && startLeftCircle.northing != goalLeftCircle.northing) {
            Get_LSL_Length()
        }

        // RSL and LSR is only working if the circles don't intersect
        val comparisonSqr: Double = turningRadius * 2f * turningRadius * 2f

        // RSL
        if ((startRightCircle - goalLeftCircle).getLengthSquared() > comparisonSqr) {
            Get_RSL_Length()
        }

        // LSR
        if ((startLeftCircle - goalRightCircle).getLengthSquared() > comparisonSqr) {
            Get_LSR_Length()
        }

        // With the LRL and RLR paths, the distance between the circles have to be less than 4 * r
        val comparisonSqrRL: Double = turningRadius * 4f * turningRadius * 4f

        // RLR
        if ((startRightCircle - goalRightCircle).getLengthSquared() < comparisonSqrRL) {
            Get_RLR_Length()
        }

        // LRL
        if ((startLeftCircle - goalLeftCircle).getLengthSquared() < comparisonSqrRL) {
            Get_LRL_Length()
        }
    }

    // RSR
    private fun Get_RSR_Length() {
        val (startTangent, goalTangent) = DubinsMath.LSLorRSR(
            startRightCircle,
            goalRightCircle,
            false
        )

        // Calculate lengths
        val length1 = DubinsMath.GetArcLength(startRightCircle, startPos, startTangent, false)
        val length2 = (startTangent - goalTangent).getLength()
        val length3 = DubinsMath.GetArcLength(goalRightCircle, goalTangent, goalPos, false)

        // Save the data
        val pathData = OneDubinsPath(
            length1,
            length2,
            length3,
            startTangent,
            goalTangent,
            PathType.RSR
        ).apply {
            segment2Turning = false
            SetIfTurningRight(true, false, true)
        }

        // Add the path to the collection of all paths
        pathDataList.add(pathData)
    }

    // LSL
    private fun Get_LSL_Length() {
        val (startTangent, goalTangent) = DubinsMath.LSLorRSR(startLeftCircle, goalLeftCircle, true)

        // Calculate lengths
        val length1 = DubinsMath.GetArcLength(startLeftCircle, startPos, startTangent, true)
        val length2 = (startTangent - goalTangent).getLength()
        val length3 = DubinsMath.GetArcLength(goalLeftCircle, goalTangent, goalPos, true)

        // Save the data
        val pathData = OneDubinsPath(
            length1,
            length2,
            length3,
            startTangent,
            goalTangent,
            PathType.LSL
        ).apply {
            segment2Turning = false
            SetIfTurningRight(false, false, false)
        }

        // Add the path to the collection of all paths
        pathDataList.add(pathData)
    }

    // RSL
    private fun Get_RSL_Length() {
        val (startTangent, goalTangent) = DubinsMath.RSLorLSR(
            startRightCircle,
            goalLeftCircle,
            false
        )

        // Calculate lengths
        val length1 = DubinsMath.GetArcLength(startRightCircle, startPos, startTangent, false)
        val length2 = (startTangent - goalTangent).getLength()
        val length3 = DubinsMath.GetArcLength(goalLeftCircle, goalTangent, goalPos, true)

        // Save the data
        val pathData = OneDubinsPath(
            length1,
            length2,
            length3,
            startTangent,
            goalTangent,
            PathType.RSL
        ).apply {
            segment2Turning = false
            SetIfTurningRight(true, false, false)
        }

        // Add the path to the collection of all paths
        pathDataList.add(pathData)
    }

    // LSR
    private fun Get_LSR_Length() {
        val (startTangent, goalTangent) = DubinsMath.RSLorLSR(
            startLeftCircle,
            goalRightCircle,
            true
        )

        // Calculate lengths
        val length1 = DubinsMath.GetArcLength(startLeftCircle, startPos, startTangent, true)
        val length2 = (startTangent - goalTangent).getLength()
        val length3 = DubinsMath.GetArcLength(goalRightCircle, goalTangent, goalPos, false)

        // Save the data
        val pathData = OneDubinsPath(
            length1,
            length2,
            length3,
            startTangent,
            goalTangent,
            PathType.LSR
        ).apply {
            segment2Turning = false
            SetIfTurningRight(false, false, true)
        }

        // Add the path to the collection of all paths
        pathDataList.add(pathData)
    }

    // RLR - Find both tangent positions and the position of the 3rd circle
    private fun Get_RLR_Length() {
        val (startTangent, goalTangent, middleCircle) = DubinsMath.GetRLRorLRLTangents(
            startRightCircle,
            goalRightCircle,
            false
        )

        // Calculate lengths
        val length1 = DubinsMath.GetArcLength(startRightCircle, startPos, startTangent, false)
        val length2 = DubinsMath.GetArcLength(middleCircle, startTangent, goalTangent, true)
        val length3 = DubinsMath.GetArcLength(goalRightCircle, goalTangent, goalPos, false)

        // Save the data
        val pathData = OneDubinsPath(
            length1,
            length2,
            length3,
            startTangent,
            goalTangent,
            PathType.RLR
        ).apply {
            segment2Turning = true
            SetIfTurningRight(true, false, true)
        }

        // Add the path to the collection of all paths
        pathDataList.add(pathData)
    }

    // LRL - Find both tangent positions and the position of the 3rd circle
    private fun Get_LRL_Length() {
        val (startTangent, goalTangent, middleCircle) = DubinsMath.GetRLRorLRLTangents(
            startLeftCircle,
            goalLeftCircle,
            true
        )

        // Calculate the total length of this path
        val length1 = DubinsMath.GetArcLength(startLeftCircle, startPos, startTangent, true)
        val length2 = DubinsMath.GetArcLength(middleCircle, startTangent, goalTangent, false)
        val length3 = DubinsMath.GetArcLength(goalLeftCircle, goalTangent, goalPos, true)

        // Save the data
        val pathData = OneDubinsPath(
            length1,
            length2,
            length3,
            startTangent,
            goalTangent,
            PathType.LRL
        ).apply {
            segment2Turning = true
            SetIfTurningRight(false, true, false)
        }

        // Add the path to the collection of all paths
        pathDataList.add(pathData)
    }

    // Generate the final path from the tangent points
    private fun GeneratePathCoordinates() {
        pathDataList.forEach { GetTotalPath(it) }
    }

    // Find the coordinates of the entire path from the 2 tangents and length of each segment
    private fun GetTotalPath(pathData: OneDubinsPath) {
        // Store the waypoints of the final path here
        val finalPath = mutableListOf<vec2>()

        // Start position of the car
        var currentPos = startPos
        // Start heading of the car
        var theta = startHeading

        // We always have to add the first position manually
        finalPath.add(currentPos)

        // How many line segments can we fit into this part of the path

        // First
        var segments = floor(pathData.length1 / CDubins.driveDistance).toInt()
        DubinsMath.AddCoordinatesToPath(
            currentPos = { currentPos },
            theta = { theta },
            finalPath = finalPath,
            segments = segments,
            isTurning = true,
            isTurningRight = pathData.segment1TurningRight
        ) { pos, t ->
            currentPos = pos
            theta = t
        }

        // Second
        segments = floor(pathData.length2 / CDubins.driveDistance).toInt()
        DubinsMath.AddCoordinatesToPath(
            currentPos = { currentPos },
            theta = { theta },
            finalPath = finalPath,
            segments = segments,
            isTurning = pathData.segment2Turning,
            isTurningRight = pathData.segment2TurningRight
        ) { pos, t ->
            currentPos = pos
            theta = t
        }

        // Third
        segments = floor(pathData.length3 / CDubins.driveDistance).toInt()
        DubinsMath.AddCoordinatesToPath(
            currentPos = { currentPos },
            theta = { theta },
            finalPath = finalPath,
            segments = segments,
            isTurning = true,
            isTurningRight = pathData.segment3TurningRight
        ) { pos, t ->
            currentPos = pos
            theta = t
        }

        // Add the final goal coordinate
        finalPath.add(vec2(goalPos.easting, goalPos.northing))

        // Save the final path in the path data
        pathData.pathCoordinates = finalPath
    }
}

// Takes care of all standardized methods related to the generating of Dubins paths
object DubinsMath {
    // Calculate center positions of the Right circle
    fun GetRightCircleCenterPos(circlePos: vec2, heading: Double): vec2 {
        return vec2(
            easting = circlePos.easting + (CDubins.turningRadius * sin(heading + glm.PIBy2)),
            northing = circlePos.northing + (CDubins.turningRadius * cos(heading + glm.PIBy2))
        )
    }

    // Calculate center positions of the Left circle
    fun GetLeftCircleCenterPos(circlePos: vec2, heading: Double): vec2 {
        return vec2(
            easting = circlePos.easting + (CDubins.turningRadius * sin(heading - glm.PIBy2)),
            northing = circlePos.northing + (CDubins.turningRadius * cos(heading - glm.PIBy2))
        )
    }

    // Calculate the start and end positions of the tangent lines

    // Outer tangent (LSL and RSR)
    fun LSLorRSR(startCircle: vec2, goalCircle: vec2, isBottom: Boolean): Pair<vec2, vec2> {
        // The angle to the first tangent coordinate is always 90 degrees if the both circles have the same radius
        var theta = glm.PIBy2

        // Need to modify theta if the circles are not on the same height (z)
        theta += atan2(
            goalCircle.northing - startCircle.northing,
            goalCircle.easting - startCircle.easting
        )

        // Add pi to get the "bottom" coordinate which is on the opposite side (180 degrees = pi)
        if (isBottom) theta += PI

        // The coordinates of the first tangent points
        val xT1 = startCircle.easting + (CDubins.turningRadius * cos(theta))
        val zT1 = startCircle.northing + (CDubins.turningRadius * sin(theta))

        // To get the second coordinate we need a direction
        // This direction is the same as the direction between the center pos of the circles
        val dirVec = goalCircle - startCircle

        val xT2 = xT1 + dirVec.easting
        val zT2 = zT1 + dirVec.northing

        // The final coordinates of the tangent lines
        return Pair(vec2(xT1, zT1), vec2(xT2, zT2))
    }

    // Inner tangent (RSL and LSR)
    fun RSLorLSR(startCircle: vec2, goalCircle: vec2, isBottom: Boolean): Pair<vec2, vec2> {
        // Find the distance between the circles
        val D = (startCircle - goalCircle).getLength()

        // If the circles have the same radius we can use cosine and not the law of cosines
        // to calculate the angle to the first tangent coordinate
        var theta = acos((CDubins.turningRadius * 2) / D)

        // If the circles is LSR, then the first tangent pos is on the other side of the center line
        if (isBottom) theta *= -1.0

        // Need to modify theta if the circles are not on the same height
        theta += atan2(
            goalCircle.northing - startCircle.northing,
            goalCircle.easting - startCircle.easting
        )

        // The coordinates of the first tangent point
        val xT1 = startCircle.easting + (CDubins.turningRadius * cos(theta))
        val zT1 = startCircle.northing + (CDubins.turningRadius * sin(theta))

        // To get the second tangent coordinate we need the direction of the tangent
        // To get the direction we move up 2 circle radius and end up at this coordinate
        val xT1_tmp = startCircle.easting + (CDubins.turningRadius * 2.0 * cos(theta))
        val zT1_tmp = startCircle.northing + (CDubins.turningRadius * 2.0 * sin(theta))

        // The direction is between the new coordinate and the center of the target circle
        val dirVec = goalCircle - vec2(xT1_tmp, zT1_tmp)

        // The coordinates of the second tangent point
        val xT2 = xT1 + dirVec.easting
        val zT2 = zT1 + dirVec.northing

        // The final coordinates of the tangent lines
        return Pair(vec2(xT1, zT1), vec2(xT2, zT2))
    }

    // Get the RLR or LRL tangent points
    fun GetRLRorLRLTangents(
        startCircle: vec2,
        goalCircle: vec2,
        isLRL: Boolean
    ): Triple<vec2, vec2, vec2> {
        // The distance between the circles
        val D = (startCircle - goalCircle).getLength()

        // The angle between the goal and the new 3rd circle we create with the law of cosines
        var theta = acos(D / (CDubins.turningRadius * 4f))

        // But we need to modify the angle theta if the circles are not on the same line
        val V1 = goalCircle - startCircle

        // Different depending on if we calculate LRL or RLR
        theta = if (isLRL) {
            atan2(V1.northing, V1.easting) + theta
        } else {
            atan2(V1.northing, V1.easting) - theta
        }

        // Calculate the position of the third circle
        val x = startCircle.easting + (CDubins.turningRadius * 2.0 * cos(theta))
        val z = startCircle.northing + (CDubins.turningRadius * 2.0 * sin(theta))
        val middleCircle = vec2(x, z)

        // Calculate the tangent points
        val V2 = (startCircle - middleCircle).normalize()
        val V3 = (goalCircle - middleCircle).normalize()
        val startTangent = middleCircle + (V2 * CDubins.turningRadius)
        val goalTangent = middleCircle + (V3 * CDubins.turningRadius)

        return Triple(startTangent, goalTangent, middleCircle)
    }

    // Calculate the length of a circle arc depending on which direction we are driving
    fun GetArcLength(
        circleCenterPos: vec2,
        startPos: vec2,
        goalPos: vec2,
        isLeftCircle: Boolean
    ): Double {
        val V1 = startPos - circleCenterPos
        val V2 = goalPos - circleCenterPos

        var theta: Double = atan2(V2.northing, V2.easting) - atan2(V1.northing, V1.easting)
        if (theta < 0f && isLeftCircle) theta += 2.0 * PI
        else if (theta > 0 && !isLeftCircle) theta -= 2.0 * PI
        return abs(CDubins.turningRadius * theta)
    }

    // Loops through segments of a path and add new coordinates to the final path
    fun AddCoordinatesToPath(
        currentPos: () -> vec2,
        theta: () -> Double,
        finalPath: MutableList<vec2>,
        segments: Int,
        isTurning: Boolean,
        isTurningRight: Boolean,
        update: (vec2, Double) -> Unit
    ) {
        var pos = currentPos()
        var t = theta()
        for (i in 0..segments) {
            // Update the position of the car
            pos = vec2(
                easting = pos.easting + CDubins.driveDistance * sin(t),
                northing = pos.northing + CDubins.driveDistance * cos(t)
            )

            // Don't update the heading if we are driving straight
            if (isTurning) {
                // Which way are we turning?
                val turnParameter = if (isTurningRight) 1.0 else -1.0

                // Update the heading
                t += (CDubins.driveDistance / CDubins.turningRadius) * turnParameter
            }

            // Add the new coordinate to the path
            finalPath.add(pos)
            update(pos, t)
        }
    }
}

// Will hold data related to one Dubins path so we can sort them
data class OneDubinsPath(
    val length1: Double,
    val length2: Double,
    val length3: Double,
    val tangent1: vec2,
    val tangent2: vec2,
    val pathType: PathType
) {
    // The total length of this path
    val totalLength: Double = length1 + length2 + length3

    // The coordinates of the final path
    var pathCoordinates: List<vec2> = emptyList()

    // Are we turning or driving straight in segment 2?
    var segment2Turning: Boolean = false

    // Are we turning right in the particular segment?
    var segment1TurningRight: Boolean = false
    var segment2TurningRight: Boolean = false
    var segment3TurningRight: Boolean = false

    // Are we turning right in any of the segments?
    fun SetIfTurningRight(
        segment1TurningRight: Boolean,
        segment2TurningRight: Boolean,
        segment3TurningRight: Boolean
    ) {
        this.segment1TurningRight = segment1TurningRight
        this.segment2TurningRight = segment2TurningRight
        this.segment3TurningRight = segment3TurningRight
    }
}