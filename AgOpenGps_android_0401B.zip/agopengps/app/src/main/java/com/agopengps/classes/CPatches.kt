package com.agopengps.classes

import android.graphics.Color
import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.PolygonOptions
import java.util.*


class CPatches(private val mf: FormGPS) {
    private val patchList: MutableList<MutableList<vec3>> = ArrayList(2048)
    private var triangleList: MutableList<vec3> = ArrayList(64)

    var isDrawing = false
    var leftPoint: vec2 = vec2(0.0, 0.0)
    var rightPoint: vec2 = vec2(0.0, 0.0)

    var numTriangles = 0
    var currentStartSectionNum: Int = 0
    var currentEndSectionNum: Int = 0
    var newStartSectionNum: Int = 0
    var newEndSectionNum: Int = 0

    private var googleMap: GoogleMap? = null

    init {
        // Initialize with empty lists
        triangleList = ArrayList(64)
        patchList.clear()
    }

    // Setter for GoogleMap instance
    fun setGoogleMap(map: GoogleMap) {
        this.googleMap = map
    }

    fun TurnMappingOn(j: Int) {
        numTriangles = 0

        if (!isDrawing) {
            isDrawing = true
            triangleList = ArrayList(64)
            patchList.add(triangleList)

            val color = when {
                !mf.tool.isMultiColoredSections -> mf.sectionColorDay
                mf.tool.isSectionsNotZones -> mf.tool.secColors[j]
                else -> mf.sectionColorDay
            }

            // Assuming color is an Android Color Int
            val red = Color.red(color as Int).toDouble()
            val green = Color.green(color as Int).toDouble()
            val blue = Color.blue(color as Int).toDouble()
            triangleList.add(vec3(red, green, blue))

            leftPoint = mf.section[currentStartSectionNum].leftPoint
            rightPoint = mf.section[currentEndSectionNum].rightPoint

            triangleList.add(vec3(leftPoint.easting, leftPoint.northing, 0.0))
            triangleList.add(vec3(rightPoint.easting, rightPoint.northing, 0.0))
        }
    }

    fun TurnMappingOff() {
        AddMappingPoint(0)
        isDrawing = false
        numTriangles = 0

        if (triangleList.size > 4) {
            mf.patchSaveList.add(triangleList)
            drawPolygon()
        } else {
            triangleList.clear()
            if (patchList.isNotEmpty()) {
                patchList.removeAt(patchList.size - 1)
            }
        }
    }

    fun AddMappingPoint(j: Int) {
        leftPoint = mf.section[currentStartSectionNum].leftPoint
        rightPoint = mf.section[currentEndSectionNum].rightPoint

        triangleList.add(vec3(leftPoint.easting, leftPoint.northing, 0.0))
        triangleList.add(vec3(rightPoint.easting, rightPoint.northing, 0.0))

        numTriangles++

        val c = triangleList.size - 1

        if (c >= 5) {
            val temp = (kotlin.math.abs(
                (triangleList[c].easting * (triangleList[c - 1].northing - triangleList[c - 2].northing)) +
                        (triangleList[c - 1].easting * (triangleList[c - 2].northing - triangleList[c].northing)) +
                        (triangleList[c - 2].easting * (triangleList[c].northing - triangleList[c - 1].northing))
            ) + kotlin.math.abs(
                (triangleList[c - 1].easting * (triangleList[c - 2].northing - triangleList[c - 3].northing)) +
                        (triangleList[c - 2].easting * (triangleList[c - 3].northing - triangleList[c - 1].northing)) +
                        (triangleList[c - 3].easting * (triangleList[c - 1].northing - triangleList[c - 2].northing))
            )) * 0.5

            mf.fd.workedAreaTotal += temp
            mf.fd.workedAreaTotalUser += temp
        }

        if (numTriangles > 61) {
            numTriangles = 0
            mf.patchSaveList.add(triangleList)
            drawPolygon()

            triangleList = ArrayList(64)
            patchList.add(triangleList)

            val color = if (!mf.tool.isMultiColoredSections)
                mf.sectionColorDay
            else
                mf.tool.secColors[j]

            val red = Color.red(color as Int).toDouble()
            val green = Color.green(color as Int).toDouble()
            val blue = Color.blue(color as Int).toDouble()
            triangleList.add(vec3(red, green, blue))

            triangleList.add(vec3(leftPoint.easting, leftPoint.northing, 0.0))
            triangleList.add(vec3(rightPoint.easting, rightPoint.northing, 0.0))
        }
    }

    private fun drawPolygon() {
        googleMap?.let { map ->
            if (triangleList.size > 2) {
                val colorVec = triangleList[0]
                val points = triangleList.drop(1).map {
                    com.google.android.gms.maps.model.LatLng(it.northing, it.easting)
                }

                map.addPolygon(
                    PolygonOptions()
                        .addAll(points)
                        .fillColor(android.graphics.Color.argb(
                            128, // alpha
                            colorVec.easting.toInt(),
                            colorVec.northing.toInt(),
                            colorVec.heading.toInt()
                        ))
                        .strokeWidth(2f)
                )
            }
        }
    }
}