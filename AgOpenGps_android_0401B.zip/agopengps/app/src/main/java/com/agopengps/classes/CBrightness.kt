package com.agopengps.classes

import android.provider.Settings
import com.agopengps.drive.FormGPS

class CBrightness(private val mf: FormGPS) {
    private var isBrightnessControllable = false

    init {
        checkBrightnessControlAvailability()
    }

    private fun checkBrightnessControlAvailability(): Boolean {
        return try {
            // Check if we can read system brightness
            Settings.System.getInt(mf.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
            isBrightnessControllable = true
            true
        } catch (e: Settings.SettingNotFoundException) {
            isBrightnessControllable = false
            false
        }
    }

    fun brightnessIncrease() {
        if (!isBrightnessControllable) return

        val current = getBrightness()
        if (current != -1) {
            setBrightness(minOf(255, current + 25))
        }
    }

    fun brightnessDecrease() {
        if (!isBrightnessControllable) return

        val current = getBrightness()
        if (current != -1) {
            setBrightness(maxOf(0, current - 25))
        }
    }

    fun getBrightness(): Int {
        return if (isBrightnessControllable) {
            try {
                Settings.System.getInt(mf.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
            } catch (e: Exception) {
                -1
            }
        } else {
            -1
        }
    }

    private fun setBrightness(brightness: Int) {
        if (!isBrightnessControllable) return

        try {
            // Set system brightness (requires WRITE_SETTINGS permission)
            Settings.System.putInt(
                mf.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                brightness.coerceIn(0, 255)
            )

            // Apply brightness to current window
            val layoutParams = mf.window.attributes // 获取当前窗口的 LayoutParams
            layoutParams.screenBrightness = brightness / 255f // 设置亮度（0.0f ~ 1.0f）
            mf.window.attributes = layoutParams // 应用修改
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    companion object {
        // Android brightness range is 0-255 (vs Windows 0-100)
        private const val MAX_BRIGHTNESS = 255
        private const val BRIGHTNESS_STEP = 25 // About 10% of range
    }
}