package com.agopengps.classes

import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotlin.math.pow

class CFont(private val mf: FormGPS) {

    companion object {
        const val GlyphsPerLine = 16
        const val GlyphLineCount = 16
        const val GlyphWidth = 16
        const val GlyphHeight = 32
        const val CharXSpacing = 16
        const val textureWidth = 256
        const val textureHeight = 256
    }

    var isFontOn: Boolean = true

    fun DrawTextVehicle(x: Double, y: Double, text: String, size: Double = 1.0, googleMap: GoogleMap) {
        var adjustedSize = size * -mf.camera.camSetDistance
        adjustedSize = adjustedSize.pow(0.8) / 800

        val position = if (mf.camera.camPitch > -58) {
            // 2D mode
            if (!mf.camera.camFollowing) {
                LatLng(x, y * 1.2) // Simplified, rotation would need map camera adjustment
            } else {
                LatLng(x, y * 1.2)
            }
        } else {
            // 3D mode
            if (!mf.camera.camFollowing) {
                LatLng(x, y * 0.3)
            } else {
                LatLng(x, y * 0.3)
            }
        }

        drawTextOnMap(googleMap, position, text, adjustedSize)
    }

    fun DrawText3D(x1: Double, y1: Double, text: String, size: Double = 1.0, googleMap: GoogleMap) {
        val adjustedSize = if (mf.camera.camPitch < -45) {
            -mf.camera.camSetDistance.pow(0.8) / 800
        } else {
            -mf.camera.camSetDistance.pow(0.85) / 1000
        }

        val position = LatLng(x1, y1)
        drawTextOnMap(googleMap, position, text, adjustedSize)
    }

    fun DrawText3DNoGPS(x1: Double, y1: Double, text: String, size: Double = 1.0, googleMap: GoogleMap) {
        var adjustedSize = 40.0
        adjustedSize = adjustedSize.pow(0.8) / 800

        val position = LatLng(x1, y1)
        drawTextOnMap(googleMap, position, text, adjustedSize)
    }

    fun DrawText(x: Double, y: Double, text: String, size: Double = 1.0, googleMap: GoogleMap) {
        val position = LatLng(x, y)
        drawTextOnMap(googleMap, position, text, size)
    }

    private fun drawTextOnMap(googleMap: GoogleMap, position: LatLng, text: String, size: Double) {
        // Since Google Maps doesn't support direct texture mapping like OpenGL,
        // we'll simulate text rendering by placing markers for each character
        var currentX = position.latitude
        val uStep = GlyphWidth.toDouble() / textureWidth
        val vStep = GlyphHeight.toDouble() / textureHeight

        text.forEach { char ->
            val idx = char.code
            val u = (idx % GlyphsPerLine) * uStep
            val v = (idx / GlyphsPerLine) * vStep

            // Note: In a real implementation, you'd need to create a bitmap for each glyph
            // from a font texture atlas and use BitmapDescriptorFactory.fromBitmap()
            // Here, we'll use a simple marker with the character as title for demonstration
            val markerOptions = MarkerOptions()
                .position(LatLng(currentX, position.longitude))
                .title(char.toString())
                .icon(BitmapDescriptorFactory.defaultMarker()) // Replace with custom glyph bitmap in practice
                .anchor(0.5f, 0.5f)

            googleMap.addMarker(markerOptions)
            currentX += CharXSpacing * size
        }
    }
}