package com.agopengps.classes

import com.agopengps.drive.FormGPS
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolylineOptions
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

class CYouTurn(private val mf: FormGPS) {

    var onA: Int = 0
    // Fields
    var isYouTurnTriggered: Boolean = false
    private var isGoingStraightThrough: Boolean = false

    var isTurnLeft: Boolean = false
    private var semiCircleIndex: Int = -1

    var isYouTurnBtnOn: Boolean = false

    var youTurnRadius: Double = 0.0

    var rowSkipsWidth: Int = 1
    var uTurnSmoothing: Int = 0

    var alternateSkips: Boolean = false
    private var previousBigSkip: Boolean = true
    var rowSkipsWidth2: Int = 3
    var turnSkips: Int = 2

    var youTurnStartOffset: Int = 0

    // Guidance values
    var DistanceFromCurrentLine: Double = 0.0
    var uturnDistanceFromBoundary: Double = 0.0

    var DistanceFromCurrentLineSteer: Double = 0.0
    var DistanceFromCurrentLinePivot: Double = 0.0
    var steerAngleGu: Double = 0.0
    var rEastSteer: Double = 0.0
    var rNorthSteer: Double = 0.0
    var rEastPivot: Double = 0.0
    var rNorthPivot: Double = 0.0

    private var A: Int = 0
    private var B: Int = 0
    var isHeadingSameWay: Boolean = true
    var isTurnCreationTooClose: Boolean = false
    var isTurnCreationNotCrossingError: Boolean = false
    var turnTooCloseTrigger: Boolean = false

    var goalPointYT: vec2 = vec2(0.0, 0.0)
    var radiusPointYT: vec2 = vec2(0.0, 0.0)
    var steerAngleYT: Double = 0.0
    var rEastYT: Double = 0.0
    var rNorthYT: Double = 0.0
    var ppRadiusYT: Double = 0.0

    //val ytList: MutableList<vec3> = mutableListOf()
    val ytList: MutableList<vec3> = ArrayList<vec3>(128)
    private val ytList2: MutableList<vec3> = mutableListOf()

    val nextCurve: MutableList<vec3> = mutableListOf()

    var isOutSameCurve: Boolean = false

    var uTurnStyle: Int = 0

    var isOutOfBounds: Boolean = false

    var youTurnPhase: Int = 0

    var iE: Double = 0.0
    var iN: Double = 0.0

    val turnClosestList: MutableList<CClose> = mutableListOf()

    var closestTurnPt: CClose = CClose()

    var inClosestTurnPt: CClose = CClose()
    var outClosestTurnPt: CClose = CClose()
    var startOfTurnPt: CClose = CClose()

    private var pointSpacing: Double = 0.0

    // Constructor
    init {
        uturnDistanceFromBoundary = mf.settings.set_youTurnDistanceFromBoundary.toDouble()
        youTurnStartOffset = mf.settings.set_youTurnExtensionLength.toInt()
        rowSkipsWidth = mf.settings.set_youSkipWidth
        Set_Alternate_skips()
        youTurnRadius = mf.settings.set_youTurnRadius.toDouble()
        uTurnStyle = mf.settings.set_uTurnStyle
        uTurnSmoothing = mf.settings.setAS_uTurnSmoothing
    }


    // Methods
    fun BuildCurveDubinsYouTurn(): Boolean {
        val turnOffset = (mf.tool.width - mf.tool.overlap) * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)
        pointSpacing = youTurnRadius * 0.1

        return when (uTurnStyle) {
            0 -> {
                if (turnOffset > (youTurnRadius * 2.0)) {
                    CreateCurveWideTurn()
                } else {
                    CreateCurveOmegaTurn()
                    CreateCurveOmegaTurn()
                }
            }
            1 -> KStyleTurnCurve()
            else -> false // Programming error if you got here
        }
    }

    fun BuildABLineDubinsYouTurn(): Boolean {
        val turnOffset = (mf.tool.width - mf.tool.overlap) * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)
        pointSpacing = youTurnRadius * 0.1

        return when (uTurnStyle) {
            0 -> {
                if (turnOffset > (youTurnRadius * 2.0)) {
                    CreateABWideTurn()
                } else {
                    CreateABOmegaTurn()
                }
            }
            1 -> KStyleTurnAB()
            else -> false // Programming error if you got here
        }
    }



    fun DistanceFromYouTurnLine(): Boolean {
        // 獲取當前轉向軸位置的副本
        var minDistA = 1_000_000.0
        var minDistB = 1_000_000.0
        val ptCount = ytList.size

        if (ptCount > 0) {
            if (mf.isStanleyUsed) {
                val pivot = mf.steerAxlePos

                // 找到距離當前位置最近的兩個點
                var a = 0
                var b = 0
                for (t in 0 until ptCount) {
                    val dist = ((pivot.easting - ytList[t].easting) * (pivot.easting - ytList[t].easting)) +
                            ((pivot.northing - ytList[t].northing) * (pivot.northing - ytList[t].northing))
                    if (dist < minDistA) {
                        minDistB = minDistA
                        b = a
                        minDistA = dist
                        a = t
                    } else if (dist < minDistB) {
                        minDistB = dist
                        b = t
                    }
                }

                if (minDistA > 16) {
                    completeYouTurn()
                    return false
                }

                // 確保點的索引按升序排列，避免方向混亂
                if (a > b) {
                    a = b.also { b = a } // Kotlin 的交換方式
                }

                // 如果 A < 0，設為 0
                if (a < 0) a = 0
                b = a + 1

                // 如果超出範圍或到達終點，重置並返回
                if (b >= ptCount - 1) {
                    completeYouTurn()
                    return false
                }

                if (uTurnStyle == 1 && mf.isReverse) {
                    completeYouTurn()
                    return true
                }

                // 計算與當前 AB 線的距離，預計算線段的法向量
                val dx = ytList[b].easting - ytList[a].easting
                val dz = ytList[b].northing - ytList[a].northing
                if (abs(dx) < Double.MIN_VALUE && abs(dz) < Double.MIN_VALUE) return false

                val abHeading = ytList[a].heading

                // 計算從當前 AB 線到轉向點的距離（90 度投影）
                DistanceFromCurrentLine = ((dz * pivot.easting) - (dx * pivot.northing) +
                        (ytList[b].easting * ytList[a].northing) - (ytList[b].northing * ytList[a].easting)) /
                        sqrt((dz * dz) + (dx * dx))

                // 計算 AB 線上距離當前位置最近的點（U 是沿線段的投影比例）
                val u = (((pivot.easting - ytList[a].easting) * dx) +
                        ((pivot.northing - ytList[a].northing) * dz)) /
                        ((dx * dx) + (dz * dz))

                // 關鍵點：U 型轉彎路徑的起點
                rEastYT = ytList[a].easting + (u * dx)
                rNorthYT = ytList[a].northing + (u * dz)

                // Stanley 算法的第一部分：提取方向誤差
                var abFixHeadingDelta = pivot.heading - abHeading

                // 修正圓周誤差，將角度限制在 -π/2 到 π/2
                if (abFixHeadingDelta > PI) abFixHeadingDelta -= PI
                else if (abFixHeadingDelta < -PI) abFixHeadingDelta += PI
                if (abFixHeadingDelta > glm.PIBy2) abFixHeadingDelta -= PI
                else if (abFixHeadingDelta < -glm.PIBy2) abFixHeadingDelta += PI

                if (mf.isReverse) abFixHeadingDelta *= -1.0
                abFixHeadingDelta *= mf.vehicle.stanleyHeadingErrorGain // 通常為 1，小於 1 減少方向誤差
                abFixHeadingDelta = abFixHeadingDelta.coerceIn(-0.74, 0.74) // 限制在 ±0.74

                // Stanley 算法的非線性距離誤差部分
                steerAngleYT = atan((DistanceFromCurrentLine * mf.vehicle.stanleyDistanceErrorGain) /
                        ((mf.avgSpeed * 0.277777) + 1))
                steerAngleYT = steerAngleYT.coerceIn(-0.74, 0.74) // 限制在 ±0.74

                // 合併方向誤差和距離誤差，轉換為度數並應用補償
                steerAngleYT = glm.toDegrees((steerAngleYT + abFixHeadingDelta * mf.vehicle.uturnCompensation) * -1.0)
                steerAngleYT = steerAngleYT.coerceIn(-mf.vehicle.maxSteerAngle, mf.vehicle.maxSteerAngle)
            } else {
                val pivot = mf.pivotAxlePos

                // 找到距離當前位置最近的兩個點
                var a = 0
                var b = 0
                for (t in 0 until ptCount) {
                    val dist = ((pivot.easting - ytList[t].easting) * (pivot.easting - ytList[t].easting)) +
                            ((pivot.northing - ytList[t].northing) * (pivot.northing - ytList[t].northing))
                    if (dist < minDistA) {
                        minDistB = minDistA
                        b = a
                        minDistA = dist
                        a = t
                    } else if (dist < minDistB) {
                        minDistB = dist
                        b = t
                    }
                }

                // 確保點的索引按升序排列
                if (a > b) {
                    a = b.also { b = a }
                }

                onA = a
                val DistancePiv = glm.Distance(ytList[a], pivot)

                if ((a > 0 && DistancePiv > 2) || (b >= ptCount - 1)) {
                    completeYouTurn()
                    return false
                }

                // 計算與當前 AB 線的距離
                val dx = ytList[b].easting - ytList[a].easting
                val dz = ytList[b].northing - ytList[a].northing
                if (abs(dx) < Double.MIN_VALUE && abs(dz) < Double.MIN_VALUE) return false

                DistanceFromCurrentLine = ((dz * pivot.easting) - (dx * pivot.northing) +
                        (ytList[b].easting * ytList[a].northing) - (ytList[b].northing * ytList[a].easting)) /
                        sqrt((dz * dz) + (dx * dx))

                // Pure Pursuit：計算 AB 線上距離當前位置最近的點
                val u = (((pivot.easting - ytList[a].easting) * dx) +
                        ((pivot.northing - ytList[a].northing) * dz)) /
                        ((dx * dx) + (dz * dz))

                rEastYT = ytList[a].easting + (u * dx)
                rNorthYT = ytList[a].northing + (u * dz)

                // 更新目標點距離（Pure Pursuit）
                var goalPointDistance = mf.vehicle.UpdateGoalPointDistance()

                isHeadingSameWay = true
                val reverseHeading = !mf.isReverse
                val count = if (reverseHeading) 1 else -1
                val start = vec3(rEastYT, rNorthYT, 0.0)
                var distSoFar = 0.0

                val range = if (reverseHeading) b until ptCount else a downTo 0
                for (i in range step count) {
                    val tempDist = glm.Distance(start, ytList[i])

                    // 是否會超出目標距離？
                    if (distSoFar + tempDist > goalPointDistance) {
                        val j = (goalPointDistance - distSoFar) / tempDist // 剩餘距離比例
                        goalPointYT.easting = ((1 - j) * start.easting) + (j * ytList[i].easting)
                        goalPointYT.northing = ((1 - j) * start.northing) + (j * ytList[i].northing)
                        break
                    } else {
                        distSoFar += tempDist
                    }

                    start.copyFrom(ytList[i])

                    if (i == ptCount - 1 || i == 0) { // 目標距離超出 U 型轉彎剩餘部分
                        completeYouTurn()
                        return false
                    }

                    if (uTurnStyle == 1 && mf.isReverse) {
                        completeYouTurn()
                        return true
                    }
                }

                // 計算從軸點到前瞻點的距離 "D"
                val goalPointDistanceSquared = glm.DistanceSquared(goalPointYT.northing, goalPointYT.easting,
                    pivot.northing, pivot.easting)

                // 計算局部坐標中的 delta x 和轉向角度
                val localHeading = glm.twoPI - mf.fixHeading
                ppRadiusYT = goalPointDistanceSquared / (2 * (((goalPointYT.easting - pivot.easting) * cos(localHeading)) +
                        ((goalPointYT.northing - pivot.northing) * sin(localHeading))))
                steerAngleYT = glm.toDegrees(atan(2 * (((goalPointYT.easting - pivot.easting) * cos(localHeading)) +
                        ((goalPointYT.northing - pivot.northing) * sin(localHeading))) * mf.vehicle.wheelbase /
                        goalPointDistanceSquared))

                steerAngleYT *= mf.vehicle.uturnCompensation
                steerAngleYT = steerAngleYT.coerceIn(-mf.vehicle.maxSteerAngle, mf.vehicle.maxSteerAngle)

                ppRadiusYT = ppRadiusYT.coerceIn(-500.0, 500.0)
                radiusPointYT.easting = pivot.easting + (ppRadiusYT * cos(localHeading))
                radiusPointYT.northing = pivot.northing + (ppRadiusYT * sin(localHeading))

                // 如果方向相反，距離取負值
                if (!isHeadingSameWay) DistanceFromCurrentLine *= -1.0
            }

            // 用於平滑模式
            mf.vehicle.modeActualXTE = DistanceFromCurrentLine

            // 轉換為厘米
            mf.guidanceLineDistanceOff = (DistanceFromCurrentLine * 1000.0).roundToInt().toShort()
            mf.guidanceLineSteerAngle = (steerAngleYT * 100).toInt().toShort()
            return true
        } else {
            completeYouTurn()
            return false
        }
    }

    // 正常完成 U 型轉彎
    fun completeYouTurn() {
        isYouTurnTriggered = false
        resetCreatedYouTurn()
        mf.sounds.isBoundAlarming = false
    }

    // 重置所有 U 型轉彎相關狀態
    fun resetYouTurn() {
        // 修復 U 型轉彎
        isYouTurnTriggered = false
        mf.makeUTurnCounter = 0
        ytList?.clear()
        resetCreatedYouTurn()
        mf.sounds.isBoundAlarming = false
        isTurnCreationTooClose = false
        isTurnCreationNotCrossingError = false
        mf.p_239.pgn[mf.p_239.uturn] = 0
    }

    // 重置已創建的 U 型轉彎
    fun resetCreatedYouTurn() {
        youTurnPhase = 0
        ytList?.clear()
        mf.makeUTurnCounter = 0
        mf.p_239.pgn[mf.p_239.uturn] = 0
        isOutSameCurve = false
        isGoingStraightThrough = false
    }


    /**
     * 尋找 AB 線上的最近轉彎點
     */
    private fun FindABTurnPoint(abLine: CABLine): Boolean {
        val pos = mf.pivotAxlePos
        var minDis = Double.MAX_VALUE

        val points = abLine.GetABLinePoints()
        if (points.isEmpty()) return false

        for (i in points.indices) {
            val dist = glm.DistanceSquared(points[i], pos)
            if (dist < minDis) {
                minDis = dist
                closestTurnPt = CClose().apply {
                    closePt = vec3(points[i])
                    closePt.heading = abLine.abHeading
                    turnLineHeading = abLine.abHeading
                    // turnLineNum 和 turnLineIndex 根據實際需求設置，否則保持 -1
                }
            }
        }

        return minDis != Double.MAX_VALUE
    }
    
    /**
     * 假設的 AB 線偏移方法（需根據實際 CABLine 類實現）
     */
    private fun CABLine.BuildNewOffsetABLine(distAway: Double): List<vec3> {
        val result = mutableListOf<vec3>()
        val points = GetABLinePoints()
        val offsetAngle = abHeading + glm.PIBy2
        for (pt in points) {
            result.add(vec3(
                easting = pt.easting + distAway * sin(offsetAngle),
                northing = pt.northing + distAway * cos(offsetAngle),
                heading = abHeading
            ))
        }
        return result
    }

    /**
     * 假設的 AB 線點獲取方法（需根據實際 CABLine 類實現）
     */
    private fun CABLine.GetABLinePoints(): List<vec3> {
        val result = mutableListOf<vec3>()
        // 模擬生成 AB 線上的點，實際應從 CABLine 中獲取
        val length = 100.0 // 假設長度
        val step = pointSpacing
        var currentEasting = currentLinePtA.easting
        var currentNorthing = currentLinePtA.northing
        for (i in 0 until (length / step).toInt()) {
            result.add(vec3(currentEasting, currentNorthing, abHeading))
            currentEasting += step * sin(abHeading)
            currentNorthing += step * cos(abHeading)
        }
        return result
    }





    class CClose {
        var closePt: vec3 = vec3()
        var turnLineNum: Int = -1
        var turnLineIndex: Int = -1
        var turnLineHeading: Double = -1.0
        var curveIndex: Int = -1

        constructor() {
            closePt = vec3()
            turnLineNum = -1
            turnLineIndex = -1
            turnLineHeading = -1.0
            curveIndex = -1
        }

        constructor(_clo: CClose) {
            closePt = vec3(_clo.closePt)
            turnLineNum = _clo.turnLineNum
            turnLineIndex = _clo.turnLineIndex
            turnLineHeading = _clo.turnLineHeading
            curveIndex = _clo.curveIndex
        }

        constructor(pt: vec3) {
            closePt = vec3(pt)
            turnLineNum = -1
            turnLineIndex = -1
            turnLineHeading = -1.0
            curveIndex = -1
        }
    }

    private fun CreateCurveOmegaTurn(): Boolean {
        // 如果 U 型轉彎計數器小於 4，直接重置階段並返回成功
        if (mf.makeUTurnCounter < 4) {
            youTurnPhase = 0
            return true
        }

        // 檢查軌跡索引是否有效
        if (mf.trk.idx < 0 || mf.trk.gArr.size <= mf.trk.idx) return true
        val track = mf.trk.gArr[mf.trk.idx]

        // 計算轉彎偏移量
        val widthMinusOverlap = mf.tool.width - mf.tool.overlap
        val turnOffset = widthMinusOverlap * rowSkipsWidth +
                (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)

        when (youTurnPhase) {
            0 -> {
                // 尋找最近的轉彎點，若失敗則根據模式處理
                if (!FindCurveTurnPoint(mf.curve, false)) {
                    if (track.mode == TrackMode.WaterPivot || track.mode == TrackMode.BndCurve) {
                        youTurnPhase = 11 // 忽略此情況
                    } else {
                        FailCreate()
                    }
                    return false
                }

                // 記錄進入點並清空 ytList
                inClosestTurnPt = CClose(closestTurnPt)
                ytList.clear()

                // 根據曲線方向決定計數增減
                val count = if (mf.curve.isHeadingSameWay) -1 else 1
                var curveIndex = inClosestTurnPt.curveIndex

                isOutOfBounds = true
                var stopIfWayOut = 0
                var head = 0.0

                // 尋找不在轉彎區域外的路徑
                while (isOutOfBounds) {
                    stopIfWayOut++
                    isOutOfBounds = false

                    ytList.clear()
                    curveIndex += count

                    // 檢查曲線索引是否越界
                    if (curveIndex < 0 || curveIndex >= mf.curve.curList.size) {
                        FailCreate()
                        return false
                    }

                    // 當前位置初始化
                    var currentPos = vec3(mf.curve.curList[curveIndex])
                    if (!mf.curve.isHeadingSameWay) currentPos.heading += glm.PIBy2
                    if (currentPos.heading >= glm.twoPI) currentPos.heading -= glm.twoPI
                    head = currentPos.heading

                    // 使用 Dubins 路徑生成器創建轉彎路徑
                    val dubYouTurnPath = CDubins(mf)
                    dubYouTurnPath.turningRadius = youTurnRadius

                    val adjustedHead = if (isTurnLeft) head + glm.PIBy2 else head - glm.PIBy2
                    head = if (adjustedHead >= glm.twoPI) adjustedHead - glm.twoPI else adjustedHead

                    val goal = vec3(
                        easting = currentPos.easting + (turnOffset * cos(head)),
                        northing = currentPos.northing + (turnOffset * sin(head)),
                        heading = head + (if (isTurnLeft) PI else -PI)
                    )

                    ytList.addAll(dubYouTurnPath.GenerateDubins(currentPos, goal))
                    if (ytList.isEmpty()) {
                        FailCreate()
                        return false
                    }

                    // 防止無限循環或索引越界
                    if (stopIfWayOut == 300 || curveIndex < 1 || curveIndex > (mf.curve.curList.size - 2)) {
                        FailCreate()
                        return false
                    }

                    // 檢查是否超出轉彎區域
                    for (i in ytList.indices step 2) {
                        if (mf.bnd.isPointInsideTurnArea(ytList[i]) != 0) {
                            isOutOfBounds = true
                            break
                        }
                    }
                }
                inClosestTurnPt.curveIndex = curveIndex

                // 過濾過密的點
                var cnt = ytList.size
                var i = 1
                while (i < cnt - 2) {
                    val Distance = glm.DistanceSquared(ytList[i], ytList[i + 1])
                    if (Distance < pointSpacing) {
                        ytList.removeAt(i + 1)
                        cnt = ytList.size
                        i--
                    }
                    i++
                }

                // 將轉彎移到內部
                val tempList = mutableListOf<vec3>().apply { addAll(ytList) }
                ytList.clear()
                ytList.addAll(MoveTurnInsideTurnLine(tempList, head, false, false))
                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                youTurnPhase = 1
                return true
            }

            1 -> {
                // 計算下一個曲線的偏移距離
                val distAway = widthMinusOverlap * (mf.curve.howManyPathsAway +
                        (if (isTurnLeft xor mf.curve.isHeadingSameWay) rowSkipsWidth else -rowSkipsWidth)) +
                        (if (mf.curve.isHeadingSameWay) -mf.tool.offset else mf.tool.offset) +
                        track.nudgeDistance + (0.5 * widthMinusOverlap)

                // 生成下一個偏移曲線
                nextCurve.clear()
                nextCurve.addAll(mf.curve.BuildNewOffsetList(distAway, track))

                // 尋找退出點
                var dis = Double.MAX_VALUE
                var outIndex = 0
                if (nextCurve.size > 1) {
                    for (i in nextCurve.indices) {
                        val newDis = glm.Distance(nextCurve[i], ytList[ytList.size - 1])
                        if (newDis < dis) {
                            dis = newDis
                            outIndex = i
                        }
                    }
                    outClosestTurnPt = CClose(vec3(nextCurve[outIndex]))
                } else {
                    FailCreate()
                    return false
                }

                // 生成第二段轉彎弧
                val startPos = ytList[ytList.size - 1]
                val goalPos = vec3(nextCurve[outIndex])
                goalPos.heading = if (mf.curve.isHeadingSameWay) startPos.heading else startPos.heading + PI

                val dubYouTurnPath = CDubins(mf)
                dubYouTurnPath.turningRadius = youTurnRadius

                ytList2.clear()
                ytList2.addAll(dubYouTurnPath.GenerateDubins(startPos, goalPos))
                if (ytList2.isEmpty()) {
                    FailCreate()
                    return false
                }

                // 檢查是否超出邊界
                isOutOfBounds = false
                for (i in ytList2.indices step 2) {
                    if (mf.bnd.isPointInsideTurnArea(ytList2[i]) != 0) {
                        isOutOfBounds = true
                        break
                    }
                }

                if (isOutOfBounds) {
                    FailCreate()
                    return false
                }

                val tempList = mutableListOf<vec3>().apply { addAll(ytList2) }
                ytList2.clear()
                ytList2.addAll(MoveTurnInsideTurnLine(tempList, goalPos.heading, false, true))
                if (ytList2.isEmpty()) {
                    FailCreate()
                    return false
                }

                youTurnPhase = 2
                return true
            }

            2 -> {
                // 合併兩段路徑
                val cnt1 = ytList.size
                val cnt2 = ytList2.size
                for (i in 0 until cnt2) {
                    ytList.add(vec3(ytList2[i]))
                }

                // 添加序列線（如果需要）
                if (!AddCurveSequenceLines()) return false

                // 插入中間點以平滑路徑
                var cnt = ytList.size
                var i = 1
                while (i < cnt - 2) {
                    val j = i + 1
                    if (j == cnt - 1) {
                        i++
                        continue
                    }
                    val Distance = glm.DistanceSquared(ytList[i], ytList[j])
                    if (Distance > 1) {
                        val pointB = vec3(
                            (ytList[i].easting + ytList[j].easting) / 2.0,
                            (ytList[i].northing + ytList[j].northing) / 2.0,
                            ytList[i].heading
                        )
                        ytList.add(j, pointB)
                        cnt = ytList.size
                        i--
                    }
                    i++
                }

                // 平滑路徑並更新方向
                cnt = ytList.size
                val arr = ytList.toTypedArray()
                cnt -= 2
                ytList.clear()

                for (i in 2 until cnt) {
                    val pt3 = vec3(arr[i])
                    pt3.heading = atan2(arr[i + 1].easting - arr[i - 1].easting, arr[i + 1].northing - arr[i - 1].northing)
                    if (pt3.heading < 0) pt3.heading += glm.twoPI
                    ytList.add(pt3)
                }

                // 檢查是否離起點太近
                if (glm.Distance(ytList[0], mf.pivotAxlePos) < 3) {
                    FailCreate()
                    return false
                }

                // 檢查是否直行通過
                isGoingStraightThrough = PI - abs(abs(ytList[ytList.size - 2].heading - ytList[1].heading) - PI) < glm.PIBy2
                ytList2.clear()
                isOutOfBounds = false
                youTurnPhase = 10
                turnTooCloseTrigger = false
                isTurnCreationTooClose = false
                return true
            }
        }
        return false
    }

    private fun CreateCurveWideTurn(): Boolean {
        // 如果 U 型轉彎計數器小於 4，直接重置階段並返回成功
        if (mf.makeUTurnCounter < 4) {
            youTurnPhase = 0
            return true
        }

        // 檢查軌跡索引是否有效
        if (mf.trk.idx < 0 || mf.trk.gArr.size <= mf.trk.idx) return true
        val track = mf.trk.gArr[mf.trk.idx]

        var head = 0.0
        val count = if (mf.curve.isHeadingSameWay) -1 else 1

        when (youTurnPhase) {
            0 -> {
                // 尋找最近的轉彎點，若失敗則處理異常
                if (!FindCurveTurnPoint(mf.curve, false)) {
                    if (track.mode == TrackMode.WaterPivot || track.mode == TrackMode.BndCurve) {
                        youTurnPhase = 11 // 忽略此情況
                    } else {
                        FailCreate()
                    }
                    return false
                }
                inClosestTurnPt = CClose(closestTurnPt)
                startOfTurnPt = CClose(inClosestTurnPt)

                var stopIfWayOut = 0
                isOutOfBounds = true

                // 生成第一段轉彎弧
                while (isOutOfBounds) {
                    isOutOfBounds = false
                    stopIfWayOut++

                    var currentPos = vec3(mf.curve.curList[inClosestTurnPt.curveIndex])
                    head = currentPos.heading
                    if (!mf.curve.isHeadingSameWay) head += PI
                    if (head > glm.twoPI) head -= glm.twoPI
                    currentPos.heading = head

                    ytList.clear()
                    ytList.add(currentPos)

                    // 生成半圓轉彎路徑
                    while (abs(head - currentPos.heading) < PI) {
                        currentPos.easting += pointSpacing * sin(currentPos.heading)
                        currentPos.northing += pointSpacing * cos(currentPos.heading)
                        val turnParameter = if (isTurnLeft) -1.0 else 1.0
                        currentPos.heading += (pointSpacing / youTurnRadius) * turnParameter
                        ytList.add(currentPos)
                    }

                    if (ytList.isEmpty()) {
                        FailCreate()
                        return false
                    }

                    // 檢查是否超出轉彎區域
                    for (j in ytList.indices step 2) {
                        if (mf.bnd.isPointInsideTurnArea(ytList[j]) != 0) {
                            isOutOfBounds = true
                            break
                        }
                    }

                    if (!isOutOfBounds) {
                        val tempList = mutableListOf<vec3>().apply { addAll(ytList) }
                        ytList.clear()
                        ytList.addAll(MoveTurnInsideTurnLine(tempList, head, true, false))
                        if (ytList.isEmpty()) {
                            FailCreate()
                            return false
                        }
                        youTurnPhase = 1
                        return true
                    }

                    // 防止無限循環或索引越界
                    if (stopIfWayOut == 300 || inClosestTurnPt.curveIndex < 1 || inClosestTurnPt.curveIndex > (mf.curve.curList.size - 2)) {
                        FailCreate()
                        return false
                    }

                    inClosestTurnPt.curveIndex += count
                    inClosestTurnPt.closePt = vec3(mf.curve.curList[inClosestTurnPt.curveIndex])

                    if (glm.Distance(ytList[0], mf.pivotAxlePos) < 3) {
                        FailCreate()
                        return false
                    }
                }
                return false
            }

            1 -> {
                // 計算下一個曲線的偏移距離
                val widthMinusOverlap = mf.tool.width - mf.tool.overlap
                val distAway = widthMinusOverlap * (mf.curve.howManyPathsAway +
                        (if (isTurnLeft xor mf.curve.isHeadingSameWay) rowSkipsWidth else -rowSkipsWidth)) +
                        (if (mf.curve.isHeadingSameWay) -mf.tool.offset else mf.tool.offset) +
                        track.nudgeDistance + (0.5 * widthMinusOverlap)

                nextCurve.clear()
                nextCurve.addAll(mf.curve.BuildNewOffsetList(distAway, track))

                // 檢查轉彎線方向是否一致
                val isTurnLineSameWay = abs(inClosestTurnPt.turnLineHeading - ytList[ytList.size - 1].heading).let {
                    it <= glm.PIBy2 || it >= 3 * glm.PIBy2
                }

                if (!FindCurveOutTurnPoint(mf.curve, nextCurve, startOfTurnPt, isTurnLineSameWay)) {
                    FailCreate()
                    return false
                }
                outClosestTurnPt = CClose(closestTurnPt)

                isOutOfBounds = true
                while (isOutOfBounds) {
                    isOutOfBounds = false
                    var currentPos = vec3(nextCurve[outClosestTurnPt.curveIndex])
                    head = currentPos.heading
                    if ((!mf.curve.isHeadingSameWay && !isOutSameCurve) || (mf.curve.isHeadingSameWay && isOutSameCurve)) head += PI
                    if (head > glm.twoPI) head -= glm.twoPI
                    currentPos.heading = head

                    ytList2.clear()
                    ytList2.add(currentPos)

                    while (abs(head - currentPos.heading) < PI) {
                        currentPos.easting += pointSpacing * sin(currentPos.heading)
                        currentPos.northing += pointSpacing * cos(currentPos.heading)
                        val turnParameter = if (isTurnLeft) 1.0 else -1.0
                        currentPos.heading += (pointSpacing / youTurnRadius) * turnParameter
                        ytList2.add(currentPos)
                    }

                    if (ytList2.isEmpty()) {
                        FailCreate()
                        return false
                    }

                    for (j in ytList2.indices step 2) {
                        if (mf.bnd.isPointInsideTurnArea(ytList2[j]) != 0) {
                            isOutOfBounds = true
                            break
                        }
                    }

                    if (!isOutOfBounds) {
                        val tempList = mutableListOf<vec3>().apply { addAll(ytList2) }
                        ytList2.clear()
                        ytList2.addAll(MoveTurnInsideTurnLine(tempList, head, true, true))
                        if (ytList2.isEmpty()) {
                            FailCreate()
                            return false
                        }
                        youTurnPhase = 2
                        return true
                    }

                    if (outClosestTurnPt.curveIndex < 1 || outClosestTurnPt.curveIndex > (nextCurve.size - 2)) {
                        FailCreate()
                        return false
                    }

                    outClosestTurnPt.curveIndex += if (!isOutSameCurve) count else -count
                    outClosestTurnPt.closePt = vec3(nextCurve[outClosestTurnPt.curveIndex])
                }
                return false
            }

            2 -> {
                val cnt1 = ytList.size
                val cnt2 = ytList2.size

                // 檢查第一段轉彎線方向是否一致
                val isFirstTurnLineSameWay = abs(inClosestTurnPt.turnLineHeading - ytList[ytList.size - 1].heading).let {
                    it <= glm.PIBy2 || it >= 3 * glm.PIBy2
                }

                FindInnerTurnPoints(ytList[cnt1 - 1], ytList[0].heading, inClosestTurnPt, isFirstTurnLineSameWay)
                val startClosestTurnPt = CClose(closestTurnPt)

                FindInnerTurnPoints(ytList2[cnt2 - 1], ytList2[0].heading + PI, outClosestTurnPt, !isFirstTurnLineSameWay)
                val goalClosestTurnPt = CClose(closestTurnPt)

                if (startClosestTurnPt.turnLineNum != goalClosestTurnPt.turnLineNum) {
                    FailCreate()
                    return false
                }

                // 連接兩段轉彎弧
                if (startClosestTurnPt.turnLineIndex == goalClosestTurnPt.turnLineIndex) {
                    for (a in 0 until cnt2) {
                        ytList.add(vec3(ytList2[cnt2 - 1 - a]))
                    }
                } else {
                    val turnCount = mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine.size
                    var loops = abs(startClosestTurnPt.turnLineIndex - goalClosestTurnPt.turnLineIndex)

                    if (loops > (turnCount / 2)) {
                        loops = if (startClosestTurnPt.turnLineIndex < goalClosestTurnPt.turnLineIndex) {
                            (turnCount - goalClosestTurnPt.turnLineIndex) + startClosestTurnPt.turnLineIndex
                        } else {
                            (turnCount - startClosestTurnPt.turnLineIndex) + goalClosestTurnPt.turnLineIndex
                        }
                    }

                    val tPoint = vec3()
                    if (isFirstTurnLineSameWay) {
                        for (i in 0 until loops) {
                            if (startClosestTurnPt.turnLineIndex + 1 >= turnCount) startClosestTurnPt.turnLineIndex = -1
                            tPoint.copyFrom(mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine[startClosestTurnPt.turnLineIndex + 1])
                            startClosestTurnPt.turnLineIndex++
                            if (startClosestTurnPt.turnLineIndex >= turnCount) startClosestTurnPt.turnLineIndex = 0
                            ytList.add(tPoint)
                        }
                    } else {
                        for (i in 0 until loops) {
                            tPoint.copyFrom(mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine[startClosestTurnPt.turnLineIndex])
                            startClosestTurnPt.turnLineIndex--
                            if (startClosestTurnPt.turnLineIndex == -1) startClosestTurnPt.turnLineIndex = turnCount - 1
                            ytList.add(tPoint)
                        }
                    }

                    for (a in 0 until cnt2) {
                        ytList.add(vec3(ytList2[cnt2 - 1 - a]))
                    }
                }

                // 添加序列線並平滑路徑
                if (!AddCurveSequenceLines()) return false

                var cnt = ytList.size
                var i = 1
                while (i < cnt - 2) {
                    val j = i + 1
                    if (j == cnt - 1) {
                        i++
                        continue
                    }
                    val Distance = glm.DistanceSquared(ytList[i], ytList[j])
                    if (Distance > 1) {
                        val pointB = vec3(
                            (ytList[i].easting + ytList[j].easting) / 2.0,
                            (ytList[i].northing + ytList[j].northing) / 2.0,
                            ytList[i].heading
                        )
                        ytList.add(j, pointB)
                        cnt = ytList.size
                        i--
                    }
                    i++
                }

                cnt = ytList.size
                val arr = ytList.toTypedArray() // 直接轉換為數組
                cnt -= 2
                ytList.clear()

                for (i in 2 until cnt) {
                    val pt3 = vec3(arr[i])
                    pt3.heading = atan2(arr[i + 1].easting - arr[i - 1].easting, arr[i + 1].northing - arr[i - 1].northing)
                    if (pt3.heading < 0) pt3.heading += glm.twoPI
                    ytList.add(pt3)
                }

                // 檢查是否離起點太近
                if (glm.Distance(ytList[0], mf.pivotAxlePos) < 3) {
                    FailCreate()
                    return false
                }

                // 檢查是否直行通過
                isGoingStraightThrough = PI - abs(abs(ytList[ytList.size - 2].heading - ytList[1].heading) - PI) < glm.PIBy2
                ytList2.clear()
                isOutOfBounds = false
                youTurnPhase = 10
                turnTooCloseTrigger = false
                isTurnCreationTooClose = false
                return true
            }
        }
        return false
    }

    private fun CreateABOmegaTurn(): Boolean {
        // 如果 U 型轉彎計數器小於 4，直接重置階段並返回成功
        if (mf.makeUTurnCounter < 4) {
            youTurnPhase = 0
            return true
        }

        // 檢查 AB 線是否有效
        if (mf.ABLine.currentLinePtA.easting == 0.0 && mf.ABLine.currentLinePtA.northing == 0.0) return true

        // 計算轉彎偏移量
        val widthMinusOverlap = mf.tool.width - mf.tool.overlap
        val turnOffset = widthMinusOverlap * rowSkipsWidth +
                (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)

        when (youTurnPhase) {
            0 -> {
                // 尋找最近的 AB 線轉彎點
                if (!FindABTurnPoint(mf.ABLine)) {
                    FailCreate()
                    return false
                }
                inClosestTurnPt = CClose(closestTurnPt)
                ytList.clear()

                var stopIfWayOut = 0
                isOutOfBounds = true
                var head = mf.ABLine.abHeading
                if (!mf.ABLine.isHeadingSameWay) head += PI
                if (head >= glm.twoPI) head -= glm.twoPI

                // 生成第一段 Omega 轉彎弧
                while (isOutOfBounds) {
                    stopIfWayOut++
                    isOutOfBounds = false

                    // 從當前 AB 線位置開始
                    val currentPos = vec3(
                        inClosestTurnPt.closePt.easting,
                        inClosestTurnPt.closePt.northing,
                        head
                    )

                    // 調整起點方向
                    val adjustedHead = if (isTurnLeft) head + glm.PIBy2 else head - glm.PIBy2
                    head = if (adjustedHead >= glm.twoPI) adjustedHead - glm.twoPI else adjustedHead

                    // 使用 Dubins 路徑生成器創建轉彎
                    val dubYouTurnPath = CDubins(mf)
                    dubYouTurnPath.turningRadius = youTurnRadius

                    // 計算臨時目標點（半圓結束點）
                    val tempGoal = vec3(
                        easting = currentPos.easting + (turnOffset * cos(head)),
                        northing = currentPos.northing + (turnOffset * sin(head)),
                        heading = head + (if (isTurnLeft) PI else -PI)
                    )

                    ytList.clear()
                    ytList.addAll(dubYouTurnPath.GenerateDubins(currentPos, tempGoal))
                    if (ytList.isEmpty()) {
                        FailCreate()
                        return false
                    }

                    // 防止無限循環
                    if (stopIfWayOut == 300) {
                        FailCreate()
                        return false
                    }

                    // 檢查是否超出轉彎區域
                    for (i in ytList.indices step 2) {
                        if (mf.bnd.isPointInsideTurnArea(ytList[i]) != 0) {
                            isOutOfBounds = true
                            break
                        }
                    }

                    if (isOutOfBounds) {
                        // 沿 AB 線移動起點
                        inClosestTurnPt.closePt.easting += pointSpacing * sin(mf.ABLine.abHeading)
                        inClosestTurnPt.closePt.northing += pointSpacing * cos(mf.ABLine.abHeading)
                    }
                }

                // 過濾過密的點
                var cnt = ytList.size
                var i = 1
                while (i < cnt - 2) {
                    val Distance = glm.DistanceSquared(ytList[i], ytList[i + 1])
                    if (Distance < pointSpacing) {
                        ytList.removeAt(i + 1)
                        cnt = ytList.size
                        i--
                    }
                    i++
                }

                // 將轉彎移到內部
                val tempList = mutableListOf<vec3>().apply { addAll(ytList) }
                ytList.clear()
                ytList.addAll(MoveTurnInsideTurnLine(tempList, head, false, false))
                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                youTurnPhase = 1
                return true
            }

            1 -> {
                // 計算下一個 AB 線的偏移距離
                val distAway = widthMinusOverlap * (mf.ABLine.howManyPathsAway +
                        (if (isTurnLeft) rowSkipsWidth else -rowSkipsWidth)) +
                        (if (mf.ABLine.isHeadingSameWay) -mf.tool.offset else mf.tool.offset)

                // 生成下一個偏移 AB 線
                val nextABLine = mf.ABLine.BuildNewOffsetABLine(distAway)
                if (nextABLine.isEmpty()) {
                    FailCreate()
                    return false
                }

                // 尋找退出點
                var dis = Double.MAX_VALUE
                val lastPoint = ytList[ytList.size - 1]
                var outIndex = 0
                for (i in nextABLine.indices) {
                    val newDis = glm.Distance(nextABLine[i], lastPoint)
                    if (newDis < dis) {
                        dis = newDis
                        outIndex = i
                    }
                }
                outClosestTurnPt = CClose(vec3(nextABLine[outIndex]))

                // 生成第二段轉彎弧
                val startPos = ytList[ytList.size - 1]
                val goalPos = vec3(nextABLine[outIndex])
                goalPos.heading = mf.ABLine.abHeading
                if (!mf.ABLine.isHeadingSameWay) goalPos.heading += PI
                if (goalPos.heading >= glm.twoPI) goalPos.heading -= glm.twoPI

                val dubYouTurnPath = CDubins(mf)
                dubYouTurnPath.turningRadius = youTurnRadius

                ytList2.clear()
                ytList2.addAll(dubYouTurnPath.GenerateDubins(startPos, goalPos))
                if (ytList2.isEmpty()) {
                    FailCreate()
                    return false
                }

                // 檢查是否超出邊界
                isOutOfBounds = false
                for (i in ytList2.indices step 2) {
                    if (mf.bnd.isPointInsideTurnArea(ytList2[i]) != 0) {
                        isOutOfBounds = true
                        break
                    }
                }

                if (isOutOfBounds) {
                    FailCreate()
                    return false
                }

                val tempList = mutableListOf<vec3>().apply { addAll(ytList2) }
                ytList2.clear()
                ytList2.addAll(MoveTurnInsideTurnLine(tempList, goalPos.heading, false, true))
                if (ytList2.isEmpty()) {
                    FailCreate()
                    return false
                }

                youTurnPhase = 2
                return true
            }

            2 -> {
                // 合併兩段路徑
                val cnt1 = ytList.size
                val cnt2 = ytList2.size
                for (i in 0 until cnt2) {
                    ytList.add(vec3(ytList2[i]))
                }

                // 添加序列線（如果需要）
                if (!AddCurveSequenceLines()) return false

                // 插入中間點以平滑路徑
                var cnt = ytList.size
                var i = 1
                while (i < cnt - 2) {
                    val j = i + 1
                    if (j == cnt - 1) {
                        i++
                        continue
                    }
                    val Distance = glm.DistanceSquared(ytList[i], ytList[j])
                    if (Distance > 1) {
                        val pointB = vec3(
                            (ytList[i].easting + ytList[j].easting) / 2.0,
                            (ytList[i].northing + ytList[j].northing) / 2.0,
                            ytList[i].heading
                        )
                        ytList.add(j, pointB)
                        cnt = ytList.size
                        i--
                    }
                    i++
                }

                // 平滑路徑並更新方向
                cnt = ytList.size
                val arr = ytList.toTypedArray()
                cnt -= 2
                ytList.clear()

                for (i in 2 until cnt) {
                    val pt3 = vec3(arr[i])
                    pt3.heading = atan2(arr[i + 1].easting - arr[i - 1].easting, arr[i + 1].northing - arr[i - 1].northing)
                    if (pt3.heading < 0) pt3.heading += glm.twoPI
                    ytList.add(pt3)
                }

                // 檢查是否離起點太近
                if (glm.Distance(ytList[0], mf.pivotAxlePos) < 3) {
                    FailCreate()
                    return false
                }

                // 檢查是否直行通過
                isGoingStraightThrough = PI - abs(abs(ytList[ytList.size - 2].heading - ytList[1].heading) - PI) < glm.PIBy2
                ytList2.clear()
                isOutOfBounds = false
                youTurnPhase = 10
                turnTooCloseTrigger = false
                isTurnCreationTooClose = false
                return true
            }
        }
        return false
    }


    private fun CreateABWideTurn(): Boolean {
        if (mf.makeUTurnCounter < 4) {
            youTurnPhase = 0
            return true
        }

        var head = mf.ABLine.abHeading
        if (!mf.ABLine.isHeadingSameWay) head += PI
        if (head >= glm.twoPI) head -= glm.twoPI

        when (youTurnPhase) {
            0 -> {
                val onPurePoint = vec3(mf.ABLine.rEastAB, mf.ABLine.rNorthAB, 0.0)
                FindABTurnPoint(onPurePoint)

                inClosestTurnPt = CClose(closestTurnPt)
                startOfTurnPt = CClose(closestTurnPt)

                if (inClosestTurnPt.turnLineIndex == -1) {
                    FailCreate()
                    return false
                }

                ytList.clear()
                var currentPos = vec3(inClosestTurnPt.closePt.easting, inClosestTurnPt.closePt.northing, head)
                ytList.add(currentPos)

                while (abs(head - currentPos.heading) < PI) {
                    currentPos.easting += pointSpacing * sin(currentPos.heading)
                    currentPos.northing += pointSpacing * cos(currentPos.heading)
                    val turnParameter = if (isTurnLeft) -1.0 else 1.0
                    currentPos.heading += (pointSpacing / youTurnRadius) * turnParameter
                    ytList.add(currentPos)
                }

                isOutOfBounds = true
                ytList.clear()
                ytList.addAll(MoveTurnInsideTurnLine(ytList, head, true, false))

                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                mf.distancePivotToTurnLine = glm.Distance(ytList[0], mf.pivotAxlePos)
                youTurnPhase = 1
                return true
            }

            1 -> {
                val widthMinusOverlap = mf.tool.width - mf.tool.overlap
                val track = mf.trk.gArr[mf.trk.idx]
                val distAway = widthMinusOverlap * (mf.ABLine.howManyPathsAway + (if (isTurnLeft xor mf.ABLine.isHeadingSameWay) rowSkipsWidth else -rowSkipsWidth)) +
                        (if (mf.ABLine.isHeadingSameWay) -mf.tool.offset else mf.tool.offset) + track.nudgeDistance + (0.5 * widthMinusOverlap)

                nextCurve.clear()
                nextCurve.addAll(mf.curve.BuildNewOffsetList(distAway, track))

                val isTurnLineSameWay = abs(startOfTurnPt.closePt.heading - ytList[ytList.size - 1].heading).let {
                    it <= glm.PIBy2 || it >= 3 * glm.PIBy2
                }

                if (!FindABOutTurnPoint(mf.ABLine, nextCurve, inClosestTurnPt, isTurnLineSameWay)) {
                    FailCreate()
                    return false
                }
                outClosestTurnPt = CClose(closestTurnPt)

                var pointPos = vec3(outClosestTurnPt.closePt.easting, outClosestTurnPt.closePt.northing, 0.0)
                val headie = if (!isOutSameCurve) head else {
                    var tempHead = head + PI
                    if (tempHead >= glm.twoPI) tempHead -= glm.twoPI
                    tempHead
                }
                pointPos.heading = headie

                ytList2.clear()
                ytList2.add(pointPos)

                while (abs(headie - pointPos.heading) < PI) {
                    pointPos.easting += pointSpacing * sin(pointPos.heading)
                    pointPos.northing += pointSpacing * cos(pointPos.heading)
                    val turnParameter = if (isTurnLeft) 1.0 else -1.0
                    pointPos.heading += (pointSpacing / youTurnRadius) * turnParameter
                    ytList2.add(pointPos)
                }

                isOutOfBounds = true
                ytList2.clear()
                ytList2.addAll(MoveTurnInsideTurnLine(ytList2, headie, true, true))

                if (ytList2.isEmpty()) {
                    FailCreate()
                    return false
                }

                youTurnPhase = 2
                return true
            }

            2 -> {
                val cnt1 = ytList.size
                val cnt2 = ytList2.size

                val isFirstTurnLineSameWay = abs(inClosestTurnPt.turnLineHeading - ytList[ytList.size - 1].heading).let {
                    it <= glm.PIBy2 || it >= 3 * glm.PIBy2
                }

                FindInnerTurnPoints(ytList[cnt1 - 1], ytList[0].heading, inClosestTurnPt, isFirstTurnLineSameWay)
                val startClosestTurnPt = CClose(closestTurnPt)

                FindInnerTurnPoints(ytList2[cnt2 - 1], ytList2[0].heading + PI, outClosestTurnPt, !isFirstTurnLineSameWay)
                val goalClosestTurnPt = CClose(closestTurnPt)

                if (startClosestTurnPt.turnLineNum != goalClosestTurnPt.turnLineNum) {
                    FailCreate()
                    return false
                }

                if (startClosestTurnPt.turnLineIndex == goalClosestTurnPt.turnLineIndex) {
                    for (a in 0 until cnt2) {
                        ytList.add(vec3(ytList2[cnt2 - 1 - a]))
                    }
                } else {
                    val turnCount = mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine.size
                    var loops = abs(startClosestTurnPt.turnLineIndex - goalClosestTurnPt.turnLineIndex)

                    if (loops > (mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine.size / 2)) {
                        loops = if (startClosestTurnPt.turnLineIndex < goalClosestTurnPt.turnLineIndex) {
                            (turnCount - goalClosestTurnPt.turnLineIndex) + startClosestTurnPt.turnLineIndex
                        } else {
                            (turnCount - startClosestTurnPt.turnLineIndex) + goalClosestTurnPt.turnLineIndex
                        }
                    }

                    val tPoint = vec3()
                    if (isFirstTurnLineSameWay) {
                        for (i in 0 until loops) {
                            if (startClosestTurnPt.turnLineIndex + 1 >= turnCount) startClosestTurnPt.turnLineIndex = -1
                            tPoint.copyFrom(mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine[startClosestTurnPt.turnLineIndex + 1])
                            startClosestTurnPt.turnLineIndex++
                            if (startClosestTurnPt.turnLineIndex >= turnCount) startClosestTurnPt.turnLineIndex = 0
                            ytList.add(tPoint)
                        }
                    } else {
                        for (i in 0 until loops) {
                            tPoint.copyFrom(mf.bnd.bndList[startClosestTurnPt.turnLineNum].turnLine[startClosestTurnPt.turnLineIndex])
                            startClosestTurnPt.turnLineIndex--
                            if (startClosestTurnPt.turnLineIndex == -1) startClosestTurnPt.turnLineIndex = turnCount - 1
                            ytList.add(tPoint)
                        }
                    }

                    for (a in 0 until cnt2) {
                        ytList.add(vec3(ytList2[cnt2 - 1 - a]))
                    }
                }

                var cnt = ytList.size
                var i = 1
                while (i < cnt - 2) {
                    val j = i + 1
                    if (j == cnt - 1) {
                        i++
                        continue
                    }
                    val Distance = glm.DistanceSquared(ytList[i], ytList[j])
                    if (Distance > 1) {
                        val pointB = vec3(
                            (ytList[i].easting + ytList[j].easting) / 2.0,
                            (ytList[i].northing + ytList[j].northing) / 2.0,
                            ytList[i].heading
                        )
                        ytList.add(j, pointB)
                        cnt = ytList.size
                        i--
                    }
                    i++
                }


                cnt = ytList.size
                val arr = Array<vec3?>(cnt) { ytList[it] }  // Creates array with same elements
                cnt -= 2
                ytList.clear()

                for (i in 2 until cnt) {
                    val pt3 = vec3(arr[i]!!)
                    pt3.heading = atan2(arr[i + 1]!!.easting - arr[i - 1]!!.easting, arr[i + 1]!!.northing - arr[i - 1]!!.northing)
                    if (pt3.heading < 0) pt3.heading += glm.twoPI
                    ytList.add(pt3)
                }

                if (glm.Distance(ytList[0], mf.pivotAxlePos) < 3) {
                    FailCreate()
                    return false
                }

                isGoingStraightThrough = PI - abs(abs(ytList[ytList.size - 2].heading - ytList[1].heading) - PI) < glm.PIBy2
                isOutOfBounds = false
                youTurnPhase = 10
                turnTooCloseTrigger = false
                isTurnCreationTooClose = false
                ytList2.clear()

                if (!AddABSequenceLines()) return false
                return true
            }
        }
        return false
    }

    private fun KStyleTurnCurve(): Boolean {
        // 如果 U 型轉彎計數器小於 4，直接重置階段並返回成功
        if (mf.makeUTurnCounter < 4) {
            youTurnPhase = 0
            return true
        }

        // 檢查軌跡索引是否有效
        if (mf.trk.idx < 0 || mf.trk.gArr.size <= mf.trk.idx) return true
        val track = mf.trk.gArr[mf.trk.idx]

        val count = if (mf.curve.isHeadingSameWay) -1 else 1

        when (youTurnPhase) {
            0 -> {
                // 尋找最近的曲線轉彎點
                if (!FindCurveTurnPoint(mf.curve, false)) {
                    if (track.mode == TrackMode.WaterPivot || track.mode == TrackMode.BndCurve) {
                        youTurnPhase = 11 // 忽略此情況
                    } else {
                        FailCreate()
                    }
                    return false
                }

                inClosestTurnPt = CClose(closestTurnPt)
                ytList.clear()

                var curveIndex = inClosestTurnPt.curveIndex
                var stopIfWayOut = 0
                isOutOfBounds = true
                var head = 0.0

                // 生成第一段 K 型轉彎路徑
                while (isOutOfBounds) {
                    stopIfWayOut++
                    isOutOfBounds = false

                    ytList.clear()
                    curveIndex += count

                    // 檢查曲線索引是否越界
                    if (curveIndex < 0 || curveIndex >= mf.curve.curList.size) {
                        FailCreate()
                        return false
                    }

                    // 當前位置
                    var currentPos = vec3(mf.curve.curList[curveIndex])
                    head = if (mf.curve.isHeadingSameWay) currentPos.heading else {
                        var tempHead = currentPos.heading + PI
                        if (tempHead >= glm.twoPI) tempHead -= glm.twoPI
                        tempHead
                    }
                    currentPos.heading = head

                    // 使用 Dubins 路徑生成器創建 K 型轉彎
                    val dubYouTurnPath = CDubins(mf)
                    dubYouTurnPath.turningRadius = youTurnRadius * uTurnSmoothing / 10.0

                    // 計算目標點（短距離轉彎）
                    val turnOffset = (mf.tool.width - mf.tool.overlap) * rowSkipsWidth +
                            (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)
                    val goal = vec3(
                        easting = currentPos.easting + (turnOffset * cos(head)),
                        northing = currentPos.northing + (turnOffset * sin(head)),
                        heading = head + (if (isTurnLeft) -PI else PI)
                    )

                    ytList.addAll(dubYouTurnPath.GenerateDubins(currentPos, goal))
                    if (ytList.isEmpty()) {
                        FailCreate()
                        return false
                    }

                    // 防止無限循環或索引越界
                    if (stopIfWayOut == 300 || curveIndex < 1 || curveIndex > (mf.curve.curList.size - 2)) {
                        FailCreate()
                        return false
                    }

                    // 檢查是否超出轉彎區域
                    for (i in ytList.indices step 2) {
                        if (mf.bnd.isPointInsideTurnArea(ytList[i]) != 0) {
                            isOutOfBounds = true
                            break
                        }
                    }
                }

                inClosestTurnPt.curveIndex = curveIndex

                // 過濾過密的點
                var cnt = ytList.size
                var i = 1
                while (i < cnt - 2) {
                    val Distance = glm.DistanceSquared(ytList[i], ytList[i + 1])
                    if (Distance < pointSpacing) {
                        ytList.removeAt(i + 1)
                        cnt = ytList.size
                        i--
                    }
                    i++
                }

                // 將轉彎移到內部
                val tempList = mutableListOf<vec3>().apply { addAll(ytList) }
                ytList.clear()
                ytList.addAll(MoveTurnInsideTurnLine(tempList, head, false, false))
                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                youTurnPhase = 1
                return true
            }

            1 -> {
                // 計算下一個曲線的偏移距離
                val widthMinusOverlap = mf.tool.width - mf.tool.overlap
                val distAway = widthMinusOverlap * (mf.curve.howManyPathsAway +
                        (if (isTurnLeft xor mf.curve.isHeadingSameWay) rowSkipsWidth else -rowSkipsWidth)) +
                        (if (mf.curve.isHeadingSameWay) -mf.tool.offset else mf.tool.offset) +
                        track.nudgeDistance + (0.5 * widthMinusOverlap)

                // 生成下一個偏移曲線
                nextCurve.clear()
                nextCurve.addAll(mf.curve.BuildNewOffsetList(distAway, track))

                // 尋找退出點
                var dis = Double.MAX_VALUE
                var outIndex = 0
                if (nextCurve.size > 1) {
                    for (i in nextCurve.indices) {
                        val newDis = glm.Distance(nextCurve[i], ytList[ytList.size - 1])
                        if (newDis < dis) {
                            dis = newDis
                            outIndex = i
                        }
                    }
                    outClosestTurnPt = CClose(vec3(nextCurve[outIndex]))
                } else {
                    FailCreate()
                    return false
                }

                // 生成第二段轉彎弧
                val startPos = ytList[ytList.size - 1]
                val goalPos = vec3(nextCurve[outIndex])
                goalPos.heading = if (mf.curve.isHeadingSameWay) startPos.heading else {
                    var tempHead = startPos.heading + PI
                    if (tempHead >= glm.twoPI) tempHead -= glm.twoPI
                    tempHead
                }

                val dubYouTurnPath = CDubins(mf)
                dubYouTurnPath.turningRadius = youTurnRadius * uTurnSmoothing / 10.0

                ytList2.clear()
                ytList2.addAll(dubYouTurnPath.GenerateDubins(startPos, goalPos))
                if (ytList2.isEmpty()) {
                    FailCreate()
                    return false
                }

                // 檢查是否超出邊界
                isOutOfBounds = false
                for (i in ytList2.indices step 2) {
                    if (mf.bnd.isPointInsideTurnArea(ytList2[i]) != 0) {
                        isOutOfBounds = true
                        break
                    }
                }

                if (isOutOfBounds) {
                    FailCreate()
                    return false
                }

                val tempList = mutableListOf<vec3>().apply { addAll(ytList2) }
                ytList2.clear()
                ytList2.addAll(MoveTurnInsideTurnLine(tempList, goalPos.heading, false, true))
                if (ytList2.isEmpty()) {
                    FailCreate()
                    return false
                }

                youTurnPhase = 2
                return true
            }

            2 -> {
                // 合併兩段路徑
                val cnt1 = ytList.size
                val cnt2 = ytList2.size
                for (i in 0 until cnt2) {
                    ytList.add(vec3(ytList2[i]))
                }

                // 添加序列線（如果需要）
                if (!AddCurveSequenceLines()) return false

                // 插入中間點以平滑路徑
                var cnt = ytList.size
                var i = 1
                while (i < cnt - 2) {
                    val j = i + 1
                    if (j == cnt - 1) {
                        i++
                        continue
                    }
                    val Distance = glm.DistanceSquared(ytList[i], ytList[j])
                    if (Distance > 1) {
                        val pointB = vec3(
                            (ytList[i].easting + ytList[j].easting) / 2.0,
                            (ytList[i].northing + ytList[j].northing) / 2.0,
                            ytList[i].heading
                        )
                        ytList.add(j, pointB)
                        cnt = ytList.size
                        i--
                    }
                    i++
                }

                // 平滑路徑並更新方向
                cnt = ytList.size
                val arr = ytList.toTypedArray()
                cnt -= 2
                ytList.clear()

                for (i in 2 until cnt) {
                    val pt3 = vec3(arr[i])
                    pt3.heading = atan2(arr[i + 1].easting - arr[i - 1].easting, arr[i + 1].northing - arr[i - 1].northing)
                    if (pt3.heading < 0) pt3.heading += glm.twoPI
                    ytList.add(pt3)
                }

                // 檢查是否離起點太近
                if (glm.Distance(ytList[0], mf.pivotAxlePos) < 3) {
                    FailCreate()
                    return false
                }

                // 檢查是否直行通過
                isGoingStraightThrough = PI - abs(abs(ytList[ytList.size - 2].heading - ytList[1].heading) - PI) < glm.PIBy2
                ytList2.clear()
                isOutOfBounds = false
                youTurnPhase = 10
                turnTooCloseTrigger = false
                isTurnCreationTooClose = false
                return true
            }
        }
        return false
    }

    // 前一部分的字段和方法保持不變，這裡從 KStyleTurnCurve 開始

    private fun KStyleTurnAB(): Boolean {
        if (mf.makeUTurnCounter < 4) {
            youTurnPhase = 0
            return true
        }

        var head = mf.ABLine.abHeading
        if (!mf.ABLine.isHeadingSameWay) head += PI
        if (head >= glm.twoPI) head -= glm.twoPI

        when (youTurnPhase) {
            0 -> {
                FindABTurnPoint(vec3(mf.ABLine.rEastAB, mf.ABLine.rNorthAB, head))

                if (closestTurnPt.turnLineIndex != -1) {
                    mf.distancePivotToTurnLine = glm.Distance(mf.pivotAxlePos, closestTurnPt.closePt)
                } else {
                    FailCreate()
                    return false
                }
                inClosestTurnPt = CClose(closestTurnPt)

                val turnOffset = (mf.tool.width - mf.tool.overlap) * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)
                val turnRadius = youTurnRadius * uTurnSmoothing / 10.0

                val start = vec3(inClosestTurnPt.closePt)
                start.heading = head

                val goal = vec3(start)
                val invertedHead = head - PI
                val adjustedInvertHead = when {
                    invertedHead < 0 -> invertedHead + glm.twoPI
                    invertedHead > glm.twoPI -> invertedHead - glm.twoPI
                    else -> invertedHead
                }

                if (isTurnLeft) {
                    goal.easting += cos(-adjustedInvertHead) * turnOffset
                    goal.northing += sin(-adjustedInvertHead) * turnOffset
                } else {
                    goal.easting -= cos(-adjustedInvertHead) * turnOffset
                    goal.northing -= sin(-adjustedInvertHead) * turnOffset
                }
                goal.heading = adjustedInvertHead

                val dubYouTurnPath = CDubins(mf)
                dubYouTurnPath.turningRadius = turnRadius
                ytList.clear()
                ytList.addAll(dubYouTurnPath.GenerateDubins(start, goal))

                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                var cnt = ytList.size
                var i = 1
                while (i < cnt - 2) {
                    val Distance = glm.DistanceSquared(ytList[i], ytList[i + 1])
                    if (Distance < pointSpacing) {
                        ytList.removeAt(i + 1)
                        cnt = ytList.size
                        i--
                    }
                    i++
                }

                youTurnPhase = 1
                return true
            }

            1 -> {
                ytList.clear()
                ytList.addAll(MoveABTurnInsideTurnLine(ytList, head))

                if (ytList.isEmpty()) {
                    FailCreate()
                    return false
                }

                isOutOfBounds = false
                youTurnPhase = 10
                turnTooCloseTrigger = false
                isTurnCreationTooClose = false

                if (!AddABSequenceLines()) return false
                return true
            }
        }
        return true
    }


    // 前一部分的字段和方法保持不變，這裡從 FindCurveTurnPoint 開始

    private fun FindCurveTurnPoint(curve: CABCurve, isFirstGuess: Boolean): Boolean {
        turnClosestList.clear()
        closestTurnPt = CClose()
        var closestDistance = Double.MAX_VALUE

        val step = if (isFirstGuess) 10 else 1
        val stepD2 = step * 2

        for (t in mf.bnd.bndList.indices) {
            val turnLine = mf.bnd.bndList[t].turnLine
            if (turnLine.isEmpty()) continue

            var jStart = 0
            var jEnd = turnLine.size

            if (semiCircleIndex != -1) {
                jStart = semiCircleIndex - stepD2
                jEnd = semiCircleIndex + stepD2 + 1
                if (jStart < 0) jStart = 0
                if (jEnd > turnLine.size) jEnd = turnLine.size
            }

            for (j in jStart until jEnd step step) {
                val Distance = glm.Distance(turnLine[j], mf.pivotAxlePos)
                if (Distance < closestDistance) {
                    closestDistance = Distance
                    closestTurnPt.closePt = vec3(turnLine[j])
                    closestTurnPt.turnLineNum = t
                    closestTurnPt.turnLineIndex = j
                    closestTurnPt.curveIndex = curve.FindClosestPointOnCurve(turnLine[j])
                    closestTurnPt.turnLineHeading = if (j < turnLine.size - 1) {
                        atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                    } else {
                        atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                    }
                    if (closestTurnPt.turnLineHeading < 0) closestTurnPt.turnLineHeading += glm.twoPI
                }

                if (!isFirstGuess && Distance < (youTurnRadius * 2.0)) {
                    val clo = CClose()
                    clo.closePt = vec3(turnLine[j])
                    clo.turnLineNum = t
                    clo.turnLineIndex = j
                    clo.curveIndex = curve.FindClosestPointOnCurve(turnLine[j])
                    clo.turnLineHeading = if (j < turnLine.size - 1) {
                        atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                    } else {
                        atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                    }
                    if (clo.turnLineHeading < 0) clo.turnLineHeading += glm.twoPI
                    turnClosestList.add(clo)
                }
            }
        }

        if (closestTurnPt.turnLineIndex == -1) {
            isTurnCreationNotCrossingError = true
            return false
        }

        if (closestDistance < youTurnRadius) {
            isTurnCreationTooClose = true
            turnTooCloseTrigger = true
            return false
        }

        return true
    }

    private fun FindABTurnPoint(onPurePoint: vec3) {
        turnClosestList.clear()
        closestTurnPt = CClose()
        var closestDistance = Double.MAX_VALUE

        for (t in mf.bnd.bndList.indices) {
            val turnLine = mf.bnd.bndList[t].turnLine
            if (turnLine.isEmpty()) continue

            for (j in turnLine.indices) {
                val Distance = glm.Distance(turnLine[j], onPurePoint)
                if (Distance < closestDistance) {
                    closestDistance = Distance
                    closestTurnPt.closePt = vec3(turnLine[j])
                    closestTurnPt.turnLineNum = t
                    closestTurnPt.turnLineIndex = j
                    closestTurnPt.turnLineHeading = if (j < turnLine.size - 1) {
                        atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                    } else {
                        atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                    }
                    if (closestTurnPt.turnLineHeading < 0) closestTurnPt.turnLineHeading += glm.twoPI
                }

                if (Distance < (youTurnRadius * 2.0)) {
                    val clo = CClose()
                    clo.closePt = vec3(turnLine[j])
                    clo.turnLineNum = t
                    clo.turnLineIndex = j
                    clo.turnLineHeading = if (j < turnLine.size - 1) {
                        atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                    } else {
                        atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                    }
                    if (clo.turnLineHeading < 0) clo.turnLineHeading += glm.twoPI
                    turnClosestList.add(clo)
                }
            }
        }

        if (closestDistance < youTurnRadius) {
            isTurnCreationTooClose = true
            turnTooCloseTrigger = true
        }
    }

    private fun FindCurveOutTurnPoint(curve: CABCurve, nextCurve: MutableList<vec3>, startPt: CClose, isTurnLineSameWay: Boolean): Boolean {
        closestTurnPt = CClose()
        var closestDistance = Double.MAX_VALUE

        val stepD2 = 20
        val count = if (curve.isHeadingSameWay) -1 else 1

        for (t in mf.bnd.bndList.indices) {
            val turnLine = mf.bnd.bndList[t].turnLine
            if (turnLine.isEmpty()) continue

            var jStart = startPt.turnLineIndex - stepD2
            var jEnd = startPt.turnLineIndex + stepD2 + 1
            if (jStart < 0) jStart = 0
            if (jEnd > turnLine.size) jEnd = turnLine.size

            for (j in jStart until jEnd) {
                if (t != startPt.turnLineNum || abs(j - startPt.turnLineIndex) > 2) {
                    val Distance = glm.Distance(turnLine[j], nextCurve[startPt.curveIndex])
                    if (Distance < closestDistance) {
                        closestDistance = Distance
                        closestTurnPt.closePt = vec3(turnLine[j])
                        closestTurnPt.turnLineNum = t
                        closestTurnPt.turnLineIndex = j
                        closestTurnPt.curveIndex = startPt.curveIndex

                        val pt = vec3(nextCurve[startPt.curveIndex])
                        val dx = turnLine[j].easting - pt.easting
                        val dz = turnLine[j].northing - pt.northing
                        val turnLineHead = atan2(dx, dz)
                        val curveHead = pt.heading

                        val delta = abs(turnLineHead - curveHead)
                        isOutSameCurve = delta <= glm.PIBy2 || delta >= (glm.twoPI - glm.PIBy2)

                        closestTurnPt.turnLineHeading = if (j < turnLine.size - 1) {
                            atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                        } else {
                            atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                        }
                        if (closestTurnPt.turnLineHeading < 0) closestTurnPt.turnLineHeading += glm.twoPI
                    }
                }
            }
        }

        if (closestTurnPt.turnLineIndex == -1) {
            isTurnCreationNotCrossingError = true
            return false
        }

        return true
    }

    private fun FindABOutTurnPoint(abLine: CABLine, nextCurve: MutableList<vec3>, startPt: CClose, isTurnLineSameWay: Boolean): Boolean {
        closestTurnPt = CClose()
        var closestDistance = Double.MAX_VALUE

        for (t in mf.bnd.bndList.indices) {
            val turnLine = mf.bnd.bndList[t].turnLine
            if (turnLine.isEmpty()) continue

            for (j in turnLine.indices) {
                val Distance = glm.Distance(turnLine[j], nextCurve[startPt.curveIndex])
                if (Distance < closestDistance) {
                    closestDistance = Distance
                    closestTurnPt.closePt = vec3(turnLine[j])
                    closestTurnPt.turnLineNum = t
                    closestTurnPt.turnLineIndex = j

                    val pt = vec3(nextCurve[startPt.curveIndex])
                    val dx = turnLine[j].easting - pt.easting
                    val dz = turnLine[j].northing - pt.northing
                    val turnLineHead = atan2(dx, dz)
                    val curveHead = pt.heading

                    val delta = abs(turnLineHead - curveHead)
                    isOutSameCurve = delta <= glm.PIBy2 || delta >= (glm.twoPI - glm.PIBy2)

                    closestTurnPt.turnLineHeading = if (j < turnLine.size - 1) {
                        atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                    } else {
                        atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                    }
                    if (closestTurnPt.turnLineHeading < 0) closestTurnPt.turnLineHeading += glm.twoPI
                }
            }
        }

        if (closestTurnPt.turnLineIndex == -1) {
            isTurnCreationNotCrossingError = true
            return false
        }

        return true
    }

    private fun FindInnerTurnPoints(turnPt: vec3, head: Double, startPt: CClose, isTurnLineSameWay: Boolean) {
        closestTurnPt = CClose()
        var closestDistance = Double.MAX_VALUE

        val stepD2 = 20

        for (t in mf.bnd.bndList.indices) {
            val turnLine = mf.bnd.bndList[t].turnLine
            if (turnLine.isEmpty()) continue

            var jStart = startPt.turnLineIndex - stepD2
            var jEnd = startPt.turnLineIndex + stepD2 + 1
            if (jStart < 0) jStart = 0
            if (jEnd > turnLine.size) jEnd = turnLine.size

            for (j in jStart until jEnd) {
                val Distance = glm.Distance(turnLine[j], turnPt)
                if (Distance < closestDistance) {
                    closestDistance = Distance
                    closestTurnPt.closePt = vec3(turnLine[j])
                    closestTurnPt.turnLineNum = t
                    closestTurnPt.turnLineIndex = j
                    closestTurnPt.turnLineHeading = if (j < turnLine.size - 1) {
                        atan2(turnLine[j + 1].easting - turnLine[j].easting, turnLine[j + 1].northing - turnLine[j].northing)
                    } else {
                        atan2(turnLine[j].easting - turnLine[j - 1].easting, turnLine[j].northing - turnLine[j - 1].northing)
                    }
                    if (closestTurnPt.turnLineHeading < 0) closestTurnPt.turnLineHeading += glm.twoPI
                }
            }
        }
    }

    // 前一部分的字段和方法保持不變，這裡從 MoveTurnInsideTurnLine 開始
    // 示例方法調整：MoveTurnInsideTurnLine
    private fun MoveTurnInsideTurnLine(
        ytListTemp: MutableList<vec3>,
        head: Double,
        isWideTurn: Boolean,
        isSecondHalf: Boolean
    ): MutableList<vec3> {
        val res = mutableListOf<vec3>()
        res.addAll(ytListTemp)
        val cnt = res.size

        if (cnt < 2) return res

        var isAllInside = true
        for (i in 0 until cnt step 2) {
            if (mf.bnd.isPointInsideTurnArea(res[i]) != 0) {
                isAllInside = false
                break
            }
        }

        if (isAllInside) return res

        val turnParameter = if (isTurnLeft) -1.0 else 1.0
        val shift = if (isSecondHalf) -turnParameter else turnParameter

        val dx = cos(-head + glm.PIBy2) * youTurnRadius * shift
        val dz = sin(-head + glm.PIBy2) * youTurnRadius * shift

        if (isWideTurn) {
            for (j in 0 until cnt) {
                res[j] = vec3(res[j].easting + dx, res[j].northing + dz, res[j].heading)
            }

            isAllInside = true
            for (i in 0 until cnt step 2) {
                if (mf.bnd.isPointInsideTurnArea(res[i]) != 0) {
                    isAllInside = false
                    break
                }
            }

            if (!isAllInside) {
                res.clear()
            }
        } else {
            val ptOut = mutableListOf<Int>()
            for (j in 0 until cnt) {
                val whichBound = mf.bnd.isPointInsideTurnArea(res[j])
                if (whichBound != 0) {
                    ptOut.add(j)
                }
            }

            if (ptOut.isNotEmpty()) {
                for (k in ptOut.indices) {
                    val j = ptOut[k]
                    res[j] = vec3(res[j].easting + dx, res[j].northing + dz, res[j].heading)
                }

                isAllInside = true
                for (i in 0 until cnt step 2) {
                    if (mf.bnd.isPointInsideTurnArea(res[i]) != 0) {
                        isAllInside = false
                        break
                    }
                }

                if (!isAllInside) {
                    res.clear()
                }
            }
        }

        return res
    }

    private fun MoveABTurnInsideTurnLine(ytListTemp: MutableList<vec3>, head: Double): MutableList<vec3> {
        val res = mutableListOf<vec3>()
        res.addAll(ytListTemp)
        val cnt = res.size

        if (cnt < 2) return res

        var isAllInside = true
        for (i in 0 until cnt step 2) {
            if (mf.bnd.isPointInsideTurnArea(res[i]) != 0) {
                isAllInside = false
                break
            }
        }

        if (isAllInside) return res

        val turnParameter = if (isTurnLeft) -1.0 else 1.0
        val dx = cos(-head + glm.PIBy2) * youTurnRadius * turnParameter
        val dz = sin(-head + glm.PIBy2) * youTurnRadius * turnParameter

        for (j in 0 until cnt) {
            res[j].easting += dx
            res[j].northing += dz
        }

        isAllInside = true
        for (i in 0 until cnt step 2) {
            if (mf.bnd.isPointInsideTurnArea(res[i]) != 0) {
                isAllInside = false
                break
            }
        }

        if (!isAllInside) {
            res.clear()
        }

        return res
    }

    private fun AddCurveSequenceLines(): Boolean {
        val widthMinusOverlap = mf.tool.width - mf.tool.overlap
        val turnOffset = widthMinusOverlap * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)

        val isTurnRight = !isTurnLeft
        val shift = if (isTurnRight) 1 else -1
        val turnSide = cos(-inClosestTurnPt.turnLineHeading + glm.PIBy2) * turnOffset * shift
        val turnSide2 = sin(-inClosestTurnPt.turnLineHeading + glm.PIBy2) * turnOffset * shift

        iE = inClosestTurnPt.closePt.easting + turnSide
        iN = inClosestTurnPt.closePt.northing + turnSide2

        val head = inClosestTurnPt.turnLineHeading
        val dx = outClosestTurnPt.closePt.easting - inClosestTurnPt.closePt.easting
        val dz = outClosestTurnPt.closePt.northing - inClosestTurnPt.closePt.northing
        val turnHead = atan2(dx, dz)

        val isTurnLineSameWay = abs(turnHead - head).let { it <= glm.PIBy2 || it >= (glm.twoPI - glm.PIBy2) }

        val pt = vec3()
        if (mf.curve.isHeadingSameWay) {
            if (!isTurnLineSameWay) {
                val turnCount = mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine.size
                var turnIndex = inClosestTurnPt.turnLineIndex
                var loops = abs(inClosestTurnPt.turnLineIndex - outClosestTurnPt.turnLineIndex)

                if (loops > turnCount / 2) {
                    loops = if (inClosestTurnPt.turnLineIndex < outClosestTurnPt.turnLineIndex) {
                        (turnCount - outClosestTurnPt.turnLineIndex) + inClosestTurnPt.turnLineIndex
                    } else {
                        (turnCount - inClosestTurnPt.turnLineIndex) + outClosestTurnPt.turnLineIndex
                    }
                }

                for (i in 0 until loops) {
                    if (turnIndex >= turnCount) turnIndex = 0
                    pt.copyFrom(mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine[turnIndex])
                    turnIndex++
                    ytList.add(pt)
                }
            }
        } else {
            if (isTurnLineSameWay) {
                val turnCount = mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine.size
                var turnIndex = inClosestTurnPt.turnLineIndex
                var loops = abs(inClosestTurnPt.turnLineIndex - outClosestTurnPt.turnLineIndex)

                if (loops > turnCount / 2) {
                    loops = if (inClosestTurnPt.turnLineIndex < outClosestTurnPt.turnLineIndex) {
                        (turnCount - outClosestTurnPt.turnLineIndex) + inClosestTurnPt.turnLineIndex
                    } else {
                        (turnCount - inClosestTurnPt.turnLineIndex) + outClosestTurnPt.turnLineIndex
                    }
                }

                for (i in 0 until loops) {
                    if (turnIndex < 0) turnIndex = turnCount - 1
                    pt.copyFrom(mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine[turnIndex])
                    turnIndex--
                    ytList.add(pt)
                }
            }
        }

        val turnDist = glm.Distance(inClosestTurnPt.closePt, outClosestTurnPt.closePt)
        if (turnDist < widthMinusOverlap * 0.75) {
            isTurnCreationTooClose = true
            turnTooCloseTrigger = true
            return false
        }

        return true
    }

    private fun AddABSequenceLines(): Boolean {
        val widthMinusOverlap = mf.tool.width - mf.tool.overlap
        val turnOffset = widthMinusOverlap * rowSkipsWidth + (if (isTurnLeft) -mf.tool.offset * 2.0 else mf.tool.offset * 2.0)

        val isTurnRight = !isTurnLeft
        val shift = if (isTurnRight) 1 else -1
        val turnSide = cos(-inClosestTurnPt.turnLineHeading + glm.PIBy2) * turnOffset * shift
        val turnSide2 = sin(-inClosestTurnPt.turnLineHeading + glm.PIBy2) * turnOffset * shift

        iE = inClosestTurnPt.closePt.easting + turnSide
        iN = inClosestTurnPt.closePt.northing + turnSide2

        val head = inClosestTurnPt.turnLineHeading
        val dx = mf.ABLine.rEastAB - inClosestTurnPt.closePt.easting
        val dz = mf.ABLine.rNorthAB - inClosestTurnPt.closePt.northing
        val turnHead = atan2(dx, dz)

        val isTurnLineSameWay = abs(turnHead - head).let { it <= glm.PIBy2 || it >= (glm.twoPI - glm.PIBy2) }

        val pt = vec3()
        if (mf.ABLine.isHeadingSameWay) {
            if (!isTurnLineSameWay) {
                val turnCount = mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine.size
                var turnIndex = inClosestTurnPt.turnLineIndex
                val loops = abs(inClosestTurnPt.turnLineIndex - outClosestTurnPt.turnLineIndex)

                for (i in 0 until loops) {
                    if (turnIndex >= turnCount) turnIndex = 0
                    pt.copyFrom(mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine[turnIndex])
                    turnIndex++
                    ytList.add(pt)
                }
            }
        } else {
            if (isTurnLineSameWay) {
                val turnCount = mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine.size
                var turnIndex = inClosestTurnPt.turnLineIndex
                val loops = abs(inClosestTurnPt.turnLineIndex - outClosestTurnPt.turnLineIndex)

                for (i in 0 until loops) {
                    if (turnIndex < 0) turnIndex = turnCount - 1
                    pt.copyFrom(mf.bnd.bndList[inClosestTurnPt.turnLineNum].turnLine[turnIndex])
                    turnIndex--
                    ytList.add(pt)
                }
            }
        }

        val turnDist = glm.Distance(inClosestTurnPt.closePt, vec3(mf.ABLine.rEastAB, mf.ABLine.rNorthAB, 0.0))
        if (turnDist < widthMinusOverlap * 0.75) {
            isTurnCreationTooClose = true
            turnTooCloseTrigger = true
            return false
        }

        return true
    }

    fun DrawYouTurn(googleMap: GoogleMap) {
        if (ytList.isEmpty()) return

        val polylineOptions = PolylineOptions()
            .color(0xFFFFA500.toInt()) // 橙色
            .width(4f)
            .geodesic(false)

        val cnt = ytList.size
        val utmE = mf.pn.longitude
        val utmN = mf.pn.latitude
        val zone = mf.pn.zone  // 直接使用 CNMEA 中的 zone
        val isNorthernHemisphere = mf.pn.latitude >= 0

        for (i in 0 until cnt) {
            val latLon = glm.UTM2LatLon(utmE + ytList[i].easting, utmN + ytList[i].northing, zone, isNorthernHemisphere)
            polylineOptions.add(LatLng(latLon.latitude, latLon.longitude))
        }

        googleMap.addPolyline(polylineOptions)
    }


    private fun calculateUTMZone(longitude: Double): Int {
        val zone = ((longitude + 180.0) / 6.0).toInt() + 1
        return zone.coerceIn(1, 60)
    }


    // 輔助方法
    private fun FailCreate() {
        ytList.clear()
        isOutOfBounds = false
        youTurnPhase = 0
        turnTooCloseTrigger = false
        isTurnCreationTooClose = false
        isTurnCreationNotCrossingError = false
    }

    fun Set_Alternate_skips() {
        if (alternateSkips) {
            rowSkipsWidth2 = if (rowSkipsWidth == 1) 3 else rowSkipsWidth + 2
            if (rowSkipsWidth2 > turnSkips) rowSkipsWidth2 = turnSkips
            previousBigSkip = rowSkipsWidth2 < rowSkipsWidth
        } else {
            rowSkipsWidth2 = rowSkipsWidth
        }
    }

    fun ResetYouTurn() {
        youTurnPhase = 0
        ytList.clear()
        nextCurve.clear()
    }

    fun SmoothYouTurn(numSmooth: Int = 3) {
        if (ytList.size < 5) return

        val oldList = mutableListOf<vec3>()
        oldList.addAll(ytList)
        ytList.clear()

        val cnt = oldList.size
        var arr = Array<vec3?>(cnt) { oldList[it] }  // Creates array with same elements


        for (smooth in 0 until numSmooth) {
            ytList.add(vec3(arr[0]!!))
            for (i in 1 until cnt - 1) {
                val pt = vec3(
                    (arr[i - 1]!!.easting + arr[i]!!.easting + arr[i + 1]!!.easting) / 3.0,
                    (arr[i - 1]!!.northing + arr[i]!!.northing + arr[i + 1]!!.northing) / 3.0,
                    arr[i]!!.heading
                )
                ytList.add(pt)
            }
            ytList.add(vec3(arr[cnt - 1]!!))

            if (smooth < numSmooth - 1) {
                oldList.clear()
                oldList.addAll(ytList)
                ytList.clear()
                arr = oldList.toTypedArray()
            }
        }

        for (i in 1 until cnt - 1) {
            ytList[i].heading = atan2(arr[i + 1]!!.easting - arr[i - 1]!!.easting, arr[i + 1]!!.northing - arr[i - 1]!!.northing)
            if (ytList[i].heading < 0) ytList[i].heading += glm.twoPI
        }
    }


}